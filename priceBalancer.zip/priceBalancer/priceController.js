
var express = require('express');
const dotenv = require('dotenv').config();
const http = require('https');
const app = express();
const Web3 = require('web3');

var CronJob = require('cron').CronJob;

var BigNumber = require('big-number');
const util = require('util');




//DUSD (DUMMY USDT) :  0x058251A3177e5B0ed06191C89e5b8B0d9d50EfA9
// DETH (DUMMY ETH) : 0x01Da4FE47eD23BCC8BC22144a48234A4231B9983



//---------------------------------------------------------------------------------------------



//------------------------------------NETWORK CONFIGURATION-----------------------------------


 //--------------------------------------------------//
 //                  CONFIGURATION                   //
 //--------------------------------------------------//
 
 var toProvider = process.env.CUSTOM_NETWORK_WEB3_PROVIDER;

 var customRouterContract = "0x9bFe428377350851A89dE8B27D527087de7EFE59";


 var customV2PairContract = "0x69787145E7F037FabA2082BFb6E6eeC8B48814Ef";

 var USDT ='0x0Ad64a789fF61c17CDaFb94673E876915979Fb2b';
 var NETZ = '0xD7b21500dFf3D5578B21EBf7F25Be806087559a7';


 //-------------------all pool pair token-------------------

 var WETH= 	"0xD7b21500dFf3D5578B21EBf7F25Be806087559a7";
 var BNB = 	"0x8573ab917b962A65f3817708C449f511569B156A";
 var ETH = 	"0x7b4f9D9E0fB7E44C77903eF3e44165A74B6204ff";
 var MATIC= "0x031b7bDd404C977f871A58F67C6cc1f522Fa14A0";


//--------------------------------web3 Object inititlization-------------------------------


 var toWeb3 = new Web3(new Web3.providers.HttpProvider(toProvider));
 var PAIR_CONTRACT_ADDR_ABI = JSON.parse(process.env.PAIR_ABI);

 var TO_PAIR_CONTRACT_ADDR_ABI = JSON.parse(process.env.PAIR_ABI);
 var ROUTER_CONTRACT_ADDR_ABI = JSON.parse(process.env.ROUTER_ABI);



const toPairInstance = new toWeb3.eth.Contract(PAIR_CONTRACT_ADDR_ABI, customV2PairContract);

const routerInstance = new toWeb3.eth.Contract(ROUTER_CONTRACT_ADDR_ABI,customRouterContract);

 var publicAddress = toWeb3.eth.accounts.privateKeyToAccount(process.env.ADMIN_PRIVATEKEY);
  
  
 toWeb3.eth.accounts.wallet.add(process.env.ADMIN_PRIVATEKEY);
 const account = toWeb3.eth.accounts.wallet[0].address;




 const getNetzPriceInUsd  = async ()=> {


	try{


	var tokenReserve = await toPairInstance.methods.getReserves().call();

	console.log((tokenReserve));

	// token1 (NETz) = token0(usdt)/token1(netz);

	const token0 = (tokenReserve[0]);
	const token1 = (tokenReserve[1]);

	const token1Price = token0/token1; // Netz Price in USD

		console.log("Netz PRICE :"+token1Price);

		return (token1Price);

	}
	catch(e){


		console.log(e);
	}

}



async function getEstimateReserve(){


	var currentPrice = await getNetzPriceInUsd();

		var targetPrice = await GetCurrencyUsdPrice();

		console.log('Price From Pool '+await GetCurrencyUsdPrice());


		// targetPrice = 1825; // just for testing ....


	console.log("======================Target========================");

		console.log("TARGE PRICE :"+targetPrice);
		console.log("CURRENT PRICE: "+currentPrice);

	console.log("====================================================");


	if (targetPrice>currentPrice){


			console.log("===========================BUY CALL==============================");



				var input = 0.001; // starter


				while(targetPrice>currentPrice){


					// increase tokenIn util achieve target reserves


					var rate = 0.2;


					input+=rate;

					// console.log("tokenInc-----===="+input);


						var amount= toWeb3.utils.toWei(String(input));

						  amount = String(amount);


					var tokenPass = await routerInstance.methods.getAmountsOut(amount,[USDT,NETZ]).call();

					console.log(tokenPass);


					// will use this tokenIn Out for Swap 

					var tokenIn = tokenPass[0];

					var tokenOut = tokenPass[1];


					// get Reserve and calculate Current price on it 

						var tokenReserve = await toPairInstance.methods.getReserves().call();

						// console.log((tokenReserve));

						var token1 = BigNumber(tokenReserve[1]).minus(tokenOut); // minus token1(NETZ) 
						var token0 = BigNumber(tokenReserve[0]).plus(tokenIn); // add token0(USDT)

						console.log('===========NEW RESERVE===============');


						console.log("token1:"+token1);

						console.log("token0:"+token0);

						var newReservePrice = token0/token1; // NETZ Price in USD

						console.log("new Reserve NETZ PRICE :"+(newReservePrice));

					 // Math.round(token1Price);

						currentPrice=(newReservePrice);



			}

			console.log('');
			console.log('===========TargetHit===============');


				console.log("newPrice :"+currentPrice);


				await BuySwap(USDT,NETZ,tokenIn);


			console.log('===============================');


	}else if (currentPrice>targetPrice){

		console.log("=================================SELL CALL===========================");


				var input = 0.05; // starter

	


				while(currentPrice>targetPrice){


					// increase tokenIn util achieve target reserves




					input+=0.4;

					// console.log("tokenInc-----===="+input);


						var amount= toWeb3.utils.toWei(String(input));

						  amount = String(amount);


					var tokenPass = await routerInstance.methods.getAmountsOut(amount,[NETZ,USDT]).call();


					// will use this tokenIn Out for Swap 

					var netzIn = tokenPass[0];

					var usdtOut = tokenPass[1];


					// get Reserve and calculate Current price on it 

						var tokenReserve = await toPairInstance.methods.getReserves().call();

						// console.log((tokenReserve));

						var token0 = BigNumber(tokenReserve[0]).minus(usdtOut);
						var token1 = BigNumber(tokenReserve[1]).plus(netzIn);

						console.log('===========NEW RESERVE===============');


						console.log("token1:"+token1);

						console.log("token0:"+token0);

						var newReservePrice = token0/token1; // ETH/BNB/MATIC Price in USD

						console.log("new Reserve NETZ PRICE :"+(newReservePrice));

					 // Math.round(token1Price);

						currentPrice=(newReservePrice);

			}


			console.log('');
			console.log('===========TargetHit===============');


				console.log("newPrice :"+currentPrice);


				console.log("tokenIn NETZ :"+(netzIn));
				console.log("tokenOut USDT :"+usdtOut);

				console.log("tokenIn :"+toWeb3.utils.fromWei(netzIn),'ether');
				console.log("tokenOut :"+toWeb3.utils.fromWei(usdtOut),'ether');


			console.log('===============================');


				await SellSwap(NETZ,USDT,netzIn,usdtOut);

	}else{



			console.log("NO NEED FOR SWAP")

	}


 		console.log("finished");

 		return true;

}


async function BuySwap(token1,token0,tokenIn){


	const d = new Date();
	const time = parseInt(d.getTime()/1000)+3000;

	try{

			console.log(tokenIn);

			var deadline = time;
		routerInstance.methods.swapExactTokensForETH(tokenIn,0,[token1,token0],account,deadline).send({from:account,gas:1000000}, function(error, txHash){
  	    
		 var data = {"txHash":txHash};

     var array = {result:"success", data:data};
        	

        	console.log(error);
        	console.log(array);
			
		}).catch(err => console.error(err));


	}catch(e){


		console.log(e);
	}


}




async function SellSwap(token0,token1,tokenIn,tokenOut){


	const d = new Date();
	const time = parseInt(d.getTime()/1000)+3000;

	try{
	

		var deadline = time;
		routerInstance.methods.swapExactETHForTokens(tokenOut,[token0,token1],account,deadline).send({from:account,value:tokenIn,gas:1000000}, function(error, txHash){
  	    
		 var data = {"txHash":txHash};

     var array = {result:"success", data:data};
        	

        	console.log(error);
        	console.log(array);
			
		}).catch(err => console.error(err));


	}catch(e){


		console.log(e);
	}


}





  function getPriceAPI(tokenID){

        return `https://api.coingecko.com/api/v3/simple/price?ids=${tokenID}&vs_currencies=usd`
  }


 async function GetCurrencyUsdPrice(){
    

    let ethPrice;
    let bnbPrice;
    let maticPrice;
    let aiObject;

    // validate cookies


        // cookies doesn't exisit set new one

         aiObject= await fetch(getPriceAPI('ethereum'))
         ethPrice = await aiObject.json()
         ethPrice = (ethPrice['ethereum']['usd'])


        aiObject= await fetch(getPriceAPI('binancecoin'))
         bnbPrice = await aiObject.json()
         bnbPrice = (bnbPrice['binancecoin']['usd'])

         aiObject= await fetch(getPriceAPI('matic-network'))
         maticPrice = await aiObject.json()
         maticPrice = (maticPrice['matic-network']['usd'])



    let currencyUsd = " "

    try {



        let allPairUsdPrice;


        // fetch price fro eth pair

        let usdcPrice = await routerInstance.methods.getAmountsOut("1000000000000000000",[WETH,ETH]).call()
    
        let calPrice  = (usdcPrice[1])/1e18
        // call the api to fetch same amount of tokens in usd value 
        calPrice= calPrice*ethPrice;
        allPairUsdPrice=calPrice; // eth price 

        // alert("eth :"+(allPairUsdPrice).toFixed(4))

        // fetch price from bnb pair

        usdcPrice = await routerInstance.methods.getAmountsOut("1000000000000000000",[WETH,BNB]).call() // need to change pair
        
        calPrice  = (usdcPrice[1])/1e18

        calPrice= calPrice*bnbPrice;

        // alert("bnb :"+(calPrice).toFixed(4))

        allPairUsdPrice+=calPrice; // bnb price 


        // fetch price from matic pair

        usdcPrice = await routerInstance.methods.getAmountsOut("1000000000000000000",[WETH,MATIC]).call() // need to change pair
        
        calPrice  = (usdcPrice[1])/1e18
        calPrice= calPrice*maticPrice;

        // alert("matic :"+(calPrice).toFixed(4))

        allPairUsdPrice+=calPrice; // matic price 

        allPairUsdPrice=allPairUsdPrice/3;

        currencyUsd= (allPairUsdPrice).toFixed(4);


    }catch(error){


    }

    return (currencyUsd)

}





app.listen(process.env.APPPORT,'127.0.0.1', function () {
	console.log('Server listening at port %d', process.env.APPPORT);


	// for (var i=1;i<=100;i++){

	// 		getEstimateReserve(i);

	// }


	//getEstimateReserve();

	
	 		

	  var job = new CronJob('0 * * * * *', async function() {
     console.log("-------------------------------------");
     console.log('Cron running, every 1 min');
     console.log("-------------------------------------");

    
  

		 await getEstimateReserve();




 }, null, true, 'America/Los_Angeles');
 



});
