(function() {
    'use strict';
    new Vue({
        el: '#Partner',
        data: {
            addr: '',
            user: {}
        },
        methods: {
            getUserInfo() {
                fetch('/partners/info/' + this.addr + '/').then(res => res.json()).then(res => {
                    if (res.success) this.user = res.user;
                });
            }
        }
    });
    (function() {
        let tree = d3.select('#tree');
        var margin = {
                top: 20,
                right: 70,
                bottom: 30,
                left: 70
            },
            width = 1110 - margin.left - margin.right,
            height = 800 - margin.top - margin.bottom;
        var svg = tree.append("svg").attr("width", width + margin.right + margin.left).attr("height", height + margin.top + margin.bottom).append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");
        var i = 0,
            duration = 750,
            root;
        var treemap = d3.tree().size([height, width]);
        root = d3.hierarchy(JSON.parse(tree.attr('data-tree')), function(d) {
            return d.children;
        });
        root.x0 = height / 2;
        root.y0 = 0;
        window.toggleTree = function() {
            root.children.forEach(function collapse(d) {
                if (d.children) {
                    d._children = d.children
                    if (d._children) d._children.forEach(collapse)
                    d.children = null
                } else {
                    d.children = d._children
                    if (d.children) d.children.forEach(collapse)
                    d._children = null
                }
            });
            update(root);
        };
        toggleTree();

        function update(source) {
            var treeData = treemap(root);
            var nodes = treeData.descendants(),
                links = treeData.descendants().slice(1);
            nodes.forEach(function(d) {
                d.y = d.depth * 100
            });
            var node = svg.selectAll('g.node').data(nodes, function(d) {
                return d.id || (d.id = ++i);
            });
            var nodeEnter = node.enter().append('g').attr('class', 'node').attr("transform", function(d) {
                return "translate(" + source.y0 + "," + source.x0 + ")";
            }).on('click', function click(d) {
                if (d.children) {
                    d._children = d.children;
                    d.children = null;
                } else {
                    d.children = d._children;
                    d._children = null;
                }
                update(d);
            });
            nodeEnter.append('circle').attr('class', 'node').attr('r', 10e-6).style("fill", function(d) {
                return d._children ? "lightsteelblue" : "#fff";
            });
            nodeEnter.append('text').attr("dy", ".35em").attr("x", function(d) {
                return d.children || d._children ? -15 : -15;
            }).attr("text-anchor", function(d) {
                return d.children || d._children ? "end" : "end";
            }).text(function(d) {
                return d.data.n;
            });
            nodeEnter.append('text').attr("dy", ".35em").attr("x", function(d) {
                return -4;
            }).text(function(d) {
                return d.data.l;
            });
            nodeEnter.append('foreignObject').attr('width', '500').attr('height', '500').attr("y", "-10px").attr("x", function(d) {
                return -10;
            }).style('overflow', function(d) {
                return 'visible';
            }).html(function(d) {
                let html = '';
                html += "<div class='tooltip-curved tooltip-curved-west'>";
                html += "<span class='tooltip-curved-content'>";
                html += d.data.m;
                html += "</span>";
                html += "</div>";
                return html;
            });
            var nodeUpdate = nodeEnter.merge(node);
            nodeUpdate.transition().duration(duration).attr("transform", function(d) {
                return "translate(" + d.y + "," + d.x + ")";
            });
            nodeUpdate.select('circle.node').attr('r', 8).style("fill", function(d) {
                return d._children ? "lightsteelblue" : "#fff";
            }).attr('cursor', 'pointer');
            var nodeExit = node.exit().transition().duration(duration).attr("transform", function(d) {
                return "translate(" + source.y + "," + source.x + ")";
            }).remove();
            nodeExit.select('circle').attr('r', 1e-6);
            nodeExit.select('text').style('fill-opacity', 1e-6);
            var link = svg.selectAll('path.link').data(links, function(d) {
                return d.id;
            });
            var linkEnter = link.enter().insert('path', "g").attr("class", "link").attr('d', function(d) {
                var o = {
                    x: source.x0,
                    y: source.y0
                }
                return diagonal(o, o)
            });
            var linkUpdate = linkEnter.merge(link);
            linkUpdate.transition().duration(duration).attr('d', function(d) {
                return diagonal(d, d.parent)
            });
            var linkExit = link.exit().transition().duration(duration).attr('d', function(d) {
                var o = {
                    x: source.x,
                    y: source.y
                }
                return diagonal(o, o)
            }).remove();
            nodes.forEach(function(d) {
                d.x0 = d.x;
                d.y0 = d.y;
            });

            function diagonal(s, d) {
                return `M ${s.y} ${s.x} C ${(s.y+d.y)/2} ${s.x}, ${(s.y+d.y)/2} ${d.x}, ${d.y} ${d.x}`;
            }
        }
    })();
})();