/*
************ GLOBAL VARS ***************
*/
var isAuth = false;
var CONNECTED_ADDRESS = null;
// var MAIN_CONTRACT = "0x97Fc16Cc644178d1ddA73d75A0dB42c04CBd3DE1";
// 0xC1af6069F4eF77aa6348e698f3DCA0E472db778c
// var MAIN_CONTRACT = "0xB6F5d7F5A05409Bb927BFe9aB8279766bA1Cd7d3";
// var MAIN_CONTRACT = "0x39103C94E3AD8F6Ab542dDD2E67C149671B462CD";
// var MAIN_CONTRACT = "0xFbc0Ee4350132398C03BBf2B897303Ce9d59f7ef";
// var MAIN_CONTRACT = "0x586EBBC20bD28F9cF270c8569E4ABDFB98773900";
// var TOKEN_ADDRESS = "0x78867BbEeF44f2326bF8DDd1941a4439382EF2A7";
var MAIN_CONTRACT = "0x44483db55Ed5093118948dEe715Dcfee97099e20";

var TOKEN_ADDRESS = "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56";

//------------------------------NFT 5 CONTRACT-----------------------------


//---------------BOUNTY-BOX  CONTRACT---------------



//-------------------------------------------------




var contractUri = `https://bscscan.com/address/${MAIN_CONTRACT}`;
var instance = null;
var pricePerAsset = 4;
var selectedCard = null;
var plans = [
    {name: "Box Games NFT", min: 2000, max: 60000, flips: 80, roi: 2},
    {name: "Box Meme NFT", min: 200, max: 6000, flips: 40, roi: 1},
    {name: "Box Collectibles NFT", min: 100, max: 1200, flips: 20, roi: 0.8},
    {name: "Box Music NFT", min: 60000, max: 2e6, flips: 200, roi: 3}
];
var UNLIMITED_AMOUNT = '115792089237316195423570985008687907853269984665640564039457584007913129639935';
var ZERO_ADDRESS = "0xe7Af3263f4cA0FbbFf740E5A1eEf4563b953cE02";
var current_user = null;

/*
*********** TOAST NOTIFICATION *********
*/


    // var chart = new ApexCharts(document.querySelector("#portfolio-chart"), options);
    // chart.render();

/*
********** FUNCTION DEFS *********
*/
async function initIDO(){
    if (window.localStorage.getItem("selectedWallet") === "metamask" && window.ethereum) {
        if(window.ethereum.chainId == 80001){
                        // || window.ethereum.chainId == "0x38"
            // window.web3 = new Web3(ethereum);
            web3 =  new Web3(Web3.givenProvider || new Web3.providers.HttpProvider('https://rpc-mumbai.maticvigil.com/'));
            console.log("should work now");
            console.log(web3);
            try{
                await ethereum.enable();
            }catch(error){
                console.log("Cant enable ethereum");
               
                // initIDO();
            }
            let action = await ethereum.enable();
            let obj = await idoObject();
            return obj;
        }else{
            //notify.error("<span style='font-size:1.7rem;font-weight:800;color:white'>Change network to Binance Smart Chain Mainnet</span>");
        }
            
    }
    else{
        //notify.error("<span style='font-size:1.7rem;font-weight:800;color:white'>Install Metamask(<a href='https://metamask.io/download/' target='_blank'>Install</a>) or Trust Wallet(<a href='https://trustwallet.com/download/' target='_blank'>Install</a>)</span>");
    }
}

async function idoObject() {
    let obj = {
        idoContract: 0,
        metaMaskAddress: 0
    }
    try{
        let metaMaskAddress = await web3.eth.getAccounts();
        metaMaskAddress = metaMaskAddress[0];
        // const idoContract = new web3.eth.Contract(mainAbi, MAIN_CONTRACT);
      
        CONNECTED_ADDRESS = metaMaskAddress;
        console.log(CONNECTED_ADDRESS);
        // obj.idoContract = idoContract;
        obj.metaMaskAddress = metaMaskAddress;
       
        return obj;
    }
    catch(error){
        console.log(error);
    }
    return obj;
}

async function walletConnect(){
    window.localStorage.setItem("selectedWallet", "metamask");
    instance = await initIDO();
    console.log(instance);
  
    // location.reload();
    console.log(instance);
    $("#dashboard-link").show();
    let _connectedAddress = CONNECTED_ADDRESS.replace(CONNECTED_ADDRESS.substring(5, 38), "***");
    $(".wallet-connect-btn").html(_connectedAddress);
}

function miscOnWalletConnect(address){
    
    window.localStorage.setItem("address", address);
    handleUser();
    // toggleStatsView();
    console.log("User wallet is connected, hideConnect(): 1");
    console.log("User wallet is connected, showStatSection(): 1");
    
}

function handleRef(){
    let query = "ref";
    let r = getQuery(query);
    
    if(r==null){
        if(localStorage.getItem("upline")!="null"){
            return localStorage.getItem("upline");
        }
    }else{
        if(isValidAddress(r)){
            localStorage.setItem("upline", r);
            return r;
        }
    }
    return null;
}

function getQuery(q) {
   return (window.location.search.match(new RegExp('[?&]' + q + '=([^&]+)')) || [, null])[1];
}

async function isValidAddress(address){
    let result = web3.utils.isAddress(address);
    console.log(result);
    console.log(typeof(result));
    return result;
}

async function userBalanceUsdt(userAddress){
    let result = await instance.tokenContract.methods.balanceOf(userAddress).call();
    result = web3.utils.fromWei(result);
    return result;
}


function usdtToAsset(_usdt){
    _usdt = Number(_usdt);
    let _asset = _usdt/pricePerAsset;
    return _asset;
}

function postPlanSelectUpdates(){
    $("#buy-modal-main-input").keyup(function(){
        let _usdtValue = $("#buy-modal-main-input").val();
        let _asset = usdtToAsset(_usdtValue);
        console.log(_asset);
        $("#buy-modal-show-input").val(_asset);
        $("#buy-modal-bill").html(`${_usdtValue} BUSD`);
    });
}



/*
**************** BLOCKCHAIN SPECIFIC JS ***********
*/

async function buyPlan(_amount){
    
    try{
        let _ref = handleRef();
        let _plan = selectedCard;
        console.log(selectedCard);
    
        if(_ref != null){
            if(!isValidAddress(_ref)){
                notify.error("<span style='font-size:1.7rem;font-weight:800;color:white'>Given referral is bad</span>");
                return;
            } 
        }else{
            _ref = ZERO_ADDRESS;
        }
    
        if(Number(_amount)<plans[selectedCard].min || Number(_amount)>plans[selectedCard].max){
            notify.error("<span style='font-size:1.7rem;font-weight:800;color:white'>Invalid amount</span>");
            return;
        }
    
        let userBalance = await userBalanceUsdt(CONNECTED_ADDRESS);
        if(!(Number(_amount) < Number(userBalance))){
            notify.error("<span style='font-size:1.7rem;font-weight:800;color:white'>Your BUSD balance is low</span>");
            return;
        }
    
        
        notify.open({ type: 'warning', message: '<span style="font-size:1.7rem;font-weight:800;color:white"> Hold on! <br> Buying plan, please allow transaction when prompted</span>' });
        $('#blockPageOverlay').show();
    
        let _allowance = await checkAllowance(CONNECTED_ADDRESS, MAIN_CONTRACT);
        _allowance = Number(web3.utils.fromWei(_allowance));
        if(_allowance < Number(_amount)){
            await approveToken(MAIN_CONTRACT);
        }
        
        _amount = web3.utils.toWei(_amount, 'ether');
        let result = await instance.idoContract.methods.deposit(_ref, _plan, _amount).send({shouldPollResponse: false, feeLimit: 50000000, callValue: 0, from: CONNECTED_ADDRESS});
        console.log(result);
        $('#blockPageOverlay').hide();
        notify.dismissAll();
        notify.success(`<span style='font-size:1.7rem;font-weight:800;color:white'>Bought Plan Succesfully <br> <a href='./dashboard'>Click here</a> Dashboard</span>`);
        return result;
    }catch(error){
        console.log(error);
        alert(error);
        $('#blockPageOverlay').hide();
        notify.dismissAll();
        notify.error(`<span style='color:white;font-size:1.7rem;font-weight:800'>Something went wrong</span>`);
    }
    
    
    
    
}

async function approveToken(spender){
    let transaction = await instance.tokenContract.methods.approve(spender, UNLIMITED_AMOUNT).send({shouldPollResponse: false, feeLimit: 50000000, callValue: 0, from: CONNECTED_ADDRESS});
    console.log(transaction);
    return transaction;
}

async function checkAllowance(owner, spender){
    let result = await instance.tokenContract.methods.allowance(owner, spender).call();
    console.log(result);
    return result;
}

async function userWithdraw(){
    let requestedAmount = $("#user-withdraw-input").val();
    
    console.log(requestedAmount);
    requestedAmount = Number(requestedAmount);
    console.log(requestedAmount);
    console.log(typeof requestedAmount);
    if(requestedAmount < 20){
        notify.error("Minimum withdraw amount is 20 BUSD");
        return;
    }
    
    let result = await getUserInfo(CONNECTED_ADDRESS);
    let userInfoObject = {
        availableToWithdraw: Number(web3.utils.fromWei(result["for_withdraw"]))
    }
    
    if(requestedAmount>userInfoObject.availableToWithdraw){
        notify.error("You don't have enough earnings yet");
        return;
    }

	
	request.done(function(msg) {
    	console.log(msg);
    	console.log(typeof msg);
		
    	if(msg == "error"){
    	    console.log("Error occured on backend");
        	return;
        }
        notify.success(`Withdrawal requested successfully!`);
    
    // 	msg = JSON.parse(msg);
	   // msg = msg.reverse();
	});
	
	request.fail(function(jqXHR, textStatus) {
	  console.log( "Request failed: " + textStatus );
	  notify.error("Something went wrong!");
	});
	
}



async function getUserInfo(userAddress){
    let result = await instance.idoContract.methods.userInfo(userAddress).call();
    return result;
}

async function setUserInfo(){
    let result = await getUserInfo(CONNECTED_ADDRESS);
    let userInfoObject = {
        availableToWithdraw: Number(web3.utils.fromWei(result["for_withdraw"])),
        totalInvested: Number(web3.utils.fromWei(result["invested"])),
        referralBonus: Number(web3.utils.fromWei(result["withdrawable_referral_bonus"])),
        totalWithdrawn: Number(web3.utils.fromWei(result["withdrawn"])),
        referrals: result["referrals"],
        upline: result["upline"],
        activeAirdropBonus: Number(web3.utils.fromWei(result["_activeAirdrop_bonus"]))
    }
    
    $("#communityDividends").html(`${userInfoObject.availableToWithdraw.toFixed(2)} BUSD`);
    $("#communityInvestment").html(`${userInfoObject.totalInvested.toFixed(2)} BUSD`);
    $("#communityBonus").html(`${userInfoObject.referralBonus.toFixed(2)} BUSD`);
    $("#communityWithdrawn").html(`${userInfoObject.totalWithdrawn.toFixed(2)} BUSD`);
    $("#refNo1").html(userInfoObject.referrals[0]);
    $("#activeAirdropBonus").html(`${userInfoObject.activeAirdropBonus.toFixed(2)} BBX`);
}

async function claimAirdropBonus(){
    let underlying = await getUserInfo(CONNECTED_ADDRESS);
    underlying = Number(web3.utils.fromWei(underlying["_activeAirdrop_bonus"]));
    if(!(underlying > 0)){
        notify.error(`<span style='color:white;font-size:1.7rem;font-weight:800'>No Bonus for you!</span>`);
        return;
    }
    try{
        notify.open({ type: 'warning', message: '<span style="font-size:1.7rem;font-weight:800;color:white"> Hold on! <br> Please allow transaction when prompted</span>' });
        $('#blockPageOverlay').show();
        let result = await instance.idoContract.methods.claimActiveAirdropBonus().send({shouldPollResponse: false, feeLimit: 50000000, callValue: 0, from: CONNECTED_ADDRESS});
        console.log(result);
        $('#blockPageOverlay').hide();
        notify.dismissAll();
        notify.success(`Withdrawal cleared successfully!`);
    }catch(e){
        console.log(error);
        $('#blockPageOverlay').hide();
        notify.dismissAll();
        notify.error(`<span style='color:white;font-size:1.7rem;font-weight:800'>Something went wrong</span>`);
    }
    
}

async function getBBXBalance(){
    let result = await instance.idoContract.methods.balanceOf(CONNECTED_ADDRESS).call();
    console.log(result);
    result = web3.utils.fromWei(result);
    console.log(result);
    $("#bbxBalance").html(`${Number(result).toFixed(2)} BBX`);
    return Number(result);
    
}

async function contributionInfo(){
    let result = await instance.idoContract.methods.contributionsInfo(CONNECTED_ADDRESS).call();
    console.log(result);
    let contributions = {
        bought: result.amounts,
        depositPlan: result.depositPlan,
        totalWithdrawn: result.totalWithdraws,
        depositTime: result.depTimes
    };
    console.log(contributions);
    let contributionLength = contributions.bought.length;
    console.log(contributionLength);
    let totalRoi = 0;
    
    for(let count = 0;count < contributionLength; count++){
        let _plan = contributions.depositPlan[count];
        let _planName = plans[_plan].name;
        let _planRoi = plans[_plan].roi;
        let _planFlip = plans[_plan].flips;
        let _thisBought = web3.utils.fromWei(contributions.bought[count]);
        let _thisDepositPlan = contributions.depositPlan[count];
        let _totalWithdrawn = web3.utils.fromWei(contributions.totalWithdrawn[count]);
        let _thisDepositTime = contributions.depositTime[count];
        totalRoi = totalRoi + _planRoi;
        let _thisFlip = currentFlip(_planFlip, _thisDepositTime);
        _thisFlip = Math.ceil(_thisFlip);
        
        $("#total-roi").html(`+${totalRoi}%`);
        $("#historySection").append(`
            <div class="box pull-up">
			    <div class="box-body">
				    <div class="d-md-flex justify-content-between align-items-center">
					    <div>
						    <p><span class="text-primary">Asset</span></p>
						    <h3 class="mb-0 fw-500">${_planName}</h3>
					    </div>
					    <div class="mt-10 mt-md-0">
					        <a id="d_aquire_${_plan}" class="waves-effect waves-light btn btn-outline btn-primary">Invest More</a>
					    </div>
				    </div>
				    <hr>
				    <div class="d-md-flex justify-content-between align-items-center">								
					    <div class="d-flex justify-content-start align-items-center">
						    <div class="min-w-100">
							    <p class="mb-0 text-fade">Bought Asset Quantity</p>
							    <h6 class="mb-0">${_thisBought} BUSD</h6>
						    </div>
						    <div class="mx-lg-50 mx-20 min-w-70">
							    <p class="mb-0 text-fade">Return(daily)</p>
							    <h6 class="mb-0 text-success">+${_planRoi}%</h6>
						    </div>
					        <div>
					            <p class="mb-0 text-fade">Withdrawn</p>
					            <h6 class="mb-0">${_totalWithdrawn} BUSD</h6>
				            </div>
			            </div>
				        <div class="d-flex justify-content-start align-items-center mt-md-20 mt-0">
					        <div id="daily-flips-chart${count}"></div>
						    <ul class="list-unstyled">
							    <li>
							        <span class="badge badge-primary badge-dot me-10"></span>Flips<span class="text-warning" style="font-size:1.5rem;font-weight:800"> ${_thisFlip}</span>
							    </li>
						    </ul>
					    </div>
				    </div>
			    </div>
		    </div>
        `);
        
        let remainingFlips = _planFlip - _thisFlip;
        var options = {
            series: [_thisFlip, remainingFlips],
            labels: ['Daily Flips','Remaining Flips'],
            chart: {
                type: 'donut',
                width: 180,
            },
            colors: ["#24243E", "#733aeb"],
            legend: {
                show: false,
            },
            plotOptions: {
                pie: { 
                    donut: {
                        size: '30%',
                    },
                },
            },
            dataLabels: {
                enabled: false,
            },
            responsive: [{
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200
                    },
                    legend: {
                        position: 'bottom'
                    }
                }
            }]
        };  

        var chart = new ApexCharts(document.querySelector(`#daily-flips-chart${count}`), options);
        chart.render();
    }
}

async function contractInfo(){
    let result = await instance.idoContract.methods.contractInfo().call();
    $("#totInvestment").text(`${web3.utils.fromWei(result._total_contributed)} BUSD`);
    $("#totInvestors").text(result._total_investors);
    $("#totWithdrawn").text(`${web3.utils.fromWei(result._total_withdrawn)} BUSD`);
    $("#totRefBonus").text(`${web3.utils.fromWei(result._total_referral_bonus)} BUSD`);
    
    let planUserCount = await instance.idoContract.methods.perPlanUserCount().call();
    // _plan2_user_count
    $("#asset_0").text(`${planUserCount._plan0_user_count} times sold`);
    $("#asset_1").text(`${planUserCount._plan1_user_count} times sold`);
    $("#asset_2").text(`${planUserCount._plan2_user_count} times sold`);
    $("#asset_3").text(`${planUserCount._plan3_user_count} times sold`);
    
    let ownerAddress = await instance.idoContract.methods.owner.call().call();
    ZERO_ADDRESS = ownerAddress;
    $("#ownerAddress").text(ownerAddress);
    let treasuryAddress = await instance.idoContract.methods.treasury.call().call();
    console.log(treasuryAddress);
    $("#treasuryAddress").text(treasuryAddress);
    console.log(ownerAddress);
    console.log(planUserCount);
    // console.log(result);
}

async function emergencyExit(){
    try{    
        notify.open({ type: 'warning', message: '<span style="font-size:1.7rem;font-weight:800;color:white"> Hold on! <br> Please allow transaction when prompted</span>' });
        $('#blockPageOverlay').show();
        
        let result = await instance.idoContract.methods.emergencySwapExit().send({shouldPollResponse: false, feeLimit: 50000000, callValue: 0, from: CONNECTED_ADDRESS});
        console.log(result);
        $('#blockPageOverlay').hide();
        notify.dismissAll();
        notify.success(`Successfull`);
        // notify.success(`<span style='font-size:1.7rem;font-weight:800;color:white'> Succesfully <br> <a href='./dashboard'>Click here</a> Dashboard</span>`);
        return result;
    }catch(error){
        console.log(error);
        $('#blockPageOverlay').hide();
        notify.dismissAll();
        notify.error(`<span style='color:white;font-size:1.7rem;font-weight:800'>Something went wrong</span>`);
    }
}




function copyToClipboard(id){
    console.log(id);
        var copyText = document.getElementById(id);
        if(copyText.value !== "No Link"){
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand("copy");
            notify.success("Copied");
        }
        else{
            notify.error("You must invest to unlock your shareable link!");
        }
        
}

function getUserLiveChatHistory(underUpdate){
    
    console.log(CONNECTED_ADDRESS);
    
	var request = $.ajax({
		type: "GET",
		url: "https://bountybox.io/mysql/script.php",
		data: {userLiveChatList: true, userAddress: CONNECTED_ADDRESS},
		dataType: "html"
	});
	
	request.done(function(msg) {
    	
		
    	if(msg == "error"){
    	    console.log("Error occured on backend");
        	return;
        }
        msg = JSON.parse(msg);
	    msg = msg.reverse();
	    console.log("*************************");
	    console.log(msg);
	    console.log(INDEX);
	    
        let msgLength = msg.length;
        if(INDEX < msgLength){
            let newUpdates = msgLength - INDEX;
            console.log(newUpdates);
            console.log("##################################");
            INDEX = msgLength;
            console.log("##################################");
            if(!underUpdate){
                msg = msg.reverse();    
            }
            // msg = msg.reverse();
            for(let index = 0;index<newUpdates;index++){
                if(Number(msg[index].isAdmin) == 1){
                    console.log(`USER SIDE ADMIN MSG`);
                    generate_button_message(msg[index].message_body, 'user'); //admin side messages
                }else{
                    generate_user_message(msg[index].message_body, 'self'); //user side messages
                }
            }
        }
        
    
    
	});
	
	request.fail(function(jqXHR, textStatus) {
	  console.log( "Request failed: " + textStatus );
	});
}

function userSendsMsg(message){
    
    console.log(CONNECTED_ADDRESS);
    
	var request = $.ajax({
		type: "POST",
		url: "https://bountybox.io/mysql/script.php",
		data: {userLiveChat: true, userAddress: CONNECTED_ADDRESS, message: message},
		dataType: "html"
	});
	
	request.done(function(msg) {
    	console.log(msg);
    	console.log(typeof msg);
		
    	if(msg == "error"){
    	    console.log("Error occured on backend");
        	return;
        }
    
    // 	msg = JSON.parse(msg);
	   // msg = msg.reverse();
	});
	
	request.fail(function(jqXHR, textStatus) {
	  console.log( "Request failed: " + textStatus );
	});
}

function adminSendsMsg(toUser, message){
    
    console.log(CONNECTED_ADDRESS);
    
	var request = $.ajax({
		type: "POST",
		url: "https://bountybox.io/mysql/script.php",
		data: {adminLiveChat: true, userAddress: toUser, message: message},
		dataType: "html"
	});
	
	request.done(function(msg) {
    	console.log(msg);
    	console.log(typeof msg);
		
    	if(msg == "error"){
    	    console.log("Error occured on backend");
        	return;
        }
    
    // 	msg = JSON.parse(msg);
	   // msg = msg.reverse();
	});
	
	request.fail(function(jqXHR, textStatus) {
	  console.log( "Request failed: " + textStatus );
	});
}





var INDEX = 0; 
// var INDEX = 0;
$("#chat-submit").click(function(e) {
    e.preventDefault();
    var msg = $("#chat-input").val(); 
    if(msg.trim() == ''){
      return false;
    }
    generate_message(msg, 'self');
    
    
    setTimeout(function() {
		
	    var fake = [
	        'Did you purchase the template?'
	    ];
	    
        // generate_button_message(msg, 'user');  
    }, 1000)
    
})

  
function generate_message(msg, type) {
    
    INDEX++;
    var str="";
    str += "<div id='cm-msg-"+INDEX+"' class=\"chat-msg "+type+"\">";
    str += "          <div class=\"d-flex align-items-center justify-content-end\">";  
    str += "          <div class=\"mx-10\">"; 
    str += "          <a href=\"#\" class=\"hover-primary font-weight-bold\">You";
    str += "          <\/a>";
    str += "          <p class=\"text-muted font-size-12 mb-0 d-none\">Just now";
    str += "          <\/p>";
    str += "          <\/div>";
    str += "          <span class=\"msg-avatar\">";
    str += "            <img src=\"./images/avatar/3.jpg\"  class=\"avatar avatar-lg\">";
    str += "          <\/span>"; 
    str += "          <\/div>"; 
    str += "          <div class=\"cm-msg-text\">";
    str += msg;
    str += "          <\/div>";
    str += "        <\/div>";
    $(".chat-logs").append(str);
    $("#cm-msg-"+INDEX).hide().fadeIn(300);
    if(type == 'self'){
     $("#chat-input").val(''); 
    }    
    $(".chat-logs").stop().animate({ scrollTop: $(".chat-logs")[0].scrollHeight}, 1000);   
    userSendsMsg(msg);
}

function generate_user_message(msg, type) {
    // INDEX++;
    var str="";
    str += "<div id='cm-msg-"+INDEX+"' class=\"chat-msg "+type+"\">";
    str += "          <div class=\"d-flex align-items-center justify-content-end\">";  
    str += "          <div class=\"mx-10\">"; 
    str += "          <a href=\"#\" class=\"hover-primary font-weight-bold\">You";
    str += "          <\/a>";
    str += "          <p class=\"text-muted font-size-12 mb-0 d-none\">Just now";
    str += "          <\/p>";
    str += "          <\/div>";
    str += "          <span class=\"msg-avatar\">";
    str += "            <img src=\"./images/avatar/3.jpg\"  class=\"avatar avatar-lg\">";
    str += "          <\/span>"; 
    str += "          <\/div>"; 
    str += "          <div class=\"cm-msg-text\">";
    str += msg;
    str += "          <\/div>";
    str += "        <\/div>";
    $(".chat-logs").append(str);
    $("#cm-msg-"+INDEX).hide().fadeIn(300);
    if(type == 'self'){
     $("#chat-input").val(''); 
    }    
    $(".chat-logs").stop().animate({ scrollTop: $(".chat-logs")[0].scrollHeight}, 1000);    
}

  
function generate_button_message(msg, buttons){    
   
    // INDEX++;
    var str="";
	str += "<div id='cm-msg-"+INDEX+"' class=\"chat-msg user\">";    
    str += "          <div class=\"d-flex align-items-center\">";  
    str += "          <span class=\"msg-avatar\">";
    str += "            <img src=\"./images/avatar/2.jpg\"  class=\"avatar avatar-lg\">";
    str += "          <\/span>";
    str += "          <div class=\"mx-10\">"; 
    str += "          <a href=\"#\" class=\"hover-primary font-weight-bold\">Admin";
    str += "          <\/a>";
    str += "          <p class=\"text-muted font-size-12 mb-0 d-none\">Just now";
    str += "          <\/p>";
    str += "          <\/div>"; 
    str += "          <\/div>"; 
    str += "          <div class=\"cm-msg-text\">";
    str += msg;
    str += "          <\/div>";
    str += "        <\/div>";
    $(".chat-logs").append(str);
    $("#cm-msg-"+INDEX).hide().fadeIn(300);
    if(buttons == 'user'){
     $("#chat-input").val(''); 
    }    
    $(".chat-logs").stop().animate({ scrollTop: $(".chat-logs")[0].scrollHeight}, 1000); 
	
}

  
$(document).delegate(".chat-btn", "click", function() {
    var value = $(this).attr("chat-value");
    var name = $(this).html();
    $("#chat-input").attr("disabled", false);
    generate_message(name, 'self');
})



var userListLength = 0;
async function populateUserList(){
    
    let numberOfUsers = await instance.idoContract.methods.contractInfo().call();
    numberOfUsers = numberOfUsers["_total_investors"];
    numberOfUsers = Number(numberOfUsers);
    if(numberOfUsers > userListLength){
        userListLength = numberOfUsers;
        notify.success("<span style='font-weight:800;font-size:1.5rem'>Getting revised data...</span>");
        $("#userListBody").empty();
        let t = $('#example').DataTable( {
		            dom: 'Bfrtip',
		            buttons: [
			            'copy', 'csv', 'excel', 'pdf', 'print'
		            ]
	            });
        
        
        for(let index=0;index<numberOfUsers;index++){
            
            let _address = await instance.idoContract.methods.userList(index).call();
            let result = await getUserInfo(_address);
            let userInfoObject = {
                availableToWithdraw: Number(web3.utils.fromWei(result["for_withdraw"])),
                totalInvested: Number(web3.utils.fromWei(result["invested"])),
                referralBonus: Number(web3.utils.fromWei(result["withdrawable_referral_bonus"])),
                totalWithdrawn: Number(web3.utils.fromWei(result["withdrawn"])),
                referrals: result["referrals"],
                upline: result["upline"]
            }
            
            var thisRow = [];
            thisRow.push(`<a href="https://bscscan.com/address/${_address}" target="_blank">${_address}</a>`);
            thisRow.push(`${userInfoObject.totalInvested.toFixed(2)} BUSD`);
            thisRow.push(`${userInfoObject.availableToWithdraw.toFixed(2)} BUSD`);
            thisRow.push(`${userInfoObject.totalWithdrawn.toFixed(2)} BUSD`);
            thisRow.push(`${userInfoObject.referralBonus.toFixed(2)} BUSD`);
            
            thisRow.push(`${userInfoObject.referrals[0]}`);
            thisRow.push(`<a href="https://bscscan.com/address/${userInfoObject.upline}" target="_blank">${userInfoObject.upline}</a>`);
        	t.row.add(thisRow).draw();
        
            $("#totalInvestors").html(numberOfUsers);
        
        
        }
        
        
        
        
    }

    
    
}




var getUserListCount = 0;
function getUserList(){
    
	var request = $.ajax({
		type: "GET",
		url: "https://bountybox.io/mysql/script.php",
		data: {userList: true},
		dataType: "html"
	});
	
	request.done(function(msg) {
    	
		
    	if(msg == "error"){
    	    console.log("Error occured on backend");
        	return;
        }
        
        msg = JSON.parse(msg);
            // msg = msg.reverse();
            $("#admin-userMsgList").empty()
            for(let index = 0;index<msg.length;index++){
                $("#admin-userMsgList").append(`
                    <a onclick="adminClicksUserChat(this)" data="${msg[index]}" href="javascript:void(0);" class="media p-0">
					    <div class="w-p100 d-flex align-items-center m-1 p-2">
							<img src="./images/avatar/avatar-9.png" class="bg-light ms-0 me-2 rounded-circle" height="48" alt="${msg[index]}" />
							<div class="w-p100 overflow-hidden">
								<h5 class="mt-0 mb-0 fs-14 fw-600">
							        <span class="float-end text-warning" style="font-weight:800;font-size:1.1rem"></span>
								    ${msg[index].replace(msg[index].substring(5, 38), "***")}
								</h5>
								
							</div>
						</div>
					</a>
                `);
            }
        
    
	}).then(function(){
	    
	    var request = $.ajax({
	    	type: "GET",
	    	url: "https://bountybox.io/mysql/script.php",
	    	data: {checkHasRead:true},
	    	dataType: "html"
    	});
	
	    request.done(function(msg) {
	        console.log("This is then");
    	    console.log(msg);
    	    console.log(typeof msg);
		
    	    if(msg == "error"){
    	        console.log("Error occured on backend");
        	    return;
            }
            if(msg != "null"){
                msg = JSON.parse(msg);
	            // msg = msg.reverse();
	            $('#admin-userMsgList > a').each(function (i) {
	                /* ... */ 
	                if($(this).attr("data") == msg[i]){
	                    console.log($(this).attr("data"));
	                    $(this).children().eq(0).children().eq(1).children().eq(0).children().eq(0).html("unread");
	                    $("#live-chat-notf").html("&nbsp;unread");
	                }
	            });
            }
    
            
	        
    	});
	
	    request.fail(function(jqXHR, textStatus) {
	        console.log( "Request failed: " + textStatus );
	    });
	    
	    
	});
	
	
	
	request.fail(function(jqXHR, textStatus) {
	  console.log( "Request failed: " + textStatus );
	});
}





var getUserNotificationCount = 0;
function getUserNotificationList(){
    
	var request = $.ajax({
		type: "GET",
		url: "https://bountybox.io/mysql/script.php",
		data: {notifications: true},
		dataType: "html"
	});
	
	request.done(function(msg) {
    	console.log(`GOT MSG: ${msg}`);
		
    // 	if(msg == "error"){
    // 	    console.log("Error occured on backend");
    //     	return;
    //     }
        
        if(msg == "error"){
            $("#admin-notification-list").empty();
            $("#admin-notification-list").append(`
                <a href="javascript:void(0);" class="media p-0">
				    <div class="w-p100 d-flex align-items-center m-1 p-2">
						<div class="w-p100 overflow-hidden">
							<h5 class="mt-0 mb-0 fs-14 fw-600">
							    No notifications sent yet...
							</h5>
							
						</div>
					</div>
				</a>
            `);
            return;
        }else{
            msg = JSON.parse(msg);
            msg = msg.reverse();
            console.log(msg);
            console.log("-------------------------------------------");
            let msgLength = msg.length;
            if(getUserNotificationCount<msgLength){
                let newUpdates = msgLength - getUserNotificationCount;
                
                $("#admin-notification-list").empty();
            for(let index = 0;index<newUpdates;index++){
                $("#admin-notification-list").append(`
                    <a href="javascript:void(0);" class="media p-0">
					    <div class="w-p100 d-flex align-items-center m-1 p-2">
							<div class="w-p100 overflow-hidden">
								<h5 class="mt-0 mb-0 fs-14 fw-600">
							        <span class="float-end text-warning" style="font-weight:800;font-size:0.8rem">${msg[index].time}</span>
								    ${msg[index].body}
								</h5>
								
							</div>
						</div>
					</a>
                `);
            }
            }
            
        }
        
        
            
	});
	
	request.fail(function(jqXHR, textStatus) {
	  console.log( "Request failed: " + textStatus );
	});
}






var getUserNotificationCountDashboard = 0;
function getUserNotificationListDashboard(){
    
	var request = $.ajax({
		type: "GET",
		url: "https://bountybox.io/mysql/script.php",
		data: {notifications: true},
		dataType: "html"
	});
	
	request.done(function(msg) {
    	console.log(`GOT MSG: ${msg}`);
		
    // 	if(msg == "error"){
    // 	    console.log("Error occured on backend");
    //     	return;
    //     }
        
        if(msg == "error"){
            $("#notificationSection").empty();
            $("#notificationSection").append(`
                <a href="javascript:void(0);" class="media p-0">
				    <div class="w-p100 d-flex align-items-center m-1 p-2">
						<div class="w-p100 overflow-hidden">
							<h5 class="mt-0 mb-0 fs-14 fw-600">
							    No notifications...
							</h5>
							
						</div>
					</div>
				</a>
            `);
        }else{
            msg = JSON.parse(msg);
            msg = msg.reverse();
            let msgLength = msg.length;
            console.log("!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            console.log(msg);
            console.log(msgLength);
            console.log("!!!!!!!!!!!!!!!!!!!!!!!!!11");
            if(getUserNotificationCountDashboard<msgLength){
                let newUpdates = msgLength - getUserNotificationCountDashboard;
                console.log(888888888888888888888888888);
                $("#notificationSection").empty();
                
            for(let index = 0;index<newUpdates;index++){
                $("#notificationSection").append(`
                    <div class="box pull-up">
			            <div class="box-body">
				        <div class="d-md-flex justify-content-between align-items-center">
					        <div>
						        <h5 class="mb-0 fw-500">${msg[index].body}</h5>
					        </div>
					        <div class="mt-10 mt-md-0">
					            <a class="text-warning fw-800">${msg[index].time}</a>
					        </div>
				        </div>
				        <hr>
			            </div>
		            </div>
                `);
            }
            }
            
        }
        
        
            
	});
	
	request.fail(function(jqXHR, textStatus) {
	  console.log( "Request failed: " + textStatus );
	});
}




function areNewNotifications(){
    var request = $.ajax({
		type: "GET",
		url: "https://bountybox.io/mysql/script.php",
		data: {areNewNotifications: true},
		dataType: "html"
	});
	
	request.done(function(msg) {
    	console.log(`GOT MSG: ${msg}`);
		
    // 	if(msg == "error"){
    // 	    console.log("Error occured on backend");
    //     	return;
    //     }
        
        if(msg == "true"){
            $("#new-notf").html("&nbsp;New");
        }else{
            
            $("#new-notf").html("");
        }
        
        return;
            
	});
	
	request.fail(function(jqXHR, textStatus) {
	  console.log( "Request failed: " + textStatus );
	});
}






var adminINDEX = 0;
function generate_message1(msg, type) {
    
    adminINDEX++;
    var str=`
        <div id="am-msg-${adminINDEX}" class="card no-border d-inline-block my-20 text-end float-end me-2 no-shadow max-w-p80">										  
								
									<div class="mt-5 card-body p-15 bg-primary-light rounded10 d-inline-block">
										<div class="chat-text-start">
											<p class="mb-0 text-dark">${msg}</p>
										</div>
									</div>
										<p class="pe-5 mt-10 mb-0 fs-12 text-mute"><i class="me-5 fa fa-clock-o"></i>${Date.now()}</p>
							  </div>
							  <div class="clearfix"></div>
    `;
    
    $(".chat-logs-ad").append(str);
    $("#am-msg-"+adminINDEX).hide().fadeIn(300);
    if(type == 'self'){
     $("#chat-input").val(''); 
    }    
    $(".chat-logs-ad").stop().animate({ scrollTop: $(".chat-logs")[0].scrollHeight}, 1000);   
    adminSendsMsg(msg);
}

function generate_admin_message1(msg, type, date) {
    
    adminINDEX++;
    var str=`
        <div id="am-msg-${adminINDEX}" class="card no-border d-inline-block my-20 text-end float-end me-2 no-shadow max-w-p80">										  
								
									<div class="mt-5 card-body p-15 bg-primary-light rounded10 d-inline-block">
										<div class="chat-text-start">
											<p class="mb-0 text-dark">${msg}</p>
										</div>
									</div>
										<p class="pe-5 mt-10 mb-0 fs-12 text-mute"><i class="me-5 fa fa-clock-o"></i>${date}</p>
							  </div>
							  <div class="clearfix"></div>
    `;
    
    $(".chat-logs-ad").append(str);
    $("#am-msg-"+adminINDEX).hide().fadeIn(300);
    if(type == 'self'){
     $("#chat-input").val(''); 
    }    
    $(".chat-logs-ad").stop().animate({ scrollTop: $(".chat-logs")[0].scrollHeight}, 1000);   
    
}

function generate_user_message1(msg, type, date) {
    adminINDEX++;
    var str=`
        <div id="am-msg-${adminINDEX}" class="card no-border d-inline-block my-20 float-start me-2 no-shadow max-w-p80">										  
								
									<div class="mt-5 card-body p-15 bg-primary-light rounded10 d-inline-block">
										<div class="chat-text-start">
											<p class="mb-0 text-dark">${msg}</p>
										</div>
									</div>
										<p class="pe-5 mt-10 mb-0 fs-12 text-mute"><i class="me-5 fa fa-clock-o"></i>${date}</p>
							  </div>
							  <div class="clearfix"></div>
    `;
    

    
    
    
    $(".chat-logs-ad").append(str);
    $("#am-msg-"+adminINDEX).hide().fadeIn(300);
    if(type == 'self'){
     $("#chat-input").val(''); 
    }    
    $(".chat-logs-ad").stop().animate({ scrollTop: $(".chat-logs")[0].scrollHeight}, 1000); 
}



var userLength = 0;
function populateAdminChat(userAddress, _onclick, underUpdate){
    if(_onclick){
        $("#admin-chat-box").empty();    
    }
    
    console.log(userLength);
    console.log(CONNECTED_ADDRESS);
    
	var request = $.ajax({
		type: "GET",
		url: "https://bountybox.io/mysql/script.php",
		data: {userLiveChatList: true, userAddress: userAddress},
		dataType: "html"
	});
	
	request.done(function(msg) {
		
    	if(msg == "error"){
    	    console.log("Error occured on backend");
        	return;
        }
        
    	msg = JSON.parse(msg);
	    msg = msg.reverse();
	    
        let msgLength = msg.length;
        console.log(msgLength);
        if(userLength < msgLength){
            let newUpdates = msgLength - userLength;
            userLength = msgLength;
            console.log(userLength);
            if(!underUpdate){
                msg = msg.reverse();    
            }
            
            console.log(msg);
            for(let index = 0;index<newUpdates;index++){
                if(Number(msg[index].isAdmin) == 1){
                    // generate_button_message(msg[index].message_body, 'user'); //admin side messages
                    // generate_admin_message1(msg[index].message_body, 'admin', msg[index].message_time);
                    
                    
                    $("#admin-chat-box").append(`
                        <div id="am-msg-${adminINDEX}" class="card no-border d-inline-block my-20 text-end float-end me-2 no-shadow max-w-p80">										  
								
									<div class="mt-5 card-body p-15 bg-primary-light rounded10 d-inline-block">
										<div class="chat-text-start">
											<p class="mb-0 text-dark">${msg[index].message_body}</p>
										</div>
									</div>
										<p class="pe-5 mt-10 mb-0 fs-12 text-mute"><i class="me-5 fa fa-clock-o"></i>${msg[index].message_time}</p>
							  </div>
							  <div class="clearfix"></div>
                    `);
                    
                    
                    
                }else{
                    // generate_user_message(msg[index].message_body, 'self'); //user side messages
                    // generate_user_message1(msg[index].message_body, 'user', msg[index].message_time);
                    $("#admin-chat-box").append(`
                            <div id="am-msg-${adminINDEX}" class="card no-border d-inline-block my-20 float-start me-2 no-shadow max-w-p80">										  
								
									<div class="mt-5 card-body p-15 bg-primary-light rounded10 d-inline-block">
										<div class="chat-text-start">
											<p class="mb-0 text-dark">${msg[index].message_body}</p>
										</div>
									</div>
										<p class="pe-5 mt-10 mb-0 fs-12 text-mute"><i class="me-5 fa fa-clock-o"></i>${msg[index].message_time}</p>
							  </div>
							  <div class="clearfix"></div>
                    `);
                }
            }
        }
        
    
    
	});
	
	request.fail(function(jqXHR, textStatus) {
	  console.log( "Request failed: " + textStatus );
	});
}


async function adminClicksUserChat(e){
    console.log(e);
    e = $(e).attr("data");
    console.log(e);
    current_user = e;
    $("#currentChatUser").text(current_user);
    $("#no-chat-open").hide();
    $("#yes-chat-open").show();
    $("#admin-chat-box").empty();
    userLength = 0;
    populateAdminChat(e, true, false);
    
    
}

function enter(e){
    userLength++;
    console.log(e);
    console.log(e.keyCode);
    console.log(e.which);
    var code = (e.keyCode ? e.keyCode : e.which);
    if(code == 13) { //Enter keycode
        // alert('enter press');
        let message = $("#admin-chat-input").val();
        $("#admin-chat-input").val("");
        adminSendsMsg(current_user, message);
        $("#admin-chat-box").append(`
            <div id="am-msg-${adminINDEX}" class="card no-border d-inline-block my-20 text-end float-end me-2 no-shadow max-w-p80">										  
				<div class="mt-5 card-body p-15 bg-primary-light rounded10 d-inline-block">
					<div class="chat-text-start">
						<p class="mb-0 text-dark">${message}</p>
					</div>
				</div>
				<p class="pe-5 mt-10 mb-0 fs-12 text-mute"><i class="me-5 fa fa-clock-o"></i>Just now</p>
			</div>
			<div class="clearfix"></div>
        `);
    }
}


function adminSendsNotification(message){
    
	var request = $.ajax({
		type: "POST",
		url: "https://bountybox.io/mysql/script.php",
		data: {adminSendsNotification: true, message: message},
		dataType: "html"
	});
	
	request.done(function(msg) {
    	console.log(msg);
    	console.log(typeof msg);
		
    	if(msg == "error"){
    	    console.log("Error occured on backend");
        	return;
        }
    
    // 	msg = JSON.parse(msg);
	   // msg = msg.reverse();
	});
	
	request.fail(function(jqXHR, textStatus) {
	  console.log( "Request failed: " + textStatus );
	});
}





/*
************ ON DOCUMENT LOAD ************
*/
$(document).ready(async function(){
    
    console.log("Document loads...");

    // getUserList();




	//----------------------------WALLET CONNECT ----------------------------------

    $(".wallet-connect-btn").click(async function(e){
        console.log(e);
        e.preventDefault();
        console.log("Wallet Connect clicked...");
        await walletConnect();
        let _connectedAddress = CONNECTED_ADDRESS.replace(CONNECTED_ADDRESS.substring(5, 38), "***");
        $(".wallet-connect-btn").html(_connectedAddress);
    });


	$("#regUser").click(async function(e){
    
    
    	// c
    	console.log("registration call");
    
    });


	

    
});




