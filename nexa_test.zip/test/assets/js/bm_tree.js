    <div id="treechart"  class="panel"></div>
    <div id="tooltip"   ></div>
    <script src="d3.v3.min.js"></script>
    <script>
// ************** Generate the tree diagram	 *****************
function initial()
{
	treeData;
	margin = {top: 30, right: 80, bottom: 30, left: 80},
	width = 1110 - margin.right - margin.left,
	height = 800 - margin.top - margin.bottom;
	
	i = 0;
	duration = 750;

	tree = d3.layout.tree()
		.size([height, width]);

	diagonal = d3.svg.diagonal()
		.projection(function(d) { return [d.y, d.x]; });

	svg = d3.select("#treechart").append("svg")
		.attr("width", width + margin.right + margin.left)
		.attr("height", height + margin.top + margin.bottom)
		.append("g")
		.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

	d3.select(self.frameElement).style("height", "800px");
	root = treeData[0];
	root.x0 = height / 2;
	root.y0 = 0;
	update(root);
}
   
getData(document.getElementById('userid').innerHTML,0);
function getData(_id,onlyone)
{
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() 
	{
		if (this.readyState == 4 && this.status == 200)
		{
			treeData = JSON.parse(this.responseText);
			initial();
		}
	};
	xhttp.open("POST", "https://billionmoney.live/office/d3chart.php", true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhttp.send("id=" + _id + "&onlyone="+onlyone);
}


function update(source) {
	
  // Compute the new tree layout.
  var nodes = tree.nodes(root).reverse(),
	  links = tree.links(nodes);

  // Normalize for fixed-depth.
  nodes.forEach(function(d) { d.y = d.depth * 110; });

  // Update the nodes…
  var node = svg.selectAll("g.node")
	  .data(nodes, function(d) { return d.id || (d.id = ++i); });

  // Enter any new nodes at the parent's previous position.
  var nodeEnter = node.enter().append("g")
	  .attr("class", "node")
	  .attr("transform", function(d) { return "translate(" + source.y0 + "," + source.x0 + ")"; })
	  .on("click", click)
	  .on("mouseover", mouseover)
	  .on("mouseleave", mouseleave);

  nodeEnter.append("circle")
	  .attr("r", 1e-6)
	  .style("fill", function(d) { return d._children ? "lightsteelblue" : "#fff"; })


            nodeEnter.append('text').attr("dy", ".35em").attr("x", function(d) {
                return d.children || d._children ? -15 : -15;
            }).attr("text-anchor", function(d) {
                return d.children || d._children ? "end" : "end";
            }).text(function(d) {
                return "ID:" + d.name;
            });
            nodeEnter.append('text').attr("dy", ".35em").attr("x", function(d) {
                return -5;
            }).text(function(d) {
                return d.level;
            });



  // Transition nodes to their new position.
  var nodeUpdate = node.transition()
	  .duration(duration)
	  .attr("transform", function(d) { return "translate(" + d.y + "," + d.x + ")"; });

  nodeUpdate.select("circle")
	  .attr("r", 8)
	  .style("fill", function(d) { return d._children ? "lightsteelblue" : "#fff"; });

  nodeUpdate.select("text")
	  .style("fill-opacity", 1);

  // Transition exiting nodes to the parent's new position.
  var nodeExit = node.exit().transition()
	  .duration(duration)
	  .attr("transform", function(d) { return "translate(" + source.y + "," + source.x + ")"; })
	  .remove();

  nodeExit.select("circle")
	  .attr("r", 1e-6);

  nodeExit.select("text")
	  .style("fill-opacity", 1e-6);

  // Update the links…
  var link = svg.selectAll("path.link")
	  .data(links, function(d) { return d.target.id; });

  // Enter any new links at the parent's previous position.
  link.enter().insert("path", "g")
	  .attr("class", "link")
	  .attr("d", function(d) {
		var o = {x: source.x0, y: source.y0};
		return diagonal({source: o, target: o});
	  });

  // Transition links to their new position.
  link.transition()
	  .duration(duration)
	  .attr("d", diagonal);

  // Transition exiting nodes to the parent's new position.
  link.exit().transition()
	  .duration(duration)
	  .attr("d", function(d) {
		var o = {x: source.x, y: source.y};
		return diagonal({source: o, target: o});
	  })
	  .remove();

  // Stash the old positions for transition.
  nodes.forEach(function(d) {
	d.x0 = d.x;
	d.y0 = d.y;
  });

}

// Toggle children on click.
function click(d) {
  	if(d.children == undefined && d._children == undefined)
	{
		if(treeData[0].name == d.name)
		{
			getData(d.name,1 );
		}
		else
		{
			getData(d.name,0);
		}
		document.getElementById('treechart').innerHTML ="";
		var ele = document.getElementById('tooltip')
		ele.innerHTML = ""
		ele.style.display = "none"		
	}
	else if(treeData[0].name != d.name)
	{
		if (d.children) {
			d._children = d.children;
			d.children = null;
		} else {
			d.children = d._children;
			d._children = null;
		}
		update(d);			
	}
	else if(d.name != 1)
	{
		getData(d.name,1 );
		document.getElementById('treechart').innerHTML ="";
		var ele = document.getElementById('tooltip')
		ele.innerHTML = ""
		ele.style.display = "none"		
	}

}


  // Three function that change the tooltip when user hover / move / leave a cell
  function mouseover(d) 
  {
	var ele = document.getElementById('tooltip')
	ele.innerHTML = levelTxt(d.detail,d.name)
	ele.style.top =(event.pageY - 125)+"px"
	ele.style.left =(event.pageX - 115)+"px"
	ele.style.display = "block"
  }


  // Three function that change the tooltip when user hover / move / leave a cell
  function mouseleave(d) 
  {
	var ele = document.getElementById('tooltip')
	ele.innerHTML = ""
	ele.style.display = "none"
  }


	function levelTxt(lvl,id)
	{
		var outTxt = '<div style="text-align:center;"> ID : ' + id + '</div>'
		outTxt += '<div style="text-align:center; margin-top:10px;"> <table>'
		for(var j=lvl.length;j>0;j--)
		{
			var d = new Date();
			var n = ((((d.getTime()/1000).toFixed(0)) - lvl[j-1]['days'] ) / 86400).toFixed(0);
			outTxt += '<tr><td>Lvl &nbsp; '+ lvl[j-1]['level'] + '&nbsp; : &nbsp; </td><td>  ' + n + ' &nbsp; d</td></tr>'		
		}
		return outTxt + '</table></div>'
	}    
    // ************** Generate the tree diagram	END *****************
    </script>