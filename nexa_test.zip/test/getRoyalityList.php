<?php 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('include_file/config.php');
include('include_file/function.php');

global $conn;







$dataQuery = "select * from reg_user";
$resultd = mysqli_query($conn,$dataQuery);

$row_count =mysqli_fetch_assoc($resultd);

echo mysqli_error($conn);
if ($row_count>0){


	while($rowdata= mysqli_fetch_assoc($resultd)){
    
    
    	if (getUserRefCount($rowdata['userWalletBase58'])){
        
        	echo "--------------Record---------------";echo "</br></br>";
        
        	    echo "UserID: - ".$rowdata['userID'];echo "</br>";
    			echo "Wallet: - ".$rowdata['userWalletBase58']; echo "</br>";
        
        	echo "</br>";
        
        }
    
 
   
    
    }


}




function getUserRefCount($user){

global $conn;


$query = "SELECT COUNT(referrerID) as direct FROM `reg_user` WHERE referrerID='$user' ";

$result = mysqli_query($conn,$query);

$row =mysqli_num_rows($result);

echo mysqli_error($conn);

if ($row>0){

	$row = mysqli_fetch_assoc($result);

	$direct = $row['direct'];


	if($direct>9){
    
    	
    	return 1;
    }

	return 0;
}

return 0;

}


?>

