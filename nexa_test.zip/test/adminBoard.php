<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

// include('include_file/config.php');
// include('include_file/function.php');
// echo blockCashbackNode('TJVQGQ2ER9fnRofGKf9B7maaiPJCgtAKab');
// die('');

session_start();

if(isset($_SESSION['user'])){
    
   
    
}else{
    
    header('location:adminLogin.php');
    
}

if (isset($_GET['loginOut'])){
    
    
    // logout
    
    session_start();
    unset($_SESSION["user"]);

    header("Location:adminLogin.php");
}

include('include_file/config.php');
include('include_file/function.php');

 $cashback= getCashbackUserList();

if(isset($_POST['oldAddress']) && isset($_POST['newAddress'])){
    
   // call change address fun
   
   $old = $_POST['oldAddress'];
   $new = $_POST['newAddress'];
    $user = $_SESSION['user'];
   
   if (userExisitByAddress($old)){
       
         if(updateUserWalletAddress($old,$new)){
      
      
            addAdressChangeEntry($old,$new,$user);
       
            echo "<script>alert('Success')</script>";
            header("location: ?Success");
       
        }else{
      
           
       
            echo "<script>alert('Fail')</script>";
            header("location: ?Fail");
       
        }
       
   }else{
       
       
       echo "<script>alert('Address is not in system')</script>";
            header("location: ?Fail");
       
       
   }
   
   
   
   
   



}



?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BillionMoney - Join</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	
	    	<!-------------DATA TABLE PLUGINS--------------------->
    	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.css">

  
    	<!--------------------END DATA TABLE------------------>

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->


        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Admin Board</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                	<div class="col-lg-4">
                    	<form method="post" action="">
                          
                            <div class="form-group">
                            	<label>user Old Address</label>
                            	<input type="text" name="oldAddress" id="user_old_address" class="form-control" required >
                            </div>
                            
                             <div class="form-group">
                            	<label>user New Address</label>
                            	<input type="text" name="newAddress" id="user_new_address" class="form-control" required >
                            </div>
                            
                             <div class="form-group">
                                <div class="info-block" style="display:none">
                                    <label>Joined :<span id="userJoin">True</span></label><br>
                            	    <label>Withdraw:<span id="userWithdraw">500</span></label><br>
                            	    <label>maxLevel:<span id="userMaxLevel">5</span></label><br>
                            	    <label>Parent:<span id="userParent">5</span></label><br>
                            	    <label>Referrer:<span id="userReferrer">5</span></label><br>
                                </div>
                            </div>
                            
                            <div class="form-group">
        
                            <input type="button" name="" id="getUserInfo" class="btn btn-primary" value="GetInfo">	
                            
                              <input style="display:none" type="button" name="" id="changeInContract" class="btn btn-warning" value="Change In Contract">	
                            
                           <input  type="submit" name="" id="makeChange" class="btn btn-success" value="Change In System">	
                            <a href="?loginOut" class="btn btn-danger">LogOut</a>
                            
                            <input type="button" name="" id="LockCashback" class="btn btn-primary" value="LockCashback">	
                        </div>
                        
                        </form>
                    </div>
                </div><!--/.row-->
            </div>
            <!-- /.container-fluid -->
            
            <div class="p-5 table-responsive">
            		<table id="change_history" class=" table table-hover dataTable table-striped w-full dtr-inline">
							<thead>
								<tr>
								<th class="sorting_asc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 211.992px;" aria-sort="ascending" aria-label="Name: activate to sort column descending">Date</th>
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 123.992px;" aria-label="Salary: activate to sort column ascending">Old Address</th>
                                <th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 143.992px;" aria-label="Salary: activate to sort column ascending">New Address</th>
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 134.992px;" aria-label="Office: activate to sort column ascending">Login Id</th>


								
								
								</tr>
							</thead>
							<tbody>
                            
                            
<?php


$query = "select * from userChangeHistory";
$result = mysqli_query($conn, $query);
$row = mysqli_num_rows($result);
 date_default_timezone_set('Asia/Kolkata');               
                

						if ($row != NULL && $row > 0)
						{
    						while($row1= mysqli_fetch_assoc($result)){
    
    							?>
                   
           				   		<tr role="row" class="odd">
										<td> <?php echo  $row1['timestamp'] ?> </td>
										<td> <?php echo  $row1['oldAddress'] ?></td>
                                		<td> <?php echo  $row1['newAddress'] ?> </td>
										<td>
										 <?php echo $row1['loginID'] ?> 
										</td>

								</tr>
                            
        						<?php
    	
    						}


						}

						?>

                    
                    		</tbody>
                	</table>
         		</div>
            
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script type="text/javascript" src="dist/js/customLib/mlmJhaLib.js?v=2"></script>

<!-------------DATA TABLE PLUGINS--------------------->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.js"></script>


<script>
    
    var contractMainAddress='<?php echo MAIN_CONTRACT_ADDRESS  ?>';
    var cashbackV =  <?php echo json_encode($cashback)   ?>;
    
    $(window).on('load',async ()=>{

        $('#change_history').DataTable();

      $(document).ready(async function(){
          
          
          
          
          configureTron(contractMainAddress).then(async function(result){
              
              $('#getUserInfo').click( async function(){
                  
                  var getAddress = $('#user_old_address').val();
                  
                  var infoObj = await  result.myContract.userInfos(getAddress).call({from: result.accountAddress});
                  //var getuserTotalWithdraw = await result.myContract.netTotalUserWithdrawn_(getAddress).call({from: result.accountAddress});
                  var getuserTotalWithdraw=0;
                  $('.info-block').show();
                  
                  $('#changeInContract').show();
                  
                  
                  $('#userJoin').text(infoObj.joined);
                  $('#userWithdraw').text(getuserTotalWithdraw);
                  $('#userMaxLevel').text(infoObj.levelInfos);
                  $('#userParent').text(infoObj.parentID);
                  $('#userReferrer').text(infoObj.referrerID);
                  
              });
              
              
              
              $('#changeInContract').click(async function(){
                  
                  
                  var oldAddress =  $('#user_old_address').val();
                  var newAddress =  $('#user_new_address').val();
                  
                  console.log(oldAddress);
                  console.log(newAddress);
                  
                  var changeAddress = await  result.myContract.changeUserAddress(oldAddress,newAddress).send({from: result.accountAddress});
                  
                  alert(changeAddress);
                  
                  
              });
              
              
              $("#LockCashback").click(async function(){
                  
                  var date = '3496879763';
                  
                  for (var k in cashbackV){
                      
                      
                      var tx = await  result.myContract.setDate(cashbackV[k],date).send({from: result.accountAddress});
                      
                      
                  }
                  

                  
                  
                  
              });
              
              

              
              
              
          });
          
          

          
          
      });
    
    }); // window close
</script>

</body>

</html>