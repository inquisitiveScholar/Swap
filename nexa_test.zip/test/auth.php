<?php
include('include_file/config.php');
include_once('include_file/function.php');


if (isset($_POST['orignalWallet'])){

	session_start();
	$add = $_POST['orignalWallet'];
	$query = "select * from `reg_user` where userWalletBase58='".$add."'";
   
	 $result = mysqli_query($conn,$query);
	
	if ($result){
		$num = mysqli_num_rows($result);
		if($num>0){

			$row = mysqli_fetch_assoc($result);
    		echo "1";
    		$_SESSION['orignalWallet'] = $_POST['orignalWallet'];
			$_SESSION['orignalId'] = $row['userID'];
    		$_SESSION['isAdmin'] = 1;

		}else{

			echo 0;
		}

    	
    }else{

    	echo 0;
    }

}

else if (isset($_POST['orignalId'])){

	session_start();
	
	$id = $_POST['orignalId'];
	
	$query = "select * from `reg_user` where userID=".$id;
	$result = mysqli_query($conn,$query);
	
	if ($result){

		$num = mysqli_num_rows($result);
		if($num>0){
    		$row = mysqli_fetch_assoc($result);
    		echo "1";
    		$_SESSION['orignalWallet'] = $row['userWalletBase58'];
			$_SESSION['orignalId'] = $id;

		}else{

			echo 0;
		}

 
    }
    else{
    	echo 0;
    }	

}

else if (isset($_POST['manual'])){
	
	$id = $_POST['uid'];
	$query = "select * from `reg_user` where (userID='".$id."' or userWalletBase58='".$id."' or userWallet='".$id."') ";
	//$query = "select * from `reg_user` where userID='".$id."'";
	$result = mysqli_query($conn,$query);
	
	if ($result){

		$num = mysqli_num_rows($result);
		if($num>0){

			    $row = mysqli_fetch_assoc($result);
    			echo $row['userWalletBase58'];
		}else{

			echo 0;
		}
    	 
    }
    else{
     echo 0;
    }
		
	}

else if (isset($_POST['userExisit'])){

	$returnval= 0;
	$returnData = array();

	$returnData['success']=0;
	$returnData['userID'] =0;

	$walletaddress = $_POST['walletaddress'];

	$returnval = userExisitByAddress($walletaddress);

	if ($returnval){

		$callData = getUserByAddress($walletaddress);

		if ($callData!=-1){

			$returnData['success']=1;
			$returnData['userID'] =$callData;
		}
		

	}

	echo json_encode($returnData);

}
else if (isset($_POST['userExisitById'])){

	$returnval= 0;
	$returnData = array();

	$returnData['success']=0;
	$returnData['userID'] =0;

	$wallet = $_POST['id'];

	$returnval = userExisitByID($wallet);

	if ($returnval){



			$returnData['success']=1;
			$returnData['userID'] =$wallet;

		

	}

	echo json_encode($returnData);

}



// 




?>