<?php 

include("include_file/config.php");




$ref_val='';

if(isset($_GET['ref'])){

	$ref_val= $_GET['ref'];


}


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <link rel="shortcut icon" type="image/x-icon" href="_next/static/images/favicon-ec2551afb2782a53fb493269d1ba4efe.png" />

  <title>NEXADAI | A 100% Blockchain decentrlized Fastest Earning program</title>
  <meta name="Description" content="" />
  <meta content="" name="keywords">

  <!-- Favicons -->
	<link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
	<link rel="manifest" href="favicon/site.webmanifest">
	<link rel="mask-icon" href="favicon/safari-pinned-tab.svg" color="#5bbad5">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="theme-color" content="#ffffff">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link rel="stylesheet" href="assets/font/kit-free.fontawesome.com/releases/latest/css/free.min.css" media="all">
  <link rel="stylesheet" href="assets/font/kit-free.fontawesome.com/releases/latest/css/free-v4-shims.min.css" media="all">
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">


	<link href="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/css/alertify.min.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="vendor/countdowntime/flipclock.css">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <a href="index.html"><img src="assets/images/logo/logoh-1.png" alt="" class="img-fluid"></a>
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li <?php echo $ref_val==''?'class="active"':''?> ><a href="#header">Home</a></li>
          <li><a href="#whyus">Why Us</a></li>
          <li><a href="#features">Our Features</a></li>
          <li><a href="#wallet">Wallets</a></li>
          <li><a href="#Opportunity">Opportunity</a></li>
          <li><a href="#faq">F.A.Q</a></li>
          <li <?php echo $ref_val!=''? 'class="active"':''?> ><a href="#regSection" id="regClick">Registration</a></li>

          <li class="get-started"><a href="" class="wallet-connect-btn" onclick="logFun(this);">Connect Wallet</a></li>
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->
  

  <!-- ======= Hero Section ======= -->
       <div id="hero" class="d-flex align-items-center eOyQPJ">
					<div class="style__ContainerWrapper-sc-1gre7ok-0 dizzRb container">
						<div class="bannerstyle__BannerContent-wawrb0-1 exOxCx">
							<div class="react-reveal">
								<h1 font-weight="bold" class="Heading__HeadingWrapper-vaqy1n-0 doYuXI">Welcome to the worlds most leading Earning Community</h1>
							</div>
							<div class="react-reveal">
								<p class="Text__TextWrapper-sc-15lufec-0 btIKJt">Join our community and make yourself financially free with NEXADAI decentralized program.</p>
							</div>
							<div class="react-reveal">
								<div class="bannerstyle__ButtonGroup-wawrb0-4 icbELA">
									<a href="https://polygonscan.com/" target="new">
										<span>
											<img src="assets/images/img/poly.png" alt="Nexadai" style="max-width:20%; margin: 0px 26px 29px 0px;; transform: translate(-0.72335px, 2.98665px);"><span class="front-text">WEB 3.0 </span>
										</span>
									</a>
								</div>

							</div>

						</div>
						<div class="bannerstyle__BannerImage-wawrb0-3 fzTDqq">
							<div class="react-reveal">
								<img src="assets/images/img/img-4.svg" alt="Banner" class="Image__ImageWrapper-xwdy9p-0 cBdvla">
							</div>
						</div>

					</div>

				</div>

				<div class="container ">
						<div class="col-xl-12 align-items-stretch order-2 order-lg-2">
							  <div class="row">
								<div class="col-md-4 col-sm-6 pt-5 mt-4 text-center" data-aos="fade-down">
								 <h1>Launching Soon</h1>
								</div>
								<div class="col-md-8 col-sm-6 mt-5" data-aos="fade-down" data-aos-delay="100" >

								   <div class="cd100 d-flex justify-content-center">ghhhh</div> 
								</div>
								
							  </div>
						</div>
				</div>

 <!-- End Hero -->
 
  <section class="featuresstyle__SectionWrapper-sc-6ox25b-0 jIufFD">
        <div class="section-title" data-aos="fade-up">
       
          <h3>How to Get  <span>Start</span></h3>
          <p>Simply follow the step and enroll your self</p>
        </div>
		<div class="style__ContainerWrapper-sc-1gre7ok-0 dizzRb container">
		<div class="row order-2 order-lg-1">
			<div class="featuresstyle__FeatureWrapper-sc-6ox25b-1 eoAGTk" >
				<div class="react-reveal  " style="animation-fill-mode: both; animation-duration: 1000ms; animation-delay: 200ms; animation-iteration-count: 1; opacity: 1; animation-name: react-reveal-233058586026039-2;">
					<div class="featureBlockstyle__FeatureBlockWrapper-sc-1pllarm-0 dcTHTR feature__block icon_left aos-animate" data-aos="fade-up" style="--color:#3DABDD">
						<div class="featureBlockstyle__IconWrapper-sc-1pllarm-1 iGbins icon__wrapper"><i fill="currentColor" style="display:inline-block" class="plus"><svg fill="currentColor" style="display:inline-block;vertical-align:middle" height="16" width="16" viewBox="0 0 24 24"><path d="M18 10h-4v-4c0-1.104-.896-2-2-2s-2 .896-2 2l.071 4h-4.071c-1.104 0-2 .896-2 2s.896 2 2 2l4.071-.071-.071 4.071c0 1.104.896 2 2 2s2-.896 2-2v-4.071l4 .071c1.104 0 2-.896 2-2s-.896-2-2-2z"></path></svg></i><i fill="currentColor" style="display:inline-block" class="circle"><svg fill="currentColor" style="display:inline-block;vertical-align:middle" height="16" width="16" viewBox="0 0 24 24"><path d="M12 8c2.205 0 4 1.794 4 4s-1.795 4-4 4-4-1.794-4-4 1.795-4 4-4m0-2c-3.314 0-6 2.686-6 6 0 3.312 2.686 6 6 6 3.312 0 6-2.688 6-6 0-3.314-2.688-6-6-6z"></path></svg></i>
							<img src="assets/images/icon/wallet.png" alt="10 Times Award" class="Image__ImageWrapper-xwdy9p-0 cBdvla"><i fill="currentColor" style="display:inline-block" class="star"><svg fill="currentColor" style="display:inline-block;vertical-align:middle" height="16" width="16" viewBox="0 0 24 24"><path d="M16.855 20.966c-.224 0-.443-.05-.646-.146l-.104-.051-4.107-2.343-4.107 2.344-.106.053c-.488.228-1.085.174-1.521-.143-.469-.34-.701-.933-.586-1.509l.957-4.642-1.602-1.457-1.895-1.725-.078-.082c-.375-.396-.509-.97-.34-1.492.173-.524.62-.912 1.16-1.009l.102-.018 4.701-.521 1.946-4.31.06-.11c.262-.473.764-.771 1.309-.771.543 0 1.044.298 1.309.77l.06.112 1.948 4.312 4.701.521.104.017c.539.1.986.486 1.158 1.012.17.521.035 1.098-.34 1.494l-.078.078-3.498 3.184.957 4.632c.113.587-.118 1.178-.59 1.519-.252.182-.556.281-.874.281zm-8.149-6.564c-.039.182-.466 2.246-.845 4.082l3.643-2.077c.307-.175.684-.175.99 0l3.643 2.075-.849-4.104c-.071-.346.045-.705.308-.942l3.1-2.822-4.168-.461c-.351-.039-.654-.26-.801-.584l-1.728-3.821-1.726 3.821c-.146.322-.45.543-.801.584l-4.168.461 3.1 2.822c.272.246.384.617.302.966z"></path></svg></i>
						</div>
						<div class="featureBlockstyle__ContentWrapper-sc-1pllarm-2 eULayP content__wrapper white">
							<h3 font-weight="bold" class="Heading__HeadingWrapper-vaqy1n-0 doYuXI">CHOOSE WALLET</h3>
							<p class="Text__TextWrapper-sc-15lufec-0 btIKJt">Downloade your decentralized wallet</p>
						</div>
					</div>
				</div>
				<div class="react-reveal " style="animation-fill-mode: both; animation-duration: 1000ms; animation-delay: 200ms; animation-iteration-count: 1; opacity: 1; animation-name: react-reveal-233058586026039-2;">
					<div class="featureBlockstyle__FeatureBlockWrapper-sc-1pllarm-0 dcTHTR feature__block icon_left aos-animate" data-aos="fade-up"  style="--color:#3DABDD">
						<div class="featureBlockstyle__IconWrapper-sc-1pllarm-1 iGbins icon__wrapper"><i fill="currentColor" style="display:inline-block" class="plus"><svg fill="currentColor" style="display:inline-block;vertical-align:middle" height="16" width="16" viewBox="0 0 24 24"><path d="M18 10h-4v-4c0-1.104-.896-2-2-2s-2 .896-2 2l.071 4h-4.071c-1.104 0-2 .896-2 2s.896 2 2 2l4.071-.071-.071 4.071c0 1.104.896 2 2 2s2-.896 2-2v-4.071l4 .071c1.104 0 2-.896 2-2s-.896-2-2-2z"></path></svg></i><i fill="currentColor" style="display:inline-block" class="circle"><svg fill="currentColor" style="display:inline-block;vertical-align:middle" height="16" width="16" viewBox="0 0 24 24"><path d="M12 8c2.205 0 4 1.794 4 4s-1.795 4-4 4-4-1.794-4-4 1.795-4 4-4m0-2c-3.314 0-6 2.686-6 6 0 3.312 2.686 6 6 6 3.312 0 6-2.688 6-6 0-3.314-2.688-6-6-6z"></path></svg></i>
							<img src="assets/images/icon/browser.png" alt="10 Times Award" class="Image__ImageWrapper-xwdy9p-0 cBdvla"><i fill="currentColor" style="display:inline-block" class="star"><svg fill="currentColor" style="display:inline-block;vertical-align:middle" height="16" width="16" viewBox="0 0 24 24"><path d="M16.855 20.966c-.224 0-.443-.05-.646-.146l-.104-.051-4.107-2.343-4.107 2.344-.106.053c-.488.228-1.085.174-1.521-.143-.469-.34-.701-.933-.586-1.509l.957-4.642-1.602-1.457-1.895-1.725-.078-.082c-.375-.396-.509-.97-.34-1.492.173-.524.62-.912 1.16-1.009l.102-.018 4.701-.521 1.946-4.31.06-.11c.262-.473.764-.771 1.309-.771.543 0 1.044.298 1.309.77l.06.112 1.948 4.312 4.701.521.104.017c.539.1.986.486 1.158 1.012.17.521.035 1.098-.34 1.494l-.078.078-3.498 3.184.957 4.632c.113.587-.118 1.178-.59 1.519-.252.182-.556.281-.874.281zm-8.149-6.564c-.039.182-.466 2.246-.845 4.082l3.643-2.077c.307-.175.684-.175.99 0l3.643 2.075-.849-4.104c-.071-.346.045-.705.308-.942l3.1-2.822-4.168-.461c-.351-.039-.654-.26-.801-.584l-1.728-3.821-1.726 3.821c-.146.322-.45.543-.801.584l-4.168.461 3.1 2.822c.272.246.384.617.302.966z"></path></svg></i>
						</div>
						<div class="featureBlockstyle__ContentWrapper-sc-1pllarm-2 eULayP content__wrapper">
							<h3 font-weight="bold" class="Heading__HeadingWrapper-vaqy1n-0 doYuXI">OPEN DAPP</h3>
							<p class="Text__TextWrapper-sc-15lufec-0 btIKJt">Go your DApp browser in your wallet</p>
						</div>
					</div>
				</div>
				<div class="react-reveal" style="animation-fill-mode: both; animation-duration: 1000ms; animation-delay: 200ms; animation-iteration-count: 1; opacity: 1; animation-name: react-reveal-233058586026039-2;">
					<div class="featureBlockstyle__FeatureBlockWrapper-sc-1pllarm-0 dcTHTR feature__block icon_left aos-animate" data-aos="fade-up" style="--color:#3DABDD">
						<div class="featureBlockstyle__IconWrapper-sc-1pllarm-1 iGbins icon__wrapper"><i fill="currentColor" style="display:inline-block" class="plus"><svg fill="currentColor" style="display:inline-block;vertical-align:middle" height="16" width="16" viewBox="0 0 24 24"><path d="M18 10h-4v-4c0-1.104-.896-2-2-2s-2 .896-2 2l.071 4h-4.071c-1.104 0-2 .896-2 2s.896 2 2 2l4.071-.071-.071 4.071c0 1.104.896 2 2 2s2-.896 2-2v-4.071l4 .071c1.104 0 2-.896 2-2s-.896-2-2-2z"></path></svg></i><i fill="currentColor" style="display:inline-block" class="circle"><svg fill="currentColor" style="display:inline-block;vertical-align:middle" height="16" width="16" viewBox="0 0 24 24"><path d="M12 8c2.205 0 4 1.794 4 4s-1.795 4-4 4-4-1.794-4-4 1.795-4 4-4m0-2c-3.314 0-6 2.686-6 6 0 3.312 2.686 6 6 6 3.312 0 6-2.688 6-6 0-3.314-2.688-6-6-6z"></path></svg></i>
							<img src="assets/images/icon/pay.png" alt="Cloud Storage" class="Image__ImageWrapper-xwdy9p-0 cBdvla">
							<i fill="currentColor" style="display:inline-block" class="star"><svg fill="currentColor" style="display:inline-block;vertical-align:middle" height="16" width="16" viewBox="0 0 24 24"><path d="M16.855 20.966c-.224 0-.443-.05-.646-.146l-.104-.051-4.107-2.343-4.107 2.344-.106.053c-.488.228-1.085.174-1.521-.143-.469-.34-.701-.933-.586-1.509l.957-4.642-1.602-1.457-1.895-1.725-.078-.082c-.375-.396-.509-.97-.34-1.492.173-.524.62-.912 1.16-1.009l.102-.018 4.701-.521 1.946-4.31.06-.11c.262-.473.764-.771 1.309-.771.543 0 1.044.298 1.309.77l.06.112 1.948 4.312 4.701.521.104.017c.539.1.986.486 1.158 1.012.17.521.035 1.098-.34 1.494l-.078.078-3.498 3.184.957 4.632c.113.587-.118 1.178-.59 1.519-.252.182-.556.281-.874.281zm-8.149-6.564c-.039.182-.466 2.246-.845 4.082l3.643-2.077c.307-.175.684-.175.99 0l3.643 2.075-.849-4.104c-.071-.346.045-.705.308-.942l3.1-2.822-4.168-.461c-.351-.039-.654-.26-.801-.584l-1.728-3.821-1.726 3.821c-.146.322-.45.543-.801.584l-4.168.461 3.1 2.822c.272.246.384.617.302.966z"></path>
							</svg></i>
						</div>
						<div class="featureBlockstyle__ContentWrapper-sc-1pllarm-2 eULayP content__wrapper">
							<h3 font-weight="bold" class="Heading__HeadingWrapper-vaqy1n-0 doYuXI">MAKE PAYMENT</h3>
							<p class="Text__TextWrapper-sc-15lufec-0 btIKJt">Make your registration successfully</p>
						</div>
					</div>
				</div>

			</div>
		</div>

		
				<div class="col-xl-12 order-1 order-lg-2 mt-3 px-5">
					  <div class="row">
                      
						<div class="col-md-7 col-sm-6 mt-3" data-aos="fade-down">
						 <input type="text" class="referalBox" id="refInput"  name="" placeholder="Put Referral Address" value="<?php echo $ref_val ?>">
                        	
						</div>
                      
                      	<div class="col-md-2 col-sm-6 mt-3 text-center" >
                        		<div class="checkbox mt-3">
                                     <label>
                                         <input type="checkbox" id="freeRegStatus"> Without DAI 
                                     </label>
                                </div>
                      	</div>
                      
						<div class="col-md-3 col-sm-6 mt-3 text-center" data-aos="fade-down" data-aos-delay="100" id="regSection" >
							<a class="ml-2 shadow-lg" id="regBtnCall">
							<button type="button" class="buttonstyle__ButtonStyle-ntq24p-0 Lvpwin reusecore__button trail"><span class=" font-20">REGISTRATION</span>
							</button>
							</a>
						</div>
						
					  </div>
				</div>
		</div>

	</section>
	
  
  <main id="main">
    <!-- ======= App Features Section ======= -->
	<section id="whyus" class="why-us">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h3><span>Why</span> Nexadai</h3>
          <p>Everyone can have an honest income in an open and transparent system, keeping pace with advanced technology</p>
        </div>

        <div class="row no-gutters">
          <div class="col-xl-12 d-flex align-items-stretch order-2 order-lg-1">
            <div class="content d-flex flex-column justify-content-center center">
              <div class="row mx-5">
                <div class="col-md-4 icon-box" data-aos="fade-up">
                  <div class="featureBlockstyle__IconWrapper-sc-1pllarm-1 icon__wrapper">
						<img class="hnVRov " src="assets/images/icon/quick.svg">
				  </div>
                  <h4>Lowest Transaction Fee</h4>
                  <p>The DApp runs on Polygain Blockchain ecosystem with turns out to be lowest transaction fees along with lightning speed.</p>
                </div>
				<div class="col-md-4 icon-box" data-aos="fade-up" data-aos-delay="200">
                  <div class="featureBlockstyle__IconWrapper-sc-1pllarm-1 icon__wrapper">
						<img class="hnVRov " src="assets/images/icon/dollar.svg">
				  </div>
                  <h4>One Time Investment</h4>
                  <p>Start with only 45 DAI and earn unlimited Passive Global Pool income along with a lot of Active and Royalty income.</p>
                </div>
                <div class="col-md-4 icon-box" data-aos="fade-up" data-aos-delay="300">
                  <div class="featureBlockstyle__IconWrapper-sc-1pllarm-1 icon__wrapper">
						<img class="hnVRov " src="assets/images/icon/code.svg">
				  </div>
                  <h4>100% Decentralised</h4>
                  <p>Every Transaction interacts with our Smart Contract and Verfied on public decentrlized Polygobn Blockchain.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>	
	
    <section id="features" class="advantage">
      <div class="container">

        <div class="section-title">
          <h3><span>Advantages</span> of Nexadai</h3>
          <p>Open source smart contract provides their users to earn unlimited Passive and Active income by using Polygain Blockchain globally.</p>
        </div>

        <div class="row no-gutters">
          <div class="col-xl-7 d-flex align-items-stretch order-2 order-lg-1">
            <div class="content d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-down">
				  <img class="icon-img " src="assets/images/icon/blockchain.png">
                  <h4>Decentralized System</h4>
                  <p>It runs on Web 0.3 Polygain Blockchain, it is completely controlled by Smart Contract. No Human Intervention.</p>
                </div>
                
                <div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-up" data-aos-delay="200">
                  <img class="icon-img " src="assets/images/icon/dollar.png">
                  <h4>Global Platform</h4>
                  <p>It can be operated from anywhere in the world as long as you have a Mobile or a Computer/Laptop.</p>
                </div>
                <div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-up" data-aos-delay="400">
                  <img class="icon-img " src="assets/images/icon/win.png">
                  <h4>Passive Income</h4>
                  <p>Huge Opportunity to earn unlimited Passive Income from this blockchain program.</p>
                </div>
                <div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-up" data-aos-delay="500">
                  <img class="icon-img " src="assets/images/icon/reward.png">
                  <h4>Guaranteed Success</h4>
                  <p>This plan is designed keeping in mind guaranteed financial freedom who invests with 45 DAI.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="image col-xl-5 d-flex align-items-stretch justify-content-center order-1 order-lg-2 " data-aos="fade-up" data-aos-delay="100">
			  <div class="blockcain-img">
				<img src="assets/images/img/img-2.png" class="blockcain-img" alt="">
			  </div>
          </div>
        </div>

      </div>
    </section>
	
	
	 <section id="wallet" class="features">
      <div class="container">
        <div class="section-title" data-aos="fade-up">
          <h3>Choose Your <span>Wallet</span></h3>
          <p>Simply follow the step and enroll your self</p>
        </div>

        <div class="row no-gutters">
          <div class="col-xl-12 d-flex align-items-stretch order-2 order-lg-2 mx-3">
            <div class="content d-flex flex-column justify-content-center">
			
              <div class="row">
                <div class="col-md-3 col-sm-6 my-2 icon-box" data-aos="fade-down">
				  <a href="https://www.coinbase.com/wallet" target="blank" title="Coinbase Wallet"><img class="icon-img-1 " src="assets/images/wallet/coinbase.png"></a>
            
                </div>
                <div class="col-md-3 col-sm-6 my-2 icon-box" data-aos="fade-down" data-aos-delay="100" >
                  <a href="https://www.tokenpocket.pro/en" target="blank" title="Token Pocket"><img class="icon-img-1 " src="assets/images/wallet/tokenpocket.png"></a>
                  
                </div>
				<div class="col-md-3 col-sm-6 my-2 icon-box" data-aos="fade-down" >
				  <a href="https://trustwallet.com/" target="blank" title="Trust Wallet"><img class="icon-img-1 " src="assets/images/wallet/trust.png"></a>
                  
                </div>
                <div class="col-md-3 col-sm-6 my-2 icon-box" data-aos="fade-down" data-aos-delay="100" >
                  <a href="https://metamask.io/" target="blank" title="Metamask Walet"><img class="icon-img-1 " src="assets/images/wallet/metamask.png" alt="metamask"></a>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
	<!-- End App Features Section -->
	
	 <section id="Opportunity" class="wallet">
      <div class="container">

        <div class="section-title">
          <h2>Opportunity</h2>
          <p>Nexadai offers six Types of Income starting with just only 45 DAI</p>
        </div>

        <div class="row no-gutters">
			<div class="image col-xl-5 d-flex align-items-stretch justify-content-center order-1 order-lg-1 " data-aos="fade-left" data-aos-delay="100">
			  <div class="pt-5 mt-3">
			  <a class="blockcain-img">
				<img src="assets/images/img/img-3.png"  alt="Nexadai">
			  </a>
			  </div>
          </div>
          <div class="col-xl-7 d-flex align-items-stretch order-2 order-lg-2">
            <div class="content d-flex flex-column justify-content-center">
			
              <div class="row">
                <div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-down">
				  <img class="icon-img-1 " src="assets/images/icon/sponsor.png">
                  <h4>Sponsor Bonus</h4>
                  <p>No limit for sponsors income, so do more get repeated</p>
                </div>
                <div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-down" data-aos-delay="100">
                  <img class="icon-img-1 " src="assets/images/icon/level.png">
                  <h4>Uni-level Bonus</h4>
                  <p>Build your team of people and get multi-level income. </p>
                </div>
				<div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-down">
				  <img class="icon-img-1 " src="assets/images/icon/medal.png">
                  <h4>Gap Commision</h4>
                  <p>Work together and achieve gap-generation income quickly.</p>
                </div>
                <div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-down" data-aos-delay="100">
                  <img class="icon-img-1 " src="assets/images/icon/crown.png">
                  <h4>Royality Bonus</h4>
                  <p>Very easy to achieve royalty income make 10 direct and get.</p>
                </div>
				<div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-down">
				  <img class="icon-img-1 " src="assets/images/icon/fan-club.png">
                  <h4>Global Pool 2X</h4>
                  <p>Everyone achieves 15X passive income with a Global pool of 2X.</p>
                </div>
                <div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-down" data-aos-delay="100">
                  <img class="icon-img-1 " src="assets/images/icon/gold-bars.png">
                  <h4>Global Pool 3X</h4>
                  <p>Achieves unlimited passive income with a Global pool of 3X.</p>
                </div>
				<div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-down">
				  <img class="icon-img-1 " src="assets/images/icon/tree.png">
                  <h4>Pool Sponsor</h4>
                  <p>You will get additional sponsor income on sponsor's pool purchases</p>
                </div>
                <div class="col-md-6 col-sm-6 my-2 icon-box" data-aos="fade-down" data-aos-delay="100">
                  <img class="icon-img-1 " src="assets/images/icon/diamond.png">
                  <h4>Pool Royalty</h4>
                  <p>You will get additional pool royalty income on the sponsor's pool income.</p>
                </div>
                
                
				<div class="col-md-12 col-sm-12 my-2 icon-box text-center" data-aos="fade-up" data-aos-delay="300">
					<a href="#" target="new">
						<button type="button" class="buttonstyle__ButtonStyle-ntq24p-0 Lvpwin reusecore__button trail"><span class="btn-text font-20">Download Marketing Plan</span>
						</button>
					</a>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
	

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq">
      <div class="container">

        <div class="section-title">

          <h2>Frequently Asked Questions</h2>
          <p>Have Any Doubts? Find Your Answers Below</p>
        </div>

        <div class="accordion-list">
          <ul>
            <li data-aos="fade-up" class="lite">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" class="collapse" href="#accordion-list-1">What is Nexadai?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-1" class="collapse" data-parent=".accordion-list">
                <p>
                Nexadai is a multi-level concept of earning money by investing a small amount and also making a community of like-minded people ready to contribute. 
				It runs on polygon Blockchain Smart Contract system where the website is just an interface for the convenience of working with a smart contract.</p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="100" class="lite">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#accordion-list-2" class="collapsed">Who administers Nexadai?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-2" class="collapse" data-parent=".accordion-list">
                <p>
                There is no administrator. There is a creator who uploaded the contract code to the polygon blockchain. Since then, the smart contract has been part of the overall Blockchain network. No one has the right to affect the operation of a smart contract, delete it or stop it. Any attempt to make unauthorized changes will be rejected due to inconsistency with previous copies in the blockchain.</p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="200" class="lite">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#accordion-list-3" class="collapsed">What is polygo Blockchain?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-3" class="collapse" data-parent=".accordion-list">
                <p>
                Polygon is a Blockchain-based decentralized operating system based on a cryptocurrency native to the system, known as matic. Currently, It is the fastest growing Blockchain explorer in the World.</p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="300" class="lite">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#accordion-list-4" class="collapsed">How does Nexadaiair?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-4" class="collapse" data-parent=".accordion-list">
                <p>
               It follows a DApp wallet to wallet system of payment. Hence, there is no chance any money goes in the wrong hands as only the owner of the wallet has the key to access. </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="400" class="lite">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#accordion-list-5" class="collapsed">What is DApp (Decentralised Application)?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-5" class="collapse" data-parent=".accordion-list">
                <p>
                 <b>DApp</b> is an abbreviated form for decentralized application. A <b>DApp</b> has its backend code running on a decentralized peer-to-peer network. polygon Blockchain has its DApp Wallets
                </p>
              </div>
            </li>
			<li data-aos="fade-up" data-aos-delay="500" class="lite">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#accordion-list-6" class="collapsed">What Currency does Nexadai Work with?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-6" class="collapse" data-parent=".accordion-list">
                <p>
                Nexadai works with DAI stable crypto currency, it is one of the well-known crypto currencies in the world currently. </p>
              </div>
            </li>
			<li data-aos="fade-up" data-aos-delay="500" class="lite">
              <i class="bx bx-help-circle icon-help"></i> <a data-toggle="collapse" href="#accordion-list-6" class="collapsed">How do I participate in the Project?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="accordion-list-6" class="collapse" data-parent=".accordion-list">
                <p>
				It is enough to have a computer or a smartphone with an Metamask. We also advise you to install Telegram instant messenger for better communication amongst the community and also receive latest news, information etc. on our chat.</div>
            </li>
			

          </ul>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->



  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6 footer-contact" data-aos="fade-up">
		  <div class="footer-logo">
            <img src="assets/images/logo/logov-1.png" alt="Banner" class="">
		  </div >
		
              <strong>Chat:</strong> +1 5589 55488 55<br>
              <strong>Email:</strong> support@nexadai.io<br>
           
          </div>

          <div class="col-lg-4 col-md-6 footer-links" data-aos="fade-up" data-aos-delay="100">
            <h4>Useful Links</h4>
            <ul>
              
              <li><i class="bx bx-chevron-right"></i> <a href="#whyus">Why us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#Opportunity">Marketing Plan</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          

          <div class="col-lg-4 col-md-6 footer-links" data-aos="fade-up" data-aos-delay="300">
            <h4>Our Social Networks</h4>
            <p>kindly follow me on social media for latest updates.</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-telegram"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-youtube"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>
	<div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span>NEXADAI.IO</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        Contract Address: <a href="<?php echo $tronscanurl ?>address/"><?php echo $mainContractAddress  ?></a>
      </div>
    </div>
  </footer>
	<!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
        
     <?php include_once("include_file/contractInfo.php"); ?>
        
      <script src="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/alertify.min.js"></script>
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

      <script src="vendor/countdowntime/flipclock.min.js"></script>
    <script src="vendor/countdowntime/moment.min.js"></script>
    <script src="vendor/countdowntime/moment-timezone.min.js"></script>
    <script src="vendor/countdowntime/moment-timezone-with-data.min.js"></script>
    <script src="vendor/countdowntime/countdowntime.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/web3/1.3.5/web3.min.js" integrity="sha512-S/O+gH5szs/+/dUylm15Jp/JZJsIoWlpSVMwT6yAS4Rh7kazaRUxSzFBwnqE2/jBphcr7xovTQJaopiEZAzi+A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
 
 <script src="controller.js?v=52.7"></script>
        


		


    <script>
        
        var refTrigger = '<?php echo $ref_val ?>';
		
		if (refTrigger!=''){
        
        	$('#regClick').click();
        	console.log("switched");
        }
        
        var CONNECTED_ADDRESS_ =null;
		var mContract =contractMainAddress;



        $('.cd100').countdown100({
            /*Set Endtime here*/
            /*Endtime must be > current time*/
            endtimeYear: 0,
            endtimeMonth: 0,
            endtimeDate: 2,
            endtimeHours: 17,
            endtimeMinutes: 0,
            endtimeSeconds: 0,
            timeZone: ""
            // ex:  timeZone: "America/New_York"
            //go to " http://momentjs.com/timezone/ " to get timezone
        });



// var countDownDate = new Date("january 21, 2023 17:00:00").getTime();

// var x = setInterval(function() {

 
//   var now = new Date().getTime();

 
//   var distance = countDownDate - now;

//   var days = Math.floor(distance / (1000 * 60 * 60 * 24));
//   var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
//   var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
//   var seconds = Math.floor((distance % (1000 * 60)) / 1000);

//   document.getElementById("divident").innerHTML = days + " DAY  " + hours + ":"
//   + minutes + ":" + seconds + " ";

//   if (distance < 0) {
//     clearInterval(x);
//     document.getElementById("divident").innerHTML = "";
//   }
// }, 1000);







     async function  logFun(e){
      
     	// alert("Clicked");

        	
        	await walletConnect();
        	let _connectedAddress = CONNECTED_ADDRESS_.replace(CONNECTED_ADDRESS_.substring(5, 38), "***");
        	$(".wallet-connect-btn").html(_connectedAddress);
           
     }
      
      
   async function walletConnect(){
    
    instance = await initIDO();
   
   
    console.log(instance);
 
    // location.reload();
    console.log(instance);

   if (instance.join){
  
   	// instance.userId;
   		// eligible for login 
   
       let _connectedAddress = CONNECTED_ADDRESS_.replace(CONNECTED_ADDRESS_.substring(5, 38), "***");
    $(".wallet-connect-btn").html(_connectedAddress);
   
   
                      	var expires = "expires=Session";
                   		var now = new Date();
                   		now.setTime(now.getTime() + 1 * 3600 * 1000);
         
                  		document.cookie = "userWallet="+CONNECTED_ADDRESS_+"; expires=" + now + "; path=/";
                
                 		document.cookie = "userID="+instance.userId+"; expires=" + now.toUTCString() + "; path=/";
                 		// location.reload();
   						var tmp = "https://nexadai.io/test/dashboard/";
                		var redirect = tmp;
                 		window.location.href = redirect;
   
   
   
   
   
   
   }else{
   
   
   		// if not then remove 
   
   
   		                  alertify.alert("Login Failed", "Please Register First. ", function(){

        });
   
   }
   
      
   
}
      
      
      
      async function initIDO(){
       window.web3 = new Web3(ethereum);
       await ethereum.enable();
      
		//window.ethereum.chainId == 137 || 
        if(window.ethereum.chainId==80001  ){
                        // || window.ethereum.chainId == "0x38"
           
        	console.log("running support");
            web3 =  new Web3(Web3.givenProvider || new Web3.providers.HttpProvider('https://polygon-rpc.com/'));
            console.log("should work now");
            console.log(web3);
            try{
                await ethereum.enable();
            }catch(error){
                console.log("Cant enable ethereum");
            alert("chain issue");
               
                // initIDO();
            }
            let action = await ethereum.enable();
            let obj = await idoObject();
            return obj;
        }else{
        
        	        alertify.alert("Different Chain", "Please Change Network", function(){

        });
        	console.log("testing");
            //notify.error("<span style='font-size:1.7rem;font-weight:800;color:white'>Change network to Binance Smart Chain Mainnet</span>");
        }
            

}
      
      
      async function idoObject() {
      
    let obj = {
        idoContract: 0,
        metaMaskAddress: 0,
    	join:0,
    	userId:0
    }
    try{
        let metaMaskAddress = await web3.eth.getAccounts();
        metaMaskAddress = metaMaskAddress[0];
    	console.log(arrayABI);
    	console.log(contractMainAddress);
        const idoContract = new web3.eth.Contract(arrayABI,contractMainAddress); 
        CONNECTED_ADDRESS_ = metaMaskAddress;
        console.log(CONNECTED_ADDRESS_);
    
    	
    
    	// get user obj 
    	// check its referal joined
    
    	var oldObj = await  idoContract.methods.userInfos(CONNECTED_ADDRESS_).call({from:CONNECTED_ADDRESS_});
    
    	console.log(oldObj);
    
    	var referal  = oldObj.referral;
    
    	var joined =  await  idoContract.methods.userInfos(referal).call({from:CONNECTED_ADDRESS_});
    
    	 console.log(joined);
    
    	if(referal!="0x0000000000000000000000000000000000000000" ||  oldObj.id==1 || metaMaskAddress=="0x2B2FE21A85B033c3E64DF5861c08f5C3504c0c30" ){
        
        	obj.join=1;
        	obj.userId=oldObj.id;
        }
    
        // obj.idoContract = idoContract;
        obj.metaMaskAddress = metaMaskAddress;
       
        return obj;
    }
    catch(error){
        alert(error);
    }
    return obj;
}






















</script>

</body>

</html>
