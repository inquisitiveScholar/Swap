<script>

var contractMainAddress='<?php echo MAIN_CONTRACT_ADDRESS  ?>';
var pay_address 	=	'<?php echo PAY_OUT  ?>';
var token           =  '<?php echo TOKEN  ?>';
var URL             = '<?php echo URL ?>';
var tronscan        = '<?php echo BSCURL?>';
var arrayABI = <?=ABI; ?>;
var tokenABI = <?=TOKEN_ABI; ?>;

</script>