<?php

// include('config.php');

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

//----------------------------------READ SECTION-----------------------------------------//


$TokenPrefix	="MM";
$POOL_2X_PAY = 10;
$POOL_3X_PAY = 4;

$POOL_UPLINE_BONUS=1;

$GAP_GEN_DIRECT =3;
$GAP_GEN_STRONG_LEG=3;
$GAP_GEN_TOTAL_TEAM=10;




$GLOBAL_ROYALITY_DIRECT =6;
$GLOBAL_ROYALITY_STRONG_LEG =9;
$GLOBAL_ROYALITY_TEAM =30;



$SYSTEM_JOIN = 45;
$POOL_BUY = 12;

$ACTIVE_ROYALITY_VALIDITY=2592000;
$ACTIVE_DIRECTS=8;
$ACTIVE_ROYALITY_BONUS=2;




function getUserIDByTokenID($token_id){

global $conn;


	$query= "select userID from reg_user where userToken ='$token_id'";

	
	$result= mysqli_query($conn,$query);

	if ($result){

		$row= mysqli_fetch_assoc($result);
		$row_count = mysqli_num_rows($result);

		if ($row_count>0){

			return $row['userID'];
		}
		
	}

	return -1;

}


function getTokenIDByUser($user){

global $conn;


	$query= "select userToken from reg_user where userID=$user";

	
	$result= mysqli_query($conn,$query);

	if ($result){

		$row= mysqli_fetch_assoc($result);
		$row_count = mysqli_num_rows($result);

		if ($row_count>0){

			return $row['userToken'];
		}
		
	}

	return "";


}


function getUserTotal2xPoolBuy($id){


global $conn;


$query = "SELECT sum(position) as total FROM `event_buyPool_2x` WHERE userID=$id";

$result = mysqli_query($conn,$query);



if($result){

    $row = mysqli_fetch_assoc($result);
    
    $pos = ($row['total']);
    
    return $pos;
    
}

	return 0;


}


function getUserTotal3xPoolBuy($id){

global $conn;


$query = "SELECT sum(position) as total FROM `event_buyPool_3x` WHERE userID=$id";

$result = mysqli_query($conn,$query);

if($result){

    
    	$row = mysqli_fetch_assoc($result);
    
    	$pos = ($row['total']);
    
    	return $pos;
   
}

	return 0;


}


function getInactiveUser($user){

// get total team
// 
$team = getCountDownline($user);
$active= getActiveCountDownline($user);

$inactive;

if ($team>=$active){


	$inactive= intval($team-$active);

}



//getteam

return $inactive;

}


function getTotalReceivedFund($user_id){

global $conn;

$query = "SELECT sum(amount) as total FROM `fund_transaction_log` WHERE toUser=$user_id";
$result = mysqli_query($conn);

if($result){

	$row_count = mysqli_num_rows(result);

	if($row_count>0){
    
    	$row = mysqli_fetch_assoc($result);
    
    	return $row['total'];
    }
}

}


function getTotalReEntryFund ($user_id){

global $conn;
global $SYSTEM_JOIN;



	return 0;

}


function getTotal2xPoolBuyFund ($user_id){

global $conn;
global $SYSTEM_JOIN;

$query = "SELECT sum(position) as total FROM `event_buyPool_2x` WHERE userID=$user_id";

$result = mysqli_query($conn);

if($result){

	$row_count = mysqli_num_rows(result);

	if($row_count>0){
    
    	$row = mysqli_fetch_assoc($result);
    
    	$pos = ($row['total']-1);
    
    	return $pos*$SYSTEM_JOIN;
    }
}

	return 0;

}


function getTotalTransferFund($user_id){

global $conn;

$query = "SELECT sum(amount) as total FROM `fund_transaction_log` WHERE fromUser=$user_id";
$result = mysqli_query($conn);

if($result){

	$row_count = mysqli_num_rows(result);

	if($row_count>0){
    
    	$row = mysqli_fetch_assoc($result);
    
    	return $row['total'];
    }
}

}


function userExisitByAddress($address){

	global $conn;

	$query= "select * from reg_user where userWalletBase58='$address'";

	$result= mysqli_query($conn,$query);

	if ($result){

		$row= mysqli_fetch_assoc($result);
		$row_count = mysqli_num_rows($result);

		if ($row_count>0){

			return true;
		}
		
	}

	return 0;

}


function userExisitByID($id){

	global $conn;

	$query= "select * from reg_user where userID=$id";

	$result= mysqli_query($conn,$query);

	if ($result){

		$row= mysqli_fetch_assoc($result);
		$row_count = mysqli_num_rows($result);

		if ($row_count>0){

			return true;
		}
		
	}

	return 0;

}


function getUserByAddress($address){

	global $conn;

	$query= "select * from reg_user where userWalletBase58='$address'";

	$result= mysqli_query($conn,$query);

	if ($result){

		$row= mysqli_fetch_assoc($result);
		$row_count = mysqli_num_rows($result);

		if ($row_count>0){

			return $row['userID'];
		}
		
		
	}
	

	return -1;

}


function getUserAddressByUserId($user_id){

	global $conn;

	$query= "select userWalletBase58 from reg_user where userID ='$user_id'";

	$result= mysqli_query($conn,$query);

	if ($result){

		$row= mysqli_fetch_assoc($result);
		$row_count = mysqli_num_rows($result);

		if ($row_count>0){

			return $row['userWalletBase58'];
		}
		
	}

	return '';

}



// GET USER referer ID ON THE BASIS OF USER ID 
function getUserReferrerId($_id){
	global $conn;

	$query= "select referrerID from reg_user where userID=$_id";

	$result= mysqli_query($conn,$query);

	if ($result){

		$row= mysqli_fetch_assoc($result);
		$row_count = mysqli_num_rows($result);
		if ($row_count>0){
			
			return $row['referrerID'];
		}

		
	}

	return 0;
}


function getActiveRoyalityExipry($user_id){
global $conn;

$query = "select * from reg_user where userID=$user_id";
$result = mysqli_query($conn,$query);

	if ($result){

		$row= mysqli_fetch_assoc($result);
		$row_count = mysqli_num_rows($result);
		if ($row_count>0){
			
			return $row['activeRoyalityValidation'];
		}

		
	}


}

function isActiveRoyalityQualified($user_id){

global $conn;

$query = "select * from reg_user where userID=$user_id";
$result = mysqli_query($conn,$query);

	if ($result){

		$row= mysqli_fetch_assoc($result);
		$row_count = mysqli_num_rows($result);
		if ($row_count>0){
			
			return $row['activeRoyalityQualified'];
		}

		
	}

}


function isPoolBuy($trnx){

global $conn;

$query = "SELECT * FROM `event_invest` WHERE  event_transaction='$trnx'";

$result= mysqli_query($conn,$query);



if($result){

	
		$row_count = mysqli_num_rows($result);

		if($row_count>0){
        
        
        	return false;
        
        }else{
        
        
        	return true;
        
        }

}


	return true;


}








//---------------------------POOL STATS------------------------------



function getAutoPool2xRebirthCount($index){

global $conn;

$query = "SELECT count(*) as total FROM `autoPool2x` WHERE mainIndex = $index and isThisRebirth !=0 ";
$result = mysqli_query($conn,$query);

if($result){

	$row = mysqli_fetch_assoc($result);

	return $row['total'];

}

return total;

}



function getAutoPool2xTotalIncome($index){

global $conn;

$user = getUserBy2xMainIndex($index);

$query = "SELECT sum(amount) as income FROM `2xAutoPoolPay` WHERE toUser=$user ";
$result = mysqli_query($conn,$query);

if($result){

	$row = mysqli_fetch_assoc($result);
	
	return $row['income'];

}

	return 0;

}





function getAutoPool3xRebirthCount($index){

global $conn;

$query = "SELECT count(*) as total FROM `autoPool3x` WHERE mainIndex = $index and isThisRebirth !=0 ";
$result = mysqli_query($conn,$query);

if($result){

	$row = mysqli_fetch_assoc($result);

	return $row['total'];

}

return total;

}



function getAutoPool3xTotalIncome($index){

global $conn;

$user = getUserByMainIndex3x($index);

$query = "SELECT sum(amount) as income FROM `3xAutoPoolPay` WHERE toUser=$user ";
$result = mysqli_query($conn,$query);

if($result){

	$row = mysqli_fetch_assoc($result);
	
	return $row['income'];

}

	return 0;

}











function getLevelDist($level){

     $levelDist[1] = 1;
     $levelDist[2] = 1;
     $levelDist[3] = 1;
     $levelDist[4] = 1;
     $levelDist[5] = 1;    
	 $levelDist[6] = 0.5;
     $levelDist[7] = 0.5;
     $levelDist[8] = 0.5;
     $levelDist[9] = 0.5;
     $levelDist[10] = 0.5; 
	 $levelDist[11] = 2.5;
     $levelDist[12] = 2.5;
     $levelDist[13] = 2.5;
     $levelDist[14] = 2.5;
     $levelDist[15] = 2.5;    
	 $levelDist[16] = 2.5;
     $levelDist[17] = 2.5;
     $levelDist[18] = 2.5;
     $levelDist[19] = 2.5;
     $levelDist[20] = 2.5;     



    return $levelDist[$level];

}


function getGapLevelDist($level){


     $levelDist[1] = 2;
     $levelDist[2] = 1;
     $levelDist[3] = 1;
     $levelDist[4] = 1;
	 $levelDist[5] = 1;

    return $levelDist[$level];

}



function getDirectUserList($user_id){

	global $conn;

	$activeUser= array();

	// if ($user_id!=0){


		$query = "SELECT * FROM `reg_user` WHERE  referrerID=".$user_id	;
		$result = mysqli_query($conn,$query);

		if($result){

			while ($row= mysqli_fetch_assoc($result)) {
			
				$id 	= $row['userID'];
            
            
					array_push($activeUser,$id);

			}

		}


	return $activeUser;
}




function getCountDownline($user_id){


	global $conn;

	$count= 0;

	$query = "select teamCount from reg_user where userID=$user_id";

	$result = mysqli_query($conn,$query);

	if($result){

		$row_count = mysqli_num_rows($result);

		if($row_count>0){

			$row= mysqli_fetch_assoc($result);

			$count= $row['teamCount'];		
		}

		else{

			return -1;

		}
	}

	else{

		return -1;

	}

	return $count;


}




function getActiveCountDownline($user_id){


	global $conn;

	$count= 0;

	$query = "select teamActiveCount from reg_user where userID=$user_id";

	$result = mysqli_query($conn,$query);

	if($result){

		$row_count = mysqli_num_rows($result);

		if($row_count>0){

			$row= mysqli_fetch_assoc($result);

			$count= $row['teamActiveCount'];		
		}

		else{

			return -1;

		}
	}

	else{

		return -1;

	}

	return $count;


}






function genrateNewToken(){

global $TokenPrefix;

$newToken;

while(true){

	$token = rand(111111,999999);

	if ($oldToken = getUserIDByTokenID($token)==-1){

		$newToken = $TokenPrefix.$token;
    	break;
	}

}

return $newToken;

}


function updateActiveRoyalityStatus($user_id){
global $conn;
global $ACTIVE_ROYALITY_VALIDITY;
global $ACTIVE_DIRECTS;
$extandDays = $ACTIVE_ROYALITY_VALIDITY;

// get direct active count if less then critera stop it 

$direct = getActiveCount($user_id);

if ($direct<$ACTIVE_DIRECTS){

	return 0;
}

// get previous time expiry
// if updatable then update it
$Preexpiry = getActiveRoyalityExipry($user_id);
$newExpiry;

$current = time();

if($Preexpiry>$current){

	$newExpiry= $Preexpiry+$extandDays;

}else{

	$newExpiry=time()+$extandDays;
}

// update status
updateActiveRoyalityExpiry($user_id,$newExpiry);


if (isActiveRoyalityQualified($user_id)){

}else{

	qualifyActiveRoyality($user_id);
}



}



function getUserReferrerIdInclude($_id){
	global $conn;

	$ref=0;
	$query= "select referrerID from reg_user where userID=$_id";

	$result= mysqli_query($conn,$query);

	if ($result){

		$row= mysqli_fetch_assoc($result);
		$row_count = mysqli_num_rows($result);
		if ($row_count>0){
			
			$ref= $row['referrerID'];
		}


    	return $ref;
	}

	return 0;
}


function getActiveCount($user_id){

	global $conn;


		$query = "SELECT count(*) as directCount FROM `reg_user` WHERE isActive=1 and  referrerID=".$user_id;


		$result = mysqli_query($conn,$query);

		if($result){

				$row= mysqli_fetch_assoc($result); 
			
				$id 	= $row['directCount'];
        	
        	return $id;

		}


	return 0;
}


function getUserActiveStatus($user_id){

	global $conn;


		$query = "SELECT isActive FROM `reg_user` WHERE isActive=1 and userID=".$user_id;


		$result = mysqli_query($conn,$query);

		if($result){

				//$row= mysqli_fetch_assoc($result); 
        
        
        $row_count= mysqli_num_rows($result);
        
        if($row_count>0){
        
        
        	return true;
        
        }
        	
        		

		}


	return false;
}

function getDirectCount($user_id){

	global $conn;


		$query = "SELECT directCount FROM `reg_user` WHERE  userID=".$user_id;


		$result = mysqli_query($conn,$query);

		if($result){

				$row= mysqli_fetch_assoc($result); 
			
				$id 	= $row['directCount'];
        	
        	return $id;

		}


	return 0;
}




function getAutopool2xTime($user){

global $conn;

$query = "SELECT timestamp FROM `2xAutoPoolPay` WHERE toUser=$user LIMIT 1";
$result = mysqli_query($conn,$query);


		

		if($result){
        

				$row= mysqli_fetch_assoc($result); 
			
				$times 	= $row['timestamp'];
        
        	return $times;

		}
	
	return 0;
}



function getAutopool3xTime($user){

global $conn;

$query = "SELECT timestamp FROM `3xAutoPoolPay` WHERE toUser=$user LIMIT 1";
$result = mysqli_query($conn,$query);


		

		if($result){
        

				$row= mysqli_fetch_assoc($result); 
			
				$times 	= $row['timestamp'];
        
        	return $times;

		}
	
	return 0;
}



//-------------------------------------------------------TEAM CHART ---------------------------------------------




function downlineDigByLevel($ref,$level=1){
   global $conn;

	$downlineObj = array();
    $teamObj= array();



if ($level>50){

	return $downlineObj;
}

	if (!empty($ref)){
    
    	$tmp_arr=[];
    
     	for ($i=0; $i < count($ref); $i++) { 
        
        // iterate all referal id 
        
    		
		    if(check_free_node($ref[$i])){
            
            	
            
            }else{
            
           
            	 
		        $id=$ref[$i];
            	// $lastRef=$id;
				
    			$query= "select * from reg_user where referrerID=$id order by userID desc";

				$result= mysqli_query($conn,$query);

					if ($result){

						$row_count= mysqli_num_rows($result);


					if ($row_count>0){

						while ($row = mysqli_fetch_assoc($result)) {
							
							// echo 'userID:'.$row['userID']."</br>";
                        
                        	$timestamp = $row['timestamp'];
                        
                        	if ($timestamp>0){
                            
                            	$timestamp = date('d/m/Y', $timestamp);
                            }
                        
                        	$referral_id_ =getUserReferrerId($row['userID']);
                        
                        	if (intval($row['isActive'])>0){
                            
                            	$infos=1;
                            
                            }else{
                            
                            	$infos=0;
                            }
                        
                        	 $link_user = BSCURL."address/".getUserAddressByUserId($row['userID']);
                             $link_sponser = BSCURL."address/".getUserAddressByUserId($referral_id_);
                        
                        	 $user_anchor=  '<a target="_blank" href="'.$link_user.'" class="user" data-placement="top" data-toggle="tooltip" data-original-title="'.getUserAddressByUserId($row[userID]). '">'.substr(getUserAddressByUserId($row[userID]),0,6).'......'.substr(getUserAddressByUserId($row[userID]),-6).'</a>'; 
                                                        
                             $sponser_anchor= '<a target="_blank" href="'.$link_sponser.'" class="user" data-placement="top" data-toggle="tooltip" data-original-title="' .getUserAddressByUserId($referral_id_). '">'.substr(getUserAddressByUserId($referral_id_),0,6).'......'.substr(getUserAddressByUserId($referral_id_),-6).'</a>'; 
                                           
                        
                        	$obj = array("level"=>$level,"team"=>$row['userID'],"name"=>$row["userFirstName"], "sponser"=>getUserAddressByUserId($referral_id_),"address"=>getUserAddressByUserId($row['userID']),"timestamp"=>$timestamp,"status"=>$infos,"anchor1"=>$user_anchor,"anchor2"=>$sponser_anchor);
                        	array_push($downlineObj,$obj);
							// array_push($tmp_arr, $row['userID']);
                        	
                        	
                        	
						}
                    
					}
                    
                    // $teamObj['obj']= $downlineObj;
                    // $teamObj['lastTeam']=$tmp_arr;
                    
                  
                  
                    
				}
            
            
            }
        
        }
    
    	
    }


    return ($downlineObj);


}


function check_free_node($ref_id){

	global $conn;
	$query= "select * from reg_user where referrerID=$ref_id order by userID asc";

	$result= mysqli_query($conn,$query);
	
	if ($result){

		$row_count= mysqli_num_rows($result);

		if ($row_count>0){


			return false;

			}

			else{


				return true;
			}

		}

	}




//-------------------------------------------------INCOME -------------------------------------------------







function getUserTotalDirectProfit($user_id){

	global $conn;
	$data = array();
	$data[0]=0;
    $data[1] = 0;
	$counter;
	$amount = 0;
	$query = "select * from user_income where gainer=$user_id and type_of_income='direct'";
	$result = mysqli_query($conn,$query);

	if($result){

		$row_count= mysqli_num_rows($result);

		if($row_count>0){

			while($row = mysqli_fetch_assoc($result)){

				$amount+=($row['income_amount']);
				$counter+=1;
			}
        
        	$data[0]=$counter;
    		$data[1] = $amount;
		}

	}

	return $data;
}


function getUserTotalUnilevelProfit($user_id){

	global $conn;
	$data = array();
	$data[0]=0;
    $data[1] = 0;
	$counter;
	$amount = 0;
	$query = "select * from user_income where gainer=$user_id and type_of_income='unilevel'";
	$result = mysqli_query($conn,$query);

	if($result){

		$row_count= mysqli_num_rows($result);

		if($row_count>0){

			while($row = mysqli_fetch_assoc($result)){

				$amount+=($row['income_amount']);
				$counter+=1;
			}
        
        	$data[0]=$counter;
    		$data[1] = $amount;
		}

	}

	return $data;
}



function getUserTotalPool2xProfit($user_id){

	global $conn;
	$data = array();
	$data[0]=0;
    $data[1] = 0;
	$counter;
	$amount = 0;
	$query = "select * from user_income where gainer=$user_id and type_of_income='globalPool2x'";
	$result = mysqli_query($conn,$query);

	if($result){

		$row_count= mysqli_num_rows($result);

		if($row_count>0){

			while($row = mysqli_fetch_assoc($result)){

				$amount+=($row['income_amount']);
				$counter+=1;
			}
        
        	$data[0]=$counter;
    		$data[1] = $amount;
		}

	}

	return $data;
}


function getUserTotalPool3xProfit($user_id){

	global $conn;
	$data = array();
	$data[0]=0;
    $data[1] = 0;
	$counter;
	$amount = 0;
	$query = "select * from user_income where gainer=$user_id and type_of_income='globalPool3x'";
	$result = mysqli_query($conn,$query);

	if($result){

		$row_count= mysqli_num_rows($result);

		if($row_count>0){

			while($row = mysqli_fetch_assoc($result)){

				$amount+=($row['income_amount']);
				$counter+=1;
			}
        
        	$data[0]=$counter;
    		$data[1] = $amount;
		}

	}

	return $data;
}




function getUserTotalPoolCommissionProfit($user_id){

	global $conn;
	$data = array();
	$data[0]=0;
    $data[1] = 0;
	$counter;
	$amount = 0;
	$query = "select * from user_income where gainer=$user_id and type_of_income='poolCommission'";
	$result = mysqli_query($conn,$query);

	if($result){

		$row_count= mysqli_num_rows($result);

		if($row_count>0){

			while($row = mysqli_fetch_assoc($result)){

				$amount+=($row['income_amount']);
				$counter+=1;
			}
        
        	$data[0]=$counter;
    		$data[1] = $amount;
		}

	}

	return $data;
}



function getUserTotalRoyalityProfit($user_id){

	global $conn;
	$data = array();
	$data[0]=0;
    $data[1] = 0;
	$counter;
	$amount = 0;
	$query = "select * from user_income where gainer=$user_id and type_of_income='globalRoyality'";
	$result = mysqli_query($conn,$query);

	if($result){

		$row_count= mysqli_num_rows($result);

		if($row_count>0){

			while($row = mysqli_fetch_assoc($result)){

				$amount+=($row['income_amount']);
				$counter+=1;
			}
        
        	$data[0]=$counter;
    		$data[1] = $amount;
		}

	}

	return $data;
}

function getUserTotalGenGapProfit($user_id){

	global $conn;
	$data = array();
	$data[0]=0;
    $data[1] = 0;
	$counter;
	$amount = 0;
	$query = "select * from user_income where gainer=$user_id and type_of_income='globalGapGen'";
	$result = mysqli_query($conn,$query);

	if($result){

		$row_count= mysqli_num_rows($result);

		if($row_count>0){

			while($row = mysqli_fetch_assoc($result)){

				$amount+=($row['income_amount']);
				$counter+=1;
			}
        
        	$data[0]=$counter;
    		$data[1] = $amount;
		}

	}

	return $data;
}


function getUserTotalProfit($user_id){

	global $conn;
	$data = array();
	$data[0]=0;
    $data[1] = 0;
	$counter;
	$amount = 0;
	$query = "select * from user_income where gainer=$user_id ";
	$result = mysqli_query($conn,$query);

	if($result){

		$row_count= mysqli_num_rows($result);

		if($row_count>0){

			while($row = mysqli_fetch_assoc($result)){

				$amount+=($row['income_amount']);
				$counter+=1;
			}
        
        	$data[0]=$counter;
    		$data[1] = $amount;
		}

	}

	return $data;
}


//-----------------------------------WRITE SECTION -------------------------------------------------//



//user earning genration
function addIncomeEntry($user_id,$payer,$amount,$type_of_income,$now) {

	global $conn;


	$query = "INSERT INTO `user_income`(`gainer`,`payer`, `income_amount`, `type_of_income`, `timestamp`) VALUES ('$user_id','$payer','$amount','$type_of_income','$now')";

	$result = mysqli_query($conn,$query);

	

	if ($result){

        
       return true;
	}

	else{
		return false;
	}


}


function addIncomeLostEntry ($user,$amount,$level,$type,$time) {

	global $conn;

	$query = "INSERT INTO `event_lostIncome`(`userID`, `amount`,`level`, `income_type` ,`timestamp`) VALUES ('$user','$amount','$level','$type','$time')";

	$result = mysqli_query($conn,$query);
	
	if ($result){
    
    	
    	return true;
    
    }


	return false;

}





function payToDirectEntry($user_id,$ref_id,$amount,$now){

	global $conn;

	
	$query = "INSERT INTO `event_paidtodirect`(`fromUser`, `toUser`, `amount`, `timestamp`) VALUES ('$user_id','$ref_id','$amount','$now')";

	$result = mysqli_query($conn,$query);

	if ($result){

		return true;

	}

	else{

		return false;
	}

}


function payToPoolRoyalityEntry($pay,$user_id,$ref_id,$amount,$now){

	global $conn;

	
	$query = "INSERT INTO `event_poolRoyality`(`payID`,`fromUser`, `toUser`, `amount`, `timestamp`) VALUES ('$pay','$user_id','$ref_id','$amount','$now')";

	$result = mysqli_query($conn,$query);

	if ($result){

		return true;

	}

	else{

		return false;
	}

}



function payToPoolSponserEntry($user_id,$ref_id,$amount,$now){

	global $conn;

	
	$query = "INSERT INTO `event_poolSponser`(`fromUser`, `toUser`, `amount`, `timestamp`) VALUES ('$user_id','$ref_id','$amount','$now')";

	$result = mysqli_query($conn,$query);

	if ($result){

		return true;

	}

	else{

		return false;
	}

}


function addActiveRoyalityQualifyEntry($user,$current,$validity,$status){

	global $conn;

	
	$query = "INSERT INTO `event_activeRoyalityQualify` (`user`, `currentIndex`, `validityIndex`, `status`) VALUES ('$user','$current','$validity','$status')";

	$result = mysqli_query($conn,$query);

	if ($result){

		return true;

	}

	else{

		return false;
	}

}


function payUnilevelEntry($from,$to,$amount,$level,$time){

// write insertion query for paid level
	global $conn;

	
	$query = "INSERT INTO `event_paidforunilevelev`(`fromUser`, `toUser`, `amount`,`level`, `timestamp`) VALUES ('$from','$to','$amount','$level','$time')";

	$result = mysqli_query($conn,$query);

	if ($result){

		return true;

	}

	else{

		return false;
	}

	

}


function payGapGenEntry($from,$to,$amount,$level,$time){

// write insertion query for paid level
	global $conn;

	
	$query = "INSERT INTO `event_paidforgapgenration`(`fromUser`, `toUser`, `amount`,`level`, `timestamp`) VALUES ('$from','$to','$amount','$level','$time')";

	$result = mysqli_query($conn,$query);

	if ($result){

		return true;

	}

	else{

		return false;
	}

	

}


function payRoyalityEntry($to,$grAmount,$arAmount,$time){

// write insertion query for paid level
	global $conn;

	
	$query = "INSERT INTO `event_paidforroyality` (`toUser`, `grAmount`,`arAmount`,`timestamp`) VALUES ('$to','$grAmount','$arAmount','$time')";

	$result = mysqli_query($conn,$query);

	if ($result){

		return true;

	}

	else{

		return false;
	}

	

}



function payGlobalActiveRoyalityEntry($from,$to,$amount,$time){

// write insertion query for paid level
	global $conn;

	
	$query = "INSERT INTO `event_paidforglobalactiveroyality`(`fromUser`, `toUser`, `amount`, `timestamp`) VALUES ('$from','$to','$amount','$time')";

	$result = mysqli_query($conn,$query);

	if ($result){

		return true;

	}

	else{

		return false;
	}

	

}



function payToGapGenEntry($user_id,$ref_id,$amount,$now){

	global $conn;

	
	$query = "INSERT INTO `event_paidforgapgenration` (`fromUser`, `toUser`, `amount`, `timestamp`) VALUES ('$user_id','$ref_id','$amount','$now')";

	$result = mysqli_query($conn,$query);

	if ($result){

		return true;

	}

	else{

		return false;
	}

}




function addWithDrawEntry($user_id,$amount,$now,$transaction){

	global $conn;

	$query = "INSERT INTO `user_withdraw`( `userID`, `withdraw_amount`, `timestamp`,`event_transaction`) VALUES ('$user_id','$amount','$now','$transaction')";

	$result = mysqli_query($conn,$query);

	if ($result){
	    

		return true;

	}

	else{

		return false;
	}

}




function addTransferCreditToCredit ($from,$to,$amount,$timestamp,$transaction){

global $conn;

$query = "INSERT INTO `event_transferFromCreditToCredit` (`fromUser`, `toUser`, `amount`, `timestamp`, `event_transaction`) VALUES ('$from','$to','$amount','$timestamp','$transaction')";
$result = mysqli_query($conn,$query);

if($result){

	return true;

}else{

	return false;

}

}



function addTransferTransFromGainToGain ($from,$to,$amount,$timestamp,$transaction){

global $conn;

$query = "INSERT INTO `event_transferFromGainToGain` (`fromUser`, `toUser`, `amount`, `timestamp`, `event_transaction`) VALUES ('$from','$to','$amount','$timestamp','$transaction')";
$result = mysqli_query($conn,$query);

if($result){

	return true;

}else{

	return false;

}

}



function addTransferTransFromGainToCredit ($from,$to,$amount,$timestamp,$transaction){

global $conn;

$query = "INSERT INTO `event_transferFromGainToCredit` (`fromUser`, `toUser`, `amount`, `timestamp`, `event_transaction`) VALUES ('$from','$to','$amount','$timestamp','$transaction')";
$result = mysqli_query($conn,$query);

if($result){

	return true;

}else{

	return false;

}

}




function addRegEntry($user,$wallet,$walletBase58,$userReferrer,$now,$transaction){


	global $conn;

	$query = "INSERT INTO `reg_user`(`userID`,`userWallet`, `userWalletBase58`, `referrerID`,`timestamp`, `event_transaction`) VALUES ('$user','$wallet','$walletBase58','$userReferrer','$now','$transaction')";

	$result = mysqli_query($conn,$query);



	if ($result){

    
    
    
    	    setUserTeamCount($user);
        
    		if ($userReferrer!=0){
            
                
            	$activeCounter= getDirectCount($userReferrer);
            
            	updateUserActiveCount($userReferrer,$activeCounter+1);
            
            
            }
            
    
		return true;

	}

	else{

		return false;
	}

}


function addBuyTopupEntry($userId,$position,$now,$trnx){

global $conn;

$query = "INSERT INTO `event_buyTopup`(`userID`, `position`,`timestamp`, `event_transaction`) VALUES ('$userId','$position','$now','$trnx')";
$result = mysqli_query($conn,$query);

	if($result){

    
    	updateUserActiveStatus($userId,1);
    
    	if(getUserActiveStatus($userId)){


			setUserActiveCount($userId);

		}
    
		// $ref = getUserReferrerId($userId);
    
		return true;

	}

	return false;

}


function addRebuyTopupEntry($userId,$position,$now,$trnx){

global $conn;

$query = "INSERT INTO `event_reTopup`(`userID`, `position`,`timestamp`, `event_transaction`) VALUES ('$userId','$position','$now','$trnx')";
$result = mysqli_query($conn,$query);

	if($result){
    
    
    	  updateUserActiveStatus($userId,1);
    
    	if(getUserActiveStatus($userId)){


			setUserActiveCount($userId);

		}

		return true;

	}

	return false;

}


function addBuyPool2xEntry($userId,$position,$now,$trnx){

global $conn;

$query = "INSERT INTO `event_buyPool_2x`(`userID`, `position`, `timestamp`, `event_transaction`) VALUES ('$userId','$position','$now','$trnx')";
$result = mysqli_query($conn,$query);


	if($result){

		return true;

	}

	return false;

}


function addRebuyPool2xEntry($userId,$position,$now,$trnx){

global $conn;

$query = "INSERT INTO `event_reBuyPool2x`(`userID`, `position`, `timestamp`, `event_transaction`) VALUES ('$userId','$position','$now','$trnx')";
$result = mysqli_query($conn,$query);


	if($result){

		return true;

	}

	return false;

}


function addBuyPool3xEntry($userId,$position,$now,$trnx){

global $conn;

$query = "INSERT INTO `event_buyPool_3x`(`userID`, `position`, `timestamp`, `event_transaction`) VALUES ('$userId','$position','$now','$trnx')";
$result = mysqli_query($conn,$query);


	if($result){

		return true;

	}

	return false;

}




//----------------------------UPDATE CALLS-------------------------------------------------//




function updateUserDownline($user_id,$value){

global $conn;

$query = "update `reg_user` SET `teamCount` ='$value' where userID=$user_id";
$result = mysqli_query($conn,$query);

if($result){
	return true;
}

return false;

}


function updateActiveUserDownline($user_id,$value){

global $conn;

$query = "update `reg_user` SET `teamActiveCount` ='$value' where userID=$user_id";
$result = mysqli_query($conn,$query);

if($result){
	return true;
}

return false;

}



function updateUserActiveCount($user_id,$value){

	global $conn;

	$query = "UPDATE `reg_user` SET `directCount`= '$value' WHERE userID= $user_id";
	$result = mysqli_query($conn,$query);

	if ($result){

		return true;
	}

	return false;

}


function qualifyActiveRoyality($user_id){
global $conn;

	$query = "UPDATE `reg_user` SET `activeRoyalityQualified`= 1 WHERE userID= $user_id";
	$result = mysqli_query($conn,$query);

	if ($result){

		return true;
	}

	return false;

}

function disqualifyActiveRoyality($user_id){
global $conn;

	$query = "UPDATE `reg_user` SET `activeRoyalityQualified`= 0 WHERE userID= $user_id";
	$result = mysqli_query($conn,$query);

	if ($result){

		return true;
	}

	return false;


}

function updateActiveRoyalityExpiry($user_id,$value){
global $conn;

	$query = "UPDATE `reg_user` SET `activeRoyalityValidation`= '$value' WHERE userID= $user_id";
	$result = mysqli_query($conn,$query);

	if ($result){

		return true;
	}

	return false;


}




function updateUserActiveStatus($user_id,$value){

	global $conn;

	$query = "UPDATE `reg_user` SET `isActive`= '$value' WHERE userID= $user_id";
	$result = mysqli_query($conn,$query);

	if ($result){

		return true;
	}

	return false;

}




//-----------------------------------LOGIC SECTION-------------------------------------------------//


function setUserTeamCount ($new_user){

$preCount= 0;

while($new_user!=0){

	$default = $new_user;

	$new_user = getUserReferrerIdInclude($new_user);
	// updateCount

// 	if ($new_user<1){
    
//     	break;
//     }

	$preCount=getCountDownline($new_user);
	updateUserDownline($new_user,$preCount+1);
	
	//$actTeam = getActiveCountDownline($new_user);

	//updateActiveUserDownline($new_user,$actTeam+1);
	

	if($default ==$new_user){
    	break;
    }

}


}


function setUserActiveCount ($new_user){

$preCount= 0;

while($new_user!=0){

	$default = $new_user;

	$new_user = getUserReferrerIdInclude($new_user);
	// updateCount

// 	if ($new_user<1){
    
//     	break;
//     }

	$actTeam = getActiveCountDownline($new_user);

	updateActiveUserDownline($new_user,$actTeam+1);
	
	if($default ==$new_user){
    	break;
    }

}


}



function joinUser($wallet,$ref,$now,$transaction){

global $POOL_UPLINE_BONUS;

// add new Reg

// pay sponser sponser bonus

// pay levelIncome

// pay payGap Genration bonus

// pay gloabl royality bonus


addRegEntry($wallet,$wallet,$ref,$now,$transaction);



$user_id = getUserByAddress($wallet);
$ref = getUserReferrerId($user_id);
addInvestEntry($user_id,1,$now,$transaction);
updateUserActiveStatus($user_id,1);
distributeSponserBonus($ref,$user_id,$now);
distributeUnilevelBonus($user_id);
distributeGenrationBonus($user_id);
distributeRoyalityBonus($user_id);

updateActiveRoyalityStatus($ref);
distributeActiveRoyalityBonus($user_id);


	$gainer =$ref;
	
	payToPoolDirectEntry($user_id,$gainer,$POOL_UPLINE_BONUS,$now);

	//payToDirectEntry($from,$to,$sponser_pay,$current)

	addIncomeEntry($gainer,$user_id,($POOL_UPLINE_BONUS),'poolUpline',$now);

addAutopoolPosition3x($user_id);
addAutopool2XPosition($user_id);

updateUserActiveStatus($user_id,1);

if(getUserActiveStatus($user_id)){


	setUserActiveCount($user_id);

}




}


function investUser($userId,$position,$now,$trnx){

$now = time();

global $POOL_UPLINE_BONUS;


addInvestEntry($userId,$position,$now,$trnx);
updateUserActiveStatus($userId,1);
$ref = getUserReferrerId($userId);

updateActiveRoyalityStatus($ref);

for ($i=1;$i<=$position;$i++){

distributeSponserBonus($ref,$userId,$now);
distributeUnilevelBonus($userId);
distributeGenrationBonus($userId);
distributeRoyalityBonus($userId);
//-------new income------------
distributeActiveRoyalityBonus($userId);

addAutopoolPosition3x($userId);

	$gainer =$ref;
	
	payToPoolDirectEntry($user,$gainer,$POOL_UPLINE_BONUS,$now);

	//payToDirectEntry($from,$to,$sponser_pay,$current)

	addIncomeEntry($gainer,$user,($POOL_UPLINE_BONUS),'poolUpline',$now);


addAutopool2XPosition($userId);


}



if(getUserActiveStatus($userId)){


	setUserActiveCount($userId);

}


}


function distributeSponserBonus($to,$from,$current){

$sponser_pay = 5;

	$returndata =false;

 
    if(payToDirectEntry($from,$to,$sponser_pay,$current)){

        	if (addIncomeEntry($to,$from,$sponser_pay,'direct',$current)){

        		$returndata= true;
        	}
      }

	return $returndata;

}


function distributeUnilevelBonus($user_id){


//-------------------------------------Referral Initilization---------------------------------
$referer = getUserReferrerId($user_id);
$now= time(); 


for($i=1;$i<=20;$i++){  // iterate 50 upline of user 

	$amount = getLevelDist($i);
	$direct = getActiveCount($referer);

	if($referer!=0 && $direct>=2 && getUserActiveStatus($referer)){

    	payUnilevelEntry($user_id,$referer,$amount,$i,$now);
    	addIncomeEntry($referer,$user_id,$amount,'unilevel',$now);
    		

	}else {
    
    	// send all fund to default id 
    
    	$defaultId=0;
    	payUnilevelEntry($user_id,$defaultId,$amount,$i,$now);
    	addIncomeEntry($defaultId,$user_id,$amount,'unilevel',$now);
    	
    }

	$referer = getUserReferrerId($referer);


}


}


function distributeGenrationBonus($user_id){

global $GAP_GEN_DIRECT ;
global $GAP_GEN_STRONG_LEG;
global $GAP_GEN_TOTAL_TEAM;



// get team
// 
//-------------------------------------Referral Initilization---------------------------------
$referer = getUserReferrerId($user_id);
// $now= time(); 
$now = time();


for($i=1;$i<=5;$i++){  // iterate 50 upline of user 

	$amount = getGapLevelDist($i);

		

	if($referer!=0){
    

		$totalTeam=0;
        $maxTeamCount=0;
		 $activeDirect= getActiveCount($referer);
    	
    	 if ($activeDirect>=$GAP_GEN_DIRECT){
         
         		$directList = getDirectUserList($referer);
         
         		
				if (count($directList)>0){
                
                	
    
    				foreach($directList as $value){
        

        				$team = getCountDownline($value);
                    
                    	$totalTeam+=$team;
                    
                    	if ($team>$maxTeamCount){
                        
                        	$maxTeamCount=$team;
                        }
        
        			}
    
    		}
         
         //---------------------criteria
         
         if (($totalTeam-$GAP_GEN_STRONG_LEG)>=$GAP_GEN_TOTAL_TEAM && $maxTeamCount>=$GAP_GEN_STRONG_LEG ){
         
         
         		payToGapGenEntry($user_id,$referer,$amount,$now);
         		addIncomeEntry($referer,$user_id,$amount,'globalGapGen',$now);
         
         }else{
         
         		// recursion
         		$i=0;
         		
         
         }
         		
      }else{  // if citeria is not full filing....
         
        		// send to recursion
         		$i=0;
         
      }
    

    		
       $referer = getUserReferrerId($referer);

	}else {
    
    	// send all fund to default id 
    	$defaultId=0;
    	payToGapGenEntry($user_id,$defaultId,$amount,$now);
    	addIncomeEntry($defaultId,$user_id,$amount,'globalGapGen',$now);
    	
    }


}




}




function distributeGenrationBonusTest($user_id){

global $GAP_GEN_DIRECT ;
global $GAP_GEN_STRONG_LEG;
global $GAP_GEN_TOTAL_TEAM;



// get team
// 
//-------------------------------------Referral Initilization---------------------------------
$referer = getUserReferrerId($user_id);
// $now= time(); 
$now = time();



for($i=1;$i<=5;$i++){  // iterate 50 upline of user 

	$amount = getGapLevelDist($i);
	echo "Ref:".$referer;echo "</br>";

	if($referer!=0){
    
    	$totalTeam=0;
        $maxTeamCount=0;

		 $activeDirect= getActiveCount($referer);
    	
    	 if ($activeDirect>=$GAP_GEN_DIRECT){
         
         		$directList = getDirectUserList($referer);
         		
         		// print_r($directList);
        
         		
				if (count($directList)>0){
                
                	
    
    				foreach($directList as $value){
        
						// echo $value;
        				$team = getCountDownline($value);
                    	
                    	$totalTeam+=$team;
                    
                    	if ($team>$maxTeamCount){
                        
                        	$maxTeamCount=$team;
                        }
        
        			}
    
    		}
         
         
				// echo "User Eligible"; echo "</br>";
				// echo "Ref:".$referer;echo "</br>";
				// echo "amount :".$amount;echo "</br>";
				// echo "</br>";
         
         //---------------------criteria
         
         if ($totalTeam>=$GAP_GEN_TOTAL_TEAM && $maxTeamCount>=$GAP_GEN_STRONG_LEG ){
         
         
				//echo "user running";
         
         }else{
         
         	
         	
         		//echo "Default  Eligible case 1 current ref: ".$referer;
         
         }
         		
      }else{
         
        	//echo "Default  Eligible case 2 ";
         
      }
    		
       $referer = getUserReferrerId($referer);

	}else {
    
    	// send all fund to default id 
        //echo "Default  Eligible case 3 ";
    	
    }


}




}






function distributeRoyalityBonus($user_id){

global $GLOBAL_ROYALITY_DIRECT;
global $GLOBAL_ROYALITY_STRONG_LEG ;
global $GLOBAL_ROYALITY_TEAM ;

$Fee = 4;
$default =0;
$now = time();

global $conn;

$query = "select userID,isActive from reg_user where userID!=0 and  directCount>=$GLOBAL_ROYALITY_DIRECT";
$result = mysqli_query($conn,$query);

$qualifyList = array();

if ($result){

	

	while($row=mysqli_fetch_assoc($result)){
    
    	$user = $row['userID'];
    	// array_push($qualifyList,$row['userI']);
    
    
    	$activeDirect= getActiveCount($user);
    	
    	 if ($activeDirect<$GLOBAL_ROYALITY_DIRECT){
         
         		continue;
         }
    
    
    	//------ check it direct qualify criteria 
		$totalTeam=0;
    	$maxTeamCount=0;
		$directList = getDirectUserList($user);
         
         		
		if (count($directList)>0){
                
                	
    
    			foreach($directList as $value){
        

        			$team = getActiveCountDownline($value);
                    
                  	$totalTeam+=$team;
                    
                  	if ($team>$maxTeamCount){
                        
                      	$maxTeamCount=$team;
                 	}
        
        		}
        
        
        	//------------fill qualify record 
        
                 if (($totalTeam-$GLOBAL_ROYALITY_STRONG_LEG)>=$GLOBAL_ROYALITY_TEAM && $maxTeamCount>=$GLOBAL_ROYALITY_STRONG_LEG ){
         
         
         				array_push($qualifyList,$user);
         
         		}
        
        
    
   		}
    
    }

}


if (count($qualifyList)>0){

$finalAmnt = $Fee/count($qualifyList);

foreach($qualifyList as $value){

//------ check it direct qualify criteria 

    payGlobalRoyalityEntry($default,$value,$finalAmnt,$now);
    addIncomeEntry($value,$default,$finalAmnt,'globalRoyality',$now);
		

}

	

}else {

	// default call 

    	payGlobalRoyalityEntry($default,$default,$Fee,$now);
    	addIncomeEntry($default,$default,$Fee,'globalRoyality',$now);


}




}


function distributeActiveRoyalityBonus($user_id){
global $conn;
global $ACTIVE_ROYALITY_BONUS;

$query = "select userID,activeRoyalityValidation from reg_user where activeRoyalityQualified=1";
$result = mysqli_query($conn,$query);
$now= time();

if($result){

	while($row=mysqli_fetch_assoc($result)){
    
    	$value = $row['userID'];
    	$default=0;
    	$finalAmnt=$ACTIVE_ROYALITY_BONUS;
    
    	if ($row['activeRoyalityValidation']<time()){
        
        	// disqualify 
        	disqualifyActiveRoyality($row['userID']);
        
        }else{
        
        	// add income and distribute 
        
        	    payGlobalActiveRoyalityEntry($default,$value,$finalAmnt,$now);
    			addIncomeEntry($value,$default,$finalAmnt,'activeRoyality',$now);
        	
        }
    }
}


}

function updateRoyalityValidation($user_id){

global $ACTIVE_ROYALITY_VALIDITY;

// get validatiy
// if eligible update 30 days

}



function distributeRoyalityBonus_($user_id){

global $GLOBAL_ROYALITY_DIRECT;
global $GLOBAL_ROYALITY_STRONG_LEG ;
global $GLOBAL_ROYALITY_TEAM ;

	$referer = getUserReferrerId($user_id);
	// $now= time(); 
	$now = time();
	
	$amount = 4;

	if($referer!=0){
    
    	$totalTeam;
        $maxTeamCount;

		 $activeDirect= getActiveCount($referer);
    	
    	 if ($activeDirect>=$GLOBAL_ROYALITY_DIRECT){
         
         		$directList = getDirectUserList($referer);
         
         		
				if (count($directList)>0){
                
                	
    
    				foreach($directList as $value){
        

        				$team = getCountDownline($value);
                    
                    	$totalTeam+=$team;
                    
                    	if ($team>$maxTeamCount){
                        
                        	$maxTeamCount=$team;
                        }
        
        			}
    
    		}
         
         
         //---------------------criteria
         
         if ($totalTeam>=$GLOBAL_ROYALITY_TEAM && $maxTeamCount>=$GLOBAL_ROYALITY_STRONG_LEG ){
         
         
         		payGlobalRoyalityEntry($user_id,$referer,$amount,$now);
         		addIncomeEntry($referer,$user_id,$amount,'globalRoyality',$now);
         
         }
         
         else{
         
            $defaultId=0;
    		payGlobalRoyalityEntry($user_id,$defaultId,$amount,$now);
    		addIncomeEntry($defaultId,$user_id,$amount,'globalRoyality',$now);
         }
         		
      }else{
      
         
        $defaultId=0;
    	payGlobalRoyalityEntry($user_id,$defaultId,$amount,$now);
    	addIncomeEntry($defaultId,$user_id,$amount,'globalRoyality',$now);
         

         
      }
    		
    	//$referer = getUserReferrerId($referer);

	}else {
    
    	// send all fund to default id 
    	$defaultId=0;
    	payGlobalRoyalityEntry($user_id,$defaultId,$amount,$now);
    	addIncomeEntry($defaultId,$user_id,$amount,'globalRoyality',$now);
    	
    }
	

}



//-----------------------------------------------------------------------------------------------//

//										AUTOPOOL SECTION         

//------------------------------------------------------------------------------------------------//



//--------------------------------------------POOL READ----------------------------------------------



function isMain2xIndexExisit($index){

global $conn;

$query = "SELECT * FROM `index_2xreference` WHERE mainIndex=$index";

$result = mysqli_query($conn,$query);

if($result){

	$rowcount=mysqli_num_rows($result);

	if($rowcount>0){
    
    	return true;
    }

}

return false;

}





function get2xIndexTarget($index){

global $conn;

$query = "SELECT targetFillBox FROM `index_2xreference` WHERE mainIndex=$index";

$result = mysqli_query($conn,$query);

if($result){

	$rowcount=mysqli_num_rows($result);

		if ($rowcount>0){
        	
        	$row = mysqli_fetch_assoc($result);

			return $row['targetFillBox'];
        }

}

return 0;

}




function getUserBy2xMainIndex($mainIndex){

global $conn;

$query = "SELECT userId FROM `index_2xreference` WHERE mainIndex=$mainIndex";

$result = mysqli_query($conn,$query);

if($result){

	$rowcount=mysqli_num_rows($result);

		if ($rowcount>0){
        	
        	$row = mysqli_fetch_assoc($result);

			return $row['userId'];
    }
}

	return 0;

}



function getIndexBy2xUser($user){

global $conn;

$query = "SELECT mainIndex FROM `index_2xreference` WHERE  userId=$user";

$result = mysqli_query($conn,$query);

if($result){

	$rowcount=mysqli_num_rows($result);

		if ($rowcount>0){
        	
        	$row = mysqli_fetch_assoc($result);

			return $row['mainIndex'];
    }
}

	return 0;

}


function getIndexBy3xUser($user){

global $conn;

$query = "SELECT mainIndex FROM `index_3xreference` WHERE  userId=$user";

$result = mysqli_query($conn,$query);

if($result){

	$rowcount=mysqli_num_rows($result);

		if ($rowcount>0){
        	
        	$row = mysqli_fetch_assoc($result);

			return $row['mainIndex'];
    }
}

	return 0;

}



function get2xIndexAchieve($index){

global $conn;

$query = "SELECT acheiveFillBox FROM `index_2xreference` WHERE mainIndex=$index";

$result = mysqli_query($conn,$query);

if($result){

	$rowcount=mysqli_num_rows($result);

		if ($rowcount>0){
        	
        	$row = mysqli_fetch_assoc($result);

			return $row['acheiveFillBox'];
    }
}


}



function getUserIDByAddress($wallet){

global $conn;

$query = "SELECT `userId` FROM `reg_user` WHERE  userWalletBase58='$wallet'";
$result = mysqli_query($conn,$query);

if($result){

	$row = mysqli_fetch_assoc($result);

	return $row['userId'];
}


}




function get2XLastParentId(){

global $conn;

$query = "SELECT max(`parent`) as parent FROM `autoPool2x`";

$result = mysqli_query($conn,$query);



if ($result){

	$row_Count =mysqli_num_rows($result);

	if($row_Count>0){
    
    	// need to execute 
    
    		$row = mysqli_fetch_assoc($result);
    
    		$parent = $row['parent'];
    
    		 $fillbox = getAutoPool2xParentFillBox($parent);
    
    
    		if ($fillbox==2  ){
            
            	$parent++;
            
            }
   
    
    		return $parent;
    		
    }else{
    
    
    	return 0; // as default index 
    
    }

}


}


function getAutopool2xParentByIndex($index){

global $conn;

$query = "SELECT `parent` as parent FROM `autoPool2x` where indexId=$index";

$result = mysqli_query($conn,$query);

if ($result){

	$row_Count =mysqli_num_rows($result);

	if($row_Count>0){
    
    	// need to execute 
    
    		$row = mysqli_fetch_assoc($result);
    
    		$parent = $row['parent'];
    
    		
    
    		return $parent;
    		
    }else{
    
    
    	return 1; // as default index 
    
    }

}


}

function getAutoPool2xLastIndex(){

global $conn;

$query= "SELECT max(indexId) as index_ FROM `autoPool2x`  ";

$result= mysqli_query($conn,$query);

if($result){

	$row = mysqli_fetch_assoc($result);

	if( $row['index_']==0 ||  $row['index_']==''){
    
    	return 0;
    }

	return  $row['index_'];

}

return 0;

}




function getAutoPool2xParentFillBox($parent){


global $conn;

$query = "SELECT count(parent) as fillbox FROM `autoPool2x` WHERE parent=$parent";

$result = mysqli_query($conn,$query);

if($result){


	$row_Count =mysqli_num_rows($result);

	if($row_Count>0){
    
    	$row = mysqli_fetch_assoc($result);

  		return  $row['fillbox'];
        
    
    }


}

	return 0;

}



function lastAutopool2xBirthParent(){

global $conn;

$query = "SELECT parent  FROM `autoPool2x` WHERE  isThisRebirth=1 order by indexId desc limit 1  ";

$result = mysqli_query($conn,$query);

if($result){

	$row_Count =mysqli_num_rows($result);

	if($row_Count>0){

		$row = mysqli_fetch_assoc($result);

  		 return  $row['parent'];
  
    }
        
}

return 0;

}


function getAutopool2xMainIndexByIndex($index){

global $conn;

$query = "SELECT mainIndex  FROM `autoPool2x` WHERE indexId=$index";

$result = mysqli_query($conn,$query);

if($result){

	$row = mysqli_fetch_assoc($result);

  return  $row['mainIndex'];
        
}

}





//---------------------------------------------------------------------------------------------------------



//---------------------------------------------------WRITE -------------------------------------------------



function addNewPool2xEntry($index,$parent,$mainIndex,$user,$trx){

global $conn;

$query = "INSERT INTO `autoPool2x`(`indexId`,`parent`, `mainIndex`,`userID`,`transaction_id`) VALUES ('$index','$parent','$mainIndex','$user','$trx')";

$result = mysqli_query($conn,$query);



if($result){

	return true;
}

return false;

}


function addNewPool2xRebirthEntry($index,$fromUser,$toUser){

global $conn;

$query = "INSERT INTO `event_pool2xRebirth`(`indexId`, `fromUser`,`toUser`) VALUES ('$index','$fromUser','$toUser')";

$result = mysqli_query($conn,$query);



if($result){

	return true;
}

return false;

}


function addNewPool3xRebirthEntry($index,$fromUser,$toUser){

global $conn;

$query = "INSERT INTO `event_pool3xRebirth`(`indexId`, `fromUser`,`toUser`) VALUES ('$index','$fromUser','$toUser')";

$result = mysqli_query($conn,$query);



if($result){

	return true;
}

return false;

}


function addNewPool3xEntry($index,$parent,$mainIndex,$user,$trx){

global $conn;

$query = "INSERT INTO `autoPool3x`(`indexId`,`parent`, `mainIndex`,`userID`,`transaction_id`) VALUES ('$index','$parent','$mainIndex',$user,'$trx')";

$result = mysqli_query($conn,$query);



if($result){

	return true;
}

return false;

}






function addNewPool2xPayEntry($index,$fromUser,$toUser,$amount,$timestamp,$cycle){

global $conn;

$query = "INSERT INTO `autoPool2xPay`(`fromUser`, `mIndex`, `toUser`, `amount`, `timestamp`,`cycle`) VALUES ('$fromUser','$index','$toUser','$amount','$timestamp','$cycle')";

$result = mysqli_query($conn,$query);



if($result){

	return true;
}

return false;

}


function addNewPool3xPayEntry($index,$fromUser,$toUser,$amount,$timestamp){

global $conn;

$query = "INSERT INTO `autoPool3xPay`(`fromUser`, `mIndex`,`toUser`, `amount`, `timestamp`) VALUES ('$fromUser','$index','$toUser','$amount','$timestamp')";

$result = mysqli_query($conn,$query);



if($result){

	return true;
}

return false;

}








function init2xIndex($mainIndex,$userID,$target,$acheive){

global $conn;

// check id is exist or not 

if (isMain2xIndexExisit($mainIndex)){

//update call

updateMain2xIndex($mainIndex,$target,$acheive);


}else{

	// add call
	addMain2xIndex($mainIndex,$userID,$target,$acheive);

}



}


function addMain2xIndex($mainIndex,$userId,$target,$acheive){

global $conn;


$query = "INSERT INTO `index_2xreference` (`mainIndex`,`userId`, `targetFillBox`, `acheiveFillBox`) VALUES ('$mainIndex','$userId','$target','$acheive')";

$result = mysqli_query($conn,$query);



if($result){

	return true;

}else{

	return false;
}

}


function updateMain2xIndex($mainIndex,$target,$acheive){

global $conn;

$query= "UPDATE `index_2xreference` SET `targetFillBox`='$target',`acheiveFillBox`='$acheive' WHERE mainIndex=$mainIndex";

$result = mysqli_query($conn,$query);

if($result){

	return true;
}

return false;

}


//-----------------------------------------CORE LOGIC-----------------------------



function addAutopool2XPosition($userId){


// -----------initiate mother id--------------



 $lastParent = get2XLastParentId();

	echo "Last Parent :".$lastParent;

 $lastIndex = getAutoPool2xLastIndex()+1;




 addNewPool2xEntry($lastParent,$lastIndex,0);

initAutopool2xMainIndex($lastIndex,$userId); // initilize main index for current entry



payNbirthAutoPool2x(($lastParent));


//checking for re-birth


}


function initAutopool2xMainIndex($index,$userId){


	$target = 4;
	$achieve = 0;

	// default value set 
	 addMain2xIndex($index,$userId,$target,$achieve);



}

function reInitAutopool2xMain($index){


if(isMain2xIndexExisit($index)){

$target = get2xIndexTarget($index);
$achive = get2xIndexAchieve($index);



if ($achive==$target){

	$achive=0;
	$target *=2;
	
}

updateMain2xIndex($index,$target,($achive));


}


}


function defaultIdPool2xPay($parent){
global $POOL_2X_PAY;
$now = time();

if($parent==0){  // defayt id will always pay 

	$mainIndex = getAutoPool2xLastIndex();
	//getAutoPool2xLastIndex
	payUserAutoPool2x($mainIndex,0,$POOL_2X_PAY);
	addIncomeEntry(0,0,$POOL_2X_PAY,'globalPool2x',$now);

	

	$target    = get2xIndexTarget($mainIndex);
	$acheive   = get2xIndexAchieve($mainIndex);

	updateMain2xIndex($mainIndex,$target,($acheive));

	return true;

}


return false;


}


function validateNdPayPool2x ($parent){

global $POOL_2X_PAY;
global $POOL_UPLINE_BONUS;

$now = time();

$mainIndex = getAutopool2xMainIndexByIndex($parent);
$user 	   = getUserBy2xMainIndex($mainIndex) ;
$target    = get2xIndexTarget($mainIndex);
$acheive   = get2xIndexAchieve($mainIndex);

echo '</br>';
echo 'mainindex :'. $mainIndex;

// Initial Updates
$payTarget = $target*25/100;
$reBirthTarget   = $target*75/100;

echo "</br>";
echo 'ache: ' .$acheive;
echo "</br>"; echo 'target :'. $payTarget;

updateMain2xIndex($mainIndex,$target,($acheive+1));

 reInitAutopool2xMain($mainIndex); // initilize main index for current entry

if ($acheive<$payTarget){

	$payAmnt = $POOL_2X_PAY*5/100;

	payUserAutoPool2x($mainIndex,$user,($POOL_2X_PAY-$payAmnt));
	//addIncomeEntry('poolCommission');
	addIncomeEntry(0,$user,$payAmnt,'poolCommission',$now);

	addIncomeEntry($user,0,($POOL_2X_PAY-$payAmnt),'globalPool2x',$now);
	// dedcut system fee 

	// add new income poolRefIncome

	$gainer = getUserReferrerId($user);
	
	payToPoolDirectEntry($user,$gainer,$POOL_UPLINE_BONUS,$now);

	//payToDirectEntry($from,$to,$sponser_pay,$current)

	addIncomeEntry($gainer,$user,($POOL_UPLINE_BONUS),'poolUpline',$now);


	return true;
}


return false;

}





function payNbirthAutoPool2x($parent){

if (defaultIdPool2xPay($parent)){ // only for default pool pay

	return 1;
}


if (validateNdPayPool2x($parent)){

	
}else{


	reBirthUserAutoPool2x();


}


}


function payUserAutoPool2x($main,$userID,$amount){

global $conn;
$now = time();

$query = "INSERT INTO `2xAutoPoolPay`(`userIndex`, `toUser`, `amount`, `timestamp`) VALUES ('$main','$userID','$amount','$now')";

$result = mysqli_query($conn,$query);



	if($result){

		return true;
	}

	return false;
}



function reBirthUserAutoPool2x($counter=0){



 $Parent = get2XLastParentId();

$counter++;



$fill = getAutoPool2xParentFillBox($Parent);

if ($fill==0){

	$lastParent=($Parent-1);
}else{

	$lastParent=($Parent);
}




$LastMainIndex = getAutopool2xMainIndexByIndex($lastParent);


$mainIndex = getAutopool2xMainIndexByIndex($Parent);



// CHECK ELIGIBLITY CITERIA OF CURRENT INDEX TO DECIDE CALL 

if (validateNdPayPool2x($Parent)){

	addNewPool2xEntry($Parent,$LastMainIndex,1);
	// pay
	return 1;  // terminate call

}else{

	addNewPool2xEntry($Parent,$LastMainIndex,2);
	
	reBirthUserAutoPool2x($counter);

}


}


function reEntryAutoPool2x($userId) {

addAutopool2XPosition($userId);

}


//-------------------------------------------------------------------------------------------------------

//---------------------------------------------TEMP AUTOPOOL 3X

//-------------------------------------------------------------------------------------------------------








function addMainIndex3x($mainIndex,$userId,$target,$acheive){

global $conn;

$query = "INSERT INTO `index_3xreference` (`mainIndex`,`userId`, `targetFillBox`, `acheiveFillBox`) VALUES ('$mainIndex','$userId','$target','$acheive')";

$result = mysqli_query($conn,$query);



if($result){

	return true;

}else{

	return false;
}

}


function updateMainIndex3x($mainIndex,$target,$acheive){

global $conn;

$query= "UPDATE `index_3xreference` SET `targetFillBox`='$target',`acheiveFillBox`='$acheive' WHERE mainIndex=$mainIndex";

$result = mysqli_query($conn,$query);

if($result){

	return true;
}

return false;

}







function isMainIndexExisit3x($index){

global $conn;

$query = "SELECT * FROM `index_3xreference` WHERE mainIndex=$index";

$result = mysqli_query($conn,$query);

if($result){

	$rowcount=mysqli_num_rows($result);

	if($rowcount>0){
    
    	return true;
    }

}

return false;

}







function getIndexTarget3x($index){

global $conn;

$query = "SELECT targetFillBox FROM `index_3xreference` WHERE mainIndex=$index";

$result = mysqli_query($conn,$query);

if($result){

	$rowcount=mysqli_num_rows($result);

		if ($rowcount>0){
        	
        	$row = mysqli_fetch_assoc($result);

			return $row['targetFillBox'];
        }

}

return 0;

}




function getUserByMainIndex3x($mainIndex){

global $conn;

$query = "SELECT userId FROM `index_3xreference` WHERE mainIndex=$mainIndex";

$result = mysqli_query($conn,$query);

if($result){

	$rowcount=mysqli_num_rows($result);

		if ($rowcount>0){
        	
        	$row = mysqli_fetch_assoc($result);

			return $row['userId'];
    }
}

	return 0;

}



function getIndexAchieve3x($index){

global $conn;

$query = "SELECT acheiveFillBox FROM `index_3xreference` WHERE mainIndex=$index";

$result = mysqli_query($conn,$query);

if($result){

	$rowcount=mysqli_num_rows($result);

		if ($rowcount>0){
        	
        	$row = mysqli_fetch_assoc($result);

			return $row['acheiveFillBox'];
    }
}


}




function addAutopoolPosition3x($userId){


// -----------initiate mother id--------------



echo $lastParent = getLastParentId3x();
echo  $lastIndex = getLastIndex3x()+1;


echo addNewPool3xEntry($lastParent,$lastIndex,0);

initMainIndex3x($lastIndex,$userId); // initilize main index for current entry



payNbirth3x(($lastParent));


//checking for re-birth



}


function getLastParentId3x(){

global $conn;

$query = "SELECT max(`parent`) as parent FROM `autoPool3x`";

$result = mysqli_query($conn,$query);

if ($result){

	$row_Count =mysqli_num_rows($result);

	if($row_Count>0){
    
    	// need to execute 
    
    		$row = mysqli_fetch_assoc($result);
    
    		$parent = $row['parent'];
    
    		$fillbox = getParentFillBox3x($parent);
    
    
    		if ($fillbox==3  ){
            
            	$parent++;
            
            }else if ($fillbox==2 && $parent==0 ){
            
            	$parent++;
            }
   
    
    		return $parent;
    		
    }else{
    
    
    	return 0; // as default index 
    
    }

}


}


function getParentByIndex($index){

global $conn;

$query = "SELECT `parent` as parent FROM `autoPool3x` where indexId=$index";

$result = mysqli_query($conn,$query);

if ($result){

	$row_Count =mysqli_num_rows($result);

	if($row_Count>0){
    
    	// need to execute 
    
    		$row = mysqli_fetch_assoc($result);
    
    		$parent = $row['parent'];
    
    		
    
    		return $parent;
    		
    }else{
    
    
    	return 1; // as default index 
    
    }

}


}

function getLastIndex3x(){

global $conn;

$query= "SELECT max(indexId) as index_ FROM `autoPool3x`  ";

$result= mysqli_query($conn,$query);

if($result){

	$row = mysqli_fetch_assoc($result);

	if( $row['index_']==0 ||  $row['index_']==''){
    
    	return 0;
    }

	return  $row['index_'];

}

return 0;

}







function getParentFillBox3x($parent){


global $conn;

$query = "SELECT count(parent) as fillbox FROM `autoPool3x` WHERE parent=$parent";

$result = mysqli_query($conn,$query);

if($result){


	$row_Count =mysqli_num_rows($result);

	if($row_Count>0){
    
    	$row = mysqli_fetch_assoc($result);

  		return  $row['fillbox'];
        
    
    }


}

	return 0;

}

function getRebirthParentFillBox($parent){


global $conn;

$query = "SELECT  *  fillbox FROM `autoPool3x` WHERE parent=$parent ";

$result = mysqli_query($conn,$query);

if($result){

	$count;

	$eligible;

	$row_Count =mysqli_num_rows($result);

	if($row_Count>0){
    
    
    	while ($row = mysqli_fetch_assoc($result)){
        
        
        	 if ($row['isThisRebirth']==1){
        
        			$eligible=true;
        
        	}
        
        	$count++;
        
        }
    
    	if ($eligible){
        
        	return $count;
        }


    }

     return 0;   
}

}


function lastBirthParent(){

global $conn;

$query = "SELECT parent  FROM `autoPool3x` WHERE  isThisRebirth=1 order by indexId desc limit 1  ";

$result = mysqli_query($conn,$query);

if($result){

	$row_Count =mysqli_num_rows($result);

	if($row_Count>0){

		$row = mysqli_fetch_assoc($result);

  		 return  $row['parent'];
  
    }
        
}

return 0;

}



function getMainIndexByIndex3x($index){

global $conn;

$query = "SELECT mainIndex  FROM `autoPool3x` WHERE indexId=$index";

$result = mysqli_query($conn,$query);

if($result){

	$row = mysqli_fetch_assoc($result);

  return  $row['mainIndex'];
        
}

}


function initMainIndex3x($index,$userId){


	$target = 6;
	$achieve = 0;

	// default value set 
	echo addMainIndex3x($index,$userId,$target,$achieve);



}

function reInitMain3x($index){

//----check index exisitance
// -------------- get target 
//-----------get acheive
//-------------get calculation

if(isMainIndexExisit3x($index)){

$target = getIndexTarget3x($index);
$achive = getIndexAchieve3x($index);



if ($achive==$target){

	$achive=0;
	$target *=2;
	
}

updateMainIndex3x($index,$target,($achive));


}


}


function defaultIdPoolPay3x($parent){

	global $POOL_3X_PAY;
	$now = time();

	if($parent==0){  // defayt id will always pay 

		$mainIndex = getLastIndex3x();
		payUser3x($mainIndex,0,$POOL_3X_PAY);
		addIncomeEntry(0,0,$POOL_3X_PAY,'globalPool3x',$now);

		

		$target    = getIndexTarget3x($mainIndex);
		$acheive   = getIndexAchieve3x($mainIndex);

		updateMainIndex3x($mainIndex,$target,($acheive));

		return true;

	}


	return false;


}


function validateNdPay3x ($parent){

 global $POOL_3X_PAY;

 $now = time();

$mainIndex = getMainIndexByIndex3x($parent);
$user 	   = getUserByMainIndex3x($mainIndex) ;
$target    = getIndexTarget3x($mainIndex);
$acheive   = getIndexAchieve3x($mainIndex);


echo '</br>';
echo 'mainindex :'. $mainIndex;

// Switch

// Initial Updates




// echo "</br>"; echo 'target :'. $payTarget;

updateMainIndex3x($mainIndex,$target,($acheive+1));
$acheive   = getIndexAchieve3x($mainIndex);

$payTarget = round($target*66.67/100);
$reBirthTarget   = round($target*33.33/100);

echo "</br></br></br>-----------------Autopool3x-------------------------------</br>";

echo "</br>-----------------------------BEFORE SWITCH------------------------------</BR>";

echo "Acheive Target :-".$acheive;
echo "Pay Target :-".$payTarget;
echo "ReBirth Target :-".$reBirthTarget;


if (($target/2)<=$acheive){

	// swap 
	$payTarget  = round($target*33.33/100);
	$reBirthTarget = round($target*66.67/100);

	echo "Switch";

	echo "</br>";

}




 reInitMain3x($mainIndex); // initilize main index for current entry
$acheive   = getIndexAchieve3x($mainIndex);

echo "</br>-----------------------------AFTER SWITCH------------------------------</BR>";
echo "Acheive Target :-".$acheive;
echo "Pay Target :-".$payTarget;
echo "ReBirth Target :-".$reBirthTarget;


if ($acheive<$payTarget){

	
	$payAmnt = $POOL_3X_PAY*5/100;

	payUser3x($mainIndex,$user,($POOL_3X_PAY-$payAmnt));
	//addIncomeEntry('poolCommission');
	addIncomeEntry(0,$user,$payAmnt,'poolCommission',$now);

	addIncomeEntry($user,0,($POOL_3X_PAY-$payAmnt),'globalPool3x',$now);
	// dedcut system fee 


	return true;
}


return false;

}



function payNbirth3x($parent){

if (defaultIdPoolPay3x($parent)){ // only for default pool pay

	return 1;
}


if (validateNdPay3x($parent)){


	// all code is done in validate body no need to express anything in this block
	
}else{



	//$getRebirth = getMaxBirth();

	reBirthUser3x();

	// check if this section required more rebirth

	// validate index if they are in 75% then recall it otherwise no need to re-call

	//updateMaxRebirth(($getRebirth));

	
}


}


function payUser3x($main,$userID,$amount){


global $conn;
$now = time();

$query = "INSERT INTO `3xAutoPoolPay`(`userIndex`, `toUser`, `amount`, `timestamp`) VALUES ('$main','$userID','$amount','$now')";

$result = mysqli_query($conn,$query);



	if($result){

		return true;
	}

	return false;

}



function reBirthUser3x($counter=0){

// ----------------------UPDATE LAST PARENT FILLING 

	

// 	$target    = getIndexTarget($LastMainIndex);
// 	$acheive   = getIndexAchieve($LastMainIndex);

// 	updateMainIndex($LastMainIndex,$target,($acheive+1)); // update current pool 

//--------------------------CURRENT CALL

echo "</br>";

 $Parent = getLastParentId3x();

$counter++;




$fill = getParentFillBox3x($Parent);

if ($fill==0){

	$lastParent=($Parent-1);
}else{

	$lastParent=($Parent);
}


$LastMainIndex = getMainIndexByIndex3x($lastParent);



$mainIndex = getMainIndexByIndex3x($Parent);





// CHECK ELIGIBLITY CITERIA OF CURRENT INDEX TO DECIDE CALL 

if (validateNdPay3x($Parent)){

	// pay
	 addNewPool3xEntry($Parent,$LastMainIndex,1);
	return 1;  // terminate call

}else{


	 addNewPool3xEntry($Parent,$LastMainIndex,2);
	reBirthUser3x($counter);


}




}


function reEntry3x($userId) {

addAutopoolPosition3x($userId);

}










// =============================================================================


					//			UI GET API CALL


//=================================================================================


//get user withdrawn balance 

function getUserWithdrawnBalanceNode($walletAddress){
    

	$url = "http://127.0.0.1:8888/getWithdrawn?userWallet=".$walletAddress;

	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $output = curl_exec($ch);
    $output = json_decode($output,true);
    // if (curl_errno($ch)) {
    // $error_msg = curl_error($ch);
    // echo $error_msg;
    // }
    curl_close ($ch);
	
// 	print "<pre>";
// 	 print_r($output);
	
if ($output['result']='success' && count($output)>0 || !empty($output) ){
    	
    	return $output['value'];
    }

	else{
    	return 0;
    }

}





function updateWithdrawNode($walletAddress,$amount){

	// $amount = intval($amount);
	// $url = "http://35.224.139.119:1122/userwithdraw?userWallet=asadsd&amount=500";
	$url = "http://127.0.0.1:8888/937ac66925865e2135e559ea848edfdc?userWallet=".$walletAddress."&amount=".$amount;
    //$url = "http://35.224.139.119:1222/userwithdraw?userWallet=".$walletAddress."&amount=500";
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $output = curl_exec($ch);
    $output = json_decode($output,true);
    // if (curl_errno($ch)) {
    // $error_msg = curl_error($ch);
    // echo $error_msg;
    // }
    curl_close ($ch);
	
// 	print "<pre>";
// 	 print_r($output);
	
if ($output['result']='success' && count($output)>0 || !empty($output) ){
    	
    	return 1;
    }

	else{
    	return 0;
    }

}


// block user


function reInvestNode($walletAddress,$position,$amount){

	
	// $url = "http://35.224.139.119:1122/userwithdraw?userWallet=asadsd&amount=500";
	$url = "http://127.0.0.1:8888/bc8595188e5faa75f91ce838e4716b54?userWallet=".$walletAddress."&position=".$position."&amount=".$amount;
    //$url = "http://35.224.139.119:1222/userwithdraw?userWallet=".$walletAddress."&amount=500";
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $output = curl_exec($ch);
    $output = json_decode($output,true);
    // if (curl_errno($ch)) {
    // $error_msg = curl_error($ch);
    // echo $error_msg;
    // }
    curl_close ($ch);
	
// 	print "<pre>";
// 	 print_r($output);
	
if ($output['result']='success' && count($output)>0 || !empty($output) ){
    	
    	return 1;
    }

	else{
    	return 0;
    }

}


function rePoolNode($walletAddress,$position,$amount){

	
	// $url = "http://35.224.139.119:1122/userwithdraw?userWallet=asadsd&amount=500";
	$url = "http://127.0.0.1:8888/1037756fb7075bd3c48aacb33e43d9e6?userWallet=".$walletAddress."&position=".$position."&amount=".$amount;
    //$url = "http://35.224.139.119:1222/userwithdraw?userWallet=".$walletAddress."&amount=500";
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $output = curl_exec($ch);
    $output = json_decode($output,true);
    // if (curl_errno($ch)) {
    // $error_msg = curl_error($ch);
    // echo $error_msg;
    // }
    curl_close ($ch);
	
// 	print "<pre>";
// 	 print_r($output);
	
if ($output['result']='success' && count($output)>0 || !empty($output) ){
    	
    	return 1;
    }

	else{
    	return 0;
    }

}



function transferNode($walletAddress,$to,$posAmount,$amount){

	
	 //$url = "http://35.224.139.119:1122/userwithdraw?userWallet=asadsd&amount=500";
	$url = "http://127.0.0.1:8888/41174020ecadc35772c03d46f0fa45d0?userWallet=".$walletAddress."&to=".$to."&position=".$posAmount."&amount=".$amount;
    //$url = "http://35.224.139.119:1222/userwithdraw?userWallet=".$walletAddress."&amount=500";
	$ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $output = curl_exec($ch);
    $output = json_decode($output,true);
    // if (curl_errno($ch)) {
    // $error_msg = curl_error($ch);
    // echo $error_msg;
    // }
    curl_close ($ch);
	
	// print "<pre>";
	//  print_r($output);
	
if ($output['result']='success' && count($output)>0 || !empty($output) ){
    	
    	return 1;
    }

	else{
    	return 0;
    }

}









?>



