<?php


//system default localhost server
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','dyILbn9pz0dSL6i9');
define('DB_NAME','nexadai_test');



$conn = mysqli_connect(DB_HOST,DB_USER, DB_PASS,DB_NAME);
// Check connection
if (mysqli_connect_errno()){
  	echo "Failed to connect to MySQL: " . mysqli_connect_error();
 }


$tronscanurl='';
$network=0;
//getting admin setting data
$query = "SELECT * FROM adminsetting  ";
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result);
if($row != NULL){
	$mainContractAddress = $row['mainContractAddress'];
	$mainContractABI = $row['mainContractABI'];
	$paxContractAddress = $row['paxContractAddress'];
	$paxABI = $row['paxABI'];
   $siteURL = $row['siteURL'];
 
  $siteName = $row['siteName'];
  $tronscanMain = $row['tronscanMain'];
  $tronscanTest = $row['tronscanTest'];
  $network = $row['network'];
	$tronPiceInUsd=$row['tronPiceInUsd'];
	$billionmoneyTokenAddress=$row['billionmoneyTokenAddress'];
	$payout =  $row['payOut_address'];
	$token = $row['paxContractAddress'];

}


$trongridurl='';

if($network==1)
{
  $tronscanurl=$tronscanMain;

  define('BSC_API','https://api.polygonscan.com/');
}
else {
  $tronscanurl=$tronscanTest;

	define('BSC_API','https://api-testnet.polygonscan.com/');

}


define('BSCURL',$tronscanurl);


define('MAIN_CONTRACT_ADDRESS',$mainContractAddress);
define('PAY_OUT',$payout);
define('TOKEN',$token);
define ('URL',$siteURL);
define ('ABI',$mainContractABI);
define ('TOKEN_ABI',$paxABI);

 function clean($string) {
   $string = str_replace(' ', '', $string); // Remove all spaces.

   return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}




