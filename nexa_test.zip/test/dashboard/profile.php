<?php include("header.php")?>
<div class="content-panel-toggler ">
   <i class="os-icon os-icon-grid-squares-22"></i>
   <span>Sidebar</span>
</div>
<div class="content-i">
   <div class="content-box">
      <div class="element-wrapper ">
         <div class="element-box">
            <form>
               <div class="row">
                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for=""> First Name</label>
                        <input class="form-control" placeholder="First Name" type="text">
                     </div>
                  </div>
                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="">Last Name</label>
                        <input class="form-control" placeholder="Last Name" type="text">
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <label for=""> Email address</label>
                  <input class="form-control" placeholder="Enter email" type="email">
               </div>
               <div class="row">
                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="">Date of Birth</label>
                        <div class="date-input"><input class="single-daterange form-control" placeholder="Date of birth" type="text" value="04/12/1978">
                        </div>
                     </div>
                  </div>
                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="">Gender</label>
                        <select class="form-control">
                           <option>Female</option>
                           <option>Male</option>
                           <option>Other</option>
                        </select>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="">Country of Origin</label>
                        <input class="form-control" placeholder="Country" type="text">
                     </div>
                  </div>
                  <div class="col-sm-6">
                     <div class="form-group">
                        <label for="">Phone Number</label>
                        <input class="form-control" placeholder="Phone Number" type="text">
                     </div>
                  </div>
               </div><!--
               <div class="form-group">
                  <label for="">Twitter Username</label>
                  <div class="input-group">
                     <div class="input-group-addon">@</div>
                     <input class="form-control" placeholder="Twitter Username" type="text">
                  </div>
               </div><
               <legend><span>Nominee</span></legend>
               <div class="row">
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Nominee Name</label>
                        <input class="form-control" placeholder="Full Nominee of Name" type="text">
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Relationship</label>
                        <select class="form-control">
                           <option>Father</option>
                           <option>Mother</option>
                           <option>Spouse</option>
                           <option>Son</option>
                           <option>Daughter</option>
                        </select>
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="form-group">
                        <label for="">Date of Birth</label>
                        <div class="date-input"><input class="single-daterange form-control" placeholder="Date of birth" type="text" value="">
                        </div>
                     </div>
                  </div>
               </div>  -->
               <div class="form-buttons-w text-right">
                  <a class="btn btn-danger step-trigger-btn" href="#">Save</a>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
</div>
</div>
<div class="display-type"></div>
</div>
<?php include("footer.php") ?>
