<?php 
include('../include_file/config.php');
include('../include_file/function.php');



if(isset($_POST['level']) && isset($_POST['nextList'])){

$list= array(1);

if (isset($_POST['nextList'])){

$list = $_POST['nextList'];

}

$obj = downlineDigByLevel($list,$_POST['level']);




echo json_encode($obj);



}




?>