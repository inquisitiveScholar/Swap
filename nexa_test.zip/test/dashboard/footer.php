   </body>
   
   <?php require('../include_file/contractInfo.php'); ?>
   
      <script src="https://cdnjs.cloudflare.com/ajax/libs/AlertifyJS/1.13.1/alertify.min.js"></script>
   
     <script src="https://cdn.jsdelivr.net/gh/ethereum/web3.js@1.0.0-beta.34/dist/web3.js"></script>
  <script src="../assets/js/jqueryv2.min.js"></script>
   <script src="bower_components/moment/moment.js"></script>
   <script src="bower_components/chart.js/dist/Chart.min.js"></script>
   <script src="bower_components/select2/dist/js/select2.full.min.js"></script>
   <script src="bower_components/jquery-bar-rating/dist/jquery.barrating.min.js"></script>
   <script src="bower_components/ckeditor/ckeditor.js"></script>
   <script src="bower_components/bootstrap/js/dist/tooltip.js"></script>
   <script src="bower_components/bootstrap-validator/dist/validator.min.js"></script>
   <script src="bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
   <script src="bower_components/ion.rangeSlider/js/ion.rangeSlider.min.js"></script>
   <script src="bower_components/dropzone/dist/dropzone.js"></script>
   <script src="bower_components/editable-table/mindmup-editabletable.js"></script>
   <script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
   <script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
   <script src="bower_components/fullcalendar/dist/fullcalendar.min.js"></script>
   <script src="bower_components/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js"></script>
   <script src="bower_components/tether/dist/js/tether.min.js"></script>
   <script src="bower_components/slick-carousel/slick/slick.min.js"></script>
   <script src="bower_components/bootstrap/js/dist/util.js"></script>
   <script src="bower_components/bootstrap/js/dist/alert.js"></script>
   <script src="bower_components/bootstrap/js/dist/button.js"></script>
   <script src="bower_components/bootstrap/js/dist/carousel.js"></script>
   <script src="bower_components/bootstrap/js/dist/collapse.js"></script>
   <script src="bower_components/bootstrap/js/dist/dropdown.js"></script>
   <script src="bower_components/bootstrap/js/dist/modal.js"></script>
   <script src="bower_components/bootstrap/js/dist/tab.js"></script>
   <script src="bower_components/bootstrap/js/dist/tooltip.js"></script>
   <script src="bower_components/bootstrap/js/dist/popover.js"></script>
  
 
   <script src="js/dataTables.bootstrap4.min.js"></script>
<script src="js/main0dc4.js?version=5"></script>
   
   <script src="../controller.js?v=58.2"></script>
   
   
   <script>
   
   var hash="na";
   
//           alertify.alert("Step 1 of 2", "Please check the status of transaction at: <a href='https://etherscan.io/tx/"+hash+"' target='_blank'> Etherscan</a> <br><br> Please wait for the transaction to be confirmed for the second step.", function(){

//         });

var wallet = '<?php echo USER_WALLET ?>';

  $('.w-short').text( wallet.substring(0,8) + '....' + wallet.slice(-8));


</script>

<script>

$('#theme_toggle').click(()=>{

var color= "color-scheme-dark";



if($("body").hasClass("color-scheme-dark")){

	// remove dark mode

	$("body").removeClass(color);
	$('.desktop-menu').removeClass(color);

	localStorage.removeItem("theme");

	$('.header-logo').attr("src","../../assets/images/logo/logoh-3.png?v=3.00");// add white

}else{

	// add dark mode
	$("body").addClass(color);
	// subset need to add also 
	localStorage.setItem("theme", color);
	$('.desktop-menu').addClass(color);

	$('.header-logo').attr("src","../../assets/images/logo/logoh-1.png"); // add dark

}


});


if (localStorage.getItem("theme")!=undefined){

	var color = localStorage.getItem("theme");

		$("body").addClass(color);
	// subset need to add also 
	$('.desktop-menu').addClass(color);
	
	if (color=="color-scheme-dark"){
    
    		$('.header-logo').attr("src","../../assets/images/logo/logoh-1.png");
    
    }else{
    
    	$('.header-logo').attr("src","../../assets/images/logo/logoh-3.png?v=3.00");
    
    }

	
	

}

</script>
   
</html>
