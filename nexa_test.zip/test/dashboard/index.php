<?php  


if (isset($_GET['team']))
{
	include ('team.php');
}

else if(isset($_GET['profile'])){

	include('profile.php');
}
else if(isset($_GET['myref'])){

	include('myref.php');
}
else if(isset($_GET['bonus'])){

	include('bonus.php');
}
else if(isset($_GET['transfer'])){

	include('transfer.php');
}
else if(isset($_GET['pool'])){

	include('pool.php');

}else if(isset($_GET['withdrawHist'])){

	include('withdrawTrans.php');

}else if(isset($_GET['investHist'])){

	include('investTrans.php');

}else if(isset($_GET['poolHist'])){

	include('poolTrans.php');
}else if (isset($_GET['lostIncome'])){

	include('lostIncome.php');
}

else{
	include ('dashboard.php');
}




?>