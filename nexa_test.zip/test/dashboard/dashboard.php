<?php include("header.php");
   $directObj= getUserTotalDirectProfit($user);
   $unilevelObj= getUserTotalUnilevelProfit($user);
   $gapObj = getUserTotalGenGapProfit($user);
   $royalObj = getUserTotalRoyalityProfit($user);
   $totalProfit = getUserTotalProfit($user);
   $totalPool2xProfit = getUserTotalPool2xProfit($user);
   $totalPool3xProfit = getUserTotalPool3xProfit($user);
   $totalTransfered = getTotalTransferFund($user);
   $total2xPoolBuyFund = getTotal2xPoolBuyFund($user);
   $totalRentryFund = getTotalReEntryFund($user);
   $totalReceivedFund = getTotalReceivedFund($user);
   
   $totalInactive = getInactiveUser($user);
   
   $totalPoolComProfit = getUserTotalPoolCommissionProfit($user);
   
   $total2xPoolBuy = getUserTotal2xPoolBuy($user);
    $total3xPoolBuy = getUserTotal3xPoolBuy($user);
   
   //ref link
   $token = getTokenIDByUser($user);
   $ref_link = URL."index?ref=".USER_WALLET;
   
   
   
 
   
   ?>
<div class="content-panel-toggler">
   <i class="os-icon os-icon-grid-squares-22"></i><span>Sidebar</span>
</div>
<div class="content-i">
   <div class="content-box">
      <div class="row">
         <div class="col-sm-12">
            <div class="alert alert-danger inactivePanel alert-dismissible fade show " style="display:none"  role="alert"><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button><strong > Welcome ! thank you for join with us, our request to you Kindly activate your account soon otherwise you will be loose your upcoming income.  </strong> <button class=" active-user btn btn-danger" >Activate</button></div>
               <div class="alert alert-danger alert-dismissible fade show" role="alert" style="display:none" ><button aria-label="Close" class="close" data-dismiss="alert" type="button"><span aria-hidden="true"> ×</span></button><strong>Attention ! your income limit has been exceed kindly re-topup again otherwise you will  loose your upcomming income </strong> 
               </div> 
            <div class="element-wrapper">
               <div class="mb-2">
                  <span class="btn btn-outline-primary btn-sm mr-1 mt-1 " style="text-transform:none"> Ref Link:<span type="text" id="ref_link" data-val="<?php echo $ref_link ?>"><?php echo substr($ref_link,0,41).'......'.substr($ref_link,-5); ?></span></span>
                  <button class="mr-2 mt-1 btn btn-primary btn-sm" id="copyel" onclick="CopyEl()" type="button">Copy</button>
                  <a class="mr-2 mt-1 btn btn-warning btn-sm" id="copyxc" href="<?php echo $ref_link ?>" target="_blank" type="button">Open</a>
               </div>
               <h6 class="element-header">My Dashboard</h6>
               <div class="row">
                  <div class="col-sm-7">
                     <div class="element-box">
                        <span class="label">MY BONUS</span>
                        <div class="row ">
                           <div class="col-sm-2 py-2 mt-3">
                              <div class="value"><i class="icon-user fs-26 fc-info float-left"></i></div>
                           </div>
                           <div class="col-sm-10 pl-0 py-2 mt-3 b-b">
                              <div class="os-progress-bar danger ml-3 mr-3">
                                 <div class="bar-labels">
                                    <div class="bar-label-left">
                                       <span class="label fs-16">Direct</span>
                                       <span class="positive">+0</span>
                                    </div>
                                    <div class="bar-label-right">
                                       <span class="info fw-600 fs-16">$ <span id="totalDirectProfit" class="info fw-600 fs-16" ></span> </span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-2 py-2">
                              <div class="value"><i class="icon-layers fs-26 fc-secondary float-left"></i></div>
                           </div>
                           <div class="col-sm-10 pl-0 py-2 b-b">
                              <div class="os-progress-bar danger ml-3 mr-3">
                                 <div class="bar-labels">
                                    <div class="bar-label-left">
                                       <span class="label fs-16">Uni-Level</span>
                                       <span class="positive">+0</span>
                                    </div>
                                    <div class="bar-label-right">
                                       <span class="info fw-600 fs-16">$ <span id="totalUnilevelProfit" class="info fw-600 fs-16" ></span></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-2 py-2">
                              <div class="value"><i class="icon-rocket fs-26 fc-danger float-left"></i></div>
                           </div>
                           <div class="col-sm-10 pl-0 py-2 b-b">
                              <div class="os-progress-bar danger ml-3 mr-3">
                                 <div class="bar-labels">
                                    <div class="bar-label-left">
                                       <span class="label fs-16">Gap Bonus</span>
                                       <span class="positive">+0</span>
                                    </div>
                                    <div class="bar-label-right">
                                       <span class="info fw-600 fs-16">$ <span id="totalGapProfit" class="info fw-600 fs-16" ></span></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-2 py-2">
                              <div class="value"><i class="icon-trophy fs-26 fc-success float-left"></i></div>
                           </div>
                           <div class="col-sm-10 pl-0 py-2 b-b">
                              <div class="os-progress-bar danger ml-3 mr-3">
                                 <div class="bar-labels">
                                    <div class="bar-label-left">
                                       <span class="label fs-16">GR Bonus</span>
                                       <span class="positive totalgrPot "></span>
                                    </div>
                                    <div class="bar-label-right">
                                       <span class="info fw-600 fs-16">$  <span id="totalGlobalRoyality" class="info fw-600 fs-16" ></span></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-2 py-2">
                              <div class="value"><i class="icon-energy fs-26 fc-warning float-left"></i></div>
                           </div>
                           <div class="col-sm-10 pl-0 py-2 b-b">
                              <div class="os-progress-bar danger ml-3 mr-3">
                                 <div class="bar-labels">
                                    <div class="bar-label-left">
                                       <span class="label fs-16">AR Bonus</span>
                                       <span class="positive totalarPot"></span>
                                    </div>
                                    <div class="bar-label-right">
                                       <span class="info fw-600 fs-16">$ <span id="totalActiveRoyality" class="info fw-600 fs-16" ></span></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-2 py-2">
                              <div class="value"><i class="icon-diamond fs-26 fc-theme float-left"></i></div>
                           </div>
                           <div class="col-sm-10 pl-0 py-2 b-b">
                              <div class="os-progress-bar danger ml-3 mr-3">
                                 <div class="bar-labels">
                                    <div class="bar-label-left">
                                       <span class="label fs-16">Global Pool</span>
                                       <span class="positive">+ <span id="poolCount"></span></span>
                                    </div>
                                    <div class="bar-label-right">
                                       <span class="info fw-600 fs-16">$ <span id="total2xPoolProfit" class="info fw-600 fs-16" ></span></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                  
                           <div class="col-sm-2 py-2">
                              <div class="value"><i class="icon-diamond fs-26 fc-theme float-left"></i></div>
                           </div>
                           <div class="col-sm-10 pl-0 py-2 b-b">
                              <div class="os-progress-bar danger ml-3 mr-3">
                                 <div class="bar-labels">
                                    <div class="bar-label-left">
                                       <span class="label fs-16">Pool Sponser</span>
                                       <span class="positive">+ <span id="poolCount"></span></span>
                                    </div>
                                    <div class="bar-label-right">
                                       <span class="info fw-600 fs-16">$ <span id="totalPoolSponserProfit" class="info fw-600 fs-16" ></span></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                          
                           <div class="col-sm-2 py-2">
                              <div class="value"><i class="icon-badge fs-26 fc-danger float-left"></i></div>
                           </div>
                           <div class="col-sm-10 pl-0 py-2 b-b">
                              <div class="os-progress-bar  ml-3 mr-3">
                                 <div class="bar-labels">
                                    <div class="bar-label-left">
                                       <span class="label fs-16">Pool Royalty</span>
                                       <span class="positive"></span>
                                    </div>
                                    <div class="bar-label-right">
                                       <span class="info fw-600 fs-16">$ <span id="poolRoyaltyGains" class="info fw-600 fs-16"></span></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-2 py-2">
                              <div class="value"><i class="icon-magic-wand fs-26 fc-warning float-left"></i></div>
                           </div>
                           <div class="col-sm-10 pl-0 py-2">
                              <div class="os-progress-bar  ml-3 mr-3">
                                 <div class="bar-labels">
                                    <div class="bar-label-left">
                                       <span class="label fs-16">Infinity Pool</span>
                                       <span class="positive">+ <span id="topUpCount"></span></span>
                                    </div>
                                    <div class="bar-label-right">
                                       <span class="info fw-600 fs-16">$ <span id="total3xPoolProfit" class="info fw-600 fs-16"></span></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-sm-5">
                     <div class="element-box pb-1">
                        <span class="label">ROYALTIES</span>
                        <span class="float-right fc-danger " id="nextRoyalty"></span>
                        <div class="row ">
                           <div class="col-sm-12 pl-0 pt-1 b-b">
                              <div class="os-progress-bar danger mx-3">
                                 <div class="bar-labels">
                                    <div class="bar-label-left">
                  						<span id="grStatus"></span>
                                       <span class="label fs-16">User GR Share</span>
                                       <span class="positive grQ">+0</span> 
                                    </div>
                                    <div class="bar-label-right">
                                       <span class="info fw-600 fs-16">$ <span id="grCollection" class="info fw-600 fs-16"></span></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-sm-12 pl-0 pt-1">
                              <div class="os-progress-bar danger mx-3">
                                 <div class="bar-labels">
                                    <div class="bar-label-left">
                  						<span id="arStatus"></span>
                                       <span class="label fs-16">User AR Share</span>
                                       <span class="positive arQ">+0</span> 
                                    </div>
                                    <div class="bar-label-right">
                                       <span class="info fw-600 fs-16">$ <span id="arCollection" class="info fw-600 fs-16"></span></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                    <div class="element-box pl-xxl-5 pr-xxl-5">
                  		<div class="el-tablo highlight bold-label">
                  			<div class="label">TOTAL BONUS</div>
                  			<div class="value fc-30" id="totalP"data-profit="<?php echo $totalProfit[1]; ?>" >$ <span id="totalProfit"></span></div>
                       </div>
                       <div class="el-chart-w">
                  			<div class="chartjs-size-monitor">
                  	 	 	   <div class="chartjs-size-monitor-expand">
                  				<div class=""></div>
                              </div>
                           <div class="chartjs-size-monitor-shrink">
                            <div class=""></div>
                           </div>
                       </div>
                       <canvas height="67" id="lineChart" width="240" style="display: block; height: 45px; width: 160px;" class="chartjs-render-monitor"></canvas></div></div>
                     <a class="element-box el-tablo">
                        <div class="label mb-1">Withdrawal Fund</div>
                        <div class="value"><i class="fc-danger picons-thin-icon-thin-0428_money_payment_dollar_bag_cash"></i> $<span id="withdrawnFund"></span></div>
                     </a>

                  </div>
                  <div class="col-sm-4">
                     <a class="element-box el-tablo" href="#">
                        <div class="label">Total Team</div>
                        <div class="value"><i class="icon-people fc-success fs-30"></i><span id="totalTeamCount"></span></div>
                     </a>
                  </div>
                  <div class="col-sm-4">
                     <a class="element-box el-tablo " href="#">
                        <div class="label bold-label">Direct Team</div>
                        <div class="value"><i class="icon-user fc-info fs-30"></i> <span id="directCount"></span> </div>
                     </a>
                  </div>
                  <div class="col-sm-4">
                     <a class="element-box el-tablo" href="#">
                        <div class="label">Strong Team</div>
                        <div class="value"><i class="fc-success icon-key"></i> <span id="strongTeam"></span></div>
                     </a>
                  </div>
               </div>
               <h6 class="element-header">Fund Manager</h6>
               <div class="element-box">
                  <div class="element-info">
                     <div class="row align-items-center">
                        <div class="col-12">
                           <div class="row text-center">
                              <div class="col-md-8 mt-1 mb-1" style="">
                                 <div class="value fs-26">
                                    <i class="fc-success os-icon os-icon-wallet-loaded"></i>
                                    <span class="fw-600 fc-info pl-2" data-placement="top" data-toggle="tooltip" data-original-title="Available Royalty ">$ <span id="avlFund"></span></span>
                                    <span class="fw-400 fs-16 fc-primary"data-placement="top" data-toggle="tooltip" data-original-title="Income Limit">/ $ <span id="withdrawLimit"></span></span>
                                 </div>
                              </div>
                              <div class="col-md-4 float-right mt-1 mb-1">
                                
                  					<button id="royalityClaim" class="ml-2 btn btn-primary">Claim Royality</button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6 col-xl-6 text-center">
                        <a class="badge badge-info-inverted fs-14 m-x-1 mb-3 fc-info"><span>Next Pool <b id="pool_countDown" class="fc-danger"></b> </span> Pool Limit<b> <span id="poolAchieve"></span>/<span id="poolLimit"></span></b> </a>
                        <div class="row">
                           <div class="col-sm-6">
                              <div class="el-tablo centered padded">
                                 <div class="value">$ <span id="poolHelpFund"></span>
                                 </div>
                                 <div class="label">Help Fund</div>
                              </div>
                           </div>
                           <div class="col-sm-6">
                              <div class="el-tablo centered padded">
                                 <div class="value"><span id="poolHelp"></span></div>
                                 <div class="label">Pool Help</div>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-sm-12">
                              <button class="btn btn-success" style="display:none" id="pool_assistance"><span> Pool Assistance </span>
                              </button>
                           </div>
                      
                        </div>
                     </div>
                     <div class="col-md-6 col-xl-6 text-center">
                        <div class="element-box b-y b-x">
                           <div class="os-tabs-w">
                              <span class="fs-16 fw-500 fc-info">Transfer Credit fund</span>
                              <div class="tab-content">
              
                                 <a class="fs-14 m-x-1 mb-3 mt-3 "><button class="btn btn-outline-danger btn fs-14 m-x-1 mb-2 mt-2"><span>Credit Fund<b> $ <span id="w-limit"></span></b></span> </button></a>

                                 <div class="tab-pane active mt-2" id="tab_sales" aria-expanded="false">
                                    <form>
                                       <div class="row">
                                          <div class="col-sm-12">
                                             <div class="form-group">
                                                <div class="input-group mb-2 mr-sm-2 mb-sm-0">
                                                   <input class="form-control" placeholder="To 0x3es.. Address" id="fund_receiver" type="address">
                                                </div>
                                             </div>
                                          </div>

                                          <div class="col-sm-12">
                                             <div class="form-group">
                                                <div class="input-group pb-1 ">
                                                   <div class="input-group-addon">DAI</div>
                                                   <input class="form-control" id="transfer_amount" placeholder="Enter Amount..." type="number">
                                                </div>
                                             </div>
                                          </div>
                                          <div class="col-sm-12">
                                             <div class="form text-center compact">
                                                <button class="btn btn-success" id="transfer_fund" ><span>TRANSFER </span>
                                                </button>
                                             </div>
                                          </div>
                                       </div>
                                    </form>
                                 </div>

                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="content-panel">
      <div class="content-panel-close">
         <i class="os-icon os-icon-close"></i>
      </div>
        <div class="element-wrapper">
			<h6 class="element-header">DApp Buy</h6>
			<div class="element-box b-y b-x">
					<div class="os-tabs-w text-center">
					<div class="os-tabs-controls">
							<ul class="nav nav-tabs smaller">
								<li class="nav-item fs-16"><a class="nav-link active" data-toggle="tab" href="#buy_fromWallet" aria-expanded="true">Buy</a>
								</li>
								<li class="nav-item fs-16"><a class="nav-link" data-toggle="tab" href="#Deposit_fromWallet" aria-expanded="false">Deposit</a>
								</li>
							</ul>
						</div>
					<button class="btn btn-outline-danger btn fs-14 m-x-1 mb-2"><span>Credit Fund<b> $ <span class="creditFund"></span></b></span> </button>
						<div class="tab-content">
							<div class="tab-pane active" id="buy_fromWallet" aria-expanded="true">
										<form>
											
											<div class="row">
                  
												<div class="col-sm-12">
													<div class="form text-center compact">
                  
														<button class="btn btn-danger" href="#" id="dapp_buy" ><i class="icon-bag"></i><span> BUY TOPUP</span>
													</button>
													</div>
												</div>
                  
                  								<div class="col-sm-12 mt-3">
													<div class="form text-center compact">
                  
														<button class="btn btn-info" href="#" id="dapp_buyPool" ><i class="icon-bag"></i><span> BUY POOL</span>
													</button>
													</div>
												</div>
											</div>
                  
										</form>
							</div>
							<div class="tab-pane" id="Deposit_fromWallet" aria-expanded="false">
									    <form>
											
											<div class="row">
												<div class="col-sm-12">
												<div class="input-group pb-3">
													<div class="input-group-addon">DAI</div>
													<input class="form-control" placeholder="Enter Amount..." type="number" id="depositAmnt">
												</div>
												</div>
												
												<div class="col-sm-12">
													<div class="form text-center compact">
													<a class="btn btn-danger" href="#" id="dapp_deposit" ><span>Deposit </span>
													</a>
													</div>
												</div>
											</div>
										</form>
									</div>
									
						</div>	
					</div>
			    </div>
		</div>		
      <div style="display:none" class="element-wrapper">
         <h6 class="element-header">Global Pools</h6>
         <div class="element-box-tp">
            <div class="activity-boxes-w">
               <div class="activity-box-w">
                  <div class="activity-time text-center fs-16 fc-info fw-600">
                     2X 
                  </div>
                  <div class="activity-box">
                     <div class="activity-info">
                        <div class="st-meta">
                           <span class=" mt-2 mr-2 ml-4 fs-12 fc-info fw-600">7686</span>
                        </div>
                        <div class="activity-title">INDEX ID :</div>
                        <div class="st-foot">
                           <span class="activity-title fs-14 float-left">Total Earn</span>
                           <span class="activity-title fs-14 float-right">$ 25</span>
                        </div>
                        <div class="ticket-description fs-12 fc-danger ">
                           <b class="float-left">Total Re-Birth</b>
                           <b class="float-right">24</b>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="activity-box-w">
                  <div class="activity-time text-center fs-16 fc-info fw-600">
                     2X 
                  </div>
                  <div class="activity-box">
                     <div class="activity-info">
                        <div class="st-meta">
                           <span class=" mt-2 mr-2 ml-4 fs-12 fc-info fw-600">7686</span>
                        </div>
                        <div class="activity-title">INDEX ID :</div>
                        <div class="st-foot">
                           <span class="activity-title fs-14 float-left">Total Earn</span>
                           <span class="activity-title fs-14 float-right">$25</span>
                        </div>
                        <div class="ticket-description fs-12 fc-danger ">
                           <b class="float-left">Total Re-Birth</b>
                           <b class="float-right">24</b>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="activity-box-w">
                  <div class="activity-time text-center fs-16 fc-info fw-600">
                     2X 
                  </div>
                  <div class="activity-box">
                     <div class="activity-info">
                        <div class="st-meta">
                           <span class=" mt-2 mr-2 ml-4 fs-12 fc-info fw-600">7686</span>
                        </div>
                        <div class="activity-title">INDEX ID :</div>
                        <div class="st-foot">
                           <span class="activity-title fs-14 float-left">Total Earn</span>
                           <span class="activity-title fs-14 float-right">$25</span>
                        </div>
                        <div class="ticket-description fs-12 fc-danger ">
                           <b class="float-left">Total Re-Birth</b>
                           <b class="float-right">24</b>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="activity-box-w">
                  <div class="activity-time text-center fs-16 fc-info fw-600">
                     2X 
                  </div>
                  <div class="activity-box">
                     <div class="activity-info">
                        <div class="st-meta">
                           <span class=" mt-2 mr-2 ml-4 fs-12 fc-info fw-600">7686</span>
                        </div>
                        <div class="activity-title">INDEX ID :</div>
                        <div class="st-foot">
                           <span class="activity-title fs-14 float-left">Total Earn</span>
                           <span class="activity-title fs-14 float-right">$25</span>
                        </div>
                        <div class="ticket-description fs-12 fc-danger ">
                           <b class="float-left">Total Re-Birth</b>
                           <b class="float-right">24</b>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="activity-box-w">
                  <div class="activity-time text-center fs-16 fc-info fw-600">
                     2X 
                  </div>
                  <div class="activity-box">
                     <div class="activity-info">
                        <div class="st-meta">
                           <span class=" mt-2 mr-2 ml-4 fs-12 fc-info fw-600">7686</span>
                        </div>
                        <div class="activity-title">INDEX ID :</div>
                        <div class="st-foot">
                           <span class="activity-title fs-14 float-left">Total Earn</span>
                           <span class="activity-title fs-14 float-right">$25</span>
                        </div>
                        <div class="ticket-description fs-12 fc-danger ">
                           <b class="float-left">Total Re-Birth</b>
                           <b class="float-right">24</b>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="activity-box-w">
                  <div class="activity-time text-center fs-16 fc-info fw-600">
                     3X 
                  </div>
                  <div class="activity-box">
                     <div class="activity-info">
                        <div class="st-meta">
                           <span class=" mt-2 mr-2 ml-4 fs-12 fc-info fw-600">7686</span>
                        </div>
                        <div class="activity-title">INDEX ID :</div>
                        <div class="st-foot">
                           <span class="activity-title fs-14 float-left">Total Earn</span>
                           <span class="activity-title fs-14 float-right">$25</span>
                        </div>
                        <div class="ticket-description fs-12 fc-danger ">
                           <b class="float-left">Total Re-Birth</b>
                           <b class="float-right">24</b>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
</div>
<div class="display-type"></div>
</div>
<?php include("footer.php");
   ?>
<script>
   function CopyEl(){
   // $('.tooltip-r').tooltip();
   
   console.log("stated");
   
   const str1 = $('#ref_link').data('val');
   const str = document.getElementById('ref_link').innerText;
   
    const el = document.createElement('textarea');
    el.value = str1.trim();
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
   
   $('#copyel').text('Copied');
   $('#copyel').removeClass("btn-primary");
   $('#copyel').addClass("btn-success");
    
    //$('#ref_box').css("color","#f9c005");
     // alertify.set('notifier','position', 'top-right');
     //  alertify.notify('Your ReferralLink is Copied', 'green', 10, function(){});
      console.log("copied");
   
   }
   
   
   
   
</script>
