<?php include('header.php')


?>

<div class="content-i">
	<div class="content-box">
		<div class="element-wrapper">
			<h6 class="element-header">My Referral</h6>
			<div class="element-box">
				
				<div class="table-responsive">
					<table id="dataTable1" width="100%" class="table table-striped table-lightfont">
						<thead>
							<tr>
								<th>Date</th>
								<th>Name</th>
								<th>Address</th>
								<th>Contact</th>
								<th>Status</th>
							
							</tr>
						</thead>
						
						<tbody>
								<?php 
								$query = "SELECT * FROM `reg_user` WHERE referrerID=$user";
								$result = mysqli_query($conn,$query);

								while($row= mysqli_fetch_assoc($result)){
                                
                                 $cls;
                                                        

                                if ($row['isActive']){
                                
                                	 $cls="fc-success";
                                
                                }else{
                                	$cls="fc-danger";
                                }
                                
                                
                                $link_user = BSCURL."address/".$row['userWalletBase58'];
                                                       
                                                        
                                                        
                                                        
           
                                
                                
                                
                                ?>
                                	<tr role="row" class="odd">
                                       
                                    		<td class="data"><?php echo date('d/m/Y', $row['timestamp']);  ?></td>
                                            					
                                           <td class="data"></td>
                                    
                                    		<td class="data" ><a target="_blank" href="<?php echo $link_user ?>" class="user" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo $row[userWalletBase58]; ?>"><?php echo substr($row['userWalletBase58'],0,6)."......".substr($row['userWalletBase58'],-6) ?></a></td>
                                    
                                			
                                    	   <td class="data"></td>
                                    		
                                    	  <td class="<?php echo $cls ?>"> <i class="icon-user-following"></i> </td>
                                    		
                                    </tr>
                                <?php
                                
                                }

								?>

						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>


</div>
</div>
	<div class="display-type"></div>
</div>



<?php include('footer.php'); ?>