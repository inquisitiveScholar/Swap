<?php include("header.php") ?>


         <div class="content-i">
            <div class="content-box">
               <div class="element-wrapper">
                  <h6 class="element-header">Lost Income Transaction </h6>
                  <div class="element-box">
                     <div class="table-responsive">
						
                        <table id="dataTable1" width="100%" class="table table-striped table-lightfont">
                           <thead>
                              <tr>
                                 <th>Date</th>
                              
                                 <th>FromAddress</th>
                                 <th>Amount</th>
								 <th>Income Type </th>
							
                                
                              </tr>
                           </thead>
                                       <tbody id="teamD">
												<?php


													$query = "SELECT * FROM `event_lostIncome` WHERE userID=$user";
													$result = mysqli_query($conn,$query);

													while($row=mysqli_fetch_assoc($result))
                                                    
                                                    {
                                                    
                                                    
                                                
                                                     $link_to = BSCURL."address/".getUserAddressByUserId($row['userID']);
                                                   
                                                     
		
                                                        
                                                      ?>
                                                        
                                                        <tr>
                                                        	<td><?php echo date('d/m/Y', $row['timestamp']); ?> </td>
                                                        	<td class="data" ><a target="_blank" href="<?php echo $link_to ?>" class="user" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo getUserAddressByUserId($row[userID]); ?>"><?php echo substr(getUserAddressByUserId($row[userID]),0,6)."......".substr( getUserAddressByUserId($row[userID]),-6) ?></a></td>
                                                      		<td><?php echo $row['amount'] ?></td>		
                                                      		
															<td> <?php echo $row['income_type'] ?> </td>
                                                        </tr>
                                                        
                                                        <?php
                                                        
                                                        }
												?>
                                                
  
                                                
                                       </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="display-type"></div>
</div>
 
<?php include('footer.php'); ?>