A Pen created at CodePen.io. You can find this one at https://codepen.io/GiacomoSorbi/pen/OyyzvO.

 Me playing around animation features with 2 different Canvas on top of each other and with different effects