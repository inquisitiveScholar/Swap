<?php include("header.php") ?>

		
<div class="content-i">
	<div class="content-box">
		<div class="element-wrapper">
			<h6 class="element-header">Global Pools</h6>
			<div class="element-box">
				
				<div class="table-responsive">
					<table id="dataTable1" width="100%" class="table table-striped table-lightfont">
						<thead>
							<tr>
								<th>Date</th>
								<th>Pool Index</th>
								<th>Re-Birth</th>
								<th>Pool Gain</th>
								<th>Pool Type</th>
								
							</tr>
						</thead>
						
						<tbody>

								<?php 




								// $index = getIndexBy2xUser($user);
								$query = "SELECT toUser,timestamp,mIndex, sum(amount) as totalIncome FROM `2xAutoPoolPay` WHERE toUser=$user GROUP BY mIndex  ";
								$result = mysqli_query($conn,$query);

								while($row= mysqli_fetch_assoc($result)){
                                
                                $userIndex = $row['userIndex'];
                                
                                
                                ?>
                                	<tr role="row" class="odd">
                                       
                                    		<td class="data"><?php echo date('d/m/Y',$row["timestamp"]  ?></td>
                                            					
                                           <td class="data"><?php echo $userIndex ?> </td>
                                    
                                    		<td class="data fc-danger fw-400"><?php echo  "NA"  ?></td>
                                    
                                    	   <td class="data  fc-success fw-400"><?php echo $row['totalIncome']; ?></td>
                                    		
                                    	   <td class="fc-primary fw-600"><?php echo "2X" ?></td>
                                    		
                                    </tr>
                                <?php
                                
                                
                                }


								$index = getIndexBy2xUser($user);
								$query = "SELECT toUser,mIndex, timestamp sum(amount) as totalIncome FROM `3xAutoPoolPay` WHERE toUser=$user GROUP BY mIndex  ";
								$result = mysqli_query($conn,$query);

								while($row= mysqli_fetch_assoc($result)){
                                
                                $userIndex = $row['mIndex'];


								?>
                                
                                
                                	<tr role="row" class="odd">
                                       
                                    		<td class="data"><?php echo date('d/m/Y', $row['timestamp'];  ?></td>
                                            					
                                           <td class="data"><?php echo $userIndex ?> </td>
                                    
                                    		<td class="data fc-danger fw-400"><?php echo  "NA"  ?></td>
                                    
                                    	   <td class="data  fc-success fw-400"><?php echo  $row['totalIncome']; ?></td>
                                    		
                                    	   <td class="fc-primary fw-600"><?php echo "3X" ?></td>
                                    		
                                    </tr>
                                
                                
                                
                                <?php
                                
                                }

								?>

						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<?php include("footer.php") ?>


</div>
</div>
	<div class="display-type"></div>
</div>