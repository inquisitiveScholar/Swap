<?php include("header.php") ?>


         <div class="content-i">
            <div class="content-box">
               <div class="element-wrapper">
                  <h6 class="element-header">My Team <span class="float-right">Team Count: <?php echo getActiveCountDownline($user); ?></span></h6>
                  <div class="element-box">
                     <div class="table-responsive">
						
                        <table id="dataTable1" width="100%" class="table table-striped table-lightfont">
                           <thead>
                              <tr>
                                 <th>Date</th>
                              
                                 <th>User Address</th>
                                 <th>Sponsor Address</th>
                                 <th>Level</th>
                                 <th>Status</th>
                              </tr>
                           </thead>
                                       <tbody id="teamData">
												<?php
														$temp = array();


														
														$obj = downlineDigByLevel(array($user),1);

									

														foreach($obj as $item){
                                                        
                                                        array_push($temp,$item['team']);
                                                        
                                                        $link_user = BSCURL."address/".$item['address'];
                                                        $link_sponser = BSCURL."address/".$item['sponser'];
                                                        
                                                        
                                                        
                                                        $cls;
                                                        
                                                        	if($item['status']==1){
                                                            
                                                            	  $cls="fc-success";
                                                            }else{
                                                            
                                                            		$cls="fc-danger";
                                                            }
                                                        
                                                      ?>
                                                        
                                                        <tr>
                                                        	<td><?php echo  $item['timestamp'] ?> </td>
                                                        	
                                                        
                                                        	<td> <a target="_blank" href="<?php echo $link_user ?>" class="user" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo $item['address'] ?>"><?php echo substr($item['address'],0,6)."......".substr($item['address'],-6) ?></a> </td>
                                                        
                                                        	<td><a target="_blank" href="<?php echo $link_sponser ?>" class="sponser" data-placement="top" data-toggle="tooltip" data-original-title="<?php echo $item['sponser'] ?>"> <?php echo substr($item['sponser'],0,6)."......".substr($item['sponser'],-6) ?></a> </td>
                                                        
                                                      		<td> <?php echo $item['level'] ?> </td>
                                                      
                                                      		<td class="<?php echo $cls ?>"> <i class="icon-user-following"></i> </td>
                                                        
                                                        </tr>
                                                        
                                                        <?php
                                                        
                                                        }
												?>
                                       </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="display-type"></div>
</div>
 
<script>
                                                
                                                
     // $('.user').text( wallet.substring(0,8) + '....' + wallet.slice(-8));                                             
     // $('.sponser').text( wallet.substring(0,8) + '....' + wallet.slice(-8));    

	var oldObj = <?php echo json_encode($temp) ?>;
	var nextLevel = 1;
	var objresponse;


</script>                                               
                                                
                                                
<?php include("footer.php") ?>


<script>

	objresponse = $('#teamData').html();



 function fetchResponse(obj,level){

     return $.ajax({

  			url:'fetchTeam.php',
  			type:'POST',
     		data:{nextList:obj,level:level},
     		dataType:'JSON',
  			

		success:function(res){

			return res;
        
// 				$("#teamData").append(res);
     
//          $('#teamView').DataTable().destroy();
//          $('#teamView').DataTable();
        
        	   
		},

		error:function(e){

			return e;
		}

	  });

}



 window.addEventListener('load', async () => {




      $(document).ready(async function(){
      
      
      
      async function getData(){
      
		nextLevel++;
      	var arr = []; 
       
		tmp= await fetchResponse(oldObj,nextLevel);
        // objresponse = objresponse+tmp;
      
      	console.log('---------------------------TEAM-----------------------------------');
      
      		console.log(tmp);
      
      	console.log('--------------------------------------------------------------------');
        
      	tmp.forEach((element, index, array) => {
    		console.log(element.level); // 100, 200, 300
    		console.log(element.team); // 0, 1, 2
        	console.log(element.anchor1);
        	console.log(element.anchor2);
        
        	var cls;
        
        	if (element.status==1){
            
            	cls="fc-success";
            
            }else{
            
            	cls="fc-danger";
            }
            
        	var tmp = `<tr> 
            <td>
            	${element.timestamp}
            </td>
            
            <td>
            	${element.anchor1}
            </td>
            
            <td>
            	${element.anchor2}
            </td>
            
            <td>
            	${element.level}
            </td>
            
            <td class="${cls}">
            	<i class="icon-user-following"></i>
            </td>
            
            </tr>
            `;
        
        	objresponse=objresponse+tmp;
        
        	console.log(objresponse);
        
        		arr.push(element.team);
    		// console.log(array); // same myArray object 3 times
		});
      
       oldObj= arr;
      console.log(oldObj);
      	if(oldObj.length>0){
        
        
        	setTimeout(function(){

              		// call function
          		getData();
          
          		console.log("running");
          
    		}, 1000);
			
        
        }else{
        
                  alertify.alert("Fetching Team", "All Team Fetched Successfully Thanks ", function(){

        });
        
                	$('#dataTable1').DataTable().clear();
        			$('#dataTable1').DataTable().destroy();
      				$("#teamData").append(objresponse);
         			$('#dataTable1').DataTable({
                 
                      "order": [],
                      responsive: false
                    
                    }
                                              
                    );
        	
        	return 0;
        }

      }
      
//       	console.log(objresponse);
      

      getData();

      

      
      
      
      });


 });
</script>
