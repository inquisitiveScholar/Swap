<?php include('header.php') ?>

			
<div class="content-i">
	<div class="content-box">
		<div class="element-wrapper">
			<h6 class="element-header">Income History</h6>
			<div class="element-box">
				
				<div class="table-responsive">
					<table id="dataTable1" width="100%" class="table table-striped table-lightfont">
						<thead>
							<tr>
								<th>Date</th>
								<th>From Address</th>
								<th>From Name</th>
								<th>Level</th>
								<th>Type Bonus</th>
								<th>Amount</th>
							</tr>
						</thead>
						
						<tbody>
		
								<?php 
                                       				
              
                                       
                                                    $query = "select * from autoPool2xPay where toUser=$user  order by timestamp desc";
                                       
                                       				$result = mysqli_query($conn,$query);
                                       				
                                       				
                                       					
                                       				while($row=mysqli_fetch_assoc($result)){
                                                    

                                                    	$type = "Pool2xPay";
                                                    	?>
                                       						<tr role="row" class="odd">
                                                            	<td class="data"><?php echo date('d/m/Y', $row['timestamp']);  ?></td>
                                            					
                                                            	<td class="data"><?php echo getUserAddressByUserId($row['fromUser']); ?></td>
                                                            	
                                                            	
                                                            
                                                            
                                                        
                                                        		<td></td>
                                                        	  <th>__</th>
                            								

                                                            	<td class="data"><?php echo  $type ?></td>
                                                        			<td class="data"> <?php echo  number_format($row['amount'], 4, '.', ""); ?></td>
												              
					
					
					

															</tr>
                                       						
                                       					<?php
                                                    
                                                    }



													// second income



                                                    $query = "select * from autoPool3xPay where toUser=$user  order by timestamp desc";
                                       
                                       				$result = mysqli_query($conn,$query);
                                       				
                                       				
                                       					
                                       				while($row=mysqli_fetch_assoc($result)){
                                                    

                                                    	$type = "Pool3xPay";
                                                    	?>
                                       						<tr role="row" class="odd">
                                                            	<td class="data"><?php echo date('d/m/Y', $row['timestamp']);  ?></td>
                                            					
                                                            	<td class="data"><?php echo getUserAddressByUserId($row['fromUser']); ?></td>
                                                            	
                                                            	
                                                            
                                                            
                                                        
                                                        		<td></td>
                            									 <th>__</th>

                                                            	<td class="data"><?php echo  $type ?></td>
                                                        			<td class="data"> <?php echo  number_format($row['amount'], 4, '.', ""); ?></td>
												              
					
					
					

															</tr>
                                       						
                                       					<?php
                                                    
                                                    }

													// third income


                                                    $query = "select * from event_paidtodirect where toUser=$user  order by timestamp desc";
                                       
                                       				$result = mysqli_query($conn,$query);
                                       				
                                       				
                                       					
                                       				while($row=mysqli_fetch_assoc($result)){
                                                    

                                                    	$type = "PaidToDirect";
                                                    	?>
                                       						<tr role="row" class="odd">
                                                            	<td class="data"><?php echo date('d/m/Y', $row['timestamp']);  ?></td>
                                            					
                                                            	<td class="data"><?php echo getUserAddressByUserId($row['fromUser']); ?></td>
                                                            	
                                                            	

                                                        		<td></td>
                            									 <th>__</th>

                                                            	<td class="data"><?php echo  $type ?></td>
                                                        		<td class="data"> <?php echo  number_format($row['amount'], 4, '.', ""); ?></td>
												            

															</tr>
                                       						
                                       					<?php
                                                    
                                                    }



													// 4th phase



                                                    $query = "select * from event_paidforunilevelev where toUser=$user  order by timestamp desc";
                                       
                                       				$result = mysqli_query($conn,$query);
                                       				
                                       				
                                       					
                                       				while($row=mysqli_fetch_assoc($result)){
                                                    

                                                    	$type = "Unilevel";
                                                    	?>
                                       						<tr role="row" class="odd">
                                                            	<td class="data"><?php echo date('d/m/Y', $row['timestamp']);  ?></td>
                                            					
                                                            	<td class="data"><?php echo getUserAddressByUserId($row['fromUser']); ?></td>
                                                            	
                                                            	
                                                            
                                                            
                                                        
                                                        		<td></td>
                            									 <th><?php echo $row['level'] ?></th>

                                                            	<td class="data"><?php echo  $type ?></td>
                                                        			<td class="data"> <?php echo  number_format($row['amount'], 4, '.', ""); ?></td>
												              
					

															</tr>
                                       						
                                       					<?php
                                                    
                                                    }

											
                                       
                                       			   //  5th phase 




                                                    $query = "select * from event_poolRoyality where toUser=$user  order by timestamp desc";
                                       
                                       				$result = mysqli_query($conn,$query);
                                       				
                                       				
                                       					
                                       				while($row=mysqli_fetch_assoc($result)){
                                                    

                                                    	$type = "PoolRoyality";
                                                    	?>
                                       						<tr role="row" class="odd">
                                                            	<td class="data"><?php echo date('d/m/Y', $row['timestamp']);  ?></td>
                                            					
                                                            	<td class="data"><?php echo getUserAddressByUserId($row['fromUser']); ?></td>
                                                            	
                                                            	
                                                            
                                                            
                                                        
                                                        		<td></td>
                            									 <th>__</th>

                                                            	<td class="data"><?php echo  $type ?></td>
                                                        			<td class="data"> <?php echo  number_format($row['amount'], 4, '.', ""); ?></td>
												              
					

															</tr>
                                       						
                                       					<?php
                                                    
                                                    }


													//6th phase



                                                    $query = "select * from event_poolSponser where toUser=$user  order by timestamp desc";
                                       
                                       				$result = mysqli_query($conn,$query);
                                       				
                                       				
                                       					
                                       				while($row=mysqli_fetch_assoc($result)){
                                                    

                                                    	$type = "PoolSponser";
                                                    	?>
                                       						<tr role="row" class="odd">
                                                            	<td class="data"><?php echo date('d/m/Y', $row['timestamp']);  ?></td>
                                            					
                                                            	<td class="data"><?php echo getUserAddressByUserId($row['fromUser']); ?></td>
                                                            	
                                                            	
                                                            
                                                            
                                                        
                                                        		<td></td>
                            									 <th>__</th>

                                                            	<td class="data"><?php echo  $type ?></td>
                                                        			<td class="data"> <?php echo  number_format($row['amount'], 4, '.', ""); ?></td>
												              
					

															</tr>
                                       						
                                       					<?php
                                                    
                                                    }




													// 7th phase


                                                    $query = "select * from event_paidforroyality where toUser=$user  order by timestamp desc";
                                       
                                       				$result = mysqli_query($conn,$query);
                                       				
                                       				
                                       					
                                       				while($row=mysqli_fetch_assoc($result)){
                                                    

                                                    	$type = "Royality (GR+AR)";
                                                    
                                                    	$amount = $row['grAmount']+$row['arAmount'];
                                                    	?>
                                       						<tr role="row" class="odd">
                                                            	<td class="data"><?php echo date('d/m/Y', $row['timestamp']);  ?></td>
                                            					
                                                            	<td class="data"><?php echo getUserAddressByUserId($row['fromUser']); ?></td>
                                                            	
                                                            	

                                                        		<td></td>
                            									 <th>__</th>

                                                            	<td class="data"><?php echo  $type ?></td>
                                                        			<td class="data"> <?php echo  number_format($amount, 4, '.', ""); ?></td>
												              
					

															</tr>
                                       						
                                       					<?php
                                                    
                                                    }




                                                    $query = "select * from event_paidforgapgenration where toUser=$user  order by timestamp desc";
                                       
                                       				$result = mysqli_query($conn,$query);
                                       				
                                       				
                                       					
                                       				while($row=mysqli_fetch_assoc($result)){
                                                    

                                                    	$type = "GapGen";
                                                    
                                                    	
                                                    	?>
                                       						<tr role="row" class="odd">
                                                            	<td class="data"><?php echo date('d/m/Y', $row['timestamp']);  ?></td>
                                            					
                                                            	<td class="data"><?php echo getUserAddressByUserId($row['fromUser']); ?></td>
                                                            	
                                                            	

                                                        
                                                        		<td></td>
                            									 <th><?php echo $row['level'] ?></th>

                                                            	<td class="data"><?php echo  $type ?></td>
                                                        			<td class="data"> <?php echo  number_format($amount, 4, '.', ""); ?></td>
												              
					

															</tr>
                                       						
                                       					<?php
                                                    
                                                    }


                                       
                                       			?>
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>


</div>
</div>
	<div class="display-type"></div>
</div>

<?php include('footer.php') ?>