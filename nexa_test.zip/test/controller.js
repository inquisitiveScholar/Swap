//

//---------------------------------------------------------
//
//
//
//					GLOBAL VARIABLE
//
//
//
//-------------------------------------------------------------


var contractAddress = contractMainAddress;

var pay             = contractMainAddress;

var tokenAddress   = token;

var CONNECTED_ADDRESS = null;

if (typeof manualWallet == 'undefined') {
 // Do something
}else{

var mWallet       = manualWallet;


}


var levelFeeLimit=8;
var pulloutFeeLimit=8;
var regFeeLimit =16;

var gasLimit= 800000;


		
var pulloutTaxPrice = 3000000;
var regTaxPrice     = 5000000;
var levelBuyTaxPrice = 3000000;
var cashbackTaxPrice = 0;
var txPaid;

var joinPrice = "45000000000000000000";
var poolPrice = "12000000000000000000";

// var pulloutTaxPrice = 3000000;
// var regTaxPrice     = 5000000;
// var levelBuyTaxPrice = 2000000;


var gasFee="55000000000";


//popup testing 





$(window).on('load', async ()=>{



        //-------------------------- all function control logic start from here -------------------
      
      		//-------- ethereum INitiate-----------
      console.log('loading........');
      
        var ABI = arrayABI;
		var contract;     
        var tokABI = tokenABI;
      	var tokenCon;

		var userAllow;
		var userJoin;


     
       	web3 = new Web3(window.ethereum);
      
//           window.web3 = new Web3(Web3.givenProvider || new Web3.providers.HttpProvider('https://polygon-rpc.com'));
      		
// 	   	  window.ethereum.enable();
		
		
      	
      	var contract =  new web3.eth.Contract(ABI,contractAddress); 
      	var tokenCon =  new web3.eth.Contract(tokABI,tokenAddress); 
      	
           
                  // balance check 
			const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
			const account = accounts[0];     

		
			
 	const gasPrice = await web3.eth.getGasPrice();

	gasFee = gasPrice;

	console.log("gasPrice : "+gasPrice);






	//--------------------GAS FEE FETCH API-------------------



			function success() {
    			var data = JSON.parse(this.responseText); //parse the string to JSON
    		
            	var fee = data['fast'].maxFee+0.1; // increase bit max
            
            	console.log(fee);
            
            	console.log(Math.floor(fee*1e9));
            
            	gasFee=Math.floor(fee*1e9);
            
			}

			// function to handle error
			function error(err) {
    				console.log('Request Failed', err); //error details will be in the "err" object
			}

		function syncGasFee(){
        
        	var xhr = new XMLHttpRequest(); //invoke a new instance of the XMLHttpRequest
			xhr.onload = success; // call success function if request is successful
			xhr.onerror = error;  // call error function if request failed
			xhr.open('GET', 'https://gasstation-mainnet.matic.network/v2'); // open a GET request
			xhr.send(); // send the request to the server.
        
        } 
 	


		syncGasFee();



      $(document).ready(async function(){


//          web3 = new Web3(window.ethereum);

// 	   	 window.ethereum.enable();
// 	   	 const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
// 		 const account = accounts[0]; 

      
      //-----------------------------DASHBOARD LOAD DATA------------------------------
      
      // get avalabel amount 
      
      

		userJoin = "33000000000000000000";

	

		userAllow =  await tokenCon.methods.allowance(account,contractAddress).call({from:account});
      
      	console.log(userAllow);
        if ($('#dapp_buy').length){
      
      

      	// LOAD DATA FROM CONTRACT HERE..............
      
        
        
        await dataRender(); // init render obj
        
         var syncComponent = setInterval( async function() {
         
         console.log("rendering....");
         
         
         await dataRender();
         
         },10000);
        
      
      
      }
      
      
      
      async function  dataRender(){
      
      // LOAD DATA FROM CONTRACT HERE..............
      
         var sysObj = await  contract.methods.sysInfos().call({from:account});
        
      	 var poolObj = await  contract.methods.userInfos(account).call({from:account});
      	 var incomeObj = await contract.methods.userGains(account).call({from:account});
        var totalGains = await contract.methods.totalGains_(account).call({from:account});
        var royalityPot = await contract.methods.viewRoyaltyPotential(account).call({from:account});
        
        var nextRoyality = await contract.methods.nextRoyalty().call({from:account});
        var runningIndex = await contract.methods.royalty_Index().call({from:account});
 		var royalityobj = await contract.methods.viewCurrentRoyalty().call({from:account});
        
        var royaltys = await contract.methods.royaltys((nextRoyality-1)).call({from:account}); // get current running objects 
        
        console.log("-------------------royality--pot-----------------");
        console.log(royalityPot);
          console.log(royalityPot[0]);
        

        
         console.log("-------------------globalGains Royality-----------------");
        
        console.log(incomeObj.totalGlobalRoyalityGains);
        
        // var userFund = await contract.methods.userFunds(account).call({from:account});

          console.log('all funcall is fetching now.......');
      
        var withdrawn= (incomeObj.totalWithdrawn/1e18);
      	$('#poolLimit').text(sysObj.pool2Entrylimit);
        $('#poolAchieve').text(poolObj.poolLimit);
        $('#pool_countDown').text(poolObj.poolTime);
        $('.creditFund').text(((incomeObj.creditFund)/1e18).toFixed(2));
       	$('#withdrawnFund').text((totalGains/1e18).toFixed(2));
        
        // $('#totalTransferFund').text((userFund.transferFund/1e18).toFixed(2));;
        // $('#totalReceivedFund').text((userFund.receiveFund/1e18).toFixed(2));;
        // $('#totalRentryFund').text((userFund.topupFund/1e18).toFixed(2));;
        // $('#totalBuyPoolFund').text((userFund.globalPoolFund/1e18).toFixed(2));;

        
      
      	
         var avl = ((totalGains)/1e18);
        console.log(avl);
      
      	var ablcr;
        
        var wLimit = incomeObj.withdrawLimit/1e18;
        
        if(wLimit>avl){
        
        	//normal avl
        
        	  $('#withdrawLimit').text((wLimit-avl).toFixed(2));
        	
        
        }else{
        
        	// float value 
        	$('#withdrawLimit').text((avl-wLimit).toFixed(2));
        
        }
      

        
        var tmpglobalRoyal = (incomeObj.totalGlobalRoyalityGains/1e18);
        var tmpRoyalitypot = (royalityPot[0]/1e18);
        
        var tmpActRoyal = (incomeObj.totalActiveRoyalityGains/1e18);
        var tmpActRoyalPot = (royalityPot[1]/1e18);
        
        
        var grShare = royaltys.GR_total_Share/1e18;
        var arShare = royaltys.GR_total_Share/1e18;
        
        
        var perGrShare = grShare/royaltys.GR_Users;
        var perArShare = arShare/royaltys.AR_Users;
        
        
       
      
      
      $('#directCount').text(poolObj.activeDirect);
      $('#totalTeamCount').text(poolObj.teamCount);
      $('#totalDirectProfit').text((incomeObj.totalSponserGains/1e18).toFixed(2));
      $('#totalGapProfit').text((incomeObj.totalGapGenGains/1e18).toFixed(2));
   
      

        
       $('#totalGlobalRoyality').text(((parseInt(tmpglobalRoyal)+ parseInt(tmpRoyalitypot))).toFixed(2));
        
      $('.totalgrPot').text('+ $'+(tmpRoyalitypot).toFixed(2));
      
      $('#totalActiveRoyality').text(((parseInt(tmpActRoyal)+parseInt(tmpActRoyalPot))).toFixed(2));
        
      $('.totalarPot').text('+ $'+(tmpActRoyalPot).toFixed(2));
        
        
      $('#total2xPoolProfit').text((incomeObj.totalAutopool2xGains/1e18).toFixed(2));
      $('#total3xPoolProfit').text((incomeObj.total3xPoolGains/1e18).toFixed(2));
      $('#totalUnilevelProfit').text((incomeObj.totalUnilevelGains/1e18).toFixed(2));
      $('#totalProfit').text((totalGains/1e18).toFixed(2));
        
         console.log(incomeObj);
        $('#totalPoolSponserProfit').text((incomeObj.poolSponsorGains/1e18).toFixed(2));
        
       // $('#poolSponsorGains').text((0).toFixed(2));
        $('#poolRoyaltyGains').text((incomeObj.poolRoyaltyGains/1e18).toFixed(2));
        
         $('#poolHelpFund').text((sysObj.storeageGP/1e18).toFixed(2));
        
         $('#poolHelp').text((sysObj.helpPoolCount));
        
          $('#avlFund').text((tmpRoyalitypot+tmpActRoyalPot).toFixed(2));
        
        
        if ((sysObj.storeageGP/1e18)>=12){
        
        
        		$('#pool_assistance').show();
        
        }
        
        
        
                var royalColl= (royalityobj[0]);
        var activeColl= (royalityobj[2]);
        
        royalColl=(royalColl/1e18);
        activeColl=(activeColl/1e18);
        
        
        // var royalityShare = 
        
      
        
       //$('#nextRoyalty').text(nextRoyality);
        
        

        
       $('#grCollection').text((perGrShare).toFixed(2));
       $('#arCollection').text((perArShare).toFixed(2));
        
       $('#strongTeam').text(poolObj.strongTeam);
       $('#poolCount').text(poolObj.globalPoolCount);
       $('#topUpCount').text(incomeObj.topup_Count);
       $('.grQ').text(royalityobj[1]);
       $('.arQ').text(royalityobj[3]);
        

        
    
      
      if (poolObj.joined==true){
      
      	$('.user-join-status').html('<i class="fa fa-circle fc-success mr-1 fs-16" data-placement="left"data-toggle="tooltip" data-original-title="Active"></i>');
      
      		$('.inactivePanel').hide();
      
      }else{
      
      
      	$('.inactivePanel').show();
      
      	$('.user-join-status').html('<i class="fa fa-circle fc-danger mr-1 fs-16 " data-placement="left"data-toggle="tooltip" data-original-title="Active"></i>');
      
      }
     

      
      	if(avl>(incomeObj.withdrawLimit/1e18)){
        
        	ablcr=(incomeObj.withdrawLimit/1e18).toFixed(2);
        
        }else{
        
        	ablcr=avl;
        
        }
      
      	$('#w-limit').text(ablcr);
      
       
		//$('#pool_countDown').text();
      		
         var res =String(poolObj.poolTime);
      	
         var countDownDate = new Date(res * 1000 ).getTime();
        
         var x = setInterval( function() {


           var now = new Date().getTime();

		
			
           var distance = (countDownDate) - (now);
         

           var days = Math.floor(distance / (1000 * 60 * 60 * 24));
           var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
           var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
           var seconds = Math.floor((distance % (1000 * 60)) / 1000);

           var tmp =  hours + ":"
              + minutes + ":" + seconds + " ";
              
           $('#pool_countDown').text(tmp);
                          
           if (distance < 0) {
             clearInterval(x);
                           
             $('#pool_countDown').text("0");
           
           }

                            

         }, 1000);
        
        
        // next time
        
        
      
         var res1 = nextRoyality;
      	
         var countDownDate1 = new Date(res1 * 1000 ).getTime();
        
         var x1 = setInterval( function() {


           var now1 = new Date().getTime();

		
			
           var distance1 = (countDownDate1) - (now1);
         

           var days1 = Math.floor(distance1 / (1000 * 60 * 60 * 24));
           var hours1 = Math.floor((distance1 % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
           var minutes1 = Math.floor((distance1 % (1000 * 60 * 60)) / (1000 * 60));
           var seconds1 = Math.floor((distance1 % (1000 * 60)) / 1000);

           var tmp1 =  hours1 + ":"
              + minutes1 + ":" + seconds1 + " ";
              
            $('#nextRoyalty').text(tmp1);
                          
           if (distance1 < 0) {
           
             clearInterval(x1);
                           
             $('#nextRoyalty').text("0");
           
           }

                            
            

         }, 1000);
        

      
      
      }

      
      
      $( "#buy_position" ).change(async function() {
      
      
  		
       	var control = $('#buy_control').val();
      	console.log(control);
      	var position = $('#buy_position').val();
      
      
      	if (parseInt(control)){
        
       
        	
        
        	var join = parseInt(poolPrice)/1e18;
        	var total = parseInt(join*position);
        
        	$('#dapp_buy_amount').val(total);
        
        }else{
        

        
        	// invest history
        
        	        console.log("investtttttttt");
        
        
        	var join = parseInt(joinPrice)/1e18;
        	var total = parseInt(join*position);
        
        	$('#dapp_buy_amount').val(total);
        
        }
      
	});
      
      
    
      $( "#buy_control" ).change(async function() {
      
      console.log("change");
  		
       	var control = $('#buy_control').val();
      	console.log(control);
      	var position = $('#buy_position').val();
      
      
      	if (parseInt(control)){
        
        	$('.dapp-pos-control').removeClass('d-none');
        
        	var join = parseInt(poolPrice)/1e18;
        	var total = parseInt(join*position);
        
        	$('#dapp_buy_amount').val(total);
        
        }else{
        
        $('#buy_position').val(1);
        
        $('.dapp-pos-control').addClass('d-none');
        
         position = 1;
        	// invest history
        
        	        console.log("investtttttttt");
        
        
        	var join = parseInt(joinPrice)/1e18;
        	var total = parseInt(join*position);
        
        	$('#dapp_buy_amount').val(total);
        
        }
      
	});
      
      
      
    
      $( "#purchase_position" ).change(async function() {
      
      console.log("change");
  		
       	var control = $('#purchase_control').val();
      	console.log(control);
      	var position = $('#purchase_position').val();
      
      
      	if (parseInt(control)){
        
        	
        	
        
        	var join = parseInt(poolPrice)/1e18;
        	var total = parseInt(join*position);
        
        	$('#purchase_amount').val(total);
        
        }else{
        

        
        	// invest history
        
        	        console.log("investtttttttt");
        	
        
        	var join = parseInt(joinPrice)/1e18;
        	var total = parseInt(join*position);
        
        	$('#purchase_amount').val(total);
        
        }
      
	});
      
      
    
      $( "#purchase_control" ).change(async function() {
      
      console.log("change");
  		
       	var control = $('#purchase_control').val();
      	console.log(control);
      	var position = $('#purchase_position').val();;
        
      
      
      	if (parseInt(control)){
        
        	$('.purchase-pos-control').removeClass('d-none');
        
        	var join = parseInt(poolPrice)/1e18;
        	var total = parseInt(join*position);
        
        	$('#purchase_amount').val(total);
        
        }else{
        
        	// invest history
        
                $('.purchase-pos-control').addClass('d-none');
        
        $('#purchase_position').val(1);
        position=1;
        
        	        console.log("investtttttttt");
        	
        
        	var join = parseInt(joinPrice)/1e18;
        	var total = parseInt(join*position);
        
        	$('#purchase_amount').val(total);
        
        }
      
	});
      
       $(document).on("click","#purchase_buy_",async function() {
       
       var control = $('#purchase_control').val();
       var position = $('#purchase_position').val();
       
                web3 = new Web3(window.ethereum);

	   	 // window.ethereum.enable();
	   	 const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
		 const account = accounts[0]; 
       
       
       if (control==0){
       
       		// reentry
       
              		$('#purchase_position').val(1);
       
       		position=1;
       
				try {
                
                		syncGasFee();
                
                	    var data =  await contract.methods.reTopup().send({ shouldPollResponse: false, from: account ,gasPrice: gasFee,gasLimit :gasLimit });
         				
                
                		            
            			          alertify.alert("Transaction", "Please check the status of transaction at: <a href='"+tronscan+"tx/"+data+"' target='_blank'> Polygon</a> ", function(){

        				});
                }
       
       			catch (e){
                
                	console.log(e);
                	//alert("Transaction Failed");
                }
       

       
       
       }else if (control==1){
       
       		// buypool
       

       
       		try{
            
            		syncGasFee();
            
            	      var data =  await contract.methods.rebuyPool_2X().send({ shouldPollResponse: false, from: account ,gasPrice: gasFee,gasLimit :gasLimit });
         
            			//alert("Transaction SuccessFull");
            
            
            			          alertify.alert("Transaction", "Please check the status of transaction at: <a href='"+tronscan+"tx/"+data+"' target='_blank'> Polygon</a> ", function(){

        				});
            }
       
       		catch(e){
            
            		console.log(e);
            		//alert("Transaction Failed");
            }
       

         
       
       }
       
       
       });
      
      
      
      
      
             $(document).on("click","#pool_assistance",async function() {
       
       
                web3 = new Web3(window.ethereum);

	   	 // window.ethereum.enable();
	   	 const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
		 const account = accounts[0]; 
       

       

       
       		try{
            
            		syncGasFee();
            
            	      var data =  await contract.methods.helpPool().send({ shouldPollResponse: false, from: account ,gasPrice: gasFee,gasLimit :gasLimit });
         
            			//alert("Transaction SuccessFull");
            
            
            			          alertify.alert("Transaction", "Please check the status of transaction at: <a href='"+tronscan+"tx/"+data+"' target='_blank'> Polygon</a> ", function(){

        				});
            }
       
       		catch(e){
            
            		console.log(e);
            		//alert("Transaction Failed");
            }
       

         

       
       
       });
      
      


    
    $(document).on("click","._poolBuy",async function() {
        
           var id = $(this).data('id');
    
    
    
    		var app = await tokenBalanceValidate();
           
            var rval=  await  userBalanceLevelValidate(tokenAddress,tokABI,contractAddress,ABI,id); 
                        
    		console.log(rval);
            if(parseInt(rval)==2){
            
                
                alert("you don't have sufficient m for Transaction fee" );
                return 0;
            
            }else if (parseInt(rval)==1){
            
             alert("you don't have sufficient XUSD Balance");
             return 0;
            
            }
            
            // var res  = await result.myContract.userInfos(result.accountAddress).call({from: result.accountAddress});
    
    		//--------res
    
    		    web3.eth.getAccounts().then(function(Accounts){
				console.log(Accounts);
          		
				return contract.methods.userInfos(Accounts[0]).call({from:Accounts[0]});
			}).then(async function(data){

                if(data.joined==true){
                
                	
                
                	return contract.methods.buyLevel(id).send({ shouldPollResponse: false, value: levelBuyTaxPrice, from: account,gasPrice: gasFee,gasLimit :gasLimit  });
                }
                
                else{
                	
                	 alertify.alert('Transaction Failed');
                }
          
          	}).then(async function (res){
                
                alertify.alert('Transaction Recorded: <a target="_blank" href="`${tronscan}transaction/${levelbuyResult}`">VIEW TX</a>');

                
             });           
       
    });
      
      
      
      //--------dapp buy ------
      
      
      
      $('#dapp_buy').click(async ()=>{
      
         web3 = new Web3(window.ethereum);

	   	 // window.ethereum.enable();
	   	 const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
		 const account = accounts[0]; 
          
         	// buy investment 
         
         	       try{
                   
                   		syncGasFee();
                   
                   		var app = await tokenBalanceValidate();
      	
      					var data =  await contract.methods.buyTopup().send({ shouldPollResponse: false, from: account ,gasPrice: gasFee,gasLimit :gasLimit });
                   
                   		alertify.alert("Transaction", "Please check the status of transaction at: <a href='"+tronscan+"tx/"+data+"' target='_blank'> Polygon</a> ", function(){

        				});
      	
       				}
      
      				catch(e){
      
      						console.log(e);
      				}
      
      });
      
      
      
      
      
            
      $('#dapp_buyPool').click(async ()=>{
      
         web3 = new Web3(window.ethereum);

	   	 // window.ethereum.enable();
	   	 const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
		 const account = accounts[0]; 
      

         		    try{
                    
                    	syncGasFee();
                    
                    	var app = await tokenBalanceValidate();
      	
      					var data =  await contract.methods.buyPool_2X().send({ shouldPollResponse: false, from: account ,gasPrice: gasFee ,gasLimit :gasLimit});
      	
       				}
      
      				catch(e){
      
      						console.log(e);
      
      				}
      
      });
      
      
      
      
      
            
      $('.active-user').click(async ()=>{
      
         web3 = new Web3(window.ethereum);

	   	 // window.ethereum.enable();
	   	 const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
		 const account = accounts[0]; 
            
	
         
         		// buy pool
         
         		    try{
                    
                    
                    	syncGasFee();
                    
                    
                    	var app = await tokenBalanceValidate();
      	
      					var data =  await contract.methods.buyTopup().send({ shouldPollResponse: false, from: account ,gasPrice: gasFee,gasLimit :gasLimit });
                    
                    	  alertify.alert("Transaction", "Please check the status of transaction at: <a href='"+tronscan+"tx/"+data+"' target='_blank'> Polygon</a> ", function(){

        				});
      	
       				}
      
      				catch(e){
      
      						console.log(e);
      
      				}
         

      
      });
      
      
      
            
      
      $('#dapp_deposit').click(async ()=>{
      
         web3 = new Web3(window.ethereum);

	   	 // window.ethereum.enable();
	   	 const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
		 const account = accounts[0]; 
      
      	var amount = $('#depositAmnt').val();
      
      	amount = (amount*1e18);
      	
      	var position = 1;
      
	
         
         		// buy pool
         
         		    try{
                    
                    
                    	syncGasFee();
                    
                    
                    	var app = await tokenBalanceValidate();
      	
      					var data =  await contract.methods.depositFund(String(amount)).send({ shouldPollResponse: false, from: account ,gasPrice: gasFee ,gasLimit :gasLimit});
                    
                    	            			          alertify.alert("Transaction", "Please check the status of transaction at: <a href='"+tronscan+"tx/"+data+"' target='_blank'> Polygon</a> ", function(){

        				});
      	
       				}
      
      				catch(e){
      
      						console.log(e);
      
      				}
         

      
      });
      
      
      
      
      
        $('#transfer_fund').click(async ()=>{
        
         web3 = new Web3(window.ethereum);

	   	 // window.ethereum.enable();
	   	 const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
		 const account = accounts[0];  
        
      
      
      	
      	var receiver = $("#fund_receiver").val();
        var fundAmount = $('#transfer_amount').val();
        
       	
        
        if (parseInt(fundAmount)<1 && receiver==''){
        
        	alert('please use valid amount or address');
        
        	return 0;
        
        }
      
	
         
         		// buy pool
         
            try{
            
            
            	syncGasFee();
            
            
      			fundAmount= fundAmount*1e18;
      			var data =  await contract.methods.transferCredit(receiver,String(fundAmount)).send({ shouldPollResponse: false, from:account ,gasPrice: gasFee,gasLimit :gasLimit });
      	
            	            			          alertify.alert("Transaction", "Please check the status of transaction at: <a href='"+tronscan+"tx/"+data+"' target='_blank'> Polygon</a> ", function(){

        				});
       		}
      
      		catch(e){
      
      				alert("Error");
      
      		}
         
      
      });
     


        $('#regBtnCall').click(async (e)=>{
        
         e.preventDefault();
        
        console.log("reg call");
        
         web3 = new Web3(window.ethereum);

	   	 // window.ethereum.enable();
	   	 const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
		 const account = accounts[0];  

          try{
          

              if(!account){

                alert('please make sure your wallet is connected');

                return false;

              }

                var referrer = $('#refInput').val();
          		

                  
            
                if ( (referrer!=''))
                
                {           
                      
                
                    
                    
                    	if($("#freeRegStatus").is(':checked')){
     										// Code in the case checkbox is checked.
                        	
                        
                        	var reg = await   regUserCall(referrer,0);
                        
						} else {
     							// Code in the case checkbox is NOT checked.
                        
                        	
                        
                        	var reg = await   regUserCall(referrer,1);
                        
						}
                    
            
                
       
          		}
          
          }
          catch(e){

              if (e instanceof ReferenceError) {
          
              console.log(e);
                  alert('Web3 is not installed or not active wallet!');

              }


          }


        });
      
      
      
      
      // wallet connect / or login 
      
      
//          $(".wallet-connect-btn").click(async function(e){
        	
//         	e.preventDefault();
//         	console.log("Wallet Connect clicked...");
//         	await walletConnect();
//         	let _connectedAddress = CONNECTED_ADDRESS.replace(CONNECTED_ADDRESS.substring(5, 38), "***");
//         	$(".wallet-connect-btn").html(_connectedAddress);
         
//     	});
      


        // function for regular update level info
                
        
        async function regUserCall(refid,status){
            
           // regFeeLimit
        
         web3 = new Web3(window.ethereum);

	   	 // window.ethereum.enable();
	   	 const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
		 const account = accounts[0];
         var trigger;
        
        		if (status){
                
                	// for paid call
                
                	console.log("paid call runing");
                

                	const balobj = await tokenBalanceValidate();
                
                	console.log('balobj.. : '+balobj);
                
                	if(balobj){
                    
                    	trigger=true;	
                    }else{
                    
                    	trigger= false;
                    }
                
                }
        		

              if(!account){

                alert('please make sure your wallet is connected');

                return false;

              }
           

        
        	try{
            //
            
            	if (status && trigger){
                
                	// paid 
         			console.log("paid regRun");
                
                		syncGasFee();
                
                		var regResult =  await contract.methods.payRegUser(refid).send({  from: account ,gasPrice: gasFee, gasLimit :gasLimit });
                
                		            			          alertify.alert("Transaction", "Please check the status of transaction at: <a href='"+tronscan+"tx/"+data+"' target='_blank'> Polygon</a> ", function(){

        				});
                
                }else{
                
                	// freee
                
                	syncGasFee();
                
                	  var regResult =  await contract.methods.regUser(refid).send({  from: account ,gasPrice: gasFee, gasLimit :gasLimit });
                
                	             			          alertify.alert("Transaction", "Please check the status of transaction at: <a href='"+tronscan+"tx/"+data+"' target='_blank'> Polygon</a> ", function(){

        				});
                
                }
            	//var regResult =  await contract.methods.regUser(refid).send({ shouldPollResponse: false, from: account ,gasPrice: gasFee });
				
            	if(regResult){
                	
//                 	$('#transaction_title').text('Success!!  Transaction Recorded');
//                 	// var anchor ='';
//                 	var anchor = "<a class='button w-24 bg-theme-1 text-white' href= '"+tronscan+"tx/"+regResult.transactionHash+"' target='_blank'>View</a>";
              
//                 	$('#transaction_view').html(anchor);
//                 	cash('#TransactionPopup').modal('show');
//                 	console.log(regResult);
                
//                 	alert("Success Please wait until your login is processed......... ");
                
//                 	const myTimeout = setTimeout(myGreeting, 60000);

//                     function myGreeting() {
                
                	 var loginResult =  await contract.methods.userInfos(account).call({ from: account });
                        
                         
                            fireAutoLoginCall(account,loginResult.id); // if data is availbel fire autologin
                    // }
                	
                }
            }
        
        	catch(error){
            	
            }
        
        }
      
      
      


        $(document).on('click','#royalityClaim', async function(){
        
        
                 web3 = new Web3(window.ethereum);

	   	 // window.ethereum.enable();
	   	 const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
		 const account = accounts[0];
        
        console.log("active "+account);
        

			        try{
                   
                    
                    	syncGasFee();
  
      					var data =  await contract.methods.claimRoyalty().send({ shouldPollResponse: false, from: account ,gasPrice: gasFee,gasLimit :gasLimit });
      					
                    	            			          alertify.alert("Transaction", "Please check the status of transaction at: <a href='"+tronscan+"tx/"+data+"' target='_blank'> Polygon</a> ", function(){

        				});
       				}
      
      				catch(e){
      
      
      						console.log(e);
      				}
        
        		        
        });
      
      
      
      
      
      
      
      
// levelBalance Validation

async function tokenBalanceValidate(){
 
				console.log("token val start");
		       	web3 = new Web3(window.ethereum);
   
          //window.web3 = new Web3(Web3.givenProvider || new Web3.providers.HttpProvider('https://polygon-rpc.com'));
      		
	   	  //window.ethereum.enable();
	   	  const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
		 const account = accounts[0]; 

			console.log("second phase");


		userAllow =  await tokenCon.methods.allowance(account,contractMainAddress).call({from:account});

		var fixAllow = BigInt(100000*1e18) ; // save gas fee


		console.log("validating....");

		if (BigInt(userAllow)<BigInt(userJoin)){
        
        	console.log("running");
        
        	try{
        	 	var data = await tokenCon.methods.approve(contractMainAddress,String(fixAllow)).send({ from:account,gasPrice: gasFee, gasLimit :gasLimit });
            
            	return 1;
            }
        
        	catch (e){
            
            	console.log(e);
            
            	return 0;
            
            }
        	console.log(data);
                         
        }else{
        
        console.log("r");
        
        	return 1;
        }
                
    	return 0;
}
      
      
      
      
      
        
                

      
      }); // ready off

}); // window off





// function logic





function getCookie(name) {
    var match = document.cookie.match(RegExp('(?:^|;\\s*)' + name + '=([^;]*)')); return match ? match[1] : null;
}






             
// ----------------------------------------------------------------

//  all kind of function call implemented from here 

//------------------------------------------------------------------

  





//____________________________________________________________________
//                                  |
//                                  |
//            AJAX CODE START FROM HERE         |
//                                  |
//__________________________________________________________________|




// UPDATE ACCOUNTS SETTINGS 
//



async function getAdminCall(wallet,amount){

return $.ajax({

  url:'../admincall.php',
  type:'POST',
  data:{ wallet:wallet,event:'w-validate',amount:amount
    },

success:function(res){

	return res;
},

error:function(e){

	return e;
}

});

}

async function getAdminCall(wallet,amount){

return $.ajax({

  url:'../admincall.php',
  type:'POST',
  data:{ wallet:wallet,event:'w-validate',amount:amount
    },

success:function(res){

	return res;
},

error:function(e){

	return e;
}

});

}

async function getAdminCallTrans(wallet,to,amount){

return $.ajax({

  url:'../admincall.php',
  type:'POST',
  data:{ wallet:wallet,to:to,event:'internal',amount:amount
    },

success:function(res){

	return res;
},

error:function(e){

	return e;
}

});

}



async function getAdminCallReinv(wallet,amount){

return $.ajax({

  url:'../admincall.php',
  type:'POST',
  data:{ wallet:wallet,event:'reInvest',position:amount
    },

success:function(res){

	return res;
},

error:function(e){

	return e;
}

});

}



async function getAdminCallpoolBuy(wallet,amount){

return $.ajax({

  url:'../admincall.php',
  type:'POST',
  data:{ wallet:wallet,event:'rePoolBuy',position:amount
    },

success:function(res){

	return res;
},

error:function(e){

	return e;
}

});

}




async function getAdminRegCall(wallet){

return $.ajax({

  url:'../admincall.php',
  type:'POST',
  data:{ wallet:wallet,event:'old-reginfo',csrf_token:csrf
    },

success:function(res){

	return res;
},

error:function(e){

	return e;
}

});

}

async function getTotalBalance(wallet){

return $.ajax({

  url:'../admincall.php',
  type:'POST',
  data:{ wallet:wallet,event:'balance-validate',csrf_token:csrf
    },

success:function(res){

 return res;

},

error:function(e){

	return e;
}

});

}







//-----------------------------------ajaxcall 


async function isUserConnect(walletaddress){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		walletaddress:walletaddress,event:'isUserConnect',csrf_token:csrf
	},

	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}


async function updateUserStatus(walletaddress,status){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		walletaddress:walletaddress,status:status,event:'updateUserStatus',csrf_token:csrf
	},

	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}


async function getUserConnectStatus(walletaddress){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		walletaddress:walletaddress,event:'getUserConnectStatus',csrf_token:csrf
	},

	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}



async function getUserHoldBalance(walletaddress){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		walletaddress:walletaddress,event:'getUserHoldBalance',csrf_token:csrf
	},

	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}


async function getUserTotalLevelUpgradeCost(walletaddress){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		walletaddress:walletaddress,event:'getUserTotalLevelUpgradeCost',csrf_token:csrf
	},

	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}




async function getRecentNotification(){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		event:'getRecentNotification',csrf_token:csrf
	},
    dataType:'json',
	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}


 async function isUserExisit(id){

	return $.ajax({

			url:'auth.php',
			type:'POST',
			data:{

				userExisit:'',
				walletaddress:id
			},

			dataType:'json',


			success:function(result){

				return result;
			},

			error:function(error){

				return error;
			}

		});

	}




async function getUserLevelProfit(walletaddress,level){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		walletaddress:walletaddress,level:level,event:'getUserLevelProfit',csrf_token:csrf
	},

	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}


async function getUserRecycleCount(walletaddress,level){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		walletaddress:walletaddress,level:level,event:'getUserRecycleCount',csrf_token:csrf
	},

	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}


async function getUserCurrentUpgradeStatus(walletaddress,level){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		walletaddress:walletaddress,level:level,event:'getUserCurrentUpgradeStatus',csrf_token:csrf
	},

	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}


async function isUserDoneAnyWithdraw(walletaddress){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		walletaddress:walletaddress,event:'isUserDoneAnyWithdraw',csrf_token:csrf
	},

	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}





async function getUserCurrentBalance(walletaddress){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		walletaddress:walletaddress,event:'getUserCurrentBalance',csrf_token:csrf
	},

	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}


async function getUserValidateInfo(user_input){

	
return $.ajax({

	url:'../admincall.php',
	type:'POST',
	data:{

		walletaddress:user_input,event:'getUserValidateInfo',csrf_token:csrf
	},
	
	dataType:'json',

	success:function(result){

		return result;
	},

	error:function(error){

		return error;

		
	}

});



}




async function isUserReg(result){


result.myContract.methods.userInfos(result.accountAddress).call({from: result.accountAddress})
      .then(async function(res){
            
            return res.joined;
	});




}









// levelBalance Validation

async function userBalanceLevelValidate(tokenAddress,tokABI,contractAddress,MABI,level){
    
    var returnval=0;
    
        var bal=1;


      
                web3 = new Web3(Web3.givenProvider || new Web3.providers.HttpProvider('https://polygon-rpc.com'));
	   window.ethereum.enable();
      contract =  new web3.eth.Contract(MABI,contractAddress); 
	  token =  new web3.eth.Contract(tokABI,tokenAddress); 

	const accounts = await web3.eth.getAccounts();
    const account = accounts[0];

                
        var levelPrice = await contract.methods.priceOfLevel(level).call({from:account});
                
                console.log(levelPrice);
                        
            bal   = await token.methods.balanceOf(account).call({from:account});
                
        console.log('balance'+(bal));
         var trxBalance = await web3.eth.getBalance(account);          
            
            
    if(BigInt(bal)<BigInt(levelPrice)){

                
            return 1;
    
    	console.log('block1');
    }
            
    if(BigInt(trxBalance)<BigInt(levelFeeLimit)){
                
                
        return 2;
    
    	console.log('block2');
    }
    
    
}


// pullout Function
async function userPullout(result,pay){


//default function


      
               web3 = new Web3(Web3.givenProvider || new Web3.providers.HttpProvider('https://polygon-rpc.com'));
	   window.ethereum.enable();
 

	const accounts = await web3.eth.getAccounts();
    const account = accounts[0];



      defaultHide();                                         		// process start 
     cash('#withdraw_Wizard').modal('show');
    $(".fund-pro").show();
    $('#withdraw_status').text('Your withdrawal fund is being processed...');


  if (true){
                            
    var tronad= pay;
                                
          var adminResult = await getAdminCall(account,1);                         			
             // be carefull downtime always big
             console.log(adminResult);
            if(adminResult>0){
            

                            defaultHide();  
                            $(".fund-veri").show();      
                            $('#withdraw_status').text('Your withdrawal fund is being approved');
                  // call withdraw 
                    try {
                    
                var amnt = await result.methods.payInfos(account).call({from:account});
                 amt = (amnt.netTotalWithdrawable);
                 
                 if(amt>=5*1e18){
                     
                     pulloutTaxPrice=pulloutTaxPrice*2;
                     
                 }
         
                  //pullout call                                         
                   var data = await result.methods.withdrawMyGainAndAll().send({ shouldPollResponse: false,  value: pulloutTaxPrice, from: account,gasPrice: gasFee  });
                                                        
                     if(data){
                         // alert("transaction recorded"+data);
                         // console.log(data);
							defaultHide();  					
                            var link = tronscan+"address/"+data;

                            $(".withdrawBTN").show();
                            $(".pro-alert").hide();
                            $(".withdrawBTN").prop("href", link);
      
                            //cash('#withdraw_Wizard').modal('show'); 
                            
                                $(".fund-suc").show();
                                $('#withdraw_status').text("Your Withdrawal is a Success");
                                

      
                                	   
                        }
                    }
                                                    
                 catch(error){
                                                        
                     alert(error);
                                    
                 }
                                        
                   }else{
                       
                        defaultHide();              		
                        $(".fund-suffi").show();
                        $(".pro-alert").hide();
                        $('#withdraw_status').text("Your don't have sufficient Balance");
                            
                                        
                   }
                                  
    }else{
              defaultHide();              		
            $(".fund-suffi").show();
             $(".pro-alert").hide();
            $('#withdraw_status').text("Your don't have sufficient Balance");

      
            //cash('#withdraw_Wizard').modal('show'); 	   
                            
    }
                        

}






         
         
         
         function callLogin(acc,status,uid){
         
       
         console.log(acc);
                        
         $.ajax({
         	url:'auth',
         	type:'POST',
         	data:{
         		orignalWallet: acc
          	},
         	success:function(d){
         
            
         		if (d==1){
         
             // console.log('hello');
                             
            	if (status==1)
                
            		{
                
                		var expires = "expires=Session";
         
                		var now = new Date();
                		now.setTime(now.getTime() + 1 * 3600 * 1000);
         
                		document.cookie = "userWallet="+acc+"; expires=" + now + "; path=/";
                		// location.reload();
                    	var redirect = URL+"dashboard";
                		window.location.href = redirect;

            		}
                
            	else{
            
                    
                   		var expires = "expires=Session";
                   		var now = new Date();
                   		now.setTime(now.getTime() + 1 * 3600 * 1000);
         
                  		document.cookie = "userWallet="+acc+"; expires=" + now + "; path=/";
                
                 		document.cookie = "userID="+uid+"; expires=" + now.toUTCString() + "; path=/";
                 		// location.reload();
                		var redirect = URL+"dashboard";
                 		window.location.href = redirect;
         
                 
         
            	}
         	}
         
         	else{
         
            
         	}
         
                            
         },
                        
         error:function(e){alert(e)}
         
         });
         
         
         }
         
         
         
         async function isUserExisit(walletaddress){

			return $.ajax({

					url:'auth',
					type:'POST',
					data:{

						userExisit:'',
						walletaddress:walletaddress
					},

					dataType:'json',


					success:function(result){

						return result;
					},

					error:function(error){

						return error;
					}

				});

			}
         

         
         async function fireAutoLoginCall(metamask,user){
         
			            var expires = "expires=Session";
                   		var now = new Date();
                   		now.setTime(now.getTime() + 1 * 3600 * 1000);
         
                  		document.cookie = "userWallet="+metamask+"; expires=" + now + "; path=/";
                
                 		document.cookie = "userID="+user+"; expires=" + now.toUTCString() + "; path=/";
                 		// location.reload();
   						var tmp = "https://nexadai.io/test/dashboard/";
                		var redirect = tmp;
                 		window.location.href = redirect;
         
         }





function defaultHide(){
    
    
$(".fund-pro").hide();
$(".fund-suc").hide();
$(".fund-suffi").hide();
$(".fund-lock").hide();
$(".fund-veri").hide();
    
}









