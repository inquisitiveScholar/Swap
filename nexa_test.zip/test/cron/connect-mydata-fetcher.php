<?php
/*c1 = main Contract : TVpvLZcFRxGfsk7Rc7tzEZtiZkspUDdfJe
Events
1.buyLevelEv
2.doTransactionEv
3.payPlatformChargeEv
4.depositedToPoolEv
5.regUserEv
6.processPayOutEv
7.startMynetworkEv
*/
error_reporting(E_ALL);
ini_set('display_errors', 1);

die();

//include("../config.php");
include '../include_file/config.php';
include '../include_file/function.php';
include 'vendor/autoload.php';

$trongridurl = "https://api.shasta.trongrid.io/v1/contract/";
$fullNode = new \IEXBase\TronAPI\Provider\HttpProvider($trongridurl);
$solidityNode = new \IEXBase\TronAPI\Provider\HttpProvider($trongridurl);
$eventServer = new \IEXBase\TronAPI\Provider\HttpProvider($trongridurl);
try {
    $tron = new \IEXBase\TronAPI\Tron($fullNode, $solidityNode, $eventServer);
} catch (\IEXBase\TronAPI\Exception\TronException $e) {
    exit($e->getMessage());
}

$contract = $mainContractAddress;

//echo TRONGRID_V2_EVENT_API_URL;


//this function will fetch and process data of ALL events
function fetchData($mysqli , $previousLastEventFingerprint, $tron,$event){

	global $conn;

	 $eventBy= '/'.$event.'/';
      $url = TRONGRID_V2_EVENT_API_URL.MAIN_CONTRACT_ADDRESS.$eventBy.'?size=200&sort=block_timestamp';
	//echo  $url = TRONGRID_V2_EVENT_API_URL.MAIN_CONTRACT_ADDRESS.'/regLevelEv?size=200';
 	
    //global $siteURL;

    if ($previousLastEventFingerprint !== null) {
        //$url .= "&previousLastEventFingerprint=".$previousLastEventFingerprint;
      $previousLastEventFingerprint=$previousLastEventFingerprint + 1;
        $url .= "&since=".$previousLastEventFingerprint;
    }
    echo $url;


    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $output = curl_exec($ch);
    $output = json_decode($output);
    curl_close ($ch);

    $last = null;
    $last_timestamp=0;
	//$i=0;
	foreach ($output as $key => $value) {
    //$i=$i+1;
    //
   
      $isAddBlock=false;
      $transaction_id = $value->transaction_id;
      $blockNumber = $value->block_number;
      $blockNumber = hexdec($blockNumber);
      $timeNow = ($value->block_timestamp / 1000);
      $last_timestamp  =$value->block_timestamp;




   
       //======================================================

                        // coonectMyData

      //=======================================================    
      //
      
     if ($value->event_name == 'connectMyDataEv'){
    
    
          $timenow = $timeNow ;
          $user = $value->result->user;
          $userWalletBase58  = str_replace('0x', '41', $user);
          $userWalletBase58 = $tron->fromHex($userWalletBase58);
    

          echo "==================================================><br>";
       
       	  echo "                           connectMyDataEv                 <br>";
       	  echo "==================================================><br>";
       
          echo "User:".$userWalletBase58."<br>";
       	 
         echo "transid:".$transaction_id."<br>";
        
       	  echo "<br><br>";

          
          		 
          
          		 $qry = "SELECT * FROM `event_connectdata` WHERE user='$userWalletBase58' and `event_transaction`='$transaction_id'";
          		 //echo $reglevel_qry;
          		 $res = mysqli_query($conn, $qry);
          		 $rescount = mysqli_num_rows($res);
          
          		if ($rescount==0){
                
                	// $preAmount = getUserAvailabelProfit($userId);

					echo addConnectDataEntry($userWalletBase58,$transaction_id);
          			echo "<br>";
                
                }

    
    
    }
    

    



        // if($isAddBlock==true){
        //   $query = "INSERT INTO `event_blocks_synced` (blockNumber) VALUES ('" . $blockNumber . "');";
        //   $result =mysqli_query($conn, $query);
        // 	if ($result){
        //     	echo '<br/>===========================<br/>';
        //     }
        // }
    
    	/*if($i==count($output)){
      		$fingerprint= $value->_fingerprint;
     		 $query = "update  `adminsetting` set  lastfingerprint='" . $fingerprint . "'";
      //echo "<br> admin settings: ".$query;
      		mysqli_query($conn, $query);
    	}*/
    }
	// if((int)$last_timestamp>0){
	// $query = "update  `adminsetting` set  last_timestamp='" . $last_timestamp . "'";
	// echo "<br> admin settings: ".$query;
	// mysqli_query($mysqli, $query);
	// }

}
/*$qryadmin = "SELECT lastfingerprint FROM adminsetting ";
$reslast = mysqli_query($conn, $qryadmin);
$res = $reslast->fetch_assoc();
$lastfingerprint=$res['lastfingerprint'];
$lastEvent = fetchData($conn, $lastfingerprint, $tron);*/
// $qryadmin = "SELECT last_timestamp FROM adminsetting ";
// $reslast = mysqli_query($conn, $qryadmin);
// $res = $reslast->fetch_assoc();
// $last_timestamp=$res['last_timestamp'];

$eventList  = array('connectMyDataEv');

foreach ($eventList as $event) {

$lastEvent = fetchData($conn, $last_timestamp, $tron,$event);

} 



$handle = curl_init();
$url = "https://api.coingecko.com/api/v3/simple/price?ids=tron&vs_currencies=usd";
// Set the url
curl_setopt($handle, CURLOPT_URL, $url);
// Set the result output to be a string.
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
$output = curl_exec($handle);
$output = json_decode($output, true);
//var_dump($output);
curl_close($handle);
$tronPrice = $output['tron']['usd'];
//updating the admin setting table
$query = "UPDATE adminsetting SET tronPiceInUsd=".$tronPrice;
mysqli_query( $conn, $query );
mysqli_close($conn);
