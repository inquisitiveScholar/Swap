<?php
/*c1 = main Contract : TVpvLZcFRxGfsk7Rc7tzEZtiZkspUDdfJe
Events
1.buyLevelEv
2.doTransactionEv
3.payPlatformChargeEv
4.depositedToPoolEv
5.regUserEv
6.processPayOutEv
7.startMynetworkEv
*/
error_reporting(E_ALL);
ini_set('display_errors', 1);



//include("../config.php");
include '../include_file/config.php';
include '../include_file/function.php';
include 'vendor/autoload.php';


function bchexdec($hex)
{
    $len = strlen($hex);
	$dec=0;
    for ($i = 1; $i <= $len; $i++)
        $dec = bcadd($dec, bcmul(strval(hexdec($hex[$i - 1])), bcpow('16', strval($len - $i))));
   
    return $dec;
}




$trongridurl = "https://api.shasta.trongrid.io/v1/contract/";
$fullNode = new \IEXBase\TronAPI\Provider\HttpProvider($trongridurl);
$solidityNode = new \IEXBase\TronAPI\Provider\HttpProvider($trongridurl);
$eventServer = new \IEXBase\TronAPI\Provider\HttpProvider($trongridurl);
try {
    $tron = new \IEXBase\TronAPI\Tron($fullNode, $solidityNode, $eventServer);
} catch (\IEXBase\TronAPI\Exception\TronException $e) {
    exit($e->getMessage());
}


$contract = $mainContractAddress;


//----------------------------LAST BLOCK SYNC-------------------------------------------------
$query = "select `blockNumber` from `event_blocks_synced`  ORDER BY `blockNumber` DESC limit 0,1";
$q = mysqli_query($conn, $query);
$x = mysqli_fetch_row($q);
$lastBlock = 0;
if ($x != null)
{
    $lastBlock = $x[0];
}

$div = "1000000000000000000";

//------------------------------------------EVENT ID-----------------------------------

$regEv = "0x7acad2406123f82011c16d3168e0be297cb634674492bb82650b9edaabaed27f";  // complete
$buyPool2xEv = "0xfc12cb852f4e9ef7c42fa9c53f526025f71f73b8a1eddd4c571d71d3fae4e54d"; // complete
$buyPool3xEv = "0xee9b07d6a5c641bf9c025955da2d50b7bae8a1a2db53f10aa22d5d4a74ab87cf"; // complete 
$pool2xPay  ="0xa2a879955dad531e105bdb341ff9d68239e0d75a21a23298fc7e778a5da6356b";   // complete
$pool2xBirth = "0x07e2f7ccc16ab9f389a68df24b1792ccdc058e32fdfd857db0421cdae7b4edd4"; // complete
$pool3xBirth = "0xef7940cbde188fe3f0000051703d2ef85d4624fa5f2b5a0dc6a0e2f56390e2da";  // complete

$pool2xPosition = "0xbf41906983bedfb2d8d22a51eca229726b94d60f652b3b8d49792efbf6957171";
$pool3xPosition = "0x20c97bf27cfa7ddd22325129e713dca50062c6b08e50fce0ee465a43bd9f54a5";

$gapGen =  "0x137ce31776118aade98dba3be397d1b9156492274472e23e0f2bd77ed8a62e4d";
$royality =  "0x7998573cdbe8e9fd79d578c2e9a1a4b248041be3559eeffec8763b0e8f8cb7ce";
$royalityQualify="0xa69cae13dd7a0bcbb9f9c374efedadfe3f17e28c67bfe4dec5f697d0c1fe7f3a";



$direct = "0x0633532d26a8a15044c7d931cf44d394f0f38a0e013f59cf59121b64c122eb11"; 

$pool3xPay	= "0x888610056ea977cd2a7424d0e0ef3870c3619fc25f0df3d2701c53207692ac63";

$unilevel = "0x51918b9f36a5b8da5c26a9f535971fed7beeefc29c6a4569a406dfeb76203362";

$poolRoyality= "0xeed1bae2e9cdb56dd08d752627e3663c188736b34f10e165681c6b5e35b73c9c";

$poolSponser = "0xbc9c8b352cd4d237fd757bf03f5079603c695838f6c88baa34d8845a9cadd37d";

$transferFromCreditToCredit = "0x009679b540aed4db019a586536beb8dc741acde4470efe562cd7dc340520c549";
$transferFromGainToGain= "0xc3e107d148356f07737b541d556b72ddfad6d64e34a32bb2351cd08b319a3207";
$transferFromGainToCredit = "0xa8a0f5b4f6d70f9eee16ce0bcd9bb049c9eae8b3d8e093553b7dd40db315e0d9";

$deposit= "0x9592c4ee40df9d6eada048b87bb7ce276074fb962ccb20cdf680474587f7e977";

$lostIncome = "0x1048d756733d6612ffe5f501a9b86c1bfae6e06107aec9facf086f1c7ee3020a";




$buyTopup= "0x975407156d66f5d2baf73fc24cb63a7a6e9fcef0024692388adca770a2800a73";    // complete
$reInvestEv="0xfeb6b0ca06788851c314f07e18b8d8b9bc4ecccefb5be0da717af6ee2553eb7b";   // complete
$transferEv = "0x0886140067c0dbab18623fa6fe791779b60be1b783f2729591f5558cfd98491f";  // complete
$withdrawEv = "0x8d3c0357d8dc04e52ccc2f31049631bcfadfee35f934ff5eae16dc72fcf14e27";  // complete
$reBuyPoolEv    = "0xc7dece468ce6a8a363935931a86ff2325ab5e01106734829433843d7f1a8d12d"; // complete





$bsc_url = BSCURL ; // for testnet
$api_key = ""; //api for bsc
$bsc_api_url=BSC_API;

$mainContract = $mainContractAddress;//contract address
echo $url = $bsc_api_url . "api?module=logs&action=getLogs&fromBlock=".($lastBlock + 0.01)."&toBlock=latest&address=".$mainContract."&apikey=".$api_key;

//$url = "https://api.polygonscan.com/api?module=logs&action=getLogs&fromBlock=0&toBlock=latest&address=0xc9461Eefa8448B3d7A664BF313d842EA9112E007&topic0=0x888610056ea977cd2a7424d0e0ef3870c3619fc25f0df3d2701c53207692ac63&apikey=YourApiKeyToken";


// bridge Connection 




//------------------------------------------------EVENT FETCHING BSCSCAN----------------------------------------



   $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $output = curl_exec($ch);
    $output = json_decode($output,true);

    curl_close ($ch);
	// $output = json_decode($output, true);

				//  $amount = '50000000000000000';
				// $div = "1000000000000000000";
				// $amounts = bcdiv($amount,$div,2);
				// echo $amounts; echo "</br>";

	// print "<pre>";
	// print_r($output);
	// print "<br>";
	foreach ($output['result'] as $key => $value) {
    
    		
    
    		//----------------------------------------INVEST EV---------------------------------------------------

    		$blockNumber = $value['blockNumber'];
            $blockNumber = hexdec($blockNumber);
    

            $query = "INSERT INTO `event_blocks_synced` (blockNumber) VALUES ('" . $blockNumber . "');";
            mysqli_query($conn, $query);
    
    		echo mysqli_error($conn);
    
    		if($value['topics'][0]==$regEv){
            
            	echo "-------------------Reg-User----------------"."</br>";
            
            	 $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            	 // echo $data; echo "</br>";
            	
            	 $userWallet = substr($value["data"], 0, 66);
            	 $userWallet = '0x' . substr($userWallet, 26);
            
            	$tronWallet   = str_replace('0x', '41', $userWallet);
          		$tronWallet = $tron->fromHex($tronWallet);
            
            	 $refWallet = substr($value["data"], 64, 66);
            	 $refWallet = '0x' . substr($refWallet, 26);
            
            	 $user = substr($value["data"], 130, 66);
            	 $user = substr($user, 26);
            	 $user = hexdec($user); 
            

            	
            	 echo $userWallet; echo "</br>";
                 echo $refWallet ; echo "</br>";
            	 echo $tronWallet ; echo "</br>";
            	
//             	 $wallet = '0x' . substr($wallet, 26); 
            
            
            	$qry = "SELECT userID FROM reg_user WHERE  event_transaction = '".$transaction_id."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		 $rescount = mysqli_num_rows($res);
       

                // default id one is calling 
                
                	if($rescount==0){
                    
                    
                        	echo "regReady";
                    
                    			if ($refWallet=="0x0000000000000000000000000000000000000000"){
                                
                                	$refid=0;
                                }else{
                                
                                	
                                		$refid = getUserByAddress($refWallet);
                                
                                }
                    
                    		
                    			
                        	//addRegEntry($tronWallet,$userWallet,$refid,$timeNow,$transaction_id);
                    		addRegEntry($user,$tronWallet,$userWallet,$refid,$timeNow,$transaction_id);
                    
                    		echo "</br></br>";
                    
                    		echo mysqli_error($conn);
                    
                    	echo "</br></br>";
                        
                    
                    }

            	
            }
    
			else if($value['topics'][0]==$buyTopup)
			{
            	echo "----------BuyTopup Ev---------"."</br>";
            
            	            
            	 $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            	  echo $data; echo "</br>";
            	
            	 $userWallet = substr($value["data"], 0, 66);
            	 $userWallet = '0x' . substr($userWallet, 26);
            
            	 $position = substr($value["data"], 64, 66);
            	 $position = substr($position, 26);
            	 $position = hexdec($position); 
            
            
            	 echo $userWallet; echo "</br>";
            	 echo $position; echo "</br>";
            
            	//investUser($userId,$position,$trnx,$now);
            
            	 $qry = "SELECT userID FROM event_buyTopup WHERE  event_transaction = '".$transaction_id."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
                	//---------------------
                	$userId = getUserByAddress($userWallet);
                	addBuyTopupEntry($userId,$position,$timeNow,$transaction_id);
                
                
                	echo "</br>";
                
                	echo mysqli_error($conn);
                
                	echo "</br>";echo "</br>";echo "</br>";
                	
                	
                
                }
               

			}
            
    		else if($value['topics'][0]==$buyPool2xEv)
			{
            	echo "----------buyPool2x---------"."</br>";
            
            	            	            
            	 $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            	  echo $data; echo "</br>";
            	
            	 $userWallet = substr($value["data"], 0, 66);
            	 $userWallet = '0x' . substr($userWallet, 26);
            

            
            	 echo $userWallet; echo "</br>";
         
            
            	
            	
            	 $qry = "SELECT userID FROM event_buyPool_2x WHERE  event_transaction = '".$transaction_id."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
                
                		$userId = getUserByAddress($userWallet);
						addBuyPool2xEntry($userId,0,$timeNow,$transaction_id);
                
                
                		echo mysqli_error($conn); echo "</br>";
                
                		// updateUserTime

                }
            
            
            
            	//addBuyPoolEntry($userId,$position,$type,$now,$trnx);
            
         	}
            
			else if($value['topics'][0]==$buyPool3xEv)
    
			{

         		echo "----------pool3x---------"."</br>";
            
            
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            	 echo $data; echo "</br>";
            	
            	 $userWallet = substr($value["data"], 0, 66);
            	 $userWallet = '0x' . substr($userWallet, 26);
            

            
            
            	 echo $userWallet; echo "</br>";
            
            
            
            	 $qry = "SELECT userID FROM event_buyPool_3x WHERE  event_transaction = '".$transaction_id."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
   						 $userId = getUserByAddress($userWallet);
						addBuyPool3xEntry($userId,0,$timeNow,$transaction_id);
                
                }
            
				

			}
    
    		// autopool2xPay
    		else if ($value['topics'][0]==$pool2xPay){
            
            
            	echo "----------AutoPool2xPay---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            	 echo $data; echo "</br>";
            
            
                  $index = substr($value["data"], 0, 66);
            
            	 $index = hexdec($index); 
            
            	 $from = substr($value["data"], 64, 66);
            	 $from = substr($from, 26);
            	 $from = hexdec($from); 
            
            	 $to = substr($value["data"], 130, 64);
            	 $to = substr($to, 26);
            	 $to = hexdec($to); 
            
            	  $amount = substr($value["data"], 194, 64); echo "</br>";
            	 $amount = substr($amount, 26);
            	 $amount = bchexdec($amount); echo "</br>";
               $amount = bcdiv($amount,$div,3); 
            
            
            	 $cycle = substr($value["data"], 258, 64);
            	 $cycle = substr($cycle, 26);
            	 $cycle = hexdec($cycle); 
            
            
            

				echo "</br>------------output------------------</br>";
            
            	echo "index:- ".$index;
            
            	echo "</br>";
            	echo "from :-".$from;
            
            	echo "</br>";
            
            	echo "to :- ".$to;
            
            	echo "</br>";
            
            	            	echo "amount :- ".$amount;
            
            	echo "</br>";
            
            	            	echo "cycle :- ".$cycle;
            
            	echo "</br>";
            
            	echo "</br>------------output------------------</br>";
            
            
            
                $qry = "SELECT fromUser FROM autoPool2xPay WHERE fromUser = '".$from."' and toUser = '".$to."' and amount='".$amount."' and timestamp='".$timeNow ."' and cycle='".$cycle."' and mIndex='".$index."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
   					addNewPool2xPayEntry($index,$from,$to,$amount,$timeNow,$cycle);
                
                	mysqli_error($conn);
                
                }
            
            		
            
            	
            }
    
    
    		// autopool3xPay
    
    		else if ($value['topics'][0]==$pool3xPay){
            
                  echo "----------AutoPool3xPay---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
            		
            	            
                  $index = substr($value["data"], 0, 66);
            
            	 $index = hexdec($index); 
            
            	 $from = substr($value["data"], 64, 66);
            	 $from = substr($from, 26);
            	 $from = hexdec($from); 
            
            	 $to = substr($value["data"], 130, 64);
            	 $to = substr($to, 26);
            	 $to = hexdec($to); 
            
            	  $amount = substr($value["data"], 194, 64); echo "</br>";
            	 $amount = substr($amount, 26);
            	 $amount = bchexdec($amount); echo "</br>";
               $amount = bcdiv($amount,$div,3); 
            
            
            
                      

				echo "</br>------------output------------------</br>";
            
            	echo "index:- ".$index;
            
            	echo "</br>";
            	echo "from :-".$from;
            
            	echo "</br>";
            
            	echo "to :- ".$to;
            
            	echo "</br>";
            
            	echo "amount :- ".$amount;
            
            	echo "</br>";
            
          
            	echo "</br>------------output------------------</br>";
            
            
            
            	// addNewPool3xPayEntry(1,0,1,0);
            
            
                 $qry = "SELECT fromUser FROM autoPool3xPay WHERE fromUser = '".$from."' and toUser = '".$to."' and amount='".$amount."' and timestamp='".$timeNow ."' and  mIndex='".$index."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
   					addNewPool3xPayEntry($index,$from,$to,$amount,$timeNow);
                
                	mysqli_error($conn);
                
                }
            
            
            
            	
            }
    
    
    
    		 // autopool2xdata
    		else if ($value['topics'][0]==$pool2xBirth){
            
            
            	  echo "----------AutoPool2xBirth---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
            	$index = substr($value["data"], 0, 66);
            
            	$index = hexdec($index); 
            
            	 $from = substr($value["data"], 64, 66);
            	 $from = substr($from, 26);
            	 $from = hexdec($from); 
            
            	 $to = substr($value["data"], 130, 64);
            	 $to = substr($to, 26);
            	 $to = hexdec($to); 

				echo "</br>------------output------------------</br>";
            
            	echo "index:- ".$index;
            
            	echo "</br>";
            	echo "from :-".$from;
            
            	echo "</br>";
            
            	echo "to :- ".$to;
            
            	echo "</br>";
            
            	echo "</br>------------output------------------</br>";
            
            
                        
                        	            
                 $qry = "SELECT id FROM event_pool2xRebirth WHERE indexId = '".$index."' and fromUser = '".$from."' and toUser='".$to."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
  
                
                	addNewPool2xRebirthEntry($index,$from,$to);
                
                	mysqli_error($conn);
                
                }
            
            
            
            
            }
    
    		// autopool3xdata
    
    		else if ($value['topics'][0]==$pool3xBirth){
            
            	  echo "----------AutoPool3xBirth---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
            	$index = substr($value["data"], 0, 66);
            
            	$index = hexdec($index); 
            
            	 $from = substr($value["data"], 64, 66);
            	 $from = substr($from, 26);
            	 $from = hexdec($from); 
            
            	 $to = substr($value["data"], 130, 64);
            	 $to = substr($to, 26);
            	 $to = hexdec($to); 

				echo "</br>------------output------------------</br>";
            
            	echo "index:- ".$index;
            
            	echo "</br>";
            	echo "from :-".$from;
            
            	echo "</br>";
            
            	echo "to :- ".$to;
            
            	echo "</br>";
            
            	echo "</br>------------output------------------</br>";
            
            
            
            
                        	            
                 $qry = "SELECT id FROM event_pool3xRebirth WHERE indexId = '".$index."' and fromUser = '".$from."' and toUser='".$to."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
  
                
                	addNewPool3xRebirthEntry($index,$from,$to);
                
                	mysqli_error($conn);
                
                }
            
           
            
            
            
            }
    
    
        		 // autopool2xPos
    		else if ($value['topics'][0]==$pool2xPosition){
            
            
            	 echo "----------AutoPool2xPosition---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            

            	            
                 $index = substr($value["data"], 0, 66);
            
            	 $index = hexdec($index); 
            
            	 $userId = substr($value["data"], 64, 66);
            	 $userId = substr($userId, 26);
            	 $userId = hexdec($userId); 
            
            	 $parent = substr($value["data"], 130, 64);
            	 $parent = substr($parent, 26);
            	 $parent = hexdec($parent); 
            
            
            	 $mIndex = substr($value["data"], 194, 64);
            	 $mIndex = substr($mIndex, 26);
            	 $mIndex = hexdec($mIndex); 
            
            
	
            	            
                 $qry = "SELECT id FROM autoPool2x WHERE indexId = '".$index."' and parent = '".$parent."' and mainIndex='".$mIndex."' and userID='".$userId."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
  
                
                	addNewPool2xEntry($index,$parent,$mIndex,$userId,$transaction_id);
                
                	mysqli_error($conn);
                
                }
            
            
            
            	
            
            
            
            }
    
    		// autopool3xPos
    
    		else if ($value['topics'][0]==$pool3xPosition){
            
            
            	            
            	echo "----------AutoPool3xPosition---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
            
            
            	 $index = substr($value["data"], 0, 66);
            
            	 $index = hexdec($index); 
            
            	 $userId = substr($value["data"], 64, 66);
            	 $userId = substr($userId, 26);
            	 $userId = hexdec($userId); 
            
            	 $parent = substr($value["data"], 130, 64);
            	 $parent = substr($parent, 26);
            	 $parent = hexdec($parent); 
            
            
            	 $mIndex = substr($value["data"], 194, 64);
            	 $mIndex = substr($mIndex, 26);
            	 $mIndex = hexdec($mIndex); 
            
            
            
            	$qry = "SELECT id FROM autoPool3x WHERE indexId = '".$index."' and parent = '".$parent."' and mainIndex='".$mIndex."' and userID='".$userId."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
  
                
                	addNewPool3xEntry($index,$parent,$mIndex,$userId,$transaction_id);
                
                	mysqli_error($conn);
                
                }
            
            
            
            		// addNewPool3xEntry
            
            }
    
    
    
    
    	else if ($value['topics'][0]==$poolSponser){
            
            
            	            
            	echo "----------PoolSponser---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
        
        
        
        
            
            
            
            	 $from = substr($value["data"], 0, 66);
            
            	 $from = hexdec($from); 
            
            	 $to = substr($value["data"], 64, 66);
            	 $to = substr($to, 26);
            	 $to = hexdec($to); 
       
            
            	 $amount = substr($value["data"], 130, 64);
            	 $amount = substr($amount, 26);
            	 $amount = bchexdec($amount); echo "</br>";
               	 $amount = bcdiv($amount,$div,3); 
        
        
        				echo "</br>------------output------------------</br>";
            
            	echo "from:- ".$from;
            
            	echo "</br>";
            	echo "TO :-".$to;
            
            	echo "</br>";
            
            	echo "AMNT :- ".$amount;
            
            	echo "</br>";
            
            	echo "</br>------------output------------------</br>";
            
            
        		
        		$qry = "SELECT fromUser FROM event_poolSponser WHERE fromUser = '".$from."' and toUser = '".$to."' and amount='".$amount."' and timestamp='".$timeNow ."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
   					payToPoolSponserEntry($from,$to,$amount,$timeNow);
                	
                	mysqli_error($conn);
                
                }
            
            		// addNewPool3xEntry
            
            }
    
    
    
    
        
    	else if ($value['topics'][0]==$royality){
            
            
            	            
            	echo "----------Royality---------"."</br></br></br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
            
            
            	 $toWallet = substr($value["data"], 0, 66);
           
        		 $toWallet = '0x' . substr($toWallet, 26);
        
        
        		 $grAmount = substr($value["data"], 64, 66);
            	 $grAmount = substr($grAmount, 26);
            	 $grAmount = bchexdec($grAmount); echo "</br>";
               	 $grAmount = bcdiv($grAmount,$div,3); 
        
        
        		 $arAmount = substr($value["data"], 130, 64);
            	 $arAmount = substr($arAmount, 26);
            	 $arAmount = bchexdec($arAmount); echo "</br>";
               	 $arAmount = bcdiv($arAmount,$div,3); 
            

        		 $userId = getUserByAddress($toWallet);
            
            		
        		
        		$qry = "SELECT toUser FROM event_paidforroyality WHERE toUser = '".$userId."' and grAmount='".$grAmount."' and arAmount='".$arAmount."' and timestamp='".$timeNow ."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
   					payRoyalityEntry($userId,$grAmount,$arAmount,$timeNow);
                	
                	mysqli_error($conn);
                
                	echo "</br>";
                
                }
            
            		// addNewPool3xEntry
            
            }
    
    
    
    
    
            
    	else if ($value['topics'][0]==$royalityQualify){
            
            
            	            
            	echo "----------RoyalityQualify---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
            
            
            	 $to = substr($value["data"], 0, 66);
           
        		 $to = '0x' . substr($to, 26);
        
        		 $userId = getUserByAddress($to);
            
            	 $current = substr($value["data"], 64, 66);
            	 $current = substr($current, 26);
            	 $current = hexdec($current); 
        
        		
        		 $validity = substr($value["data"], 130, 64);
            	 $validity = substr($validity, 26);
            	 $validity = hexdec($validity); 
            
            	 $status = substr($value["data"], 194, 64);
            	 $status = substr($status, 26);
             	 $status = hexdec($status); 
            
            
        		
        		$qry = "SELECT user FROM event_activeRoyalityQualify WHERE user = '".$to."' and currentIndex = '".$current."' and validityIndex='".$validity."' and status='".$status ."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
   					addActiveRoyalityQualifyEntry($userId,$current,$validity,$status);
                	
                	mysqli_error($conn);
                
                }
            
            		// addNewPool3xEntry
            
            }
    
    
    
        
    	else if ($value['topics'][0]==$poolRoyality){
            
            
            	            
            	echo "----------PoolSponser---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
            
            
            
            	 $payId = substr($value["data"], 0, 66);
            
            	 $payId = hexdec($payId); 
        
        
        		 $from = substr($value["data"], 64, 66);
            	 $from = substr($from, 26);
            	 $from = hexdec($from); 
            
            	 $to = substr($value["data"], 130, 64);
            	 $to = substr($to, 26);
            	 $to = hexdec($to); 
            
            	 $amount = substr($value["data"], 194, 64);
            	 $amount = substr($amount, 26);
            	 $amount = bchexdec($amount); echo "</br>";
               	 $amount = bcdiv($amount,$div,3); 
            
            
            		// addNewPool3xEntry
        
        
                
        				echo "</br>------------output------------------</br>";
            
            	echo "from:- ".$from;
            
            	echo "</br>";
            	echo "TO :-".$to;
            
            	echo "</br>";
            
            	echo "AMNT :- ".$amount;
            
            	echo "</br>";
        
        			echo "PayID :- ".$payId;
            
            	echo "</br>------------output------------------</br>";
        
        
        			        		
        		$qry = "SELECT fromUser FROM event_poolRoyality WHERE fromUser = '".$from."' and toUser = '".$to."' and amount='".$amount."' and timestamp='".$timeNow ."' and payID='".$payId."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
   					
                	 payToPoolRoyalityEntry($payId,$from,$to,$amount,$timeNow);
                	
                

                	mysqli_error($conn);
                
                }
            
            }
    
    		
    
    
    
    		  else if ($value['topics'][0]==$unilevel){
            
            
            	            
            	 echo "----------Unilevel---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];echo "</br>";echo "</br>";
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
              
              	            	          	
            	 $fromWallet = substr($value["data"], 0, 66);
            	 $fromWallet = '0x' . substr($fromWallet, 26);
            
            
            
            	 $toWallet = substr($value["data"], 64, 66);
            	 $toWallet = '0x' . substr($toWallet, 26); 
              
              	 $level = substr($value["data"], 130, 64); echo "</br>";
            	 $level = substr($level, 26);
              	  //$level = hexdec($level); 
            
            	 $amount = substr($value["data"], 194, 64); echo "</br>";
            	 $amount = substr($amount, 26);
            	 $amount = bchexdec($amount,$div); echo "</br>";
               	$amount = bcdiv($amount,$div,3); 
            
            
            	echo "</br>------------output------------------</br>";
            
            	echo "from:- ".$fromWallet;
            
            	echo "</br>";
            	echo "to :-".$toWallet;
            
            	echo "</br>";
            
            	echo "level :- ".$level;
            
            	echo "</br>";
              
                          	echo "amount :- ".$amount;
            
            	echo "</br>";
            
            	echo "</br>------------output------------------</br>";
              
              	$from = getUserByAddress($fromWallet);
              	$to=getUserByAddress($toWallet);
              
              	
              
              
                $qry = "SELECT fromUser FROM event_paidforunilevelev WHERE fromUser = '".$from."' and toUser = '".$to."' and amount='".$amount."' and timestamp='".$timeNow ."' and level='".$level."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
   					
             
                	payUnilevelEntry($from,$to,$amount,$level,$timeNow);
                	mysqli_error($conn);
                
                }
              
              
              	
            
            }
    
    
    
   			else if ($value['topics'][0]==$gapGen){
            
            
            	            
            	 echo "----------GapGEN---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
            
            	          	
            	 $fromWallet = substr($value["data"], 0, 66);
            	 $fromWallet = '0x' . substr($fromWallet, 26);
            
            
            
            	 $toWallet = substr($value["data"], 64, 66);
            	 $toWallet = '0x' . substr($toWallet, 26); 
            
            	 $level = substr($value["data"], 130, 64); echo "</br>";
            	 $level = substr($level, 26);
            	 $level = hexdec($level); 
            
            	   $amount = substr($value["data"], 194, 64); echo "</br>";
            	 $amount = substr($amount, 26);
            	  $amount = bchexdec($amount); echo "</br>";
            
            		 $amount = bcdiv($amount,$div,3); 
            
            
            					echo "</br>------------output------------------</br>";
            
            	echo "from:- ".$fromWallet;
            
            	echo "</br>";
            	echo "to :-".$toWallet;
            
            	echo "</br>";
            
            	echo "amount :- ".$amount;
            
            	echo "</br>";
            
            	echo "</br>------------output------------------</br>";
            	
            
                $qry = "SELECT fromUser FROM event_paidforgapgenration WHERE fromUser = '".$from."' and toUser = '".$to."' and amount='".$amount."' and timestamp='".$timeNow ."' and level='".$level."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
   					
             
                	payGapGenEntry($from,$to,$amount,$level,$timeNow);
                	mysqli_error($conn);
                
                }
            
            
            }
    
    
 
        
   			else if ($value['topics'][0]==$direct){
            
            
            	            
            	 echo "----------Direct---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
            	          	
            	 $fromWallet = substr($value["data"], 0, 66);
            	 $fromWallet = '0x' . substr($fromWallet, 26);
            
            
            
            	 $toWallet = substr($value["data"], 64, 66);
            	 $toWallet = '0x' . substr($toWallet, 26); 
            
            	 $amount = substr($value["data"], 130, 64); echo "</br>";
            	 $amount = substr($amount, 26);
            	 $amount = bchexdec($amount); 
            	 $amount = bcdiv($amount,$div,3); 
            
            
            					echo "</br>------------output------------------</br>";
            
            	echo "from:- ".$fromWallet;
            
            	echo "</br>";
            	echo "to :-".$toWallet;
            
            	echo "</br>";
            
            	echo "amount :- ".$amount;
            
            	echo "</br>";
            
            	echo "</br>------------output------------------</br>";
            
            
            
            
            	$from = getUserByAddress($fromWallet);
              	$to=getUserByAddress($toWallet);
              
              	
              
              
                $qry = "SELECT fromUser FROM event_paidtodirect WHERE fromUser = '".$from."' and toUser = '".$to."' and amount='".$amount."' and timestamp='".$timeNow ."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
   					
                	//payUnilevelEntry($from,$to,$amount,0,$timeNow);
                
                	 payToDirectEntry($from,$to,$amount,$timeNow);
                	mysqli_error($conn);
                
                }
            
            
            
            
            }else if ($value['topics'][0]==$lostIncome){
            
                        	            
            	echo "----------lostIncome---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
                        	          	
            	 $fromWallet = substr($value["data"], 0, 66);
            	 $fromWallet = '0x' . substr($fromWallet, 26);
            
            
            
            	 $type = substr($value["data"], 64, 66);
            	 $type= substr($type, 26);
            	 $type = hexdec($type); 
            
            
            
            	 $amount= substr($value["data"], 130, 64);
            	 $amount = substr($amount, 26);     
            	 $amount = bchexdec($amount); 
            	 $amount = bcdiv($amount,$div,3); 
            
            	 $typeEnum;
            
            
            
            	if ($type==1){
                
                	$typeEnum= "sponser";
                	
                }else if ($type==2){
                
                	$typeEnum="unilevel";
                
                }else if ($type==3){
                
                	$typeEnum="gap";
                
                }else if ($type==4) {
                
                	$typeEnum;
                
                }else if ($type==5) {
                
                	$typeEnum="globalRoyality";
                
                }else if ($type==6){
                
                	$typeEnum="pool";
                
                }else if ($type==7){
                
                	$typeEnum;
                
                }	
            
            else if ($type==8){
                
                	$typeEnum="poolRoyality";
                
                }	
            
            else if ($type==9){
                
                	$typeEnum="infinityPool";
                
                }	
            
                $userId = getUserByAddress($userWallet);
            
            
            
               
			    echo "</br>------------output------------------</br>";
            
            	echo "from:- ".$fromWallet;
            
            	echo "</br>";
            	echo "type :-".$typeEnum;
            
            	echo "</br>";
            
            	echo "amount :- ".$amount;
            
            	echo "</br>";
            
            	echo "</br>------------output------------------</br>";
            
            
  
            	echo addIncomeLostEntry($userId,$amount,0,$typeEnum,$timeNow);
            
            	echo "</br>";
            	echo "</br>";
            
            	echo mysqli_error($conn);
                      
            
            
            }
    
    
    
    		else if ($value['topics'][0]==$deposit){
            
            
            	 echo "----------Deposit---------"."</br>";
            	   
                 echo $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            
            	 echo $data; echo "</br>";
            
            	          	
            	 $fromWallet = substr($value["data"], 0, 66);
            	 $fromWallet = '0x' . substr($fromWallet, 26);
            
            
            	 $toWallet = substr($value["data"], 64, 66);
            	 $toWallet = '0x' . substr($toWallet, 26); 
            
            	 $amount = substr($value["data"], 130, 64); echo "</br>";
            	 $amount = substr($amount, 26);
            	 $amount = bchexdec($amount); 
            	 $amount = bcdiv($amount,$div,3); 
            
            
			    echo "</br>------------output------------------</br>";
            
            	echo "from:- ".$fromWallet;
            
            	echo "</br>";
            	echo "to :-".$toWallet;
            
            	echo "</br>";
            
            	echo "amount :- ".$amount;
            
            	echo "</br>";
            
            	echo "</br>------------output------------------</br>";
            
            
                        
            	 $qry = "SELECT userID FROM event_reTopup WHERE  event_transaction = '".$transaction_id."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
               
                		
                        
                        $userId = getUserByAddress($userWallet);
                		addRebuyTopupEntry($userId,$position,$timeNow,$transaction_id);
                
                echo "</br>";
                
                	echo mysqli_error($conn);
                
                	echo "</br>";
                }
            	
            
            
            
            }
    
    
    		else if ($value['topics'][0]==$reInvestEv){
            
            
            	echo "-------------reInvest------------"."</br>"; 
            
            
                  $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            	  echo $data; echo "</br>";
            	
            	 $userWallet = substr($value["data"], 0, 66);
            	 $userWallet = '0x' . substr($userWallet, 26);
            
            	 $position = substr($value["data"], 64, 66);
            	 $position = substr($position, 26);
            	 $position = hexdec($position); 
            
            
            	 echo $userWallet; echo "</br>";
            	 echo $position; echo "</br>";
            
            	//investUser($userId,$position,$trnx,$now);
            
            	 $qry = "SELECT userID FROM event_reTopup WHERE  event_transaction = '".$transaction_id."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
               
                		
                        
                        $userId = getUserByAddress($userWallet);
                		addRebuyTopupEntry($userId,$position,$timeNow,$transaction_id);
                
                		                	                	echo "</br>";
                
                	echo mysqli_error($conn);
                
                	echo "</br>";
                }
            
            	
            
            }else if ($value['topics'][0]==$reBuyPoolEv){
            
            
                 echo "----------RePoolEV---------"."</br>";
            
            	            	            
            	 $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            	  echo $data; echo "</br>";
            	
            	 $userWallet = substr($value["data"], 0, 66);
            	 $userWallet = '0x' . substr($userWallet, 26);
            
            	 $position = substr($value["data"], 64, 66);
            	 $position = substr($position, 26);
            	 $position = hexdec($position); 
            
            
            	 echo $userWallet; echo "</br>";
            	 echo $position; echo "</br>";
            
            	
            	
            	 $qry = "SELECT userID FROM event_reBuyPool2x WHERE  event_transaction = '".$transaction_id."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
                	//---------------------
                
                
                		$userId = getUserByAddress($userWallet);
						addRebuyPool2xEntry($userId,$position,$timeNow,$transaction_id);
                
                
                	      echo "</br>";
                
                	echo mysqli_error($conn);
                
                	echo "</br>";
                

                }
            
            
            }
    
    
    
    		else if ($value['topics'][0]==$transferFromCreditToCredit){
            
            
            	echo "-------------transfer------------"."</br>"; 
            
            
                 $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            	 // echo $data; echo "</br>";
            	
            	 $fromWallet = substr($value["data"], 0, 66);
            	 $fromWallet = '0x' . substr($fromWallet, 26);
            echo $value["data"]; echo "</br>";
            
            
            	 $toWallet = substr($value["data"], 64, 66);
            	 $toWallet = '0x' . substr($toWallet, 26); 
            
            	 echo  $amount = substr($value["data"], 130, 64); echo "</br>";
            	 $amount = substr($amount, 26);
            	 echo $amount = bchexdec($amount); echo "</br>";
            
            		
            	
            	 echo $fromWallet; echo "</br>";
                 echo $toWallet ; echo "</br>";
            
            		$amount= bcdiv($amount,$div,3);	
            
            	
            	 $qry = "SELECT * FROM event_transferFromCreditToCredit WHERE  event_transaction = '".$transaction_id."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
                	$from = getUserByAddress($fromWallet);
                	$to =  getUserByAddress($toWallet);
                
                	echo addTransferCreditToCredit($from,$to,$amount,$timeNow,$transaction_id);
                
                	echo "</br>";
                
                	echo mysqli_error($conn);
                
                	echo "</br>";
                
                }
            	
            
            
            }
    
    
        
    		else if ($value['topics'][0]==$transferFromGainToGain){
            
            
            	echo "-------------transfer------------"."</br>"; 
            
            
                 $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            	 // echo $data; echo "</br>";
            	
            	 $fromWallet = substr($value["data"], 0, 66);
            	 $fromWallet = '0x' . substr($fromWallet, 26);
            echo $value["data"]; echo "</br>";
            
            
            	 $toWallet = substr($value["data"], 64, 66);
            	 $toWallet = '0x' . substr($toWallet, 26); 
            
            	 echo  $amount = substr($value["data"], 130, 64); echo "</br>";
            	 $amount = substr($amount, 26);
            	 echo $amount = bchexdec($amount); echo "</br>";
            
            		
            	
            	 echo $fromWallet; echo "</br>";
                 echo $toWallet ; echo "</br>";
            
            		$amount= bcdiv($amount,$div,3);	
            
            	
            	 $qry = "SELECT * FROM event_transferFromGainToCredit WHERE  event_transaction = '".$transaction_id."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
                	$from = getUserByAddress($fromWallet);
                	$to =  getUserByAddress($toWallet);
                
                	echo addTransferTransFromGainToGain($from,$to,$amount,$timeNow,$transaction_id);
                
                                	echo "</br>";
                
                	echo mysqli_error($conn);
                
                	echo "</br>";
                
                }
            	
            
            
            }
    
    
        
    		else if ($value['topics'][0]==$transferFromGainToCredit){
            
            
            	echo "-------------transfer------------"."</br>"; 
            
            
                 $transaction_id = $value['transactionHash'];
            	
				 $timeNow = hexdec($value['timeStamp']); 
				
            	 $data = $value['data'];
            	 // echo $data; echo "</br>";
            	
            	 $fromWallet = substr($value["data"], 0, 66);
            	 $fromWallet = '0x' . substr($fromWallet, 26);
            echo $value["data"]; echo "</br>";
            
            
            	 $toWallet = substr($value["data"], 64, 66);
            	 $toWallet = '0x' . substr($toWallet, 26); 
            
            	 echo  $amount = substr($value["data"], 130, 64); echo "</br>";
            	 $amount = substr($amount, 26);
            	 echo $amount = bchexdec($amount); echo "</br>";
            
            		
            	
            	 echo $fromWallet; echo "</br>";
                 echo $toWallet ; echo "</br>";
            
            		$amount= bcdiv($amount,$div,3);	
            
            	
            	 $qry = "SELECT * FROM event_transferFromGainToGain WHERE  event_transaction = '".$transaction_id."' ";
          		//echo $reglevel_qry;
          		$res = mysqli_query($conn, $qry);
          		$rescount = mysqli_num_rows($res);
            
            	if($rescount==0){
                
                	$from = getUserByAddress($fromWallet);
                	$to =  getUserByAddress($toWallet);
                
                	echo addTransferTransFromGainToCredit($from,$to,$amount,$timeNow,$transaction_id);
                
                
                	                	echo "</br>";
                
                	echo mysqli_error($conn);
                
                	echo "</br>";
                
                }
            	
            
            
            }
    
    
    
    
    
    		
    
    		else if($value['topics'][0]==$withdrawEv){
            
             	echo "---------------------Withdraw-------------------------"."</br>";   
            
            
                 $transaction_id = $value['transactionHash'];
				
				 $blockNumber = hexdec($blockNumber);
				 $timeNow = hexdec($value['timeStamp']);
            
            	 $wallet = substr($value["data"], 0, 66);
            
            	echo $value["data"]; echo "</br>";
                 echo $wallet = '0x' . substr($wallet, 26);  echo "</br>";
            	
                echo $amount = substr($value["data"], 66, 64); echo "</br>";
            	echo $amount =bchexdec($amount);  echo "</br>";
            

            	 
          		$userId = getUserByAddress($wallet);
       

              
           
            	$amount= bcdiv($amount,$div,3);		 
          
          		  $qry = "SELECT id FROM user_withdraw WHERE  event_transaction = '".$transaction_id."' ";
          		 //echo $reglevel_qry;
          		 $res = mysqli_query($conn, $qry);
          		 $rescount = mysqli_num_rows($res);
          
          		if ($rescount==0){
                
                	// $preAmount = getUserAvailabelProfit($userId);
					echo addWithDrawEntry($userId,$amount,$timeNow,$transaction_id);
				
          			echo "<br>";
                
                	                	                	echo "</br>";
                
                	echo mysqli_error($conn);
                
                	echo "</br>";
                
          			
                
                }
            

            

            
            
            
                 
            	
            }
    
    
    

	}




/*$qryadmin = "SELECT lastfingerprint FROM adminsetting ";
$reslast = mysqli_query($conn, $qryadmin);
$res = $reslast->fetch_assoc();
$lastfingerprint=$res['lastfingerprint'];
$lastEvent = fetchData($conn, $lastfingerprint, $tron);*/
// $qryadmin = "SELECT last_timestamp FROM adminsetting ";
// $reslast = mysqli_query($conn, $qryadmin);
// $res = $reslast->fetch_assoc();
// $last_timestamp=$res['last_timestamp'];

// $eventList  = array('regUserEv','buyLevelEv','withdrawEv');

// foreach ($eventList as $event) {

// $lastEvent = fetchData($conn, $last_timestamp, $tron,$event);

// } 



//binancecoin
$handle = curl_init();
$url = "https://api.coingecko.com/api/v3/simple/price?ids=binancecoin&vs_currencies=usd";
// Set the url
curl_setopt($handle, CURLOPT_URL, $url);
// Set the result output to be a string.
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, false);
$output = curl_exec($handle);
$output = json_decode($output, true);
//var_dump($output);
curl_close($handle);
$tronPrice = $output['binancecoin']['usd'];
//updating the admin setting table
$query = "UPDATE adminsetting SET tronPiceInUsd=".$tronPrice;
mysqli_query( $conn, $query );
mysqli_close($conn);

