<?php

include ('include_file/config.php');

include ('include_file/function.php');

session_start();
// die('hello world');
 $returnd = 0;

if (isset($_COOKIE['userWallet'])==true || isset($_SESSION['orignalWallet'])==true )
	
{
 
// break here if validation is failed 
 
 


// CHECK POST REQUEST 
if(isset($_POST) && !empty($_POST)){
	
	// CSRF TOKEN VALIDATION

}
 
 
 
 // if verified with success please continue ---
 
	if(isset($_POST['event'])){
    		
    
    	if ($_POST['event']=='w-validate'){
        
        //------------for testing purpose only
        // $wallet = $_POST['wallet'];
        // $returnd =updateWithdrawNode($wallet,500);  // call to node 
        // echo $returnd;
        // die();
        $admin=1;
        $wallet = $_POST['wallet'];
         $totalEarned  = getUserTotalProfit(getUserByAddress($wallet));
        
       		if(isset($_SESSION['isAdmin'])){
         	    
 			    $admin=$_SESSION['isAdmin'];
            
            	
 			}

          if($admin){
        
          		 	$wallet = $_POST['wallet'];
        			$amount =  $_POST['amount'];
				
					if (userExisitByAddress($wallet)){
                    
                     	$totalEarned  = getUserTotalProfit(getUserByAddress($wallet));
                    	
                    	$totalEarned= $totalEarned[1];
                     
                    
                    	// $returnd =transferNode($wallet,$amount,$totalEarned);  // call to node 
                    	// call here 
                    
                    	     $divider = "1000000000000000000";
                 			 $WithdrawnBalance = bcdiv(getUserWithdrawnBalanceNode($wallet),$divider);
//           		 		//$avlamount 	= getUserAvailabelProfit(getUserByAddress($wallet));
          	

                 		$avlamount=$totalEarned-$WithdrawnBalance;
                    
                    		if ($avlamount>0){
                            
                            	$returnd =updateWithdrawNode($wallet,$totalEarned);  // call to node 
                            
                            }else{
                            
                            
                            	$returnd=0;
                            }
                    
                    }else{
                    
                    	$returnd=0;
                    
                    }
        
        	}
        
        
        else{
          		$returnd=0;
          }
        
        }else if ($_POST['event']=='balance-validate'){
        
        	$wallet = $_POST['wallet'];
        
        	 session_start();
 			$uAddress = $_SESSION['orignalWallet'];
        
        	if(getUserByAddress($uAddress)!=-1){
            
         		$returnd = getUserTotalProfit(getUserByAddress($uAddress));
         	}
        
        }else if ($_POST['event']=='getUserValidateInfo'){
        

 			$user_input = $_POST['walletaddress'];
 			
 			$returnd = getUserValidation($user_input);
 			
            echo json_encode($returnd);
            
            die();
        
        }else if ($_POST['event']=='internal'){
        

             if(isset($_SESSION['isAdmin'])){
         	    
 			    $admin=$_SESSION['isAdmin'];
 			}
        
        
        	$wallet = $_POST['wallet'];
        	
        	$to = $_POST['to'];
        
        	$amount = $_POST['amount'];
        
        	$totalEarned  = getUserTotalProfit(getUserByAddress($wallet));
        
        
        if ($admin){
        
        	if ($totalEarned[1]>0){
            
            	$returnd =transferNode($wallet,$to,$amount,$totalEarned[1]); 
            }
        
        	else{
            
            	$returnd = 0;
            }
        
        }else{
        
        	$returnd=$admin;
        }
        
        
        
        //$returnd=0;

        }else if ($_POST['event']=='reInvest'){
        
        
             if(isset($_SESSION['isAdmin'])){
         	    
 			    $admin=$_SESSION['isAdmin'];
 			}
        
        
        	$wallet = $_POST['wallet'];
        	$pos =  $_POST['position'];
        	
                	//$multiplier = "1000000000000000000";
        	
        	if ($admin){
            
            	if (isset($wallet) && isset($pos) ){
                
                	// call here 
                
                	if (userExisitByAddress($wallet)){
                    
                     $totalEarned  = getUserTotalProfit(getUserByAddress($wallet));
                     
                    
                    	$returnd =reInvestNode($wallet,$pos,$totalEarned[1]);  // call to node 
                    	// call here 
                    
                    }
                
                	else{
                    
                    	$returnd=0;
                    }
                	
                }else{
                
                	$returnd=0;
                }
            
            }else{
            
            	$returnd=0;
            }
        
        
        
        }else if ($_POST['event']=='rePoolBuy'){
        

        	if(isset($_SESSION['isAdmin'])){
         	    
 			    $admin=$_SESSION['isAdmin'];
 			}
        
        
        	$wallet = $_POST['wallet'];
        	$pos =  $_POST['position'];
        	

                	
        	if ($admin){
            
            	if (isset($wallet) && isset($pos) ){
                
                	// call here 
                
                	if (userExisitByAddress($wallet)){
                    
                     $totalEarned  = getUserTotalProfit(getUserByAddress($wallet));
                     
                    
                    	$returnd =rePoolNode($wallet,$pos,$totalEarned[1]);  // call to node 
                    	// call here 
                    
                    }
                
                	else{
                    
                    	$returnd=0;
                    }
                	
                }else{
                
                	$returnd=0;
                }
            
            }else{
            
            	$returnd=0;
            }
        
        
        
        
        }else{
        
        
        	$returnd=0;
        
        }


    
    }




}


echo $returnd;



?>