
var express = require('express');
const dotenv = require('dotenv').config();
const http = require('https');
const app = express();
const Web3 = require('web3');

 var CronJob = require('cron').CronJob;

  var BigNumber = require('big-number');
 const util = require('util');


//------------------------------------------CODE WORK FLOW-------------------------------



//==> get tokenPair price in usd from other blockchain like (ethereum)

//==> get Reserve of current pair 

// ==> calculate total amountsOut call untill it's divide number is == price of token



//DUSD (DUMMY USDC) :  0x058251A3177e5B0ed06191C89e5b8B0d9d50EfA9
 // DETH (DUMMY ETH) : 0x01Da4FE47eD23BCC8BC22144a48234A4231B9983



//---------------------------------------------------------------------------------------------



//------------------------------------NETWORK CONFIGURATION-----------------------------------


 //--------------------------------------------------//
 //                  CONFIGURATION                   //
 //--------------------------------------------------//
 

 var fromProvider = process.env.ETH_WEB3_PROVIDER;
 var toProvider = process.env.CUSTOM_NETWORK_WEB3_PROVIDER;
 var fromV2PairContract = process.env.FROM_MATIC_PAIR_CONTRACT;
 var customRouterContract = process.env.CUSTOM_ROUTER_CONTRACT;
 var customV2PairContract = process.env.CUSTOM_MATIC_PAIR_CONTRACT;


 var USDC ='0x0Ad64a789fF61c17CDaFb94673E876915979Fb2b';
var MATIC = '0x031b7bDd404C977f871A58F67C6cc1f522Fa14A0';



//--------------------------------web3 Object inititlization-------------------------------

 var fromWeb3 = new Web3(new Web3.providers.HttpProvider(fromProvider));
 var toWeb3 = new Web3(new Web3.providers.HttpProvider(toProvider));
 var PAIR_CONTRACT_ADDR_ABI = JSON.parse(process.env.PAIR_ABI);


 var TO_PAIR_CONTRACT_ADDR_ABI = JSON.parse(process.env.PAIR_ABI);
 var ROUTER_CONTRACT_ADDR_ABI = JSON.parse(process.env.ROUTER_ABI);


const fromPairInstance = new fromWeb3.eth.Contract(PAIR_CONTRACT_ADDR_ABI, fromV2PairContract);


const toPairInstance = new toWeb3.eth.Contract(PAIR_CONTRACT_ADDR_ABI, customV2PairContract);

const routerInstance = new toWeb3.eth.Contract(ROUTER_CONTRACT_ADDR_ABI,customRouterContract);

  var publicAddress = toWeb3.eth.accounts.privateKeyToAccount(process.env.ADMIN_MATIC_PRIVATEKEY);
  
  
  toWeb3.eth.accounts.wallet.add(process.env.ADMIN_MATIC_PRIVATEKEY);
  const account = toWeb3.eth.accounts.wallet[0].address;




 const getFromTokenPrice  = async ()=> {


	try{


	var tokenReserve = await fromPairInstance.methods.getReserves().call();

	console.log((tokenReserve));

	const token0 = (tokenReserve[0]);
	const token1 = (tokenReserve[1]);

	const token1Price = token1/token0; // ETH/BNB/MATIC Price in USD

		console.log("MATIC PRICE :"+Math.round(token1Price));

		return Math.round(token1Price);

	}
	catch(e){


		console.log(e);
	}

}


 const getToTokenPrice  = async ()=> {


	try{


	var tokenReserve = await toPairInstance.methods.getReserves().call();

	console.log((tokenReserve));

	const token0 = (tokenReserve[0]);
	const token1 = (tokenReserve[1]);

	const token1Price = token1/token0; // ETH/BNB/MATIC Price in USD

		console.log("Custom Network MATIC PRICE :"+Math.round(token1Price));

		return Math.round(token1Price);

	}
	catch(e){


		console.log(e);
	}

}



async function getEstimateReserve(){


	var currentPrice = await getToTokenPrice();

		var targetPrice = await getFromTokenPrice();


		// targetPrice = 1800+num; // just for testing ....


	console.log("======================Target========================");

		console.log("TARGE PRICE :"+targetPrice);
		console.log("CURRENT PRICE: "+currentPrice);

	console.log("====================================================");


	if (targetPrice>currentPrice){


			console.log("===========================BUY CALL==============================");

				var input = 0.5; // starter


				while(targetPrice>currentPrice){


					// increase tokenIn util achieve target reserves


					input+=0.1;

					// console.log("tokenInc-----===="+input);


						var amount= toWeb3.utils.toWei(String(input));

						  amount = String(amount);


					var tokenPass = await routerInstance.methods.getAmountsOut(amount,[MATIC,USDC]).call();


					// will use this tokenIn Out for Swap 

					var tokenIn = tokenPass[0];

					var tokenOut = tokenPass[1];


					// get Reserve and calculate Current price on it 

						var tokenReserve = await toPairInstance.methods.getReserves().call();

						// console.log((tokenReserve));

						var token0 = BigNumber(tokenReserve[0]).minus(tokenIn);
						var token1 = BigNumber(tokenReserve[1]).plus(tokenOut);

						console.log('===========NEW RESERVE===============');


						// console.log("token1:"+token1);

						// console.log("token0:"+token0);

						var newReservePrice = token1/token0; // ETH/BNB/MATIC Price in USD

						console.log("new Reserve MATIC PRICE :"+Math.round(newReservePrice));

					 // Math.round(token1Price);

						currentPrice=Math.round(newReservePrice);

			}

			console.log('');
			console.log('===========TargetHit===============');


				console.log("newPrice :"+currentPrice);


				await swap(USDC,ETH,tokenOut);


			console.log('===============================');


	}else if (currentPrice>targetPrice){

		console.log("=================================SELL CALL===========================");


				var input = 0.5; // starter


				while(currentPrice>targetPrice){


					// increase tokenIn util achieve target reserves


					input+=0.1;

					// console.log("tokenInc-----===="+input);


						var amount= toWeb3.utils.toWei(String(input));

						  amount = String(amount);


					var tokenPass = await routerInstance.methods.getAmountsOut(amount,[MATIC,USDC]).call();


					// will use this tokenIn Out for Swap 

					var tokenIn = tokenPass[0];

					var tokenOut = tokenPass[1];


					// get Reserve and calculate Current price on it 

						var tokenReserve = await toPairInstance.methods.getReserves().call();

						// console.log((tokenReserve));

						var token0 = BigNumber(tokenReserve[0]).plus(tokenIn);
						var token1 = BigNumber(tokenReserve[1]).minus(tokenOut);

						console.log('===========NEW RESERVE===============');


						console.log("token1:"+token1);

						console.log("token0:"+token0);

						var newReservePrice = token1/token0; // ETH/BNB/MATIC Price in USD

						console.log("new Reserve MATIC PRICE :"+Math.round(newReservePrice));

					 // Math.round(token1Price);

						currentPrice=Math.round(newReservePrice);

			}


			console.log('');
			console.log('===========TargetHit===============');


				console.log("newPrice :"+currentPrice);


				console.log("tokenIn :"+(tokenIn));
				console.log("tokenOut :"+tokenOut);

				console.log("tokenIn :"+toWeb3.utils.fromWei(tokenIn),'ether');
				console.log("tokenOut :"+toWeb3.utils.fromWei(tokenOut),'ether');


			console.log('===============================');


				await swap(MATIC,USDC,tokenIn);

	}else{



			console.log("NO NEED FOR SWAP")

	}




}


async function swap(token0,token1,tokenIn){


	const d = new Date();
	const time = parseInt(d.getTime()/1000)+3000;

	try{

			console.log(tokenIn);

			var deadline = time;
		routerInstance.methods.swapExactTokensForTokens(tokenIn,0,[token0,token1],account,deadline).send({from:account,gas:1000000}, function(error, txHash){
  	    
		 var data = {"txHash":txHash};

     var array = {result:"success", data:data};
        	

        	console.log(error);
        	console.log(array);
			
		}).catch(err => console.error(err));


	}catch(e){


		console.log(e);
	}


}




app.listen(process.env.APPPORT,'127.0.0.1', function () {
	console.log('Server listening at port %d', process.env.APPPORT);


	// for (var i=1;i<=100;i++){

	// 		getEstimateReserve(i);

	// }


	getEstimateReserve();
	 		

// 	  var job = new CronJob('0 * * * * *', function() {
 //     console.log("-------------------------------------");
 //     console.log('Cron running, every 1 min');
 //     console.log("-------------------------------------");

// 		getEstimateReserve();
 // }, null, true, 'America/Los_Angeles');
 
 // job.start();

 

});
