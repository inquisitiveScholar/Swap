import { dcsmEnforcer } from './dcsmNetworkEnforcer';

/**
 * Web3 Transaction Wrapper
 * Automatically enforces DCSM network before any Web3 transaction
 * No user confirmation required - switches silently
 */
export class Web3TransactionWrapper {
  private static instance: Web3TransactionWrapper;
  private switchingInProgress = false;

  static getInstance(): Web3TransactionWrapper {
    if (!Web3TransactionWrapper.instance) {
      Web3TransactionWrapper.instance = new Web3TransactionWrapper();
    }
    return Web3TransactionWrapper.instance;
  }

  /**
   * Execute any Web3 transaction with automatic DCSM network enforcement
   * @param transactionFn - Function that performs the Web3 transaction
   * @param operationName - Name of the operation for error reporting
   */
  async executeWithNetworkEnforcement<T>(
    transactionFn: () => Promise<T>,
    operationName: string = 'Web3 transaction'
  ): Promise<T> {
    // Prevent concurrent network switches
    if (this.switchingInProgress) {
      await this.waitForSwitchCompletion();
    }

    try {
      // Check if already on DCSM network
      const isOnDCSM = await dcsmEnforcer.isOnDCSMNetwork();
      
      if (!isOnDCSM) {
        console.log(`${operationName}: Not on DCSM network, switching automatically...`);
        this.switchingInProgress = true;
        
        try {
          await dcsmEnforcer.enforceForWalletConnection();
          console.log(`${operationName}: Successfully switched to DCSM network`);
        } catch (switchError) {
          console.error(`${operationName}: Network switch failed:`, switchError);
          throw new Error(`Failed to switch to DCSM network for ${operationName.toLowerCase()}`);
        } finally {
          this.switchingInProgress = false;
        }
      }

      // Execute the actual transaction
      return await transactionFn();
      
    } catch (error) {
      console.error(`${operationName} failed:`, error);
      throw error;
    }
  }

  /**
   * Wait for any ongoing network switch to complete
   */
  private async waitForSwitchCompletion(): Promise<void> {
    let attempts = 0;
    const maxAttempts = 30; // 3 seconds max wait
    
    while (this.switchingInProgress && attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 100));
      attempts++;
    }
    
    if (this.switchingInProgress) {
      console.warn('Network switch taking too long, proceeding anyway');
      this.switchingInProgress = false;
    }
  }

  /**
   * Pre-enforce DCSM network for multiple operations
   * Useful when you know multiple Web3 calls will happen in sequence
   */
  async preEnforceDCSMNetwork(): Promise<void> {
    const isOnDCSM = await dcsmEnforcer.isOnDCSMNetwork();
    if (!isOnDCSM) {
      console.log('Pre-enforcing DCSM network for upcoming transactions...');
      await dcsmEnforcer.enforceForWalletConnection();
    }
  }
}

// Export singleton instance
export const web3TxWrapper = Web3TransactionWrapper.getInstance();