// Comprehensive network authentication and enforcement system
import { getDefaultNetwork, getNetworkConfig } from './networks';

declare global {
  interface Window {
    ethereum?: {
      request: (args: { method: string; params?: any[] }) => Promise<any>;
      on: (event: string, callback: (...args: any[]) => void) => void;
      removeListener: (event: string, callback: (...args: any[]) => void) => void;
      isMetaMask?: boolean;
    };
  }
}

export class NetworkAuthenticator {
  private static instance: NetworkAuthenticator;
  private currentChainId: string | null = null;
  private isEnforcing = false;
  private callbacks: Array<(isCorrectNetwork: boolean) => void> = [];

  static getInstance(): NetworkAuthenticator {
    if (!NetworkAuthenticator.instance) {
      NetworkAuthenticator.instance = new NetworkAuthenticator();
    }
    return NetworkAuthenticator.instance;
  }

  // Get current wallet network
  async getCurrentNetwork(): Promise<string | null> {
    if (!window.ethereum) return null;
    
    try {
      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      this.currentChainId = chainId;
      return chainId;
    } catch (error) {
      console.error('Failed to get current network:', error);
      return null;
    }
  }

  // Check if current network is DCSM
  async isOnDCSMNetwork(): Promise<boolean> {
    const currentChainId = await this.getCurrentNetwork();
    const dcsmConfig = getNetworkConfig(getDefaultNetwork());
    
    console.log('Current chain ID:', currentChainId);
    console.log('Expected DCSM chain ID:', dcsmConfig?.chainId);
    
    return currentChainId === dcsmConfig?.chainId;
  }

  // Force switch to DCSM network
  async forceDCSMNetwork(): Promise<boolean> {
    if (!window.ethereum) {
      throw new Error('MetaMask is not installed');
    }

    if (this.isEnforcing) {
      console.log('Network enforcement already in progress');
      return false;
    }

    this.isEnforcing = true;

    try {
      const dcsmConfig = getNetworkConfig(getDefaultNetwork());
      if (!dcsmConfig) {
        throw new Error('DCSM network configuration not found');
      }

      console.log('Attempting to switch to DCSM network:', dcsmConfig.chainId);

      // First try to switch to the network
      try {
        await window.ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: dcsmConfig.chainId }],
        });
        
        // Verify the switch was successful
        const newChainId = await this.getCurrentNetwork();
        const success = newChainId === dcsmConfig.chainId;
        
        if (success) {
          console.log('Successfully switched to DCSM network');
          this.notifyCallbacks(true);
        }
        
        return success;
      } catch (switchError: any) {
        console.log('Switch failed, trying to add network. Error code:', switchError.code);
        
        // If network doesn't exist (error 4902), add it
        if (switchError.code === 4902) {
          try {
            await window.ethereum.request({
              method: 'wallet_addEthereumChain',
              params: [{
                chainId: dcsmConfig.chainId,
                chainName: dcsmConfig.name,
                nativeCurrency: {
                  name: dcsmConfig.currency,
                  symbol: dcsmConfig.symbol,
                  decimals: dcsmConfig.decimals || 18,
                },
                rpcUrls: [dcsmConfig.rpcUrl],
                blockExplorerUrls: [dcsmConfig.blockExplorer],
              }],
            });

            // After adding, verify we're on the correct network
            const newChainId = await this.getCurrentNetwork();
            const success = newChainId === dcsmConfig.chainId;
            
            if (success) {
              console.log('Successfully added and switched to DCSM network');
              this.notifyCallbacks(true);
            }
            
            return success;
          } catch (addError: any) {
            console.error('Failed to add DCSM network:', addError);
            throw new Error('Failed to add DCSM network to wallet');
          }
        } else {
          console.error('Failed to switch to DCSM network:', switchError);
          throw new Error('Failed to switch to DCSM network');
        }
      }
    } finally {
      this.isEnforcing = false;
    }
  }

  // Add callback for network status changes
  onNetworkChange(callback: (isCorrectNetwork: boolean) => void): void {
    this.callbacks.push(callback);
  }

  // Remove callback
  removeCallback(callback: (isCorrectNetwork: boolean) => void): void {
    this.callbacks = this.callbacks.filter(cb => cb !== callback);
  }

  // Notify all callbacks about network status
  private notifyCallbacks(isCorrectNetwork: boolean): void {
    this.callbacks.forEach(callback => {
      try {
        callback(isCorrectNetwork);
      } catch (error) {
        console.error('Error in network callback:', error);
      }
    });
  }

  // Set up network monitoring
  setupNetworkMonitoring(): void {
    if (!window.ethereum) return;

    const handleChainChanged = async (chainId: string) => {
      console.log('Network changed to:', chainId);
      this.currentChainId = chainId;
      
      const isCorrect = await this.isOnDCSMNetwork();
      this.notifyCallbacks(isCorrect);
      
      // Auto-enforce DCSM network if wrong network detected
      if (!isCorrect && !this.isEnforcing) {
        console.log('Wrong network detected, auto-switching to DCSM...');
        setTimeout(async () => {
          try {
            await this.forceDCSMNetwork();
          } catch (error) {
            console.error('Auto network switch failed:', error);
          }
        }, 1000);
      }
    };

    const handleAccountsChanged = async (accounts: string[]) => {
      if (accounts.length > 0) {
        console.log('Account changed, verifying network...');
        const isCorrect = await this.isOnDCSMNetwork();
        if (!isCorrect) {
          try {
            await this.forceDCSMNetwork();
          } catch (error) {
            console.error('Network enforcement on account change failed:', error);
          }
        }
      }
    };

    // Remove existing listeners
    try {
      window.ethereum.removeListener('chainChanged', handleChainChanged);
      window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
    } catch (error) {
      // Ignore errors when removing listeners that might not exist
    }

    // Add new listeners
    window.ethereum.on('chainChanged', handleChainChanged);
    window.ethereum.on('accountsChanged', handleAccountsChanged);
  }

  // Initialize network enforcement
  async initialize(): Promise<void> {
    this.setupNetworkMonitoring();
    
    // Check current network status
    const isCorrect = await this.isOnDCSMNetwork();
    this.notifyCallbacks(isCorrect);
    
    // If wallet is connected but on wrong network, force switch
    if (window.ethereum) {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' });
        if (accounts && accounts.length > 0 && !isCorrect) {
          console.log('Wallet connected but wrong network, forcing DCSM...');
          await this.forceDCSMNetwork();
        }
      } catch (error) {
        console.error('Failed to check accounts during initialization:', error);
      }
    }
  }
}

// Export singleton instance
export const networkAuth = NetworkAuthenticator.getInstance();