import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useAuth } from "@/context/AuthContext";
import { getAvatarSrc } from "./AvatarSelector";
import { User } from "@shared/schema";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

export default function UserSuggestions() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const [showAll, setShowAll] = useState(false);
  const [followingUsers, setFollowingUsers] = useState<number[]>([]);
  const { toast } = useToast();

  // Only fetch suggestions if user is logged in
  const { data: suggestions = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/users/suggestions"],
    enabled: !!user
  });

  // Follow mutation
  const followMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest("POST", `/api/users/${userId}/follow`);
      return response.json();
    },
    onSuccess: (data, userId) => {
      setFollowingUsers(prev => [...prev, userId]);
      queryClient.invalidateQueries({ queryKey: ["/api/users/suggestions"] });
      toast({
        title: "Following",
        description: "You are now following this user",
      });
    },
    onError: (error, userId) => {
      console.error('Follow error:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to follow user. Please try again.",
      });
    }
  });

  const handleFollow = (userId: number) => {
    if (followingUsers.includes(userId)) return;
    followMutation.mutate(userId);
  };

  const handleUserClick = (username: string) => {
    navigate(`/profile/${username}`);
  };

  if (isLoading || !suggestions.length) {
    return null;
  }

  return (
    <Card className="bg-[#141e33] rounded-xl mb-6 border border-[#1a2747] overflow-hidden">
      <CardHeader className="pb-0 pt-4 px-4">
        <CardTitle className="text-lg font-bold text-white">Who to follow</CardTitle>
      </CardHeader>
      <CardContent className="pt-3 px-0">
        <div>
          {suggestions.map((suggestion: User) => (
            <div 
              key={suggestion.id} 
              className="px-4 py-3 hover:bg-[#1a2747] transition-colors"
            >
              <div className="flex items-center justify-between">
                <div 
                  className="flex items-center cursor-pointer group"
                  onClick={() => handleUserClick(suggestion.username)}
                >
                  <div className="h-11 w-11 rounded-full overflow-hidden mr-3 ring-2 ring-primary">
                    {suggestion.avatar ? (
                      <img src={getAvatarSrc(suggestion.avatar)} alt={`${suggestion.displayName}'s avatar`} className="h-full w-full object-cover" />
                    ) : (
                      <div className="h-full w-full bg-[#141e33] flex items-center justify-center">
                        <span className="material-icons text-sm text-primary">person</span>
                      </div>
                    )}
                  </div>
                  <div>
                    <div className="font-bold group-hover:text-primary transition-colors text-white">{suggestion.displayName}</div>
                    <div className="text-sm text-gray-400">@{suggestion.username}</div>
                  </div>
                </div>
                <Button
                  className={`border-2 px-4 py-1 rounded-xl font-bold text-sm transition-colors ${
                    followingUsers.includes(suggestion.id) 
                      ? "bg-primary border-primary text-white" 
                      : "bg-transparent border-primary text-primary hover:bg-primary/10"
                  }`}
                  onClick={() => handleFollow(suggestion.id)}
                  disabled={followMutation.isPending || followingUsers.includes(suggestion.id)}
                >
                  {followMutation.isPending && followMutation.variables === suggestion.id ? (
                    <>
                      <Loader2 className="h-3 w-3 animate-spin mr-1" />
                      Following...
                    </>
                  ) : followingUsers.includes(suggestion.id) ? (
                    "Following"
                  ) : (
                    "Follow"
                  )}
                </Button>
              </div>
            </div>
          ))}
          {!showAll && suggestions.length >= 3 && (
            <div 
              className="px-4 py-3 text-primary hover:underline cursor-pointer font-medium"
              onClick={() => setShowAll(true)}
            >
              Show more
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
