import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface MobileNavProps {
  onCreatePost: () => void;
}

export default function MobileNav({ onCreatePost }: MobileNavProps) {
  const [location, navigate] = useLocation();
  const { user } = useAuth();

  const { data: notifications = [] } = useQuery<any[]>({
    queryKey: ["/api/notifications"],
    enabled: !!user,
    refetchInterval: 30000,
  });

  const unreadCount = notifications.filter((n) => !n.read).length;

  const isActive = (path: string) => {
    return location.startsWith(path) ? "text-purple-500" : "text-gray-400";
  };

  return (
    <>
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-[#0f172a] border-t border-[#1a2747] flex justify-around py-2 z-10">
        <a 
          href="/" 
          className={`p-3 text-center ${isActive("/")} hover:text-purple-400 transition-colors`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/");
          }}
        >
          <span className="material-icons block mx-auto text-2xl">home</span>
        </a>
        <a 
          href="/explore" 
          className={`p-3 text-center ${isActive("/explore")} hover:text-purple-400 transition-colors`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/explore");
          }}
        >
          <span className="material-icons block mx-auto text-2xl">explore</span>
        </a>
        <a 
          href="/notifications" 
          className={`p-3 text-center ${isActive("/notifications")} hover:text-purple-400 transition-colors relative`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/notifications");
          }}
        >
          <div className="relative inline-block">
            <Bell className="w-6 h-6 mx-auto" />
            {unreadCount > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-2 -right-2 h-5 min-w-5 p-0 text-xs flex items-center justify-center"
              >
                {unreadCount > 99 ? '99+' : unreadCount}
              </Badge>
            )}
          </div>
        </a>
        <a 
          href="/profile" 
          className={`p-3 text-center ${isActive("/profile")} hover:text-purple-400 transition-colors`}
          onClick={(e) => {
            e.preventDefault();
            if (user?.username) {
              navigate(`/profile/${user.username}`);
            } else {
              navigate("/profile");
            }
          }}
        >
          <span className="material-icons block mx-auto text-2xl">person</span>
        </a>
        <a 
          href="/support" 
          className={`p-3 text-center ${isActive("/support")} hover:text-purple-400 transition-colors`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/support");
          }}
        >
          <span className="material-icons block mx-auto text-2xl">help</span>
        </a>
        <a 
          href="/settings" 
          className={`p-3 text-center ${isActive("/settings")} hover:text-purple-400 transition-colors`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/settings");
          }}
        >
          <span className="material-icons block mx-auto text-2xl">settings</span>
        </a>
      </nav>

      <div className="md:hidden fixed right-6 bottom-20 z-10">
        <button 
          className="h-14 w-14 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 text-white flex items-center justify-center shadow-lg hover:from-purple-700 hover:to-blue-700 transition-colors"
          onClick={onCreatePost}
        >
          <span className="material-icons text-2xl">add</span>
        </button>
      </div>
    </>
  );
}
