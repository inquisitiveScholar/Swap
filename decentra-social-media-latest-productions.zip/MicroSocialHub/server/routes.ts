import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertPostSchema, 
  insertCommentSchema, 
  insertLikeSchema, 
  insertFollowSchema,
  walletLoginSchema
} from "@shared/schema";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import MemoryStore from "memorystore";
import { setupApiRoutes } from "./api-routes";
import bcrypt from "bcryptjs";
import path from "path";
import express from "express";
import { WebSocketServer, WebSocket } from 'ws';

const SessionStore = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve WalletConnect verification file
  app.use('/.well-known', express.static(path.join(process.cwd(), '.well-known')));
  
  // Configure session
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "micro-session-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: false, // Allow HTTP in production for now
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
      store: new SessionStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
    })
  );

  // Configure passport
  app.use(passport.initialize());
  app.use(passport.session());
  
  // Setup all API routes from the separate file
  setupApiRoutes(app);

  // Passport local strategy
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Incorrect username." });
        }
        
        // Check if this is a wallet-only user (has no password because wallet-connected)
        if (user.walletAddress && !user.password) {
          return done(null, false, { message: "Please login with your wallet" });
        }
        
        // For now, allow plaintext password comparison for testing
        let isMatch = false;
        
        // Try with bcrypt first (for hashed passwords)
        try {
          if (user.password.startsWith('$2a$')) {
            isMatch = await bcrypt.compare(password, user.password);
          } else {
            // Direct comparison for plaintext password (only for testing)
            isMatch = password === user.password;
          }
        } catch (err) {
          console.error('Password comparison error:', err);
          // Fallback to direct comparison if bcrypt fails
          isMatch = password === user.password;
        }
        
        if (!isMatch) {
          console.log('Password mismatch:', { provided: password, hashedStored: user.password });
          return done(null, false, { message: "Incorrect password." });
        }
        
        return done(null, user);
      } catch (err) {
        console.error('Authentication error:', err);
        return done(err);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // Wallet-only authentication - removed traditional login endpoints

  // Endpoint to check if a wallet is already registered
  app.get("/api/wallet/:address/exists", async (req, res) => {
    try {
      const walletAddress = req.params.address;
      const user = await storage.getUserByWalletAddress(walletAddress);
      
      return res.json({
        exists: !!user,
        user: user ? {
          id: user.id,
          username: user.username,
          displayName: user.displayName
        } : null
      });
    } catch (error) {
      console.error("Error checking wallet:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  // Wallet login/registration endpoint
  app.post("/api/auth/wallet", async (req, res) => {
    try {
      const walletData = walletLoginSchema.parse(req.body);
      
      // Check minimum balance requirement (0.1 DCSM) - critical security check
      if (!walletData.balance || parseFloat(walletData.balance) < 0.1) {
        return res.status(400).json({ 
          message: "Insufficient balance. You need at least 0.1 DCSM to use this platform.",
          required: "0.1 DCSM",
          current: walletData.balance || "0",
          code: "INSUFFICIENT_BALANCE"
        });
      }
      
      // Check if a user with this wallet address already exists
      let user = await storage.getUserByWalletAddress(walletData.walletAddress);
      
      if (user) {
        // User exists, log them in using passport
        req.login(user, (err) => {
          if (err) {
            return res.status(500).json({ message: "Error logging in" });
          }
          return res.json({ 
            success: true, 
            user,
            message: "Login successful" 
          });
        });
        return;
      } else {
        // If user doesn't exist, check if we need to create a new one
        if (!walletData.username || !walletData.displayName) {
          // Just return that the wallet is not registered yet
          return res.status(404).json({ 
            message: "Wallet not registered",
            walletAddress: walletData.walletAddress,
            registered: false 
          });
        }
        
        // Validate username - must be lowercase only
        if (walletData.username !== walletData.username.toLowerCase()) {
          return res.status(400).json({ 
            message: "Username must be lowercase only",
            field: "username"
          });
        }
        
        // CRITICAL: Double-check wallet address is not already registered
        // This prevents race conditions and ensures database integrity
        const existingWalletUser = await storage.getUserByWalletAddress(walletData.walletAddress);
        if (existingWalletUser) {
          return res.status(409).json({ 
            message: "Wallet address already registered. Please login instead.",
            field: "walletAddress",
            code: "WALLET_ALREADY_REGISTERED"
          });
        }
        
        // Check if username already exists (case-insensitive check for safety)
        const existingUser = await storage.getUserByUsername(walletData.username.toLowerCase());
        if (existingUser) {
          return res.status(400).json({ 
            message: "Username already taken",
            field: "username"
          });
        }
        
        // Create a new user with the wallet address
        // Generate a random password since passport local requires it
        const randomPassword = Math.random().toString(36).slice(-10);
        
        user = await storage.createUser({
          username: walletData.username.toLowerCase(), // Force lowercase
          displayName: walletData.displayName,
          password: randomPassword, // We won't use this for wallet logins
          bio: walletData.bio || null,
          avatar: walletData.avatar || null,
          walletAddress: walletData.walletAddress,
          network: walletData.network,
        });
        
        // Log the new user in
        req.login(user, (err) => {
          if (err) {
            return res.status(500).json({ message: "Error logging in" });
          }
          return res.json({
            success: true,
            user,
            message: "Registration and login successful",
            registered: true,
            authenticated: true
          });
        });
      }
    } catch (error: any) {
      console.error("Wallet authentication error:", error);
      
      // Check if it's a validation error from Zod
      if (error.errors && Array.isArray(error.errors)) {
        return res.status(400).json({ 
          message: "Validation failed",
          errors: error.errors 
        });
      }
      
      // Return generic error message
      res.status(500).json({ 
        message: "Registration failed. Please try again."
      });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      // Check if wallet address is already registered
      if (userData.walletAddress) {
        const existingWallet = await storage.getUserByWalletAddress(userData.walletAddress);
        if (existingWallet) {
          return res.status(409).json({ message: "Wallet address already registered" });
        }
      }
      
      // Hash password if not using wallet authentication
      if (!userData.walletAddress) {
        userData.password = await bcrypt.hash(userData.password, 10);
      }
      
      const newUser = await storage.createUser(userData);
      
      // Log the user in
      req.login(newUser, (err) => {
        if (err) {
          return res.status(500).json({ message: "Error logging in" });
        }
        return res.status(201).json(newUser);
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  // Session check endpoint
  app.get("/api/auth/session", (req, res) => {
    if (req.isAuthenticated()) {
      res.status(200).json({ authenticated: true, user: req.user });
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });
  
  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/session", (req, res) => {
    if (req.isAuthenticated()) {
      res.json(req.user);
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });

  // User routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(parseInt(req.params.id));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      // Don't send password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Query parameter required" });
      }
      
      const users = await storage.searchUsers(query);
      
      // Remove passwords
      const sanitizedUsers = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.json(sanitizedUsers);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Post routes
  app.post("/api/posts", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postData = insertPostSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const newPost = await storage.createPost(postData);
      res.status(201).json(newPost);
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  app.get("/api/posts", isAuthenticated, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      const user = req.user as any;
      
      const posts = await storage.getPosts(limit, offset, user.id);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/posts/:id", async (req, res) => {
    try {
      const post = await storage.getPost(parseInt(req.params.id));
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const user = await storage.getUser(post.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send user password
      const { password, ...userWithoutPassword } = user;
      
      res.json({ ...post, user: userWithoutPassword });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users/:id/posts", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const posts = await storage.getPostsByUser(userId, limit, offset);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Comment routes
  app.post("/api/posts/:id/comments", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      const commentData = insertCommentSchema.parse({
        ...req.body,
        postId: postId,
        userId: user.id
      });
      
      const newComment = await storage.createComment(commentData);
      
      // Create notification for post owner (if not commenting on own post)
      const post = await storage.getPost(postId);
      if (post && post.userId !== user.id) {
        await storage.createNotification({
          userId: post.userId,
          fromUserId: user.id,
          type: 'comment',
          postId: postId,
          commentId: newComment.id,
          message: `${user.displayName || user.username} commented on your post`,
          read: false
        });
      }
      
      // Get user data for response
      const commentUser = await storage.getUser(newComment.userId);
      const { password, ...userWithoutPassword } = commentUser!;
      
      res.status(201).json({
        ...newComment,
        user: userWithoutPassword
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  app.get("/api/posts/:id/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const comments = await storage.getCommentsByPost(postId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Reaction routes (YouTube-style like/dislike)
  app.post("/api/posts/:id/reaction", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      const { isLike } = req.body;
      
      // Check if user already has a reaction
      const existingReaction = await storage.getLike(postId, user.id);
      
      if (existingReaction) {
        // If same reaction, remove it
        if (existingReaction.isLike === isLike) {
          await storage.deleteLike(postId, user.id);
          const counts = await storage.getReactionCounts(postId);
          return res.json({ 
            reaction: null, 
            likesCount: counts.likes, 
            dislikesCount: counts.dislikes 
          });
        } else {
          // Different reaction, update it
          await storage.deleteLike(postId, user.id);
          await storage.createLike({ postId, userId: user.id, isLike });
          
          // Create notification for post owner (if not reacting to own post)
          const post = await storage.getPost(postId);
          if (post && post.userId !== user.id) {
            await storage.createNotification({
              userId: post.userId,
              fromUserId: user.id,
              type: isLike ? 'like' : 'dislike',
              postId: postId,
              message: `${user.displayName || user.username} ${isLike ? 'liked' : 'disliked'} your post`,
              read: false
            });
          }
          
          const counts = await storage.getReactionCounts(postId);
          return res.json({ 
            reaction: isLike ? 'like' : 'dislike', 
            likesCount: counts.likes, 
            dislikesCount: counts.dislikes 
          });
        }
      } else {
        // No existing reaction, create new one
        await storage.createLike({ postId, userId: user.id, isLike });
        
        // Create notification for post owner (if not reacting to own post)
        const post = await storage.getPost(postId);
        if (post && post.userId !== user.id) {
          await storage.createNotification({
            userId: post.userId,
            fromUserId: user.id,
            type: isLike ? 'like' : 'dislike',
            postId: postId,
            message: `${user.displayName || user.username} ${isLike ? 'liked' : 'disliked'} your post`,
            read: false
          });
        }
        
        const counts = await storage.getReactionCounts(postId);
        res.json({ 
          reaction: isLike ? 'like' : 'dislike', 
          likesCount: counts.likes, 
          dislikesCount: counts.dislikes 
        });
      }
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/posts/:id/reaction", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      const existingReaction = await storage.getLike(postId, user.id);
      const counts = await storage.getReactionCounts(postId);
      
      res.json({ 
        reaction: existingReaction ? (existingReaction.isLike ? 'like' : 'dislike') : null,
        likesCount: counts.likes,
        dislikesCount: counts.dislikes
      });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Block user routes
  app.post("/api/users/:id/block", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const blockedUserId = parseInt(req.params.id);
      
      // Can't block yourself
      if (user.id === blockedUserId) {
        return res.status(400).json({ message: "Cannot block yourself" });
      }
      
      const blockData = {
        blockerId: user.id,
        blockedId: blockedUserId
      };
      
      await storage.createBlock(blockData);
      res.json({ message: "User blocked successfully" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Report post routes
  app.post("/api/posts/:id/report", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      const { reason, description } = req.body;
      
      const reportData = {
        reporterId: user.id,
        reportedPostId: postId,
        reason,
        description
      };
      
      await storage.createReport(reportData);
      res.json({ message: "Report submitted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Follow routes
  app.post("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const followingId = parseInt(req.params.id);
      
      // Can't follow yourself
      if (user.id === followingId) {
        return res.status(400).json({ message: "Cannot follow yourself" });
      }
      
      const followData = insertFollowSchema.parse({
        followerId: user.id,
        followingId
      });
      
      const newFollow = await storage.createFollow(followData);
      res.status(201).json(newFollow);
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  app.delete("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const followingId = parseInt(req.params.id);
      
      const success = await storage.deleteFollow(user.id, followingId);
      if (!success) {
        return res.status(404).json({ message: "Follow relationship not found" });
      }
      
      res.json({ message: "Unfollowed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const followingId = parseInt(req.params.id);
      
      const follow = await storage.getFollow(user.id, followingId);
      if (!follow) {
        return res.json({ following: false });
      }
      
      res.json({ following: true });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // User suggestions
  app.get("/api/users/suggestions", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
      
      const suggestions = await storage.getUserSuggestions(user.id, limit);
      
      // Remove passwords
      const sanitizedSuggestions = suggestions.map(suggestion => {
        const { password, ...userWithoutPassword } = suggestion;
        return userWithoutPassword;
      });
      
      res.json(sanitizedSuggestions);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Tip routes
  app.post("/api/posts/:id/tip", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      const { amount, currency, network, txHash } = req.body;
      
      if (!amount || !currency || !network) {
        return res.status(400).json({ message: "Amount, currency, and network are required" });
      }
      
      // Get the post to find the recipient
      const post = await storage.getPost(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Can't tip your own post
      if (post.userId === user.id) {
        return res.status(400).json({ message: "Cannot tip your own post" });
      }
      
      const tipData = {
        fromUserId: user.id,
        toUserId: post.userId,
        postId,
        amount: amount.toString(),
        currency,
        network,
        txHash: txHash || null,
      };
      
      const newTip = await storage.createTip(tipData);
      
      // Create notification for the tip recipient
      await storage.createNotification({
        userId: post.userId,
        fromUserId: user.id,
        type: 'tip',
        postId: postId,
        message: `${user.displayName || user.username} sent you a ${amount} ${currency} tip`,
        read: false
      });
      
      res.status(201).json(newTip);
    } catch (error) {
      console.error("Error creating tip:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/posts/:id/tips", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const tipSummary = await storage.getTipsByPost(postId);
      res.json(tipSummary);
    } catch (error) {
      console.error("Error fetching tips:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users/:id/tips", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const tips = await storage.getTipsByUser(userId);
      res.json(tips);
    } catch (error) {
      console.error("Error fetching user tips:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Notification routes
  app.get("/api/notifications", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const notifications = await storage.getNotificationsByUser(user.id);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/notifications/:id/read", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const notificationId = parseInt(req.params.id);
      
      const notification = await storage.markNotificationAsRead(notificationId, user.id);
      
      if (!notification) {
        return res.status(404).json({ message: "Notification not found" });
      }
      
      res.json(notification);
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/notifications/mark-all-read", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      await storage.markAllNotificationsAsRead(user.id);
      res.json({ message: "All notifications marked as read" });
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Report routes
  app.post("/api/reports", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const { reportedUserId, reportedPostId, reason, description } = req.body;
      
      if (!reason) {
        return res.status(400).json({ message: "Reason is required" });
      }
      
      if (!reportedUserId && !reportedPostId) {
        return res.status(400).json({ message: "Either reportedUserId or reportedPostId is required" });
      }
      
      const reportData = {
        reporterId: user.id,
        reportedUserId: reportedUserId || null,
        reportedPostId: reportedPostId || null,
        reason,
        description: description || null,
      };
      
      const newReport = await storage.createReport(reportData);
      res.status(201).json(newReport);
    } catch (error) {
      console.error("Error creating report:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/reports", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      
      // Only allow admins to view reports (you can add admin check here)
      // For now, we'll restrict this endpoint
      if (user.id !== 1) { // Assuming user ID 1 is admin
        return res.status(403).json({ message: "Access denied" });
      }
      
      const status = req.query.status as string;
      const reports = await storage.getReports(status);
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/reports/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const reportId = parseInt(req.params.id);
      const { status } = req.body;
      
      // Only allow admins to update reports
      if (user.id !== 1) { // Assuming user ID 1 is admin
        return res.status(403).json({ message: "Access denied" });
      }
      
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      const updatedReport = await storage.updateReportStatus(reportId, status, user.id);
      if (!updatedReport) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      res.json(updatedReport);
    } catch (error) {
      console.error("Error updating report:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  const httpServer = createServer(app);
  
  // Set up WebSocket server on a different path than Vite's HMR
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Track connected clients
  const clients = new Map<WebSocket, { userId?: number }>();
  
  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');
    
    // Add client to the clients map
    clients.set(ws, {});
    
    // Handle messages from clients
    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message);
        
        // Handle different message types
        switch (data.type) {
          case 'auth':
            // Authenticate the client
            if (data.userId) {
              clients.set(ws, { userId: data.userId });
              console.log(`User ${data.userId} authenticated via WebSocket`);
            }
            break;
            
          case 'newPost':
            // Broadcast new post to all clients
            broadcastMessage({
              type: 'newPost',
              post: data.post
            });
            break;
            
          case 'newLike':
            // Notify specific user about a like
            if (data.targetUserId) {
              sendToUser(data.targetUserId, {
                type: 'notification',
                action: 'like',
                postId: data.postId,
                userId: data.userId
              });
            }
            break;
            
          case 'newComment':
            // Notify specific user about a comment
            if (data.targetUserId) {
              sendToUser(data.targetUserId, {
                type: 'notification',
                action: 'comment',
                postId: data.postId,
                userId: data.userId
              });
            }
            break;
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    // Handle client disconnection
    ws.on('close', () => {
      clients.delete(ws);
      console.log('WebSocket client disconnected');
    });
    
    // Send welcome message
    ws.send(JSON.stringify({ 
      type: 'welcome',
      message: 'Connected to Web3 Social WebSocket server'
    }));
  });
  
  // Helper function to broadcast message to all clients
  function broadcastMessage(message: any) {
    const messageStr = JSON.stringify(message);
    
    clients.forEach((client, ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(messageStr);
      }
    });
  }
  
  // Helper function to send message to specific user
  function sendToUser(userId: number, message: any) {
    const messageStr = JSON.stringify(message);
    
    clients.forEach((client, ws) => {
      if (client.userId === userId && ws.readyState === WebSocket.OPEN) {
        ws.send(messageStr);
      }
    });
  }
  
  return httpServer;
}
