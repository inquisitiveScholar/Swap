import React from "react";
import { SimpleChat } from "./components/chat/simple-chat";

function App() {
  return (
    <div className="min-h-screen bg-slate-900 text-white">
      <header className="bg-slate-800 border-b border-slate-700 p-4">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
          Orion AI Assistant - Web3 Intelligence Platform
        </h1>
        <p className="text-slate-400 text-sm mt-1">
          Chat-based wallet management, balance checks, transfers, and smart contract generation
        </p>
      </header>
      <SimpleChat />
    </div>
  );
}

export default App;
