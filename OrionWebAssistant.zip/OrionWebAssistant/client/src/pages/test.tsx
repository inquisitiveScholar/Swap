import React from "react";

export default function Test() {
  return (
    <div style={{ padding: "20px", backgroundColor: "#1a1a1a", color: "white", minHeight: "100vh" }}>
      <h1>Orion AI Assistant Test Page</h1>
      <p>Testing basic React rendering...</p>
      <div style={{ backgroundColor: "#333", padding: "20px", marginTop: "20px", borderRadius: "8px" }}>
        <h2>System Status</h2>
        <p>Frontend: Running on port 5000</p>
        <p>Backend: Should be running on port 8000</p>
        <button 
          style={{ 
            backgroundColor: "#6366f1", 
            color: "white", 
            padding: "10px 20px", 
            border: "none", 
            borderRadius: "6px",
            cursor: "pointer"
          }}
          onClick={() => alert("Button clicked!")}
        >
          Test Button
        </button>
      </div>
    </div>
  );
}