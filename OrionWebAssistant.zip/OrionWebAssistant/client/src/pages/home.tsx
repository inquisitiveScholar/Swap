import React from "react";
import { Header } from "@/components/layout/header";
import { ChatInterface } from "@/components/chat/chat-interface";

export default function Home() {
  return (
    <div className="min-h-screen bg-orion-bg-primary">
      <Header />
      <div className="pt-16 h-screen">
        <ChatInterface />
      </div>
    </div>
  );
}
