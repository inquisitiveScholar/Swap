import { apiRequest } from "./queryClient";

export interface ChatMessage {
  id: number;
  content: string;
  role: "user" | "assistant";
  timestamp: Date;
  metadata?: any;
}

export interface ChatResponse {
  userMessage: ChatMessage;
  assistantMessage: ChatMessage;
  actions: any[];
  intent?: string;
}

export const chatApi = {
  async getMessages(): Promise<ChatMessage[]> {
    try {
      const response = await fetch("/api/messages");
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error("Failed to fetch messages:", error);
      return [];
    }
  },

  async sendMessage(content: string): Promise<ChatResponse> {
    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content })
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      
      return {
        userMessage: data.userMessage,
        assistantMessage: data.assistantMessage,
        actions: data.actionData ? [data.actionData] : [],
        intent: data.intent
      };
    } catch (error) {
      console.error("Failed to send message:", error);
      return {
        userMessage: {
          id: Date.now(),
          content: content,
          role: "user",
          timestamp: new Date(),
          metadata: null
        },
        assistantMessage: {
          id: Date.now() + 1,
          content: "I'm having trouble connecting to the AI service. Please check your connection and try again.",
          role: "assistant",
          timestamp: new Date(),
          metadata: null
        },
        actions: [],
        intent: "error"
      };
    }
  },

  async executeWeb3Action(actionType: string, actionData: any): Promise<any> {
    try {
      const response = await fetch(`/api/web3/${actionType}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(actionData)
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error("Failed to execute Web3 action:", error);
      return { error: "Web3 action execution failed" };
    }
  }
};
