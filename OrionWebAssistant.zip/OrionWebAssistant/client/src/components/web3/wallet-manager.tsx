import React, { useState, useEffect } from "react";
import { chatApi } from "@/lib/chat-api";

declare global {
  interface Window {
    ethereum?: any;
  }
}

export const useWallet = () => {
  const [connectedAddress, setConnectedAddress] = useState<string>('');
  const [chainId, setChainId] = useState<string>('');
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  useEffect(() => {
    // Check if wallet is already connected
    if (window.ethereum && !connectedAddress) {
      window.ethereum.request({ method: 'eth_accounts' })
        .then((accounts: string[]) => {
          if (accounts.length > 0) {
            window.ethereum.request({ method: 'eth_chainId' })
              .then((chainId: string) => {
                setConnectedAddress(accounts[0]);
                setChainId(chainId);
                setIsConnected(true);
              });
          }
        })
        .catch(console.error);
    }
  }, []);

  const connectWallet = async () => {
    if (!window.ethereum) {
      throw new Error('Please install MetaMask or another Web3 wallet');
    }

    setIsConnecting(true);
    try {
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts'
      });
      
      const chainId = await window.ethereum.request({
        method: 'eth_chainId'
      });

      if (accounts.length > 0) {
        setConnectedAddress(accounts[0]);
        setChainId(chainId);
        setIsConnected(true);
        
        // Notify backend
        await chatApi.executeWeb3Action('connect', {
          address: accounts[0],
          chainId
        });
      }
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      throw error;
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnectWallet = async () => {
    setConnectedAddress('');
    setChainId('');
    setIsConnected(false);
    
    // Notify backend
    await chatApi.executeWeb3Action('disconnect', {});
  };

  return {
    connectedAddress,
    chainId,
    isConnected,
    isConnecting,
    connectWallet,
    disconnectWallet
  };
};