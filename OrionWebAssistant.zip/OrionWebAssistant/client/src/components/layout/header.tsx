import React from "react";
import { Settings, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export function Header() {
  return (
    <header className="glassmorphism border-b border-orion-surface/20 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-500 rounded-xl flex items-center justify-center animate-glow">
                <span className="text-white text-xl">⭐</span>
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                  Orion AI Assistant
                </h1>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-orion-text-muted">Web3 Intelligence Platform</span>
                  <Badge className="px-2 py-0.5 text-xs font-medium bg-gradient-to-r from-cyan-500 to-green-500 text-white animate-pulse-slow">
                    BETA
                  </Badge>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              size="sm"
              className="p-2 rounded-lg bg-orion-surface/50 hover:bg-orion-surface transition-colors"
            >
              <Settings className="h-4 w-4 text-orion-text-muted" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              className="p-2 rounded-lg bg-orion-surface/50 hover:bg-orion-surface transition-colors"
            >
              <Wallet className="h-4 w-4 text-orion-accent" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
