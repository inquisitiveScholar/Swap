import React from "react";
import { useQuery } from "@tanstack/react-query";
import { NewsCard } from "@/components/news/news-card";
import { Button } from "@/components/ui/button";
import { Wallet, Send, TrendingUp } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

export function Sidebar() {
  const { data: news, isLoading } = useQuery({
    queryKey: ["/api/news?limit=10"],
  });

  const handleQuickAction = (action: string) => {
    // This would typically dispatch to the chat interface
    console.log(`Quick action: ${action}`);
  };

  return (
    <aside className="w-80 glassmorphism border-r border-orion-surface/20 flex flex-col">
      <div className="p-6 border-b border-orion-surface/20">
        <h2 className="text-lg font-semibold mb-4">Web3 News</h2>
        
        <ScrollArea className="h-96">
          <div className="space-y-4">
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="glassmorphism rounded-xl p-4 animate-pulse">
                    <div className="flex items-start space-x-3">
                      <div className="w-12 h-12 bg-orion-surface rounded-lg" />
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-orion-surface rounded w-3/4" />
                        <div className="h-3 bg-orion-surface rounded w-full" />
                        <div className="h-3 bg-orion-surface rounded w-1/2" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : news && news.length > 0 ? (
              news.map((article: any) => (
                <NewsCard key={article.id} article={article} />
              ))
            ) : (
              <div className="glassmorphism rounded-xl p-4">
                <div className="flex items-start space-x-3">
                  <img 
                    src="https://images.unsplash.com/photo-1639762681485-074b7f938ba0?ixlib=rb-4.0.3&w=48&h=48&fit=crop&crop=center" 
                    alt="Ethereum" 
                    className="w-12 h-12 rounded-lg" 
                  />
                  <div className="flex-1">
                    <h3 className="font-medium text-sm group-hover:text-orion-accent transition-colors">
                      Ethereum 2.0 Staking Yields Hit New High
                    </h3>
                    <p className="text-xs text-orion-text-muted mt-1">
                      Latest developments in ETH staking rewards show promising returns for validators...
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-orion-accent">CoinDesk</span>
                      <span className="text-xs text-orion-text-muted">2h ago</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>

      <div className="p-6">
        <h3 className="text-sm font-medium text-orion-text-muted mb-3">Quick Actions</h3>
        <div className="space-y-2">
          <Button
            variant="ghost"
            className="w-full justify-start p-3 rounded-lg bg-orion-surface/30 hover:bg-orion-surface/50 transition-colors"
            onClick={() => handleQuickAction("Check Wallet Balance")}
          >
            <Wallet className="h-4 w-4 text-orion-accent mr-3" />
            <span className="text-sm">Check Wallet Balance</span>
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start p-3 rounded-lg bg-orion-surface/30 hover:bg-orion-surface/50 transition-colors"
            onClick={() => handleQuickAction("Send Transaction")}
          >
            <Send className="h-4 w-4 text-green-500 mr-3" />
            <span className="text-sm">Send Transaction</span>
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start p-3 rounded-lg bg-orion-surface/30 hover:bg-orion-surface/50 transition-colors"
            onClick={() => handleQuickAction("Market Analysis")}
          >
            <TrendingUp className="h-4 w-4 text-purple-400 mr-3" />
            <span className="text-sm">Market Analysis</span>
          </Button>
        </div>
      </div>
    </aside>
  );
}
