import React from "react";

export function TypingIndicator() {
  return (
    <div className="chat-message">
      <div className="flex items-start space-x-4">
        <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-500 rounded-full flex items-center justify-center">
          <span className="text-white">🤖</span>
        </div>
        <div className="flex-1">
          <div className="glassmorphism rounded-2xl rounded-tl-sm p-4 w-20">
            <div className="flex space-x-1">
              <div className="typing-indicator"></div>
              <div className="typing-indicator"></div>
              <div className="typing-indicator"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
