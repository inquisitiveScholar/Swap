import React, { useState } from "react";

export function SimpleChat() {
  const [inputValue, setInputValue] = useState("");
  const [messages, setMessages] = useState([
    {
      id: 1,
      content: "👋 Welcome to Orion AI Assistant! I'm your Web3 intelligence companion.\n\nI can help you with:\n• **Connect/disconnect wallet** (say 'connect my wallet')\n• **Check balances** (say 'check my balance')\n• **Send tokens** (say 'send 0.1 ETH to 0x...')\n• **Generate smart contracts** (say 'create ERC20 token')\n• **Web3 questions** and protocol information\n\nTry saying: 'connect my wallet' to get started!",
      role: "assistant",
      timestamp: new Date()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const analyzeIntent = (message) => {
    const lower = message.toLowerCase();
    
    if (lower.includes('connect wallet') || lower.includes('connect my wallet')) {
      return { action: 'connect_wallet', response: "I'll help you connect your wallet. Please click 'Connect Wallet' when the browser prompt appears. I'll detect MetaMask, WalletConnect, or other Web3 wallets." };
    }
    
    if (lower.includes('disconnect')) {
      return { action: 'disconnect_wallet', response: "I'll disconnect your wallet now. Your session will be cleared." };
    }
    
    if (lower.includes('balance') || lower.includes('check my')) {
      return { action: 'check_balance', response: "I'll check your wallet balance including ETH and all ERC-20 tokens. Make sure your wallet is connected first." };
    }
    
    if (lower.includes('send') || lower.includes('transfer')) {
      return { action: 'transfer', response: "I'll help you transfer tokens. Please specify the amount and recipient address. Example: 'send 0.1 ETH to 0x123...'" };
    }
    
    if (lower.includes('smart contract') || lower.includes('create contract') || lower.includes('erc20')) {
      return { action: 'create_contract', response: "I'll generate a smart contract for you. Please specify the type and parameters. Example: 'create ERC20 token named MyToken with 1 million supply'" };
    }
    
    if (lower.includes('network') || lower.includes('chain')) {
      return { action: 'network_info', response: "I can help you with network information and switching between Ethereum, Polygon, BSC, Arbitrum, and custom networks." };
    }
    
    return { action: 'general_query', response: "I'm here to help with Web3 and blockchain questions. Try asking about wallet connections, balance checks, token transfers, or smart contract generation." };
  };

  const handleSend = async () => {
    if (!inputValue.trim()) return;
    
    setIsLoading(true);
    
    // Add user message
    const userMessage = {
      id: Date.now(),
      content: inputValue,
      role: "user",
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    
    // Analyze intent and generate response
    const intent = analyzeIntent(inputValue);
    
    setTimeout(() => {
      const aiMessage = {
        id: Date.now() + 1,
        content: intent.response,
        role: "assistant",
        timestamp: new Date(),
        actionType: intent.action
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsLoading(false);
    }, 1000);
    
    setInputValue("");
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const connectWallet = async () => {
    if (window.ethereum) {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        const chainId = await window.ethereum.request({ method: 'eth_chainId' });
        
        const successMessage = {
          id: Date.now(),
          content: `✅ Wallet connected successfully!\n\nAddress: ${accounts[0]}\nNetwork: ${chainId}\n\nYou can now check your balance or perform transactions.`,
          role: "assistant",
          timestamp: new Date()
        };
        
        setMessages(prev => [...prev, successMessage]);
      } catch (error) {
        const errorMessage = {
          id: Date.now(),
          content: `❌ Failed to connect wallet: ${error.message}`,
          role: "assistant",
          timestamp: new Date()
        };
        setMessages(prev => [...prev, errorMessage]);
      }
    } else {
      const errorMessage = {
        id: Date.now(),
        content: "❌ No Web3 wallet detected. Please install MetaMask or another Web3 wallet.",
        role: "assistant",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    }
  };

  const suggestions = [
    "Connect my wallet",
    "Check my balance", 
    "Create ERC20 token",
    "Send 0.1 ETH"
  ];

  return (
    <main className="flex-1 flex flex-col h-screen">
      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-3xl p-4 rounded-2xl ${
                message.role === 'user' 
                  ? 'bg-purple-600 text-white ml-auto' 
                  : 'bg-gray-800 text-white'
              }`}>
                <div className="whitespace-pre-wrap">{message.content}</div>
                
                {message.actionType === 'connect_wallet' && (
                  <button
                    onClick={connectWallet}
                    className="mt-3 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                  >
                    Connect Wallet
                  </button>
                )}
                
                {message.actionType === 'create_contract' && (
                  <div className="mt-3 p-3 bg-gray-700 rounded-lg">
                    <p className="text-sm text-gray-300 mb-2">Smart Contract Generator Ready</p>
                    <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
                      Generate Contract
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-gray-800 text-white p-4 rounded-2xl">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Chat Input */}
      <div className="border-t border-gray-700 p-6 bg-slate-800">
        <div className="max-w-4xl mx-auto">
          <div className="flex space-x-4">
            <div className="flex-1 relative">
              <textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Ask about Web3, wallets, DeFi, or say 'connect my wallet'..."
                className="w-full min-h-[80px] max-h-[200px] p-4 pr-12 rounded-2xl bg-gray-800/80 border border-gray-600 focus:border-purple-400 focus:outline-none text-base text-white placeholder-gray-400 transition-colors resize-none"
                rows={3}
              />
              <button
                onClick={handleSend}
                className="absolute right-4 bottom-4 p-2 text-gray-400 hover:text-purple-400 transition-colors"
              >
                →
              </button>
            </div>
            <button 
              onClick={handleSend}
              disabled={isLoading}
              className="px-6 py-4 bg-gradient-to-r from-purple-600 to-blue-500 rounded-2xl text-white font-medium hover:shadow-lg transition-all disabled:opacity-50"
            >
              Send
            </button>
          </div>
          
          {/* Input Suggestions */}
          <div className="flex flex-wrap gap-2 mt-3">
            {suggestions.map((suggestion) => (
              <button
                key={suggestion}
                onClick={() => setInputValue(suggestion)}
                className="px-3 py-1.5 text-xs bg-gray-700 hover:bg-gray-600 rounded-full text-gray-300 transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
}