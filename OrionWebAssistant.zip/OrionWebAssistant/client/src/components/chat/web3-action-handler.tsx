import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { chatApi } from "@/lib/chat-api";
import { useWallet } from "@/components/web3/wallet-manager";

interface ActionData {
  type: string;
  data: any;
}

interface Web3ActionHandlerProps {
  actionData: ActionData;
  onActionComplete: (result: any) => void;
}

export function Web3ActionHandler({ actionData, onActionComplete }: Web3ActionHandlerProps) {
  const [isExecuting, setIsExecuting] = useState(false);
  const [result, setResult] = useState<any>(null);
  const wallet = useWallet();

  const executeAction = async () => {
    setIsExecuting(true);
    try {
      let actionResult;
      
      switch (actionData.type) {
        case 'wallet_connect':
          await wallet.connectWallet();
          actionResult = { success: true, message: 'Wallet connected successfully' };
          break;
          
        case 'wallet_disconnect':
          await wallet.disconnectWallet();
          actionResult = { success: true, message: 'Wallet disconnected successfully' };
          break;
          
        case 'balance_check':
          if (!wallet.isConnected && !actionData.data.address) {
            actionResult = { error: 'Please connect your wallet first' };
          } else {
            actionResult = await chatApi.executeWeb3Action('balance', {
              address: actionData.data.address || wallet.connectedAddress,
              chainId: wallet.chainId
            });
          }
          break;
          
        case 'transfer':
          if (!wallet.isConnected) {
            actionResult = { error: 'Please connect your wallet first' };
          } else {
            actionResult = await chatApi.executeWeb3Action('transfer', {
              ...actionData.data,
              from: wallet.connectedAddress,
              chainId: wallet.chainId
            });
          }
          break;
          
        case 'create_contract':
          actionResult = await fetch('/api/contracts/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(actionData.data)
          }).then(res => res.json());
          break;
          
        default:
          actionResult = { error: 'Unknown action type' };
      }
      
      setResult(actionResult);
      onActionComplete(actionResult);
    } catch (error) {
      const errorResult = { error: error.message };
      setResult(errorResult);
      onActionComplete(errorResult);
    } finally {
      setIsExecuting(false);
    }
  };

  const downloadContract = () => {
    if (result?.contractCode) {
      const blob = new Blob([result.contractCode], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = result.fileName || 'contract.sol';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const getActionTitle = () => {
    switch (actionData.type) {
      case 'wallet_connect': return 'Connect Wallet';
      case 'wallet_disconnect': return 'Disconnect Wallet';
      case 'balance_check': return 'Check Balance';
      case 'transfer': return 'Transfer Tokens';
      case 'create_contract': return 'Generate Smart Contract';
      case 'network_info': return 'Network Information';
      default: return 'Execute Action';
    }
  };

  return (
    <Card className="p-4 mt-4 bg-gray-800/50 border-gray-600">
      <h4 className="font-semibold text-white mb-3">{getActionTitle()}</h4>
      
      {actionData.type === 'wallet_connect' && (
        <div className="space-y-2">
          <p className="text-gray-300 text-sm">Connect your Web3 wallet to access blockchain features</p>
          <Button onClick={executeAction} disabled={isExecuting || wallet.isConnected}>
            {wallet.isConnected ? 'Wallet Connected' : isExecuting ? 'Connecting...' : 'Connect Wallet'}
          </Button>
          {wallet.isConnected && (
            <div className="mt-2 p-2 bg-green-900/30 rounded text-green-400 text-sm">
              Connected: {wallet.connectedAddress.slice(0, 6)}...{wallet.connectedAddress.slice(-4)}
            </div>
          )}
        </div>
      )}

      {actionData.type === 'wallet_disconnect' && wallet.isConnected && (
        <div className="space-y-2">
          <p className="text-gray-300 text-sm">Disconnect your current wallet session</p>
          <Button onClick={executeAction} disabled={isExecuting} variant="destructive">
            {isExecuting ? 'Disconnecting...' : 'Disconnect Wallet'}
          </Button>
        </div>
      )}

      {actionData.type === 'balance_check' && (
        <div className="space-y-2">
          <p className="text-gray-300 text-sm">
            Check balance for: {actionData.data.address || 'connected wallet'}
          </p>
          <Button onClick={executeAction} disabled={isExecuting}>
            {isExecuting ? 'Checking...' : 'Check Balance'}
          </Button>
        </div>
      )}

      {actionData.type === 'transfer' && (
        <div className="space-y-2">
          <p className="text-gray-300 text-sm">
            Transfer {actionData.data.amount || '[amount]'} to {actionData.data.to || '[recipient]'}
          </p>
          <Button onClick={executeAction} disabled={isExecuting || !wallet.isConnected}>
            {isExecuting ? 'Processing...' : 'Execute Transfer'}
          </Button>
        </div>
      )}

      {actionData.type === 'create_contract' && (
        <div className="space-y-2">
          <p className="text-gray-300 text-sm">Generate a smart contract template</p>
          <Button onClick={executeAction} disabled={isExecuting}>
            {isExecuting ? 'Generating...' : 'Generate Contract'}
          </Button>
        </div>
      )}

      {result && (
        <div className="mt-4 p-3 rounded bg-gray-900/50">
          {result.error ? (
            <div className="text-red-400 text-sm">{result.error}</div>
          ) : (
            <div className="text-green-400 text-sm">
              {result.message}
              {result.contractCode && (
                <div className="mt-2">
                  <Button onClick={downloadContract} size="sm">
                    Download Contract
                  </Button>
                </div>
              )}
              {result.nativeBalance && (
                <div className="mt-2">
                  <div>Balance: {result.nativeBalance}</div>
                  {result.tokens?.map((token: any, i: number) => (
                    <div key={i}>{token.symbol}: {token.balance}</div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </Card>
  );
}