import React from "react";
import { Web3ActionHandler } from "./web3-action-handler";

interface MessageBubbleProps {
  message: ChatMessage;
  showActions?: boolean;
}

export function MessageBubble({ message, showActions = false }: MessageBubbleProps) {
  const isUser = message.role === "user";
  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  const formatContent = (content: string) => {
    // Simple markdown-like formatting
    return content
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .split('\n').map((line, index) => (
        <span key={index}>
          <span dangerouslySetInnerHTML={{ __html: line }} />
          {index < content.split('\n').length - 1 && <br />}
        </span>
      ));
  };

  if (isUser) {
    return (
      <div className="chat-message">
        <div className="flex items-start space-x-4 justify-end">
          <div className="flex-1 flex justify-end">
            <div className="bg-gradient-to-r from-purple-600 to-blue-500 rounded-2xl rounded-tr-sm p-4 max-w-2xl">
              <p className="text-sm leading-relaxed text-white">
                {formatContent(message.content)}
              </p>
            </div>
          </div>
          <div className="w-10 h-10 bg-orion-surface rounded-full flex items-center justify-center">
            <span className="text-orion-text-muted text-sm">👤</span>
          </div>
        </div>
        <div className="flex justify-end">
          <span className="text-xs text-orion-text-muted mr-14 mt-1 block">
            You • {formatTimeAgo(message.timestamp!)}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="chat-message">
      <div className="flex items-start space-x-4">
        <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-500 rounded-full flex items-center justify-center animate-float">
          <span className="text-white">🤖</span>
        </div>
        <div className="flex-1">
          <div className="glassmorphism rounded-2xl rounded-tl-sm p-4 max-w-2xl">
            <div className="text-sm leading-relaxed">
              {formatContent(message.content)}
            </div>
            
            {/* Action Planning Interface */}
            {showActions && message.metadata && (
              <ActionPlanner metadata={message.metadata} />
            )}
          </div>
          <span className="text-xs text-orion-text-muted ml-4 mt-1 block">
            Orion AI • {formatTimeAgo(message.timestamp!)}
          </span>
        </div>
      </div>
    </div>
  );
}
