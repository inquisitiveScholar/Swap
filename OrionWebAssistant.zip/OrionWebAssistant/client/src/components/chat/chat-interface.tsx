import React, { useState, useEffect } from "react";
import { chatApi } from "@/lib/chat-api";
import { MessageBubble } from "./message-bubble";
import { TypingIndicator } from "./typing-indicator";

export function ChatInterface() {
  const [inputValue, setInputValue] = useState("");
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = async (content) => {
    setIsLoading(true);
    try {
      const response = await chatApi.sendMessage(content);
      setMessages(prev => [...prev, response.userMessage, response.assistantMessage]);
    } catch (error) {
      console.error("Failed to send message:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSend = async () => {
    if (!inputValue.trim()) return;
    
    await sendMessage(inputValue);
    setInputValue("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const insertSuggestion = (suggestion: string) => {
    setInputValue(suggestion);
  };

  const suggestions = [
    "Check my DeFi positions",
    "Latest Ethereum news", 
    "Plan token swap",
    "Gas fee optimization"
  ];

  return (
    <main className="flex-1 flex flex-col h-screen">
      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Welcome Message */}
          <MessageBubble
            message={{
              id: 0,
              content: "👋 Welcome to Orion AI Assistant! I'm your Web3 intelligence companion.\n\nI can help you with:\n• **Connect/disconnect wallet** (just say 'connect my wallet')\n• **Check balances** (say 'check my balance' or 'balance of 0x...')\n• **Send tokens** (say 'send 0.1 ETH to 0x...')\n• **Generate smart contracts** (say 'create ERC20 token named MyToken')\n• **Web3 questions** and protocol information\n\nTry saying: 'connect my wallet' to get started!",
              role: "assistant",
              timestamp: new Date(),
              metadata: null
            }}
            showActions={false}
          />

          {/* Chat Messages */}
          {messages.map((message) => (
            <MessageBubble 
              key={message.id} 
              message={message}
              showActions={message.role === "assistant"}
            />
          ))}

          {/* Typing Indicator */}
          {isLoading && <TypingIndicator />}
        </div>
      </div>

      {/* Chat Input */}
      <div className="border-t border-gray-700 p-6 bg-slate-800">
        <div className="flex space-x-4">
          <div className="flex-1 relative">
            <textarea
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Ask about Web3, DeFi, transactions, or market analysis..."
              className="w-full min-h-[80px] max-h-[200px] p-4 pr-12 rounded-2xl bg-gray-800/80 border border-gray-600 focus:border-purple-400 focus:outline-none text-base text-white placeholder-gray-400 transition-colors resize-none"
              rows={3}
            />
            <button
              onClick={handleSend}
              className="absolute right-4 bottom-4 p-2 text-gray-400 hover:text-purple-400 transition-colors"
            >
              →
            </button>
          </div>
          <button 
            onClick={handleSend}
            disabled={isLoading}
            className="px-6 py-4 bg-gradient-to-r from-purple-600 to-blue-500 rounded-2xl text-white font-medium hover:shadow-lg transition-all"
          >
            Send
          </button>
        </div>
        
        {/* Input Suggestions */}
        <div className="flex flex-wrap gap-2 mt-3">
          {suggestions.map((suggestion) => (
            <button
              key={suggestion}
              onClick={() => insertSuggestion(suggestion)}
              className="px-3 py-1.5 text-xs bg-gray-700 hover:bg-gray-600 rounded-full text-gray-300 transition-colors"
            >
              {suggestion}
            </button>
          ))}
        </div>
      </div>
    </main>
  );
}
