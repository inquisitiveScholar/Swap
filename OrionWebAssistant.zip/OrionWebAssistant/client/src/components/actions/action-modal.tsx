import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { X } from "lucide-react";

interface ActionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  actionData?: any;
}

export function ActionModal({ isOpen, onClose, onConfirm, actionData }: ActionModalProps) {
  const [isExecuting, setIsExecuting] = useState(false);

  const handleConfirm = async () => {
    setIsExecuting(true);
    try {
      await onConfirm();
      onClose();
    } catch (error) {
      console.error('Action execution failed:', error);
    } finally {
      setIsExecuting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glassmorphism border border-orion-surface/20 max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-semibold">Confirm Transaction</DialogTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-orion-text-muted">Amount:</span>
            <span className="font-medium">0.5 ETH</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-orion-text-muted">To:</span>
            <span className="font-mono text-sm">0x742d...8c4f</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-orion-text-muted">Gas Fee:</span>
            <span className="font-medium">~0.025 ETH</span>
          </div>
          <hr className="border-orion-surface/20" />
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Total:</span>
            <span className="font-semibold text-lg">0.525 ETH</span>
          </div>
        </div>

        <div className="flex space-x-3 mt-6">
          <Button 
            variant="outline"
            className="flex-1 py-3 rounded-xl border border-orion-surface/50 text-orion-text-muted hover:bg-orion-surface/20 transition-colors"
            onClick={onClose}
            disabled={isExecuting}
          >
            Cancel
          </Button>
          <Button 
            className="flex-1 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-blue-500 text-white font-medium hover:shadow-lg transition-all"
            onClick={handleConfirm}
            disabled={isExecuting}
          >
            {isExecuting ? 'Executing...' : 'Confirm'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
