import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, Cog, AlertCircle } from "lucide-react";

interface ActionStep {
  id: string;
  title: string;
  description: string;
  status: 'completed' | 'in_progress' | 'pending' | 'failed';
  details?: string[];
}

interface ActionPlannerProps {
  metadata: any;
}

export function ActionPlanner({ metadata }: ActionPlannerProps) {
  const [steps] = useState<ActionStep[]>([
    {
      id: 'step1',
      title: 'Step 1: Wallet Balance Check',
      description: 'Check current wallet balance and token holdings',
      status: 'completed',
      details: [
        'Connected to wallet: 0x742d...8c4f',
        'Current ETH balance: 2.34 ETH',
        'USD value: ~$3,756.80'
      ]
    },
    {
      id: 'step2', 
      title: 'Step 2: Transaction Planning',
      description: 'Calculate gas fees and validate transaction parameters',
      status: 'in_progress',
      details: [
        'Amount: 0.5 ETH',
        'Estimated gas: ~21,000 units',
        'Gas price: 25 gwei (Normal)',
        'Total cost: ~0.525 ETH'
      ]
    },
    {
      id: 'step3',
      title: 'Step 3: Execute Transaction', 
      description: 'Finalize and broadcast transaction to network',
      status: 'pending',
      details: [
        'Waiting for recipient address confirmation'
      ]
    }
  ]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'in_progress':
        return <Cog className="h-4 w-4 text-purple-400 animate-spin" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-orion-text-muted" />;
      case 'failed':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-orion-text-muted" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      completed: 'bg-green-500/20 text-green-500',
      in_progress: 'bg-purple-400/20 text-purple-400', 
      pending: 'bg-orion-text-muted/20 text-orion-text-muted',
      failed: 'bg-red-500/20 text-red-500'
    };

    const labels = {
      completed: 'Completed',
      in_progress: 'In Progress',
      pending: 'Pending', 
      failed: 'Failed'
    };

    return (
      <Badge className={`text-xs px-2 py-1 rounded-full ${variants[status as keyof typeof variants]}`}>
        {labels[status as keyof typeof labels]}
      </Badge>
    );
  };

  const getBorderColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'border-green-500/30';
      case 'in_progress':
        return 'border-purple-400/30';
      case 'pending':
        return 'border-orion-text-muted/30';
      case 'failed':
        return 'border-red-500/30';
      default:
        return 'border-orion-text-muted/30';
    }
  };

  return (
    <div className="space-y-3 mt-4">
      {steps.map((step) => (
        <div key={step.id} className={`glassmorphism rounded-lg p-3 border ${getBorderColor(step.status)} ${step.status === 'pending' ? 'opacity-60' : ''}`}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium flex items-center space-x-2">
              {getStatusIcon(step.status)}
              <span className={step.status === 'completed' ? 'text-green-500' : step.status === 'in_progress' ? 'text-purple-400' : 'text-orion-text-muted'}>
                {step.title}
              </span>
            </span>
            {getStatusBadge(step.status)}
          </div>
          {step.details && (
            <div className="text-xs text-orion-text-muted space-y-1">
              {step.details.map((detail, index) => (
                <div key={index}>• {detail}</div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
