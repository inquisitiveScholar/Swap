import React from "react";

interface NewsArticle {
  id: number;
  title: string;
  excerpt: string;
  source: string;
  publishedAt: string;
  imageUrl?: string;
  url?: string;
}

interface NewsCardProps {
  article: NewsArticle;
}

export function NewsCard({ article }: NewsCardProps) {
  const handleClick = () => {
    if (article.url) {
      window.open(article.url, '_blank');
    }
  };

  const formatTimeAgo = (date: string) => {
    const now = new Date();
    const publishedDate = new Date(date);
    const diffInHours = Math.floor((now.getTime() - publishedDate.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  return (
    <div 
      className="glassmorphism rounded-xl p-4 hover:bg-orion-surface/20 transition-all cursor-pointer group"
      onClick={handleClick}
    >
      <div className="flex items-start space-x-3">
        <img 
          src={article.imageUrl || "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?ixlib=rb-4.0.3&w=48&h=48&fit=crop&crop=center"} 
          alt={article.title}
          className="w-12 h-12 rounded-lg object-cover"
        />
        <div className="flex-1">
          <h3 className="font-medium text-sm group-hover:text-orion-accent transition-colors line-clamp-2">
            {article.title}
          </h3>
          <p className="text-xs text-orion-text-muted mt-1 line-clamp-2">
            {article.excerpt}
          </p>
          <div className="flex items-center justify-between mt-2">
            <span className="text-xs text-orion-accent">{article.source}</span>
            <span className="text-xs text-orion-text-muted">
              {formatTimeAgo(article.publishedAt)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
