import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { chatApi } from "@/lib/chat-api";
import type { ChatMessage } from "@shared/schema";

export function useChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const queryClient = useQueryClient();

  const { data: initialMessages } = useQuery({
    queryKey: ["/api/chat/messages"],
    queryFn: () => chatApi.getMessages(),
  });

  const sendMessageMutation = useMutation({
    mutationFn: (content: string) => chatApi.sendMessage(content),
    onSuccess: (response) => {
      setMessages(prev => [...prev, response.userMessage, response.assistantMessage]);
      queryClient.invalidateQueries({ queryKey: ["/api/chat/messages"] });
    },
  });

  useEffect(() => {
    if (initialMessages) {
      setMessages(initialMessages);
    }
  }, [initialMessages]);

  const sendMessage = async (content: string) => {
    return sendMessageMutation.mutateAsync(content);
  };

  return {
    messages,
    sendMessage,
    isLoading: sendMessageMutation.isPending,
    error: sendMessageMutation.error,
  };
}
