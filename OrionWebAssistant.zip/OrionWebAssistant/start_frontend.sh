#!/bin/bash
# Start only the React frontend with Vite
cd client && npm run dev