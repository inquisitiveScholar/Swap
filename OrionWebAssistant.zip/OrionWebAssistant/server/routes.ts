import express from "express";
import { storage } from "./storage";
import OpenAI from "openai";

const router = express.Router();

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Web3 Intent Analysis
function analyzeIntent(message: string) {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('connect wallet') || lowerMessage.includes('connect my wallet')) {
    return { action: 'connect_wallet', params: {} };
  }
  
  if (lowerMessage.includes('disconnect wallet') || lowerMessage.includes('disconnect my wallet')) {
    return { action: 'disconnect_wallet', params: {} };
  }
  
  if (lowerMessage.includes('balance') || lowerMessage.includes('how much') || lowerMessage.includes('check my')) {
    const addressMatch = message.match(/0x[a-fA-F0-9]{40}/);
    return { 
      action: 'check_balance', 
      params: { 
        address: addressMatch ? addressMatch[0] : null,
        isConnectedWallet: !addressMatch
      }
    };
  }
  
  if (lowerMessage.includes('send') || lowerMessage.includes('transfer')) {
    const amountMatch = message.match(/(\d+(?:\.\d+)?)/);
    const addressMatch = message.match(/0x[a-fA-F0-9]{40}/);
    return { 
      action: 'transfer', 
      params: { 
        amount: amountMatch ? amountMatch[1] : null,
        to: addressMatch ? addressMatch[0] : null
      }
    };
  }
  
  if (lowerMessage.includes('smart contract') || lowerMessage.includes('create contract') || lowerMessage.includes('erc20')) {
    return { action: 'create_contract', params: { type: 'erc20' } };
  }
  
  if (lowerMessage.includes('network') || lowerMessage.includes('chain')) {
    return { action: 'network_info', params: {} };
  }
  
  return { action: 'general_query', params: {} };
}

// Generate Web3 responses
async function generateWeb3Response(message: string, intent: any) {
  const systemPrompt = `You are Orion AI Assistant, a specialized Web3 AI that helps users with blockchain operations, DeFi, smart contracts, and cryptocurrency. 

Available actions:
- Wallet connection/disconnection
- Balance checks (native tokens and ERC-20)
- Token transfers and transactions
- Smart contract creation
- Network management
- Web3 knowledge base queries

Always respond in a helpful, professional tone focused on Web3 and blockchain technology. When users request actions, provide clear step-by-step guidance.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      max_tokens: 500
    });

    return response.choices[0].message.content;
  } catch (error) {
    return "I'm having trouble accessing the AI service. Please ensure your OpenAI API key is configured correctly.";
  }
}

// Chat endpoints
router.get("/api/messages", async (req, res) => {
  try {
    const messages = await storage.getMessages();
    res.json(messages);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch messages" });
  }
});

router.post("/api/messages", async (req, res) => {
  try {
    const { content } = req.body;
    
    // Analyze user intent
    const intent = analyzeIntent(content);
    
    // Create user message
    const userMessage = await storage.createMessage({
      content,
      role: "user",
      metadata: { intent }
    });
    
    // Generate AI response based on intent
    let aiResponse = "";
    let actionData = null;
    
    switch (intent.action) {
      case 'connect_wallet':
        aiResponse = "I'll help you connect your wallet. Please click 'Connect Wallet' when the browser prompt appears. I'll detect your wallet provider (MetaMask, WalletConnect, etc.) and establish the connection.";
        actionData = { type: 'wallet_connect', data: {} };
        break;
        
      case 'disconnect_wallet':
        aiResponse = "I'll disconnect your wallet now. Your session will be cleared and you'll need to reconnect to perform blockchain operations.";
        actionData = { type: 'wallet_disconnect', data: {} };
        break;
        
      case 'check_balance':
        const address = intent.params.address || "connected";
        aiResponse = `I'll check the balance for ${address === "connected" ? "your connected wallet" : address}. This includes both native currency (ETH, MATIC, etc.) and any ERC-20 tokens you hold.`;
        actionData = { 
          type: 'balance_check', 
          data: { 
            address: intent.params.address,
            isConnectedWallet: intent.params.isConnectedWallet 
          }
        };
        break;
        
      case 'transfer':
        aiResponse = `I'll help you transfer ${intent.params.amount || "[amount]"} to ${intent.params.to || "[recipient address]"}. Please confirm the transaction details and gas fees before proceeding.`;
        actionData = { 
          type: 'transfer', 
          data: { 
            amount: intent.params.amount,
            to: intent.params.to 
          }
        };
        break;
        
      case 'create_contract':
        aiResponse = "I'll create a smart contract for you. Please specify the contract type (ERC-20 token, NFT collection, etc.) and provide the required parameters like name, symbol, and supply.";
        actionData = { type: 'create_contract', data: { type: intent.params.type } };
        break;
        
      case 'network_info':
        aiResponse = "I'll show you the current network information and available networks. You can switch between Ethereum Mainnet, Polygon, BSC, Arbitrum, and custom networks.";
        actionData = { type: 'network_info', data: {} };
        break;
        
      default:
        aiResponse = await generateWeb3Response(content, intent);
        break;
    }
    
    // Create AI message
    const aiMessage = await storage.createMessage({
      content: aiResponse,
      role: "assistant",
      metadata: { intent, actionData }
    });
    
    res.json({
      userMessage,
      assistantMessage: aiMessage,
      intent: intent.action,
      actionData
    });
    
  } catch (error) {
    console.error("Error processing message:", error);
    res.status(500).json({ error: "Failed to process message" });
  }
});

// Web3 action endpoints
router.post("/api/web3/connect", async (req, res) => {
  try {
    const { address, chainId } = req.body;
    // Store wallet connection state
    res.json({ 
      success: true, 
      address, 
      chainId,
      message: "Wallet connected successfully" 
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to connect wallet" });
  }
});

router.post("/api/web3/disconnect", async (req, res) => {
  try {
    res.json({ 
      success: true,
      message: "Wallet disconnected successfully" 
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to disconnect wallet" });
  }
});

router.post("/api/web3/balance", async (req, res) => {
  try {
    const { address, chainId } = req.body;
    
    // Ensure we're on The Orion Network (1001)
    if (chainId !== '0x3E9') {
      return res.status(400).json({ 
        error: "Please switch to The Orion Network (Chain ID: 1001)" 
      });
    }
    
    // This would integrate with The Orion Network RPC
    res.json({
      address,
      chainId,
      network: "THE ORION Network",
      nativeBalance: "2.5 ORIN",
      currency: "ORIN",
      rpc: "testnet-rpc.theorionscan.com"
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch balance from The Orion Network" });
  }
});

router.post("/api/web3/transfer", async (req, res) => {
  try {
    const { to, amount, chainId } = req.body;
    
    // Ensure we're on The Orion Network (1001)
    if (chainId !== '0x3E9') {
      return res.status(400).json({ 
        error: "Transfers only supported on The Orion Network (Chain ID: 1001)" 
      });
    }
    
    // This would execute the actual transfer on The Orion Network
    res.json({
      success: true,
      txHash: "0x" + Math.random().toString(16).substr(2, 64),
      network: "THE ORION Network",
      message: `Transfer of ${amount} ORIN to ${to} initiated on The Orion Network`
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to execute transfer on The Orion Network" });
  }
});

router.post("/api/contracts/generate", async (req, res) => {
  try {
    const { type, name, symbol, supply } = req.body;
    
    if (type === 'erc20') {
      const contractCode = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address recipient, uint256 amount) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 amount) external returns (bool);
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}

contract ${name || 'MyToken'} is IERC20 {
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    
    uint256 private _totalSupply;
    string private _name;
    string private _symbol;
    uint8 private _decimals;
    
    constructor() {
        _name = "${name || 'MyToken'}";
        _symbol = "${symbol || 'MTK'}";
        _decimals = 18;
        _totalSupply = ${supply || '1000000'} * 10**_decimals;
        _balances[msg.sender] = _totalSupply;
        emit Transfer(address(0), msg.sender, _totalSupply);
    }
    
    function name() public view returns (string memory) {
        return _name;
    }
    
    function symbol() public view returns (string memory) {
        return _symbol;
    }
    
    function decimals() public view returns (uint8) {
        return _decimals;
    }
    
    function totalSupply() public view override returns (uint256) {
        return _totalSupply;
    }
    
    function balanceOf(address account) public view override returns (uint256) {
        return _balances[account];
    }
    
    function transfer(address recipient, uint256 amount) public override returns (bool) {
        require(recipient != address(0), "ERC20: transfer to the zero address");
        require(_balances[msg.sender] >= amount, "ERC20: transfer amount exceeds balance");
        
        _balances[msg.sender] -= amount;
        _balances[recipient] += amount;
        emit Transfer(msg.sender, recipient, amount);
        return true;
    }
    
    function allowance(address owner, address spender) public view override returns (uint256) {
        return _allowances[owner][spender];
    }
    
    function approve(address spender, uint256 amount) public override returns (bool) {
        require(spender != address(0), "ERC20: approve to the zero address");
        
        _allowances[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }
    
    function transferFrom(address sender, address recipient, uint256 amount) public override returns (bool) {
        require(sender != address(0), "ERC20: transfer from the zero address");
        require(recipient != address(0), "ERC20: transfer to the zero address");
        require(_balances[sender] >= amount, "ERC20: transfer amount exceeds balance");
        require(_allowances[sender][msg.sender] >= amount, "ERC20: transfer amount exceeds allowance");
        
        _balances[sender] -= amount;
        _balances[recipient] += amount;
        _allowances[sender][msg.sender] -= amount;
        
        emit Transfer(sender, recipient, amount);
        return true;
    }
}`;

      res.json({
        success: true,
        contractCode,
        fileName: `${name || 'MyToken'}.sol`,
        type: 'erc20'
      });
    } else {
      res.status(400).json({ error: "Unsupported contract type" });
    }
  } catch (error) {
    res.status(500).json({ error: "Failed to generate contract" });
  }
});

export default router;