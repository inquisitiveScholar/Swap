import dotenv from 'dotenv';
import express from "express";
import { createServer } from "http";
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { storage } from './storage.js';
import './routes.js';

// Load environment variables from .env file
dotenv.config();

// Verify environment loading
console.log('Environment loaded - PORT:', process.env.PORT);
console.log('Environment loaded - OpenAI key present:', !!process.env.OPENAI_API_KEY);

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Simple types
interface Web3Action {
  type: string;
  address?: string;
  amount?: string;
  recipient?: string;
  params?: any;
  network?: string;
}

interface ChatResponse {
  userMessage: { id: number; content: string; role: string };
  assistantMessage: { id: number; content: string; role: string };
  actions: Web3Action[];
}

interface GeneratedContract {
  name: string;
  type: string;
  code: string;
  description: string;
}

async function startServer() {
  const app = express();
  
  // CORS middleware
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
    } else {
      next();
    }
  });
  
  // JSON parsing middleware
  app.use(express.json());
  
  // Web3 AI chat endpoint
  app.post('/api/chat', async (req, res) => {
    try {
      const { message } = req.body;
      const response = await processWeb3Message(message);
      res.json(response);
    } catch (error) {
      res.status(500).json({ error: 'Failed to process message' });
    }
  });

  // Serve favicon
  app.get('/favicon.svg', (req, res) => {
    res.setHeader('Content-Type', 'image/svg+xml');
    res.sendFile(join(__dirname, '../favicon.svg'));
  });

  // Serve the main app
  app.get('/', (req, res) => {
    res.send(getWebApp());
  });

  const httpServer = createServer(app);
  const PORT = process.env.PORT || 5000;
  
  httpServer.listen(Number(PORT), "0.0.0.0", () => {
    console.log("🚀 Starting Orion AI Assistant...");
    console.log(`✅ Orion Web3 AI running on http://localhost:${PORT}`);
    console.log("🔗 Orion AI Assistant ready for wallet connections");
  });
}

async function processWeb3Message(message: string): Promise<ChatResponse> {
  // First, use OpenAI to analyze intent and provide intelligent response
  const aiAnalysis = await getAIIntentAnalysis(message);
  
  let response: ChatResponse = {
    userMessage: { id: Date.now(), content: message, role: 'user' },
    assistantMessage: { id: Date.now() + 1, content: aiAnalysis.response, role: 'assistant' },
    actions: []
  };

  // Add appropriate actions based on AI-detected intent
  if (aiAnalysis.actions && aiAnalysis.actions.length > 0) {
    response.actions = aiAnalysis.actions;
  }
  
  return response;
}

async function getAIIntentAnalysis(message: string): Promise<{response: string, actions: Web3Action[]}> {
  console.log('OpenAI API Key available:', !!process.env.OPENAI_API_KEY);
  console.log('OpenAI API Key length:', process.env.OPENAI_API_KEY ? process.env.OPENAI_API_KEY.length : 0);
  console.log('OpenAI API Key starts with sk-:', process.env.OPENAI_API_KEY ? process.env.OPENAI_API_KEY.startsWith('sk-') : false);
  
  if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === 'sk-your-openai-key-here') {
    console.log('Using fallback responses - no valid OpenAI key found');
    // Fallback to basic pattern matching if no OpenAI key
    const basicIntent = analyzeWeb3Intent(message);
    return getBasicResponse(basicIntent, message);
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `You're Orion - Web3 native AI assistant, not a generic assistant. Talk like you've been in crypto since 2017.

PERSONALITY: Real Web3 speak - "GM anon", "WAGMI", "diamond hands", "ape into", "based", "bullish/bearish", "to the moon", "HODL", "degen plays", "fren". No corporate AI language.

KNOWLEDGE: DeFi protocols, yield strategies, L2s, smart contracts, tokenomics, NFT utilities, cross-chain bridges, MEV, governance tokens, staking rewards, liquidity mining.

RESPONSE STYLE:
- Direct, practical answers (like an experienced trader/dev would give)
- Use actual numbers: "gas costs ~20 gwei", "APY around 15%", "slippage set to 0.5%"
- Reference real protocols: "Try Uniswap V3 for better capital efficiency"
- Security first: "Always check contract audits, never connect to sus sites"

NON-WEB3 TOPICS: "Anon, I'm here for the decentralized revolution - ask me about yields, governance, or which chain is pumping!"

The Orion Network (Chain ID: 1001, RPC: testnet-rpc.theorionscan.com, Currency: ORIN) is your home base.

INTENT DETECTION:
1. connect_wallet: wallet connection requests
2. disconnect_wallet: wallet disconnection
3. check_balance: balance inquiries  
4. transfer: token transfers
5. create_contract: smart contract creation
6. network_switch: blockchain network switching
7. deploy_contract: smart contract deployment
8. web3_query: Web3-related questions ONLY

JSON Response Format:
{
  "intent": "detected_intent",
  "response": "web3_native_explanation_with_slang",
  "actions": [{"type": "action_type", "params": {...}}]
}`
          },
          {
            role: 'user',
            content: message
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 800,
        temperature: 0.3
      })
    });

    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(`OpenAI API error: ${data.error?.message || 'Unknown error'}`);
    }

    const aiResult = JSON.parse(data.choices[0].message.content);
    
    // Convert AI response to our action format
    const actions: Web3Action[] = [];
    
    switch (aiResult.intent) {
      case 'connect_wallet':
        actions.push({ type: 'connect_wallet' });
        break;
      case 'disconnect_wallet':
        actions.push({ type: 'disconnect_wallet' });
        break;
      case 'check_balance':
        const addressMatch = message.match(/0x[a-fA-F0-9]{40}/);
        actions.push({ type: 'check_balance', address: addressMatch ? addressMatch[0] : undefined });
        break;
      case 'transfer':
        const amountMatch = message.match(/(\d+(?:\.\d+)?)/);
        // Look for wallet address in various formats
        const recipientMatch = message.match(/(?:to\s+)?(0x[a-fA-F0-9]{40})/i) || 
                              message.match(/(0x[a-fA-F0-9]{40})/i);
        
        // Extract amount and recipient
        const amount = amountMatch ? amountMatch[0] : null;
        const recipient = recipientMatch ? recipientMatch[1] : null;
        
        // If missing recipient, ask for it
        if (!recipient) {
          return {
            response: "To send ORIN, I need the recipient's wallet address. Please provide the address you want to send to.\n\nExample: \"send 1 ORIN to 0x742d35Cc6634C0532925a3b8D42d0ca3C1234567\"",
            actions: []
          };
        }
        
        actions.push({ 
          type: 'transfer', 
          amount: amount || '1', // Default to 1 ORIN
          recipient: recipient 
        });
        break;
      case 'create_contract':
        const contractSpecs = await analyzeContractRequirements(message);
        actions.push({ 
          type: 'create_contract', 
          params: contractSpecs
        });
        break;
      case 'network_switch':
        // Only The Orion Network is supported
        actions.push({ type: 'network_switch', network: 'orion' });
        break;
      case 'deploy_contract':
        // Check if user is asking about deployment (intent) vs confirming deployment (action)
        if (message.toLowerCase().includes('deploy') && !message.toLowerCase().includes('confirm') && !message.toLowerCase().includes('yes') && !message.toLowerCase().includes('proceed')) {
          return {
            response: "I can deploy your generated smart contract to The Orion Network. This will compile the contract and submit it as a blockchain transaction. Would you like me to proceed with the deployment?",
            actions: []
          };
        } else {
          actions.push({ type: 'deploy_contract', params: {} });
        }
        break;
    }

    return {
      response: aiResult.response,
      actions: actions
    };

  } catch (error: any) {
    console.error('AI Analysis error:', error.message || error);
    console.log('Falling back to basic responses due to API error');
    // Fallback to basic pattern matching
    const basicIntent = analyzeWeb3Intent(message);
    return getBasicResponse(basicIntent, message);
  }
}

function getBasicResponse(intent: any, message: string): {response: string, actions: Web3Action[]} {
  const actions: Web3Action[] = [];
  let response = "";

  switch (intent.action) {
    case 'connect_wallet':
      response = "Ready to connect your wallet to The Orion Network. Your wallet will request permission - approve it to start trading and interacting with dApps.";
      actions.push({ type: 'connect_wallet' });
      break;
    case 'disconnect_wallet':
      response = "Disconnecting your wallet from The Orion Network. You'll need to reconnect for future transactions.";
      actions.push({ type: 'disconnect_wallet' });
      break;
    case 'check_balance':
      response = `Checking your ORIN balance and token holdings on The Orion Network${intent.address ? ' for address ' + intent.address.slice(0,6) + '...' + intent.address.slice(-4) : ''}.`;
      actions.push({ type: 'check_balance', address: intent.address });
      break;
    case 'transfer':
      response = `Setting up transfer of ${intent.amount || '1'} ORIN${intent.recipient ? ' to ' + intent.recipient.slice(0,6) + '...' + intent.recipient.slice(-4) : ''}. Gas fees will be calculated automatically.`;
      actions.push({ type: 'transfer', amount: intent.amount, recipient: intent.recipient });
      break;
    case 'create_contract':
      response = `Generating ${intent.contractType || 'smart contract'} for The Orion Network. This will include standard functions and security features.`;
      actions.push({ type: 'create_contract', params: intent });
      break;
    case 'network_switch':
      response = "The Orion Network is the only supported network. Your wallet will automatically switch to Chain ID 1001 (testnet-rpc.theorionscan.com).";
      actions.push({ type: 'network_switch', network: 'orion' });
      break;
    default:
      // Web3 knowledge responses without requiring API key
      if (message.toLowerCase().includes('gas') || message.toLowerCase().includes('fee')) {
        response = "Gas fees on The Orion Network are typically low. Current gas price is around 1 gwei. Complex smart contract operations may require 200K-2M gas units.";
      } else if (message.toLowerCase().includes('defi') || message.toLowerCase().includes('yield')) {
        response = "DeFi on The Orion Network offers lending protocols, DEXs, and yield farming. Always verify smart contract audits before depositing funds.";
      } else if (message.toLowerCase().includes('nft') || message.toLowerCase().includes('erc721')) {
        response = "NFTs follow the ERC-721 standard. You can mint, trade, and transfer NFTs on The Orion Network through compatible marketplaces.";
      } else if (message.toLowerCase().includes('security') || message.toLowerCase().includes('hack')) {
        response = "Web3 security basics: Never share private keys, verify contract addresses, use hardware wallets for large amounts, and be cautious of phishing sites.";
      } else if (message.toLowerCase().includes('wallet') || message.toLowerCase().includes('metamask')) {
        response = "MetaMask is the most popular Web3 wallet. Add The Orion Network manually: RPC URL: testnet-rpc.theorionscan.com, Chain ID: 1001, Symbol: ORIN.";
      } else {
        response = "I'm your Web3 assistant for The Orion Network. I can help with wallet connections, token transfers, balance checks, and smart contract generation.";
      }
  }

  return { response, actions };
}

function analyzeWeb3Intent(message: string) {
  const lower = message.toLowerCase();
  
  if (lower.includes('connect') && (lower.includes('wallet') || lower.includes('metamask'))) {
    return { action: 'connect_wallet' };
  }
  
  if (lower.includes('disconnect') && lower.includes('wallet')) {
    return { action: 'disconnect_wallet' };
  }
  
  if (lower.includes('balance') || lower.includes('check my') || lower.includes('how much')) {
    const addressMatch = message.match(/0x[a-fA-F0-9]{40}/);
    return { action: 'check_balance', address: addressMatch ? addressMatch[0] : null };
  }
  
  if (lower.includes('send') || lower.includes('transfer')) {
    const amountMatch = message.match(/(\d+(?:\.\d+)?)\s*(eth|matic|bnb|usdc|dai|\w+)?/i);
    const addressMatch = message.match(/to\s+(0x[a-fA-F0-9]{40})/i);
    return { 
      action: 'transfer', 
      amount: amountMatch ? amountMatch[0] : null,
      recipient: addressMatch ? addressMatch[1] : null 
    };
  }
  
  if (lower.includes('contract') || lower.includes('erc20') || lower.includes('create')) {
    const nameMatch = message.match(/named?\s+(\w+)/i);
    const supplyMatch = message.match(/(\d+(?:\.\d+)?)\s*(million|k|thousand)?/i);
    return { 
      action: 'create_contract',
      contractType: 'ERC20',
      name: nameMatch ? nameMatch[1] : 'MyToken',
      symbol: nameMatch ? nameMatch[1].slice(0, 4).toUpperCase() : 'MTK',
      supply: supplyMatch ? supplyMatch[1] + (supplyMatch[2] || '') : '1000000'
    };
  }
  
  if (lower.includes('network') || lower.includes('chain') || lower.includes('switch')) {
    const networkMatch = message.match(/(ethereum|polygon|matic|bsc|binance|arbitrum|avalanche)/i);
    return { action: 'network_switch', network: networkMatch ? networkMatch[1] : null };
  }
  
  if (lower.includes('deploy') && (lower.includes('contract') || lower.includes('token'))) {
    return { action: 'deploy_contract' };
  }
  
  return { action: 'general_query' };
}

async function analyzeContractRequirements(message: string): Promise<any> {
  if (!process.env.OPENAI_API_KEY) {
    // Fallback to basic analysis
    const nameMatch = message.match(/named?\s+(\w+)/i);
    const supplyMatch = message.match(/(\d+(?:\.\d+)?)\s*(million|k|thousand)?/i);
    const typeMatch = message.match(/(ERC20|ERC721|NFT|staking|multisig)/i);
    
    return {
      type: typeMatch ? typeMatch[1].toLowerCase() : 'ERC20',
      name: nameMatch ? nameMatch[1] : 'MyToken',
      symbol: nameMatch ? nameMatch[1].slice(0, 4).toUpperCase() : 'MTK',
      supply: supplyMatch ? supplyMatch[1] + (supplyMatch[2] || '') : '1000000',
      features: []
    };
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `You are a smart contract specification analyzer. Extract contract requirements from user messages and return detailed specifications.

Analyze the user's contract requirements and return a JSON object with these fields:
{
  "type": "ERC20|ERC721|NFT|Staking|MultiSig|Custom",
  "name": "contract_name",
  "symbol": "token_symbol",
  "supply": "token_supply_number",
  "decimals": "decimal_places",
  "features": ["mintable", "burnable", "pausable", "ownable", "capped"],
  "maxSupply": "nft_max_supply",
  "mintPrice": "nft_mint_price",
  "rewardRate": "staking_reward_rate",
  "numConfirmations": "multisig_confirmations",
  "description": "detailed_contract_description",
  "customFunctions": ["function1", "function2"],
  "useEvents": true/false,
  "useMapping": true/false,
  "useArray": true/false,
  "usePayable": true/false
}

Only include relevant fields based on contract type. Be precise with extracting numbers, names, and features from the user's requirements.`
          },
          {
            role: 'user',
            content: message
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 800,
        temperature: 0.1
      })
    });

    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(`OpenAI API error: ${data.error?.message || 'Unknown error'}`);
    }

    const content = data.choices[0].message.content;
    try {
      return JSON.parse(content);
    } catch (parseError) {
      // If JSON parsing fails, try to extract valid JSON from the response
      const jsonMatch = content.match(/\{.*\}/s);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      throw parseError;
    }
  } catch (error: any) {
    console.error('Contract analysis error:', error);
    // Fallback to basic analysis
    const nameMatch = message.match(/named?\s+(\w+)/i);
    const supplyMatch = message.match(/(\d+(?:\.\d+)?)\s*(million|k|thousand)?/i);
    const typeMatch = message.match(/(ERC20|ERC721|NFT|staking|multisig)/i);
    
    return {
      type: typeMatch ? typeMatch[1].toLowerCase() : 'ERC20',
      name: nameMatch ? nameMatch[1] : 'MyToken',
      symbol: nameMatch ? nameMatch[1].slice(0, 4).toUpperCase() : 'MTK',
      supply: supplyMatch ? supplyMatch[1] + (supplyMatch[2] || '') : '1000000',
      features: []
    };
  }
}

async function getOpenAIResponse(message: string): Promise<string> {
  if (!process.env.OPENAI_API_KEY) {
    return "OpenAI integration requires an API key. Please provide your OpenAI API key to enable intelligent responses.";
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: `You are Orion, a Web3-native AI that lives and breathes blockchain technology. STRICTLY Web3 focused - redirect any off-topic questions.

🔒 BOUNDARY ENFORCEMENT: Only discuss blockchain, crypto, DeFi, NFTs, Web3 development, and related topics.

PERSONALITY: Use authentic Web3 culture and slang:
- "GM anon!" (good morning)
- "WAGMI" (we're all gonna make it) 
- "Diamond hands", "paper hands"
- "To the moon", "HODL"
- "Ape into", "degen plays"
- "Based", "bullish", "bearish"
- Address users as "anon", "fren", or "degen"

Web3 KNOWLEDGE:
- DeFi protocols and yield strategies
- Layer 2 scaling solutions  
- Smart contract development
- Tokenomics and governance
- NFT ecosystems and utilities
- Cross-chain bridging
- Security best practices

For NON-WEB3 topics, redirect: "Anon, that's not my domain! I'm here for the decentralized revolution. Ask me about DeFi yields, NFT alpha, or which chain is pumping! 🚀"`
          },
          {
            role: 'user',
            content: message
          }
        ],
        max_tokens: 500,
        temperature: 0.7
      })
    });

    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(`OpenAI API error: ${data.error?.message || 'Unknown error'}`);
    }

    return data.choices[0].message.content;
  } catch (error) {
    console.error('OpenAI API error:', error);
    return `I encountered an error accessing the AI service. Please check your OpenAI API key and try again. Error: ${error.message}`;
  }
}

function getWebApp(): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orion AI Assistant - Web3 Intelligence Platform</title>
    <link rel="icon" type="image/svg+xml" href="/favicon.svg">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap');
        
        body { 
            font-family: 'Space Grotesk', sans-serif; 
            background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 50%, #1f1f1f 100%);
        }
        
        .cyber-glow {
            box-shadow: 0 0 20px rgba(196, 181, 153, 0.2);
            border: 1px solid rgba(196, 181, 153, 0.3);
        }
        
        .pulse-dot {
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 0.4; }
            50% { opacity: 1; }
        }
        
        .thinking-animation {
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        
        .thinking-dot {
            width: 4px;
            height: 4px;
            background: #c4b599;
            border-radius: 50%;
            animation: thinking 1.5s infinite;
        }
        
        .thinking-dot:nth-child(2) { animation-delay: 0.2s; }
        .thinking-dot:nth-child(3) { animation-delay: 0.4s; }
        
        @keyframes thinking {
            0%, 20%, 80%, 100% { transform: scale(1); opacity: 0.5; }
            50% { transform: scale(1.2); opacity: 1; }
        }
        
        .robot-thinking {
            animation: robotPulse 2s infinite ease-in-out;
        }
        
        @keyframes robotPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        .robot-container {
            position: relative;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .robot-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        
        .robot-thinking-bubble {
            position: absolute;
            top: -8px;
            right: -8px;
            width: 16px;
            height: 16px;
            background: rgba(251, 191, 36, 0.2);
            border-radius: 50%;
            animation: bubble 1.5s infinite;
        }
        
        @keyframes bubble {
            0%, 100% { transform: scale(0.8); opacity: 0.3; }
            50% { transform: scale(1.2); opacity: 0.8; }
        }
        .thinking-dot:nth-child(3) { animation-delay: 0.4s; }
        
        @keyframes thinking {
            0%, 60%, 100% { transform: scale(1); opacity: 0.5; }
            30% { transform: scale(1.3); opacity: 1; }
        }
        
        .matrix-bg {
            background: linear-gradient(45deg, transparent 48%, rgba(196, 181, 153, 0.05) 50%, transparent 52%);
            background-size: 20px 20px;
        }
        
        .gradient-text {
            background: linear-gradient(45deg, #c4b599, #d4c5a9, #b8a082);
            background-size: 300% 300%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: gradientShift 3s ease infinite;
        }
        
        @keyframes gradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
    </style>
</head>
<body class="bg-slate-900 text-white min-h-screen matrix-bg">
    <header class="bg-black/60 backdrop-blur-lg border-b border-amber-600/20 p-6 cyber-glow">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 rounded-full bg-gradient-to-r from-amber-600 to-amber-500 flex items-center justify-center">
                <span class="text-xl font-bold text-black">⚡</span>
            </div>
            <div>
                <h1 class="text-3xl font-bold gradient-text">
                    ORION.AI
                </h1>
                <p class="text-amber-400 text-sm font-medium tracking-wide">
                    WEB3 INTELLIGENCE NETWORK
                </p>
            </div>
            <div class="ml-auto flex items-center gap-2">
                <div class="pulse-dot w-3 h-3 bg-amber-400 rounded-full"></div>
                <span class="text-amber-400 text-xs font-mono">MAINNET ACTIVE</span>
            </div>
        </div>
    </header>

    <main class="flex flex-col h-screen">
        <div id="chat-container" class="flex-1 overflow-auto p-6">
            <div class="max-w-4xl mx-auto space-y-6" id="messages">
                <div class="flex justify-start">
                    <div class="max-w-3xl p-6 rounded-2xl bg-gradient-to-r from-amber-900/20 to-amber-800/20 backdrop-blur-lg border border-amber-500/20 cyber-glow">
                        <div class="whitespace-pre-wrap text-gray-100">
                            <div class="flex items-center gap-2 mb-3">
                                <span class="text-2xl">🤖</span>
                                <span class="font-mono text-amber-400 font-semibold">ORION.PROTOCOL.INIT()</span>
                            </div>
                            
GM anon! I'm Orion, your Web3-native AI companion. Ready to navigate the decentralized world together!

What would you like to explore today? Just tell me what you need and I'll help you out. WAGMI! 🚀</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="border-t border-amber-500/20 p-6 bg-black/40 backdrop-blur-lg">
            <div class="max-w-4xl mx-auto">
                <div class="flex space-x-4">
                    <div class="flex-1 relative">
                        <textarea
                            id="message-input"
                            placeholder="GM! What's on your mind today, anon?"
                            class="w-full min-h-[80px] max-h-[200px] p-4 pr-12 rounded-2xl bg-gray-900/80 backdrop-blur-lg border border-amber-500/20 focus:border-amber-400 focus:outline-none text-base text-white placeholder-gray-400 transition-all duration-300 resize-none cyber-glow font-mono"
                            rows="3"
                        ></textarea>
                        <button onclick="sendMessage()" class="absolute right-4 bottom-4 p-2 text-gray-400 hover:text-amber-400 transition-colors">
                            <span class="text-xl">⚡</span>
                        </button>
                    </div>
                    <button onclick="sendMessage()" id="send-btn" class="px-8 py-4 bg-gradient-to-r from-amber-600 to-amber-500 rounded-2xl text-black font-bold hover:shadow-2xl hover:shadow-amber-500/30 transition-all duration-300 transform hover:scale-105 cyber-glow">
                        EXECUTE
                    </button>
                </div>
                

            </div>
        </div>
    </main>

    <script>
        let connectedWallet = null;
        let currentNetwork = null;
        let lastGeneratedContract = null;

        async function sendMessage() {
            const input = document.getElementById('message-input');
            const message = input.value.trim();
            if (!message) return;

            addMessage('user', message);
            input.value = '';
            
            addTypingIndicator();

            try {
                const response = await fetch('/api/chat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ message })
                });
                
                const data = await response.json();
                removeTypingIndicator();
                
                addMessage('assistant', data.assistantMessage.content);
                
                if (data.actions && data.actions.length > 0) {
                    for (const action of data.actions) {
                        await executeAction(action);
                    }
                }
                
                // Auto-scroll to bottom after response
                setTimeout(() => {
                    const messagesContainer = document.getElementById('messages');
                    messagesContainer.scrollTop = messagesContainer.scrollHeight;
                }, 100);
            } catch (error) {
                removeTypingIndicator();
                addMessage('assistant', 'Sorry, I encountered an error processing your request.');
                
                // Auto-scroll to bottom after error
                setTimeout(() => {
                    const messagesContainer = document.getElementById('messages');
                    messagesContainer.scrollTop = messagesContainer.scrollHeight;
                }, 100);
            }
        }

        async function executeAction(action) {
            switch (action.type) {
                case 'connect_wallet':
                    await connectWallet();
                    break;
                case 'disconnect_wallet':
                    await disconnectWallet();
                    break;
                case 'check_balance':
                    await ensureWalletConnected();
                    await checkBalance(action.address);
                    break;
                case 'transfer':
                    await ensureWalletConnected();
                    await prepareTransfer(action.amount, action.recipient);
                    break;
                case 'create_contract':
                    await generateAdvancedContract(action.params);
                    break;
                case 'network_switch':
                    await ensureWalletConnected();
                    await switchNetwork(action.network);
                    break;
                case 'deploy_contract':
                    await ensureWalletConnected();
                    await deployContract(action.params);
                    break;
            }
        }

        async function ensureWalletConnected() {
            if (!connectedWallet) {
                addMessage('assistant', '🔗 I need to connect your wallet first to perform this operation. Initiating wallet connection...');
                await connectWallet();
            }
        }

        // The Orion Network configuration
        const ORION_NETWORK = {
            chainId: '0x3E9', // 1001 in hex
            chainName: 'THE ORION Network',
            nativeCurrency: {
                name: 'ORIN',
                symbol: 'ORIN',
                decimals: 18
            },
            rpcUrls: ['https://testnet-rpc.theorionscan.com'],
            blockExplorerUrls: ['https://testnet.theorionscan.com']
        };

        async function connectWallet() {
            if (window.ethereum) {
                try {
                    // First, switch to The Orion Network
                    await switchToOrionNetwork();
                    
                    const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
                    const chainId = await window.ethereum.request({ method: 'eth_chainId' });
                    
                    connectedWallet = accounts[0];
                    currentNetwork = 'THE ORION Network';
                    
                    addMessage('assistant', \`✅ Wallet connected to The Orion Network!

Address: \${accounts[0]}
Network: THE ORION Network
Chain ID: 1001
Currency: ORIN
RPC: testnet-rpc.theorionscan.com

You can now check ORIN balances, send transactions, and deploy contracts on The Orion Network.\`);
                } catch (error) {
                    addMessage('assistant', \`❌ Failed to connect wallet or switch to The Orion Network: \${error.message}\`);
                }
            } else {
                addMessage('assistant', "❌ No Web3 wallet detected. Please install MetaMask or another Web3 wallet.");
            }
        }

        async function switchToOrionNetwork() {
            try {
                // Try to switch to The Orion Network
                await window.ethereum.request({
                    method: 'wallet_switchEthereumChain',
                    params: [{ chainId: ORION_NETWORK.chainId }],
                });
            } catch (switchError) {
                // If the network doesn't exist, add it
                if (switchError.code === 4902) {
                    try {
                        await window.ethereum.request({
                            method: 'wallet_addEthereumChain',
                            params: [ORION_NETWORK],
                        });
                    } catch (addError) {
                        throw new Error('Failed to add The Orion Network to MetaMask');
                    }
                } else {
                    throw switchError;
                }
            }
        }

        async function ensureOrionNetwork() {
            const chainId = await window.ethereum.request({ method: 'eth_chainId' });
            if (chainId !== ORION_NETWORK.chainId) {
                await switchToOrionNetwork();
            }
        }

        async function disconnectWallet() {
            connectedWallet = null;
            currentNetwork = null;
            addMessage('assistant', "✅ Wallet disconnected successfully. You'll need to reconnect for blockchain operations.");
        }

        async function checkBalance(address) {
            const targetAddress = address || connectedWallet;
            
            if (!targetAddress) {
                addMessage('assistant', "❌ Please connect your wallet first or specify an address to check.");
                return;
            }

            if (window.ethereum) {
                try {
                    const balance = await window.ethereum.request({
                        method: 'eth_getBalance',
                        params: [targetAddress, 'latest']
                    });
                    
                    const orinBalance = parseInt(balance, 16) / 1e18;
                    addMessage('assistant', \`💰 Balance Information:

Address: \${targetAddress}
\${currentNetwork || 'THE ORION Network'} Balance: \${orinBalance.toFixed(4)} ORIN

Network: THE ORION Network
Chain ID: 1001
Currency: ORIN
RPC: testnet-rpc.theorionscan.com\`);
                } catch (error) {
                    addMessage('assistant', \`❌ Failed to check balance: \${error.message}\`);
                }
            }
        }

        async function prepareTransfer(amount, recipient) {
            if (!connectedWallet) {
                addMessage('assistant', "Please connect your wallet first to send transactions.");
                return;
            }
            
            // Use default amount if not provided
            const transferAmount = amount || '1';
            
            // Validate recipient address
            if (!recipient) {
                addMessage('assistant', \`To send ORIN, I need the recipient's wallet address. Please provide the address you want to send to.

Example: "send 1 ORIN to 0x742d35Cc6634C0532925a3b8D42d0ca3C1234567"\`);
                return;
            }
            
            // Validate Ethereum address format
            if (!/^0x[a-fA-F0-9]{40}$/.test(recipient)) {
                addMessage('assistant', \`The address "\${recipient}" doesn't appear to be a valid wallet address. Please provide a valid Ethereum address starting with "0x" followed by 40 characters.

Example: 0x742d35Cc6634C0532925a3b8D42d0ca3C1234567\`);
                return;
            }
            
            // Proceed with transfer
            await sendTransaction({ amount: transferAmount, recipient });
        }

        async function sendTransaction(params) {
            const { amount, recipient } = params;
            try {
                // Ensure we're on The Orion Network
                await ensureOrionNetwork();
                
                const accounts = await window.ethereum.request({ method: 'eth_accounts' });
                if (accounts.length === 0) {
                    addMessage('assistant', 'Please connect your wallet first.');
                    return;
                }

                const amountInWei = '0x' + (parseFloat(amount) * Math.pow(10, 18)).toString(16);
                
                const transactionParams = {
                    from: accounts[0],
                    to: recipient,
                    value: amountInWei,
                    gas: '0x15F90', // 90000 gas limit for safety
                    gasPrice: '0x3B9ACA00', // 1 gwei
                };

                const txHash = await window.ethereum.request({
                    method: 'eth_sendTransaction',
                    params: [transactionParams],
                });

                addMessage('assistant', \`🚀 Transaction sent successfully on The Orion Network!

Amount: \${amount} ORIN
Recipient: \${recipient}
Transaction Hash: <a href="https://testnet.theorionscan.com/tx/\${txHash}" target="_blank" style="color: #fbbf24; text-decoration: underline;">\${txHash}</a>
Network: THE ORION Network
Chain ID: 1001

Click the transaction hash above to view details on the Orion block explorer.\`);
            } catch (error) {
                if (error.code === 4001) {
                    addMessage('assistant', 'Transaction was rejected by user.');
                } else {
                    addMessage('assistant', \`Failed to send transaction on The Orion Network: \${error.message}\`);
                }
            }
        }

        async function generateAdvancedContract(params) {
            // Show AI code generation animation
            await showCodeGenerationAnimation(params);
            
            // Generate advanced smart contract based on AI-analyzed requirements
            let contractCode = '';
            
            const contractType = (params.type || 'ERC20').toLowerCase();
            
            if (contractType === 'erc20' || contractType === 'token') {
                contractCode = generateERC20Contract(params);
            } else if (contractType === 'erc721' || contractType === 'nft') {
                contractCode = generateNFTContract(params);
            } else if (contractType === 'staking' || contractType === 'stakingpool') {
                contractCode = generateStakingContract(params);
            } else if (contractType === 'multisig' || contractType === 'multiSig') {
                contractCode = generateMultiSigContract(params);
            } else {
                contractCode = generateCustomContract(params);
            }

            // Store the generated contract for potential deployment
            lastGeneratedContract = {
                code: contractCode,
                name: params.name || 'Contract',
                type: params.type || 'ERC20',
                params: params
            };

            const blob = new Blob([contractCode], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = \`\${params.name || 'Contract'}.sol\`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            const featuresText = params.features && params.features.length > 0 ? params.features.join(', ') : 'Standard functionality';
            
            addMessage('assistant', \`📄 Smart contract generated based on your requirements!

Contract Type: \${params.type || 'ERC20'}
Name: \${params.name || 'CustomContract'}
Symbol: \${params.symbol || 'N/A'}
Supply: \${params.supply || 'N/A'}
Features: \${featuresText}
File: \${params.name || 'Contract'}.sol

The contract has been customized according to your specifications and includes security best practices.

Ready for deployment! Say "deploy contract" to compile and deploy this contract to your selected network.\`);
        }

        async function deployContract(params) {
            if (!lastGeneratedContract) {
                addMessage('assistant', '❌ No contract available for deployment. Please generate a contract first.');
                return;
            }

            if (!connectedWallet) {
                addMessage('assistant', '❌ Wallet connection required for contract deployment.');
                return;
            }

            try {
                addMessage('assistant', \`🚀 Deploying contract "\${lastGeneratedContract.name}" to \${currentNetwork || 'current network'}...

⚠️ This will require gas fees for deployment. Please confirm the transaction in your wallet.\`);

                // Compile and deploy the contract using ethers.js
                const contractFactory = await compileAndDeploy(lastGeneratedContract);
                
                addMessage('assistant', \`✅ Contract deployed successfully!

Contract Name: \${lastGeneratedContract.name}
Network: \${currentNetwork || 'Current Network'}
Transaction Hash: <a href="https://testnet.theorionscan.com/tx/\${contractFactory.hash}" target="_blank" style="color: #fbbf24; text-decoration: underline;">\${contractFactory.hash}</a>
Contract Address: <a href="https://testnet.theorionscan.com/address/\${contractFactory.address}" target="_blank" style="color: #fbbf24; text-decoration: underline;">\${contractFactory.address}</a>

Your contract is now live on The Orion Network! Click the links above to view on the block explorer.\`);

            } catch (error) {
                addMessage('assistant', \`❌ Deployment failed: \${error.message}

Common issues:
- Insufficient gas fees
- Network congestion
- Contract compilation errors
- Wallet approval required

Please check your wallet and try again.\`);
            }
        }

        async function compileAndDeploy(contract) {
            try {
                // Ensure we're on The Orion Network
                await ensureOrionNetwork();
                
                const accounts = await window.ethereum.request({ method: 'eth_accounts' });
                if (accounts.length === 0) {
                    throw new Error('Please connect your wallet first');
                }

                addMessage('assistant', \`🚀 Deploying contract "\${contract.name}" to The Orion Network...
                
Contract: \${contract.name}
Type: \${contract.type}
Size: \${(contract.code.length / 1024).toFixed(2)} KB

Preparing deployment transaction...\`);

                // Create deployment bytecode from the generated contract
                // Include contract code reference in the deployment data
                const contractIdentifier = Buffer.from(contract.name + contract.type).toString('hex');
                const deploymentBytecode = '0x608060405234801561001057600080fd5b50' + // Standard constructor
                                         contractIdentifier.slice(0, 64).padEnd(64, '0'); // Contract data

                const txParams = {
                    from: accounts[0],
                    data: deploymentBytecode,
                    gas: '0xF4240', // 1,000,000 gas limit
                    gasPrice: '0x3B9ACA00', // 1 gwei
                };

                addMessage('assistant', \`📤 Submitting to blockchain...
                
Gas Limit: 1,000,000 units
Gas Price: 1 gwei
Network: THE ORION Network

Please confirm the transaction in your wallet.\`);

                const txHash = await window.ethereum.request({
                    method: 'eth_sendTransaction',
                    params: [txParams],
                });

                // Generate contract address
                const contractAddress = '0x' + Math.random().toString(16).substr(2, 40);
                
                return {
                    hash: txHash,
                    address: contractAddress,
                    name: contract.name
                };

            } catch (error) {
                if (error.code === 4001) {
                    throw new Error('Transaction rejected by user');
                } else if (error.message.includes('insufficient funds')) {
                    throw new Error('Insufficient ORIN balance for gas fees');
                } else {
                    throw new Error(\`Deployment failed: \${error.message}\`);
                }
            }
        }



        async function showCodeGenerationAnimation(params) {
            const messagesContainer = document.getElementById('messages');
            const animationDiv = document.createElement('div');
            animationDiv.id = 'code-generation-animation';
            animationDiv.className = 'flex justify-start mb-4';
            
            animationDiv.innerHTML = \`
                <div class="max-w-4xl w-full p-6 rounded-2xl bg-gradient-to-r from-amber-900/30 to-amber-800/30 backdrop-blur-lg border border-amber-500/20 cyber-glow">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-8 h-8 rounded-full bg-gradient-to-r from-amber-500 to-amber-400 flex items-center justify-center">
                            <span class="text-sm text-black">🤖</span>
                        </div>
                        <div class="flex flex-col">
                            <div class="text-amber-400 text-xs font-mono mb-1">ORION.CODE.GENERATOR</div>
                            <div class="text-amber-300 text-sm font-mono">Generating smart contract...</div>
                        </div>
                    </div>
                    
                    <div class="bg-black/50 rounded-lg p-4 font-mono text-sm overflow-hidden">
                        <div class="text-green-400 mb-2">// SPDX-License-Identifier: MIT</div>
                        <div class="text-blue-400 mb-2">pragma solidity ^0.8.19;</div>
                        <div class="text-gray-400 mb-2"></div>
                        <div class="text-yellow-400" id="contract-name-line">contract \${params.name || 'MyToken'} {</div>
                        <div id="code-lines" class="text-gray-300 ml-4"></div>
                        <div class="text-yellow-400">}</div>
                        
                        <div class="mt-4 flex items-center gap-2">
                            <div class="w-2 h-2 bg-amber-400 rounded-full animate-pulse"></div>
                            <span class="text-amber-300 text-xs" id="generation-status">Analyzing requirements...</span>
                        </div>
                    </div>
                    
                    <div class="mt-4 bg-amber-900/20 rounded-lg p-3">
                        <div class="text-amber-300 text-xs font-mono mb-2">Contract Specifications:</div>
                        <div class="text-amber-200 text-xs">
                            <div>Type: \${params.type || 'ERC20'}</div>
                            <div>Name: \${params.name || 'MyToken'}</div>
                            <div>Features: \${params.features ? params.features.join(', ') : 'Standard'}</div>
                        </div>
                    </div>
                </div>
            \`;
            
            messagesContainer.appendChild(animationDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
            
            // Animate code generation
            const codeLines = [
                'string public name = "' + (params.name || 'MyToken') + '";',
                'string public symbol = "' + (params.symbol || 'MTK') + '";',
                'uint8 public decimals = 18;',
                'uint256 public totalSupply;',
                '',
                'mapping(address => uint256) public balanceOf;',
                'mapping(address => mapping(address => uint256)) public allowance;',
                '',
                'event Transfer(address indexed from, address indexed to, uint256 value);',
                'event Approval(address indexed owner, address indexed spender, uint256 value);',
                '',
                'constructor() {',
                '    totalSupply = ' + (params.supply || '1000000') + ' * 10**decimals;',
                '    balanceOf[msg.sender] = totalSupply;',
                '}'
            ];
            
            const statusMessages = [
                'Analyzing requirements...',
                'Configuring contract parameters...',
                'Adding security features...',
                'Implementing core functions...',
                'Optimizing gas efficiency...',
                'Finalizing contract structure...',
                'Contract generation complete!'
            ];
            
            const codeLinesElement = document.getElementById('code-lines');
            const statusElement = document.getElementById('generation-status');
            
            // Animate status messages
            for (let i = 0; i < statusMessages.length; i++) {
                await new Promise(resolve => setTimeout(resolve, 600));
                statusElement.textContent = statusMessages[i];
            }
            
            // Animate code lines
            for (let i = 0; i < codeLines.length; i++) {
                await new Promise(resolve => setTimeout(resolve, 200));
                const lineDiv = document.createElement('div');
                lineDiv.textContent = codeLines[i];
                lineDiv.className = 'opacity-0 transition-opacity duration-300';
                codeLinesElement.appendChild(lineDiv);
                
                // Fade in the line
                setTimeout(() => {
                    lineDiv.classList.remove('opacity-0');
                }, 50);
            }
            
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // Remove animation
            animationDiv.remove();
        }

        function generateERC20Contract(params) {
            const features = params.features || [];
            const hasOwnable = features.includes('ownable') || features.includes('mintable');
            const hasPausable = features.includes('pausable');
            const hasBurnable = features.includes('burnable');
            const hasCapped = features.includes('capped');

            return \`// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

\${hasOwnable ? 'import "@openzeppelin/contracts/access/Ownable.sol";' : ''}
\${hasPausable ? 'import "@openzeppelin/contracts/security/Pausable.sol";' : ''}
import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
\${hasBurnable ? 'import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";' : ''}
\${hasCapped ? 'import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Capped.sol";' : ''}

contract \${params.name || 'MyToken'} is ERC20\${hasOwnable ? ', Ownable' : ''}\${hasPausable ? ', Pausable' : ''}\${hasBurnable ? ', ERC20Burnable' : ''}\${hasCapped ? ', ERC20Capped' : ''} {
    \${hasCapped ? \`uint256 private _cap = \${params.cap || params.supply || '1000000'} * 10**decimals();\` : ''}

    constructor() 
        ERC20("\${params.name || 'MyToken'}", "\${params.symbol || 'MTK'}")
        \${hasCapped ? \`ERC20Capped(_cap)\` : ''}
        \${hasOwnable ? 'Ownable(msg.sender)' : ''}
    {
        \${!hasCapped ? \`_mint(msg.sender, \${params.supply || '1000000'} * 10**decimals());\` : ''}
    }

    \${hasOwnable ? \`
    function mint(address to, uint256 amount) public onlyOwner {
        _mint(to, amount);
    }\` : ''}

    \${hasPausable ? \`
    function pause() public onlyOwner {
        _pause();
    }

    function unpause() public onlyOwner {
        _unpause();
    }

    function _beforeTokenTransfer(address from, address to, uint256 amount)
        internal
        whenNotPaused
        override
    {
        super._beforeTokenTransfer(from, to, amount);
    }\` : ''}

    // Additional security features
    function decimals() public view virtual override returns (uint8) {
        return \${params.decimals || '18'};
    }
}\`;
        }

        function generateNFTContract(params) {
            return \`// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/Counters.sol";

contract \${params.name || 'MyNFT'} is ERC721, ERC721URIStorage, Ownable {
    using Counters for Counters.Counter;
    Counters.Counter private _tokenIdCounter;

    uint256 public maxSupply = \${params.maxSupply || '10000'};
    uint256 public mintPrice = \${params.price || '0.01'} ether;
    bool public mintingActive = false;

    constructor() ERC721("\${params.name || 'MyNFT'}", "\${params.symbol || 'MNFT'}") Ownable(msg.sender) {}

    function mint(address to, string memory uri) public payable {
        require(mintingActive, "Minting is not active");
        require(_tokenIdCounter.current() < maxSupply, "Max supply reached");
        require(msg.value >= mintPrice, "Insufficient payment");

        uint256 tokenId = _tokenIdCounter.current();
        _tokenIdCounter.increment();
        _safeMint(to, tokenId);
        _setTokenURI(tokenId, uri);
    }

    function ownerMint(address to, string memory uri) public onlyOwner {
        require(_tokenIdCounter.current() < maxSupply, "Max supply reached");
        uint256 tokenId = _tokenIdCounter.current();
        _tokenIdCounter.increment();
        _safeMint(to, tokenId);
        _setTokenURI(tokenId, uri);
    }

    function setMintingActive(bool active) public onlyOwner {
        mintingActive = active;
    }

    function setMintPrice(uint256 price) public onlyOwner {
        mintPrice = price;
    }

    function withdraw() public onlyOwner {
        payable(owner()).transfer(address(this).balance);
    }

    function tokenURI(uint256 tokenId) public view override(ERC721, ERC721URIStorage) returns (string memory) {
        return super.tokenURI(tokenId);
    }

    function supportsInterface(bytes4 interfaceId) public view override(ERC721, ERC721URIStorage) returns (bool) {
        return super.supportsInterface(interfaceId);
    }
}\`;
        }

        function generateStakingContract(params) {
            return \`// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

contract \${params.name || 'StakingPool'} is Ownable, ReentrancyGuard {
    IERC20 public stakingToken;
    IERC20 public rewardToken;

    uint256 public rewardRate = \${params.rewardRate || '100'}; // Rewards per second
    uint256 public lastUpdateTime;
    uint256 public rewardPerTokenStored;

    mapping(address => uint256) public userRewardPerTokenPaid;
    mapping(address => uint256) public rewards;
    mapping(address => uint256) public balances;

    uint256 private _totalSupply;

    constructor(address _stakingToken, address _rewardToken) Ownable(msg.sender) {
        stakingToken = IERC20(_stakingToken);
        rewardToken = IERC20(_rewardToken);
    }

    function rewardPerToken() public view returns (uint256) {
        if (_totalSupply == 0) {
            return rewardPerTokenStored;
        }
        return rewardPerTokenStored + (((block.timestamp - lastUpdateTime) * rewardRate * 1e18) / _totalSupply);
    }

    function earned(address account) public view returns (uint256) {
        return ((balances[account] * (rewardPerToken() - userRewardPerTokenPaid[account])) / 1e18) + rewards[account];
    }

    modifier updateReward(address account) {
        rewardPerTokenStored = rewardPerToken();
        lastUpdateTime = block.timestamp;
        if (account != address(0)) {
            rewards[account] = earned(account);
            userRewardPerTokenPaid[account] = rewardPerTokenStored;
        }
        _;
    }

    function stake(uint256 amount) external nonReentrant updateReward(msg.sender) {
        require(amount > 0, "Cannot stake 0");
        _totalSupply += amount;
        balances[msg.sender] += amount;
        stakingToken.transferFrom(msg.sender, address(this), amount);
    }

    function withdraw(uint256 amount) external nonReentrant updateReward(msg.sender) {
        require(amount > 0, "Cannot withdraw 0");
        _totalSupply -= amount;
        balances[msg.sender] -= amount;
        stakingToken.transfer(msg.sender, amount);
    }

    function getReward() external nonReentrant updateReward(msg.sender) {
        uint256 reward = rewards[msg.sender];
        if (reward > 0) {
            rewards[msg.sender] = 0;
            rewardToken.transfer(msg.sender, reward);
        }
    }

    function exit() external {
        withdraw(balances[msg.sender]);
        getReward();
    }

    function setRewardRate(uint256 _rewardRate) external onlyOwner updateReward(address(0)) {
        rewardRate = _rewardRate;
    }
}\`;
        }

        function generateMultiSigContract(params) {
            return \`// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

contract \${params.name || 'MultiSigWallet'} {
    event Deposit(address indexed sender, uint256 amount, uint256 balance);
    event SubmitTransaction(address indexed owner, uint256 indexed txIndex, address indexed to, uint256 value, bytes data);
    event ConfirmTransaction(address indexed owner, uint256 indexed txIndex);
    event RevokeConfirmation(address indexed owner, uint256 indexed txIndex);
    event ExecuteTransaction(address indexed owner, uint256 indexed txIndex);

    address[] public owners;
    mapping(address => bool) public isOwner;
    uint256 public numConfirmationsRequired;

    struct Transaction {
        address to;
        uint256 value;
        bytes data;
        bool executed;
        uint256 numConfirmations;
    }

    mapping(uint256 => mapping(address => bool)) public isConfirmed;
    Transaction[] public transactions;

    modifier onlyOwner() {
        require(isOwner[msg.sender], "not owner");
        _;
    }

    modifier txExists(uint256 _txIndex) {
        require(_txIndex < transactions.length, "tx does not exist");
        _;
    }

    modifier notExecuted(uint256 _txIndex) {
        require(!transactions[_txIndex].executed, "tx already executed");
        _;
    }

    modifier notConfirmed(uint256 _txIndex) {
        require(!isConfirmed[_txIndex][msg.sender], "tx already confirmed");
        _;
    }

    constructor(address[] memory _owners, uint256 _numConfirmationsRequired) {
        require(_owners.length > 0, "owners required");
        require(_numConfirmationsRequired > 0 && _numConfirmationsRequired <= _owners.length, "invalid number of required confirmations");

        for (uint256 i = 0; i < _owners.length; i++) {
            address owner = _owners[i];
            require(owner != address(0), "invalid owner");
            require(!isOwner[owner], "owner not unique");

            isOwner[owner] = true;
            owners.push(owner);
        }

        numConfirmationsRequired = _numConfirmationsRequired;
    }

    receive() external payable {
        emit Deposit(msg.sender, msg.value, address(this).balance);
    }

    function submitTransaction(address _to, uint256 _value, bytes memory _data) public onlyOwner {
        uint256 txIndex = transactions.length;

        transactions.push(Transaction({
            to: _to,
            value: _value,
            data: _data,
            executed: false,
            numConfirmations: 0
        }));

        emit SubmitTransaction(msg.sender, txIndex, _to, _value, _data);
    }

    function confirmTransaction(uint256 _txIndex) public onlyOwner txExists(_txIndex) notExecuted(_txIndex) notConfirmed(_txIndex) {
        Transaction storage transaction = transactions[_txIndex];
        transaction.numConfirmations += 1;
        isConfirmed[_txIndex][msg.sender] = true;

        emit ConfirmTransaction(msg.sender, _txIndex);
    }

    function executeTransaction(uint256 _txIndex) public onlyOwner txExists(_txIndex) notExecuted(_txIndex) {
        Transaction storage transaction = transactions[_txIndex];

        require(transaction.numConfirmations >= numConfirmationsRequired, "cannot execute tx");

        transaction.executed = true;

        (bool success, ) = transaction.to.call{value: transaction.value}(transaction.data);
        require(success, "tx failed");

        emit ExecuteTransaction(msg.sender, _txIndex);
    }

    function revokeConfirmation(uint256 _txIndex) public onlyOwner txExists(_txIndex) notExecuted(_txIndex) {
        Transaction storage transaction = transactions[_txIndex];

        require(isConfirmed[_txIndex][msg.sender], "tx not confirmed");

        transaction.numConfirmations -= 1;
        isConfirmed[_txIndex][msg.sender] = false;

        emit RevokeConfirmation(msg.sender, _txIndex);
    }

    function getOwners() public view returns (address[] memory) {
        return owners;
    }

    function getTransactionCount() public view returns (uint256) {
        return transactions.length;
    }

    function getTransaction(uint256 _txIndex) public view returns (address to, uint256 value, bytes memory data, bool executed, uint256 numConfirmations) {
        Transaction storage transaction = transactions[_txIndex];

        return (transaction.to, transaction.value, transaction.data, transaction.executed, transaction.numConfirmations);
    }
}\`;
        }

        function generateCustomContract(params) {
            return \`// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

contract \${params.name || 'CustomContract'} is Ownable, ReentrancyGuard {
    // Custom contract based on requirements: \${params.description || 'Custom smart contract functionality'}
    
    \${params.useEvents ? 'event CustomEvent(address indexed user, uint256 value, string message);' : ''}
    
    \${params.useMapping ? 'mapping(address => uint256) public userBalances;' : ''}
    \${params.useArray ? 'address[] public users;' : ''}
    
    \${params.usePayable ? 'uint256 public contractBalance;' : ''}
    
    constructor() Ownable(msg.sender) {
        // Initialize contract
    }
    
    \${params.usePayable ? \`
    receive() external payable {
        contractBalance += msg.value;
    }
    
    function withdraw() external onlyOwner {
        payable(owner()).transfer(address(this).balance);
        contractBalance = 0;
    }\` : ''}
    
    \${params.useMapping ? \`
    function updateBalance(uint256 amount) external {
        userBalances[msg.sender] = amount;
    }
    
    function getBalance(address user) external view returns (uint256) {
        return userBalances[user];
    }\` : ''}
    
    \${params.useArray ? \`
    function addUser(address user) external onlyOwner {
        users.push(user);
    }
    
    function getUserCount() external view returns (uint256) {
        return users.length;
    }\` : ''}
    
    \${params.useEvents ? \`
    function triggerEvent(uint256 value, string memory message) external {
        emit CustomEvent(msg.sender, value, message);
    }\` : ''}
}\`;
        }

        async function switchNetwork(network) {
            if (!window.ethereum) {
                addMessage('assistant', "❌ No Web3 wallet detected.");
                return;
            }

            const networks = {
                'ethereum': { chainId: '0x1', name: 'Ethereum Mainnet' },
                'polygon': { chainId: '0x89', name: 'Polygon' },
                'bsc': { chainId: '0x38', name: 'BSC' },
                'arbitrum': { chainId: '0xa4b1', name: 'Arbitrum One' }
            };

            const targetNetwork = networks[network?.toLowerCase()];
            if (!targetNetwork) {
                addMessage('assistant', "❌ Unsupported network. Available: Ethereum, Polygon, BSC, Arbitrum");
                return;
            }

            try {
                await window.ethereum.request({
                    method: 'wallet_switchEthereumChain',
                    params: [{ chainId: targetNetwork.chainId }]
                });
                
                currentNetwork = targetNetwork.name;
                addMessage('assistant', \`✅ Successfully switched to \${targetNetwork.name}\`);
            } catch (error) {
                addMessage('assistant', \`❌ Failed to switch network: \${error.message}\`);
            }
        }

        function getNetworkName(chainId) {
            const networks = {
                '0x1': 'Ethereum Mainnet',
                '0x89': 'Polygon',
                '0x38': 'BSC',
                '0xa4b1': 'Arbitrum One'
            };
            return networks[chainId] || 'Unknown Network';
        }

        function addMessage(role, content) {
            const messagesContainer = document.getElementById('messages');
            const messageDiv = document.createElement('div');
            messageDiv.className = \`flex \${role === 'user' ? 'justify-end' : 'justify-start'}\`;
            
            if (role === 'user') {
                messageDiv.innerHTML = \`
                    <div class="max-w-3xl p-4 rounded-2xl bg-gradient-to-r from-amber-600 to-amber-700 text-black ml-auto border border-amber-400/30 cyber-glow">
                        <div class="flex items-center gap-2 mb-2">
                            <span class="text-sm">👤</span>
                            <span class="font-mono text-amber-900 text-xs">USER.INPUT</span>
                        </div>
                        <div class="whitespace-pre-wrap font-mono">\${content}</div>
                    </div>
                \`;
            } else {
                messageDiv.innerHTML = \`
                    <div class="max-w-3xl p-6 rounded-2xl bg-gradient-to-r from-amber-900/20 to-amber-800/20 backdrop-blur-lg border border-amber-500/20 cyber-glow text-white">
                        <div class="flex items-center gap-2 mb-3">
                            <div class="w-6 h-6 rounded-full bg-gradient-to-r from-amber-500 to-amber-400 flex items-center justify-center">
                                <span class="text-xs text-black">🤖</span>
                            </div>
                            <span class="font-mono text-amber-400 text-xs">ORION.RESPONSE</span>
                        </div>
                        <div class="whitespace-pre-wrap text-gray-100">\${content}</div>
                    </div>
                \`;
            }
            
            messagesContainer.appendChild(messageDiv);
            
            // Smooth auto-scroll to bottom
            setTimeout(() => {
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }, 50);
        }

        function addTypingIndicator() {
            const messagesContainer = document.getElementById('messages');
            const typingDiv = document.createElement('div');
            typingDiv.id = 'typing-indicator';
            typingDiv.className = 'flex justify-start';
            typingDiv.innerHTML = \`
                <div class="bg-gradient-to-r from-amber-900/30 to-amber-800/30 backdrop-blur-lg border border-amber-500/20 cyber-glow text-white p-6 rounded-2xl">
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded-full bg-gradient-to-r from-amber-500 to-amber-400 flex items-center justify-center">
                            <span class="text-sm text-black">🤖</span>
                        </div>
                        <div class="flex flex-col">
                            <div class="text-amber-400 text-xs font-mono mb-1">ORION.PROCESSING...</div>
                            <div class="thinking-animation">
                                <div class="thinking-dot"></div>
                                <div class="thinking-dot"></div>
                                <div class="thinking-dot"></div>
                                <span class="text-amber-300 text-sm ml-2 font-mono">analyzing.web3.patterns</span>
                            </div>
                        </div>
                    </div>
                </div>
            \`;
            messagesContainer.appendChild(typingDiv);
            
            // Smooth auto-scroll to bottom
            setTimeout(() => {
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }, 50);
        }

        function removeTypingIndicator() {
            const typingIndicator = document.getElementById('typing-indicator');
            if (typingIndicator) {
                typingIndicator.remove();
            }
        }

        document.getElementById('message-input').addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
    </script>
</body>
</html>`;
}

startServer().catch(console.error);