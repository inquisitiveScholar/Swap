export interface ChatMessage {
  id: number;
  content: string;
  role: "user" | "assistant";
  timestamp: Date;
  metadata?: any;
}

export interface InsertChatMessage {
  content: string;
  role: "user" | "assistant";
  metadata?: any;
}

export interface IStorage {
  getMessages(): Promise<ChatMessage[]>;
  createMessage(message: InsertChatMessage): Promise<ChatMessage>;
}

export class MemStorage implements IStorage {
  private messages: ChatMessage[] = [];
  private idCounter = 1;

  async getMessages(): Promise<ChatMessage[]> {
    return [...this.messages];
  }

  async createMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const newMessage: ChatMessage = {
      id: this.idCounter++,
      content: message.content,
      role: message.role,
      timestamp: new Date(),
      metadata: message.metadata || null,
    };
    
    this.messages.push(newMessage);
    return newMessage;
  }
}

export const storage = new MemStorage();