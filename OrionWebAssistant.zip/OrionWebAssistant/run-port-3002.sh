#!/bin/bash
export PORT=3002
echo "Starting Ori Web3 Assistant on port 3002..."
tsx server/index.ts