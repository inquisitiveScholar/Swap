// Simple server starter that uses port 3002
const { spawn } = require('child_process');

process.env.PORT = '3002';

const server = spawn('tsx', ['server/index.ts'], {
  stdio: 'inherit',
  env: { ...process.env, PORT: '3002' }
});

server.on('close', (code) => {
  console.log(`Server process exited with code ${code}`);
});

process.on('SIGINT', () => {
  server.kill();
  process.exit();
});