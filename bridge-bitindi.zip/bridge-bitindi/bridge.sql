-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 03, 2022 at 12:45 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bridge`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_settings`
--

CREATE TABLE `admin_settings` (
  `id` int(11) NOT NULL,
  `networkid` int(11) NOT NULL,
  `last_block_synced` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_settings`
--

INSERT INTO `admin_settings` (`id`, `networkid`, `last_block_synced`) VALUES
(1, 1, 15801624),
(2, 56, 34647414),
(3, 137, 25100432),
(5, 4099, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bridge_transactions`
--

CREATE TABLE `bridge_transactions` (
  `id` int(11) NOT NULL,
  `fromTxnHash` varchar(70) NOT NULL,
  `fromChainID` int(11) NOT NULL,
  `toChainID` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `secretText` varchar(100) DEFAULT NULL,
  `toWallet` varchar(50) NOT NULL,
  `toAmount` varchar(30) NOT NULL,
  `status` tinyint(4) DEFAULT 0,
  `inputCurrency` varchar(50) NOT NULL,
  `outputCurrency` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `nonce_admin_table`
--

CREATE TABLE `nonce_admin_table` (
  `id` int(11) NOT NULL,
  `walletid` varchar(100) NOT NULL,
  `walletpk` varchar(100) NOT NULL,
  `chainid` int(11) NOT NULL,
  `isFrozen` tinyint(1) NOT NULL,
  `secretphrase` varchar(300) DEFAULT NULL,
  `freezetime` int(11) DEFAULT 0,
  `nonce` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `token_pricing_table`
--

CREATE TABLE `token_pricing_table` (
  `id` int(11) NOT NULL,
  `tokenName` varchar(100) DEFAULT NULL,
  `tokenPriceInUSD` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `token_pricing_table`
--

INSERT INTO `token_pricing_table` (`id`, `tokenName`, `tokenPriceInUSD`) VALUES
(1, 'ETH', 1300),
(2, 'BNB', 300),
(3, 'USDT', 1),
(4, 'Matic', 0.79),
(5, 'clientChainNativeCoin', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_settings`
--
ALTER TABLE `admin_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bridge_transactions`
--
ALTER TABLE `bridge_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nonce_admin_table`
--
ALTER TABLE `nonce_admin_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `token_pricing_table`
--
ALTER TABLE `token_pricing_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_settings`
--
ALTER TABLE `admin_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bridge_transactions`
--
ALTER TABLE `bridge_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nonce_admin_table`
--
ALTER TABLE `nonce_admin_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `token_pricing_table`
--
ALTER TABLE `token_pricing_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
