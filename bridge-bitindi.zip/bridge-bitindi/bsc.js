#!/usr/bin/nodejs

/** Bridge specifications
 * This bridge suppors 2 chain IDs to covert from and to any network.
 * This bridge does not support multiple networks.
 * Token names and their prices must be set in database for the currencies, which are not 1:1
 * TokenOut will use outputcurrency [ tokencontractAddress ] to understand which token to send
 */

 var mysql = require('mysql');
 const util = require('util');
 require('dotenv').config();
 const Web3 = require("web3");
 var Tx = require('ethereumjs-tx').Transaction;
 var Contract = require('web3-eth-contract');
 var CronJob = require('cron').CronJob;
 const BigNumber = require('bignumber.js');
 
 
 //--------------------------------------------------//
 //                  CONFIGURATION                   //
 //--------------------------------------------------//
 
 var fromChainID = 56;
 var toChainID = 4099;
 var fromProvider = "https://data-seed-prebsc-1-s1.binance.org:8545/";
 var toProvider = "https://rpc-mainnet.bitindi.org/";
 var fromBridgeContract = "0xc2A094253F72b857D68E68f7d4ABf06443E1625B";
 var toBridgeContract = "0xe30E2F0aFD56dacF8b8D4afBc594f63eE21B9441";
 var fromTokenDecimals = 18;
 var toTokenDecimals = 18;
 var adminWaletFreezeTime = [];
 adminWaletFreezeTime[toChainID] = 50; 
 var maxTxnsInBatch = 5; // this is number of transactions to be sent in one go when cron runs
 
 //Tokens
 var ethTokenContract = "0x04279c1DCf6667A6FA31eA84287ed7A9fe781536";    // ETH Token on To Network
 var bnbTokenContract = "0x45ADFadAaeC7f7BFC59846006973876051001fA7";    // BNB Token on To Network
 var maticTokenContract = "0x83d92a3EF1491B19978bf2EEaB63Ce93161AF4EC";  // MATIC Token on To Network
 var usdtTokenContract = "0xAEc27a6cF692A97f4579D580305667999899cc06";   // USDT Token on from Network
 var nativeCoin = "0x0000000000000000000000000000000000000000";          // The native coin will represent address zero
 
  
 //// MIN AMOUNT -> BRIDGE UI
 const minInputAmount = 100000000;
 
 var fromWeb3 = new Web3(new Web3.providers.HttpProvider(fromProvider));
 var toWeb3 = new Web3(new Web3.providers.HttpProvider(toProvider));
 var CONTRACT_ADDR_ABI = JSON.parse(process.env.BRIDGE_ABI);


 // Add here both input and output tokens
 var allowedTokens = [
     fromWeb3.utils.toChecksumAddress(usdtTokenContract),fromWeb3.utils.toChecksumAddress(ethTokenContract),fromWeb3.utils.toChecksumAddress(bnbTokenContract),fromWeb3.utils.toChecksumAddress(maticTokenContract), fromWeb3.utils.toChecksumAddress(nativeCoin), fromWeb3.utils.toChecksumAddress(ethTokenContract)

];
 
 
 /// DB Connection Config Obj
 var DB_CONFIG = {
     host: process.env.DB_HOST.toString(),
     user: process.env.DB_USER.toString(),
     password: process.env.DB_PASSWORD.toString(),
     database: process.env.DB_DATABASE.toString(),
     connectTimeout: 50000,
     port: process.env.DB_PORT
 };
  

 

 
 /// Converter Code - 05 Oct 2022
 async function logEtoLongNumber(amountInLogE){
    
  amountInLogE = amountInLogE.toString();
  var noDecimalDigits = "";

  if(amountInLogE.includes("e-")){
    
    var splitString = amountInLogE.split("e-"); //split the string from 'e-'

    noDecimalDigits = splitString[0].replace(".", ""); //remove decimal point

    //how far decimals to move
    var zeroString = "";
    for(var i=1; i < splitString[1]; i++){
      zeroString += "0";
    }

    return  "0."+zeroString+noDecimalDigits;
    
  }
  else if(amountInLogE.includes("e+")){

    var splitString = amountInLogE.split("e+"); //split the string from 'e+'
    var ePower = parseInt(splitString[1]);

    noDecimalDigits = splitString[0].replace(".", ""); //remove decimal point

    if(ePower >= noDecimalDigits.length-1){
      var zerosToAdd = ePower  - noDecimalDigits.length;

      for(var i=0; i <= zerosToAdd; i++){
        noDecimalDigits += "0";
      }

    }
    else{
      //this condition will run if the e+n is less than numbers
      var stringFirstHalf = noDecimalDigits.slice(0, ePower+1);
      var stringSecondHalf = noDecimalDigits.slice(ePower+1);

      return stringFirstHalf+"."+stringSecondHalf;
    }
    return noDecimalDigits;
  }
  else if(amountInLogE.includes(".")){
        var splitString = amountInLogE.split("."); //split the string from '.'
        return splitString[0];
     }
  return amountInLogE;  //by default it returns stringify value of original number if its not logarithm number
}
 

 
 async function bridge_send_transaction(inputCurrency, outputCurrency, _toWallet, _amt, orderid, _chainid, adminWallet, adminWalletPK, nonce) {

        console.log("----------------------------------------------@@@@checking--------------------------------");

        console.log(adminWalletPK);

        console.log("--------------------------------@@checking End--------------------------------");

     console.log("~~~~~~~~~~~~~~~~~@@@@@@@@@@~~~~~~~~~~~~~~~~~~~~~~~~");
     console.log(">>>>inputCurrency, outputCurrency, _toWallet, _amt, orderid, _chainid, adminWallet, nonce >>>>",inputCurrency, outputCurrency, _toWallet, _amt, orderid, _chainid, adminWallet, nonce);
     console.log("~~~~~~~~~~~~~~~~~@@@@@@@@@@~~~~~~~~~~~~~~~~~~~~~~~~~");
     console.log(">>>> in bridge_send_transction function >>>>");    
     // not valid token addr
     if (!allowedTokens.includes(inputCurrency) || !allowedTokens.includes(outputCurrency)) {
         return;
     }  
     console.log(">>>>> Working on chain id >>>> ", _chainid);
     
     try {
         var bridgeinstance = new toWeb3.eth.Contract(CONTRACT_ADDR_ABI, toBridgeContract);
     } catch (e) {
         console.log(" >>>>> EEEEE >>>>", e);
     }      
             console.log(">>>>>>!!!!!!!!!!!!!!!!!!!!!!!!_chainid, adminWallet~~~~~~~~~~~~~~~~~~~~~~~~", _chainid, adminWallet);
             var mydata = '';
             let status = false;
             console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
             console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
             console.log(">>>> In send Transaction  function >>>>");
             console.log(">>>>>>> outputCurrency, nativeCoin  >>>>>", outputCurrency,nativeCoin);
             console.log(">>>> toWeb3.utils.toChecksumAddress(outputCurrency), toWeb3.utils.toChecksumAddress(nativeCoin) >>>",toWeb3.utils.toChecksumAddress(outputCurrency), toWeb3.utils.toChecksumAddress(nativeCoin));
             console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
             console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
             if (toWeb3.utils.toChecksumAddress(outputCurrency) === toWeb3.utils.toChecksumAddress(nativeCoin)) {
                 status = true;
                 console.log(">>>>>>@@@@@!~~~~");                
                    console.log("<<<<< new_amount BEFORE DB PRICE multiplication >>>>>", _amt);
                    
                    if(toWeb3.utils.toChecksumAddress(inputCurrency) === toWeb3.utils.toChecksumAddress(usdtTokenContract)){
                        //do nothing currently. But if there would be different  price of native coin than $1, then that logic will go here.
                    }
                    else{
                        var pricedata = await getPriceFromDB(); 
                        _amt = parseFloat(pricedata[1].tokenPriceInUSD) * _amt / parseFloat(pricedata[4].tokenPriceInUSD); 
                        console.log(">>>>> pricedata[1].tokenPriceInUSD >>>>", pricedata[1].tokenPriceInUSD); 
                    }
                    _amt = await logEtoLongNumber(_amt / (10**fromTokenDecimals) * (10**toTokenDecimals));   // to decimal issue of tokens having different decimals                     
                     
                     console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                     console.log("<<<<< new_amount >>>>>", _amt);
                     console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");      
                     mydata = await bridgeinstance.methods.coinOut(_toWallet.toString(), _amt.toString(), orderid.toString()).encodeABI();                                          
                     console.log(">>>> CoinOut >> myData >>>>", mydata);
             }else{
                status = true;
                console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                console.log(">>>>>>@@@@@!~~~~ Send Transction - TokenOut [TokenOut] >>>>");
                console.log("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                    _amt = await logEtoLongNumber(_amt / (10**fromTokenDecimals) * (10**toTokenDecimals));   // to decimal issue of tokens having different decimals  
                    console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    console.log("<<<<< new_amount, outputCurrency.toString(), _toWallet.toString(), _amt.toString(), orderid.toString(), _chaninid >>>>>", _amt,outputCurrency.toString(), _toWallet.toString(), _amt.toString(), orderid.toString(), toChainID);
                    console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");                          
                    mydata = await bridgeinstance.methods.tokenOut(outputCurrency.toString(), _toWallet.toString(), _amt.toString(), orderid.toString(), toChainID).encodeABI();
                    console.log("~~~~~~~~~~~~~~~~~~~~~~MYDATA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    console.log(">>>> TokenOut >> myData >>>>", mydata);
                    console.log("~~~~~~~~~~~~~~~~~>>>>> MYDATA <<<<~~~~~~~~~~~~~~~~~~~~~~~~");
             }
                   
             if(status){
                 toWeb3.eth.getGasPrice().then(gasPrice => {                     
                     const raw_tx = {
                         nonce: nonce,
                         gasPrice: toWeb3.utils.toHex(gasPrice),                    
                         gasLimit: 100000,
                         from: adminWallet,
                         to: toBridgeContract,
                         data: mydata,                    
                         chainId: parseInt(_chainid)
                     };
                     console.log(">>>> RAW TX [raw_tx] >>>>", raw_tx);
                     try {
 
                         toWeb3.eth.accounts.signTransaction(raw_tx, adminWalletPK, function(error, result) {
                             if (!error) {
                                 try {
                                     var serializedTx = result.rawTransaction;                                     
                                     console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                                     console.log("-->> Signed Transaction -->> Serialized Tx ::", serializedTx);
                                     console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
                                     toWeb3.eth.sendSignedTransaction(serializedTx.toString('hex')).on('receipt', console.log).on('error', console.log);
                                 } catch (e) {
                                     console.log(e);
                                 }
                             }
                         });
                         setTimeout(() => {}, 5000);
                         //																		
                     } catch (e) {
                         console.log("##### :::: ERR0R :::: ######", e);
                     }
                 })
             }			    			             
 }
 
 async function getTransactionsFromDB() {     
     try {
        var adminWallet = process.env.ADMIN_WALLET_BSC;
        var adminWalletPK = process.env.ADMIN_WALLET_BSC_PK;
        console.log(adminWalletPK);
        var nonce = await toWeb3.eth.getTransactionCount(adminWallet, "pending");
     
         console.log("~~~~~~~~~~ GET AvailableAdminWallet ~~~~~~~~~~~");
         console.log("adminWallet, nonce >>>>>", adminWallet, nonce); 
 
         if (typeof(adminWallet) == "undefined" || (!adminWallet)) {
            console.log("<<@@@>@@@>>No admin wallet bridge available ...<@@@@@@>>");                         
         } else {
               // HERE TRY BLOCK
                var bridgedbConnect = mysql.createConnection(DB_CONFIG);
                try{                                   
                        var util_bridgequery = util.promisify(bridgedbConnect.query).bind(bridgedbConnect);
                        var query2 = "select * from bridge_transactions where status=0 and fromChainID=" + fromChainID + " and toChainID=" + toChainID + " limit "+maxTxnsInBatch;
                        console.log(">>selecting from DB...., select QUERY<<", query2)
                        var result = await util_bridgequery(query2);
                        var tempArray = [];             
                        //make an array for all order id. this is to update its status all in one go
                        for(j=0; j<result.length; j++){
                            tempArray.push(result[j].orderid);
                        }                          
                        //update the status of all records.
                        if(tempArray.length > 0){                 
                            var updateQuery = "update bridge_transactions set status=1 where fromChainID=" + fromChainID + " and orderid IN ("+tempArray+")";
                            console.log("============>>>> update query "+updateQuery);
                            await util_bridgequery(updateQuery);
                        }
        
                        const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));   
                        console.log(">>>>>> here reached >>>>");
                        //sending individual transactions.
                        for(i=0; i<result.length; i++){                
                            await wait(4500); 
                            console.log(result[i]);
                            
                            let inputCurrency = result[i].inputCurrency;
                            let outputCurrency = result[i].outputCurrency;
                            let sendcoinsTo = result[i].toWallet;
                            let amount = result[i].toAmount;
                            let orderid = result[i].orderid;
                            let chainid = result[i].toChainID;
                            console.log(">>>>> HERE REACHED >>>> <<<< HERE REACHED <<<<, bridge send transcations >>>>");                                                                 
                            console.log(">>>>>result[i] >>>>>",result[i]);
                            var z = await bridge_send_transaction(inputCurrency, outputCurrency, sendcoinsTo, amount, orderid, toChainID, adminWallet, adminWalletPK, nonce).catch(console.log);
                            nonce++;
                        }
                    }catch(e){
                        console.log(e);
                    }finally{
                        bridgedbConnect.end();
                    }
            }	// else close
     } catch (e) {
        console.error("ERROR SQL>>Catch", e);
     } finally { 
		console.log("In finally block ...");
	 }
 }
 
 
 
 
 async function db_select( transactionHash, orderid, sendcoinsTo, amount, inputToken, outputToken, secretText) {   

 console.log("insert--------------------------");  
     var select_dbConnection = mysql.createConnection(DB_CONFIG); 
     try {          
         var util_query = util.promisify(select_dbConnection.query).bind(select_dbConnection);
         var select_query = "SELECT count(orderid) as rec FROM bridge_transactions  where fromTxnHash='" + transactionHash + "' ";
         console.log(">>>>>> select_query >>>>>", select_query);
         var records = await util_query(select_query).catch(console.log);
         console.log(">>>>>> records <<<<<<", records);
         if (parseInt(records[0].rec) < 1) {             
             var insert_query = "INSERT INTO bridge_transactions (`fromTxnHash`,`fromChainID`,`toChainID`,`orderid`,`secretText`,`toWallet`,`toAmount`,`inputCurrency`,`outputCurrency`) VALUES ('" + transactionHash + "'," + parseInt(fromChainID) + "," + parseInt(toChainID) + "," + parseInt(orderid) +"," + secretText + ",'" +sendcoinsTo.toString()+ "'," + amount.toString() + ",'" + inputToken + "','" + outputToken + "')";
             //console.log(">>> Inserting record, orderid, fromChainID, toChainID >>>", orderid, fromChainID, toChainID);
             
             var result = await util_query(insert_query).catch(console.log);
             //console.log("Insert query ", insert_query);             
         } else {
             console.log(">>> Skipping already in database, orderid, fromChainID, toChainID ", orderid, fromChainID, toChainID);
             return 1;
         }
     } catch (e) {
         console.error("ERROR SQL>>Catch", e);
     } finally {         
         select_dbConnection.end();
     }
 }
 

 async function getEventData(_fromBlock, _toBlock, _eventName) {
     const myinstance = new fromWeb3.eth.Contract(CONTRACT_ADDR_ABI, fromBridgeContract);
     
     try{
     await myinstance.getPastEvents(_eventName, {
         fromBlock: _fromBlock,
         toBlock: _toBlock
     }, function(error, myevents) {
         
         if (myevents === undefined) {
             return
         }
         var myeventlen = myevents.length;
        
         console.log("=================================================");
         console.log("FETCHING EVENTS >>> myeventlen >>>>", _eventName, myeventlen);
         console.log("=================================================");
         var secretText = Math.random(33831, 6914351);
         process.env.secretText = secretText.toString();
         for (k = 0; k < myeventlen; k++) {
             var myeve = myevents[k];
             console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
             console.log("Event Details ::: >>>",  myeve.blockNumber);
             console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			 console.log(myeve);
             var _transactionHash = myeve.transactionHash;
             var _myorderid = myeve.returnValues.orderID;
             var _mysendcoinsTo = myeve.returnValues.user;
             var _myamount = myeve.returnValues.value;
             var _inputToken = "0x0000000000000000000000000000000000000000"; //this is default for CoinIn event
             var _outputToken = myeve.returnValues.outputCurrency;
 
             if(_eventName == 'TokenIn'){
                 _inputToken = myeve.returnValues.tokenAddress.trim();
             }
 
             
             // It will check minimum amount of tokens must be there to be accepted.           
             if ((!BigNumber(_myamount).lt(minInputAmount))) {
                 console.log("!!!!!! tokenAddress >>>>>", _inputToken);
                 
                 if (allowedTokens.includes(fromWeb3.utils.toChecksumAddress(_inputToken))) {
                     console.log("<<<<@>>>> Looking for ---->>>>", _inputToken);
                     try {
                         console.log("~~~~~TokenIn EVENT >>>>_inputToken ~~~~~", _inputToken);
                         (async () => {
                             var cnt = await db_select(_transactionHash, _myorderid, _mysendcoinsTo, _myamount, _inputToken, _outputToken, secretText).catch(console.log);
                         })();
                     } catch (e) {
                         console.log(">>>>>Catch >>>>", e);
                     }
                 } else {
                     console.log(">>>> not matched !!");
                 }
             } else {
                 console.log(">>> TOKENIN/ ELSE >>>> In for loop, _orderid, toChainID,  _myamount, k >>>>", _myorderid, toChainID, _myamount, k);
             }
         }
     });
 }catch(e){}
 }
 
 async function checkLatestBlock() {   
     var toBlock = await fromWeb3.eth.getBlockNumber();
     var fromBlock = 0; 
     // getting last synced block number from DB.
     // this is to elimate the overhead of reading lots of events from blockchain.
     // so, only read the blocks which are not already read previously.
     var mydbConnection = mysql.createConnection(DB_CONFIG);
     try{        
        var myquery = util.promisify(mydbConnection.query).bind(mydbConnection);
        var select_query = "SELECT last_block_synced FROM admin_settings where `networkid`="+fromChainID;
        var records = await myquery(select_query).catch(console.log);
        console.log(">>>>>> records <<<<<<", records); 
        if (parseInt(records[0].last_block_synced) > 0) { 
            fromBlock = records[0].last_block_synced;
            var update_query = "UPDATE `admin_settings` SET `last_block_synced`=" + toBlock + " where `networkid`="+fromChainID;
            await myquery(update_query).catch(console.log);
            console.log("update_query ", update_query);   
        }
     }catch(e){
        console.log("In catch block [checkLatestBlock]...", e);
     }finally{
        // end connection here
        mydbConnection.end();    
     }
     console.log(">>TESTING FOR>>fromblock, toblock>>", fromBlock, toBlock);
     getEventData(fromBlock, toBlock, 'TokenIn');    
     getEventData(fromBlock, toBlock, 'CoinIn');    
 }
 
 async function getPriceFromDB(){    
     var Connection = mysql.createConnection(DB_CONFIG);
     try {         
         var query = util.promisify(Connection.query).bind(Connection);         
         var sel_query = "SELECT `tokenPriceInUSD` FROM token_pricing_table";
         return data = await query(sel_query).catch(console.log);
     } catch (e) {
         console.log("ERROR IN SQL GET PRICE FROM DB SEL QUERY >>", e);
     }finally{
        Connection.end();
     }
 }
 
 //Cron running Every 1 min
 //var job = new CronJob('0 */1 * * * *', function() {
 var job = new CronJob('0 * * * * *', function() {
     // console.log("-------------------------------------");
     // console.log('Cron running, every 1 min');
     // console.log("-------------------------------------");

     checkLatestBlock();
     getTransactionsFromDB();
 }, null, true, 'America/Los_Angeles');
 
 job.start();
