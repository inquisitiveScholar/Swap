import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAuth } from "@/context/AuthContext";
// Remove Web3Context import that's causing errors
// import { useWeb3 } from "@/context/Web3Context";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import MobileDrawer from "@/components/MobileDrawer";
import MobileNav from "@/components/MobileNav";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import CreatePostInput from "@/components/CreatePostInput";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

// Define avatar options
const AVATAR_OPTIONS = [
  '/avatars/crypto-1.png',
  '/avatars/crypto-2.png',
  '/avatars/crypto-3.png',
  '/avatars/crypto-4.png',
  '/avatars/crypto-5.png',
  '/avatars/crypto-6.png',
  'https://api.dicebear.com/7.x/identicon/svg?seed=crypto1',
  'https://api.dicebear.com/7.x/identicon/svg?seed=crypto2',
  'https://api.dicebear.com/7.x/identicon/svg?seed=crypto3',
  'https://api.dicebear.com/7.x/identicon/svg?seed=crypto4',
];

// Profile update schema
const profileSchema = z.object({
  displayName: z.string().min(2, { message: "Display name is required" }),
  bio: z.string().optional(),
  avatar: z.string().optional(),
});

// Password change schema
const passwordSchema = z.object({
  currentPassword: z.string().min(6, { message: "Current password is required" }),
  newPassword: z.string().min(6, { message: "Password must be at least 6 characters" }),
  confirmPassword: z.string().min(6, { message: "Please confirm your password" }),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type ProfileFormValues = z.infer<typeof profileSchema>;
type PasswordFormValues = z.infer<typeof passwordSchema>;

export default function UserSettings() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [createPostOpen, setCreatePostOpen] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState<string | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [, navigate] = useLocation();
  const { user, logout, updateUser } = useAuth();
  const { toast } = useToast();

  // Redirect if not logged in and handle initial data setup
  useEffect(() => {
    if (!user) {
      navigate("/login");
    } else {
      // Set the initial avatar selection
      setSelectedAvatar(user.avatar || null);
      
      // Ensure form has the latest user data
      profileForm.reset({
        displayName: user.displayName || "",
        bio: user.bio || "",
        avatar: user.avatar || "",
      });
    }
  }, [user, navigate]);

  // Profile form
  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      displayName: user?.displayName || "",
      bio: user?.bio || "",
      avatar: user?.avatar || "",
    },
  });

  // Update profile when user data changes
  useEffect(() => {
    if (user) {
      profileForm.reset({
        displayName: user.displayName || "",
        bio: user.bio || "",
        avatar: user.avatar || "",
      });
    }
  }, [user, profileForm]);

  // Password form
  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  // Profile update mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PATCH", "/api/users/profile", data);
      return response.json();
    },
    onSuccess: (updatedUser) => {
      // Manually update the user data in AuthContext
      updateUser(updatedUser);
      
      // Invalidate all queries that might display user data
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/comments"] });
      
      // Manually update the user data in the cache for immediate display
      queryClient.setQueryData(["/api/user"], updatedUser);
      
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: error instanceof Error ? error.message : "Failed to update profile",
      });
    },
  });

  // Password change mutation
  const changePasswordMutation = useMutation({
    mutationFn: async (data: PasswordFormValues) => {
      const response = await apiRequest("PATCH", "/api/users/password", {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Password updated",
        description: "Your password has been changed successfully.",
      });
      passwordForm.reset();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: error instanceof Error ? error.message : "Failed to change password",
      });
    },
  });

  // Wallet connect/disconnect mutation
  const updateWalletMutation = useMutation({
    mutationFn: async (walletAddress: string | null) => {
      if (walletAddress) {
        // Connect wallet
        const response = await apiRequest("PATCH", "/api/users/wallet", {
          walletAddress,
          network: "ethereum",
        });
        return response.json();
      } else {
        // Disconnect wallet
        const response = await apiRequest("DELETE", "/api/users/wallet");
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Wallet updated",
        description: "Your wallet connection has been updated.",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Wallet update failed",
        description: error instanceof Error ? error.message : "Failed to update wallet connection",
      });
    },
  });

  // Handle profile form submission
  async function onSubmitProfile(data: ProfileFormValues) {
    // Include the selected avatar
    const updatedData = {
      ...data,
      avatar: selectedAvatar || null,
    };
    
    updateProfileMutation.mutate(updatedData);
  }

  // Handle password form submission
  async function onSubmitPassword(data: PasswordFormValues) {
    changePasswordMutation.mutate(data);
  }

  // Handle wallet connect
  const handleConnectWallet = async () => {
    // Redirect to wallet auth page
    navigate('/eth-wallet-auth');
  };

  // Handle wallet disconnect
  const handleDisconnectWallet = () => {
    updateWalletMutation.mutate(null);
  };

  // Handle logout
  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  if (!user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-t-2 border-b-2 border-primary rounded-full mx-auto"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header openMobileMenu={() => setMobileMenuOpen(true)} />
      
      <div className="flex flex-1 relative">
        <MobileDrawer 
          isOpen={mobileMenuOpen} 
          onClose={() => setMobileMenuOpen(false)} 
        />
        
        <Sidebar />
        
        <main className="flex-1 max-w-4xl mx-auto p-4 lg:px-8 pb-24 md:pb-6">
          <h1 className="text-2xl font-bold mb-6">Account Settings</h1>
          
          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="w-full md:w-auto grid grid-cols-3 gap-1">
              <TabsTrigger value="profile" className="crypto-card hover:crypto-glow">Profile</TabsTrigger>
              <TabsTrigger value="account" className="crypto-card hover:crypto-glow">Account</TabsTrigger>
              <TabsTrigger value="wallet" className="crypto-card hover:crypto-glow">Wallet</TabsTrigger>
            </TabsList>
            
            {/* Profile Tab */}
            <TabsContent value="profile" className="mt-6">
              <Card className="crypto-card">
                <CardHeader>
                  <CardTitle className="crypto-text-gradient">Profile Information</CardTitle>
                  <CardDescription>
                    Update your profile details and how others see you on the platform
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...profileForm}>
                    <form onSubmit={profileForm.handleSubmit(onSubmitProfile)} className="space-y-6">
                      <FormField
                        control={profileForm.control}
                        name="displayName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Display Name</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Your display name" 
                                {...field} 
                                className="bg-[#1a2747] border-[#2a3c6a] text-white" 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={profileForm.control}
                        name="bio"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Bio</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Tell others about yourself..." 
                                {...field} 
                                className="bg-[#1a2747] border-[#2a3c6a] text-white min-h-[100px]" 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div>
                        <Label htmlFor="avatar" className="block mb-2">Profile Avatar</Label>
                        <div className="grid grid-cols-5 gap-2">
                          {AVATAR_OPTIONS.map((avatar, index) => (
                            <div 
                              key={index}
                              className={`
                                w-full aspect-square rounded-full overflow-hidden cursor-pointer border-2 
                                ${selectedAvatar === avatar ? 'border-primary crypto-glow' : 'border-transparent'}
                              `}
                              onClick={() => setSelectedAvatar(avatar)}
                            >
                              <img 
                                src={avatar} 
                                alt={`Avatar option ${index + 1}`} 
                                className="h-full w-full object-cover"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <Button
                        type="submit"
                        className="w-full crypto-button-gradient"
                        disabled={updateProfileMutation.isPending}
                      >
                        {updateProfileMutation.isPending ? (
                          <span className="flex items-center justify-center">
                            <span className="animate-spin h-4 w-4 mr-2 border-2 border-t-transparent border-white rounded-full"></span>
                            Saving...
                          </span>
                        ) : 'Save Profile'}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Account Tab */}
            <TabsContent value="account" className="mt-6">
              <div className="grid gap-6">
                <Card className="crypto-card">
                  <CardHeader>
                    <CardTitle className="crypto-text-gradient">Change Password</CardTitle>
                    <CardDescription>
                      Update your password to secure your account
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...passwordForm}>
                      <form onSubmit={passwordForm.handleSubmit(onSubmitPassword)} className="space-y-4">
                        <FormField
                          control={passwordForm.control}
                          name="currentPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Current Password</FormLabel>
                              <FormControl>
                                <Input 
                                  type="password" 
                                  placeholder="••••••" 
                                  {...field} 
                                  className="bg-[#1a2747] border-[#2a3c6a] text-white" 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="newPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>New Password</FormLabel>
                              <FormControl>
                                <Input 
                                  type="password" 
                                  placeholder="••••••" 
                                  {...field} 
                                  className="bg-[#1a2747] border-[#2a3c6a] text-white" 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={passwordForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Confirm Password</FormLabel>
                              <FormControl>
                                <Input 
                                  type="password" 
                                  placeholder="••••••" 
                                  {...field} 
                                  className="bg-[#1a2747] border-[#2a3c6a] text-white" 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button
                          type="submit"
                          className="w-full"
                          disabled={changePasswordMutation.isPending}
                        >
                          {changePasswordMutation.isPending ? (
                            <span className="flex items-center justify-center">
                              <span className="animate-spin h-4 w-4 mr-2 border-2 border-t-transparent border-white rounded-full"></span>
                              Updating...
                            </span>
                          ) : 'Change Password'}
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
                
                <Card className="crypto-card">
                  <CardHeader>
                    <CardTitle className="crypto-text-gradient">Account Preferences</CardTitle>
                    <CardDescription>
                      Customize your account settings
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Dark Mode</h3>
                        <p className="text-sm text-muted-foreground">Toggle between dark and light theme</p>
                      </div>
                      <Switch
                        checked={isDarkMode}
                        onCheckedChange={setIsDarkMode}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Email Notifications</h3>
                        <p className="text-sm text-muted-foreground">Receive email notifications</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="crypto-card border-destructive/20">
                  <CardHeader>
                    <CardTitle className="text-destructive">Danger Zone</CardTitle>
                    <CardDescription>
                      Actions that can't be undone
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button
                      variant="destructive"
                      className="w-full"
                      onClick={handleLogout}
                    >
                      Log Out
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* Wallet Tab */}
            <TabsContent value="wallet" className="mt-6">
              <Card className="crypto-card">
                <CardHeader>
                  <CardTitle className="crypto-text-gradient">Wallet Connection</CardTitle>
                  <CardDescription>
                    Connect your crypto wallet to enable additional features
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="p-4 rounded-lg border border-[#2a3c6a] bg-[#1a2747]">
                      <div className="flex justify-between items-center">
                        <div>
                          <h3 className="font-medium">Wallet Status</h3>
                          <div className="mt-1">
                            {user.walletAddress ? (
                              <div className="flex items-center text-sm">
                                <span className="inline-block h-2 w-2 rounded-full bg-green-500 mr-2"></span>
                                <span className="text-muted-foreground">Connected</span>
                              </div>
                            ) : (
                              <div className="flex items-center text-sm">
                                <span className="inline-block h-2 w-2 rounded-full bg-yellow-500 mr-2"></span>
                                <span className="text-muted-foreground">Not connected</span>
                              </div>
                            )}
                          </div>
                        </div>
                        {user.walletAddress ? (
                          <div className="flex flex-col items-end">
                            <span className="text-xs text-muted-foreground mb-1">Wallet Address</span>
                            <code className="text-xs bg-[#0f172a] p-1 rounded">
                              {user.walletAddress.substring(0, 6)}...{user.walletAddress.substring(user.walletAddress.length - 4)}
                            </code>
                          </div>
                        ) : null}
                      </div>
                    </div>
                    
                    {user.walletAddress ? (
                      <Button
                        variant="outline"
                        className="w-full border-destructive text-destructive hover:bg-destructive/10"
                        onClick={handleDisconnectWallet}
                        disabled={updateWalletMutation.isPending}
                      >
                        {updateWalletMutation.isPending ? (
                          <span className="flex items-center justify-center">
                            <span className="animate-spin h-4 w-4 mr-2 border-2 border-t-transparent border-destructive rounded-full"></span>
                            Disconnecting...
                          </span>
                        ) : 'Disconnect Wallet'}
                      </Button>
                    ) : (
                      <Button
                        className="w-full crypto-button-gradient"
                        onClick={handleConnectWallet}
                        disabled={updateWalletMutation.isPending}
                      >
                        {updateWalletMutation.isPending ? (
                          <span className="flex items-center justify-center">
                            <span className="animate-spin h-4 w-4 mr-2 border-2 border-t-transparent border-white rounded-full"></span>
                            Connecting...
                          </span>
                        ) : (
                          <span className="flex items-center justify-center">
                            <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M11.9993 2L11.8047 2.65593V16.3047L11.9993 16.4993L18.5173 12.615L11.9993 2Z" fill="#39A1FF"/>
                              <path d="M11.999 2L5.48096 12.615L11.999 16.4993V9.723V2Z" fill="#91CBF5"/>
                              <path d="M11.9993 17.8961L11.8906 18.0292V22.5383L11.9993 22.852L18.5213 14.0151L11.9993 17.8961Z" fill="#39A1FF"/>
                              <path d="M11.999 22.8519V17.8961L5.48096 14.015L11.999 22.8519Z" fill="#91CBF5"/>
                              <path d="M11.999 16.4993L18.5171 12.6151L11.999 9.72305V16.4993Z" fill="#1D62E0"/>
                              <path d="M5.48096 12.6151L11.999 16.4993V9.72305L5.48096 12.6151Z" fill="#7BA6E7"/>
                            </svg>
                            Connect Wallet
                          </span>
                        )}
                      </Button>
                    )}
                    
                    <div className="rounded-lg p-4 bg-[#1a2747] border border-[#2a3c6a]">
                      <h4 className="font-medium mb-2">Benefits of connecting your wallet</h4>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-start">
                          <span className="text-primary mr-2">✓</span>
                          <span>Login with your wallet - no password needed</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-primary mr-2">✓</span>
                          <span>Display your ENS name and NFT avatars</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-primary mr-2">✓</span>
                          <span>Verify your identity with your blockchain credentials</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-primary mr-2">✓</span>
                          <span>Access Web3 features like token-gated content</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
      
      <MobileNav onCreatePost={() => setCreatePostOpen(true)} />
      
      <Dialog open={createPostOpen} onOpenChange={setCreatePostOpen}>
        <DialogContent className="bg-elevation2 border-elevation4">
          <DialogHeader>
            <DialogTitle>Create a new post</DialogTitle>
          </DialogHeader>
          <CreatePostInput inDialog onComplete={() => setCreatePostOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}