import { useState } from "react";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import MobileDrawer from "@/components/MobileDrawer";
import MobileNav from "@/components/MobileNav";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import CreatePostInput from "@/components/CreatePostInput";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// For demo purposes, we'll use static notifications
const notifications = [
  {
    id: 1,
    type: "like",
    user: {
      displayName: "Alex Williams",
      username: "alexw",
      avatar: "/crypto-avatar-1.png"
    },
    post: "Just launched my new project!",
    time: "2h ago"
  },
  {
    id: 2,
    type: "follow",
    user: {
      displayName: "Maya Rodriguez",
      username: "mayar",
      avatar: "/crypto-avatar-2.png"
    },
    time: "3h ago"
  },
  {
    id: 3,
    type: "comment",
    user: {
      displayName: "Daniel Kim",
      username: "danielk",
      avatar: "/crypto-avatar-3.png"
    },
    comment: "I'll be there too! Let's connect.",
    post: "Attending the React Conference this weekend",
    time: "5h ago"
  },
  {
    id: 4,
    type: "mention",
    user: {
      displayName: "Sophia Chen",
      username: "sophiac",
      avatar: "/crypto-avatar-4.png"
    },
    post: "Hey @user, check out this new design tool!",
    time: "1d ago"
  }
];

export default function Notifications() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [createPostOpen, setCreatePostOpen] = useState(false);

  return (
    <div className="flex flex-col min-h-screen">
      <Header openMobileMenu={() => setMobileMenuOpen(true)} />
      
      <div className="flex flex-1 relative">
        <MobileDrawer 
          isOpen={mobileMenuOpen} 
          onClose={() => setMobileMenuOpen(false)} 
        />
        
        <Sidebar />
        
        <main className="flex-1 max-w-2xl mx-auto border-l border-r border-elevation4 min-h-[calc(100vh-4rem)]">
          <div className="p-4 border-b border-elevation4">
            <h1 className="text-xl font-medium">Notifications</h1>
          </div>
          
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="w-full grid grid-cols-3 bg-elevation2">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="mentions">Mentions</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="divide-y divide-elevation4">
              {notifications.length === 0 ? (
                <div className="p-4 text-center py-10">
                  <span className="material-icons text-4xl text-gray-400 mb-2">notifications_off</span>
                  <p className="text-gray-400">No notifications yet</p>
                </div>
              ) : (
                notifications.map(notification => (
                  <div key={notification.id} className="p-4 hover:bg-elevation1">
                    <div className="flex">
                      <div className="mr-3">
                        <div className="h-10 w-10 rounded-full ring-2 ring-primary bg-[#141e33] flex items-center justify-center overflow-hidden">
                          <img 
                            src={notification.user.avatar} 
                            alt={`${notification.user.displayName}'s avatar`} 
                            className="h-full w-full object-cover"
                          />
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{notification.user.displayName}</span>
                          
                          {notification.type === 'like' && (
                            <>
                              <span className="material-icons text-red-500 text-sm">favorite</span>
                              <span>liked your post</span>
                            </>
                          )}
                          
                          {notification.type === 'follow' && (
                            <>
                              <span className="material-icons text-primary text-sm">person_add</span>
                              <span>started following you</span>
                            </>
                          )}
                          
                          {notification.type === 'comment' && (
                            <>
                              <span className="material-icons text-blue-500 text-sm">comment</span>
                              <span>commented on your post</span>
                            </>
                          )}
                          
                          {notification.type === 'mention' && (
                            <>
                              <span className="material-icons text-green-500 text-sm">alternate_email</span>
                              <span>mentioned you</span>
                            </>
                          )}
                        </div>
                        
                        {notification.post && (
                          <p className="text-gray-400 mt-1">"{notification.post}"</p>
                        )}
                        
                        {notification.comment && (
                          <p className="text-gray-400 mt-1">"{notification.comment}"</p>
                        )}
                        
                        <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </TabsContent>
            
            <TabsContent value="mentions" className="divide-y divide-elevation4">
              {notifications.filter(n => n.type === 'mention').length === 0 ? (
                <div className="p-4 text-center py-10">
                  <span className="material-icons text-4xl text-gray-400 mb-2">alternate_email</span>
                  <p className="text-gray-400">No mentions yet</p>
                </div>
              ) : (
                notifications
                  .filter(n => n.type === 'mention')
                  .map(notification => (
                    <div key={notification.id} className="p-4 hover:bg-elevation1">
                      <div className="flex">
                        <div className="mr-3">
                          <div className="h-10 w-10 rounded-full overflow-hidden">
                            <img 
                              src={notification.user.avatar} 
                              alt={`${notification.user.displayName}'s avatar`} 
                              className="h-full w-full object-cover"
                            />
                          </div>
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{notification.user.displayName}</span>
                            <span className="material-icons text-green-500 text-sm">alternate_email</span>
                            <span>mentioned you</span>
                          </div>
                          
                          <p className="text-gray-400 mt-1">"{notification.post}"</p>
                          <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                        </div>
                      </div>
                    </div>
                  ))
              )}
            </TabsContent>
            
            <TabsContent value="activity" className="divide-y divide-elevation4">
              {notifications.filter(n => n.type !== 'mention').length === 0 ? (
                <div className="p-4 text-center py-10">
                  <span className="material-icons text-4xl text-gray-400 mb-2">notifications_active</span>
                  <p className="text-gray-400">No activity yet</p>
                </div>
              ) : (
                notifications
                  .filter(n => n.type !== 'mention')
                  .map(notification => (
                    <div key={notification.id} className="p-4 hover:bg-elevation1">
                      <div className="flex">
                        <div className="mr-3">
                          <div className="h-10 w-10 rounded-full overflow-hidden">
                            <img 
                              src={notification.user.avatar} 
                              alt={`${notification.user.displayName}'s avatar`} 
                              className="h-full w-full object-cover"
                            />
                          </div>
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{notification.user.displayName}</span>
                            
                            {notification.type === 'like' && (
                              <>
                                <span className="material-icons text-red-500 text-sm">favorite</span>
                                <span>liked your post</span>
                              </>
                            )}
                            
                            {notification.type === 'follow' && (
                              <>
                                <span className="material-icons text-primary text-sm">person_add</span>
                                <span>started following you</span>
                              </>
                            )}
                            
                            {notification.type === 'comment' && (
                              <>
                                <span className="material-icons text-blue-500 text-sm">comment</span>
                                <span>commented on your post</span>
                              </>
                            )}
                          </div>
                          
                          {notification.post && (
                            <p className="text-gray-400 mt-1">"{notification.post}"</p>
                          )}
                          
                          {notification.comment && (
                            <p className="text-gray-400 mt-1">"{notification.comment}"</p>
                          )}
                          
                          <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                        </div>
                      </div>
                    </div>
                  ))
              )}
            </TabsContent>
          </Tabs>
        </main>
      </div>
      
      <MobileNav onCreatePost={() => setCreatePostOpen(true)} />
      
      <Dialog open={createPostOpen} onOpenChange={setCreatePostOpen}>
        <DialogContent className="bg-elevation2 border-elevation4">
          <DialogHeader>
            <DialogTitle>Create a new post</DialogTitle>
          </DialogHeader>
          <CreatePostInput inDialog onComplete={() => setCreatePostOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
