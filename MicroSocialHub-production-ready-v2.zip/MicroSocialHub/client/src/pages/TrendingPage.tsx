import React, { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { PostWithUser } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import PostCard from "@/components/PostCard";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Loader2, TrendingUp, Users, Hash } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChevronLeft } from "lucide-react";

export default function TrendingPage() {
  const params = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const hashtag = params.hashtag;
  const [postCount, setPostCount] = useState(0);
  const [userCount, setUserCount] = useState(0);
  
  // Fetch posts containing the hashtag
  const { data: posts, isLoading: isLoadingPosts } = useQuery<PostWithUser[]>({
    queryKey: [`/api/posts/hashtag/${hashtag}`],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/posts/hashtag/${hashtag}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch trending posts');
        }
        
        const data = await response.json();
        
        // Update metrics
        if (data.posts) {
          setPostCount(data.postCount || data.posts.length);
          setUserCount(data.userCount || new Set(data.posts.map((post: PostWithUser) => post.userId)).size);
          return data.posts;
        }
        
        return [];
      } catch (error) {
        console.error("Error fetching trending posts:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load trending posts",
        });
        return [];
      }
    },
    enabled: !!hashtag
  });
  
  // Handle case where hashtag doesn't exist
  if (hashtag === undefined) {
    return (
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-1 container max-w-5xl mx-auto px-4 py-6">
          <div className="text-center py-12">
            <h1 className="text-3xl font-bold mb-4">Trending Topics</h1>
            <p className="text-gray-400 mb-8">Discover what people are talking about</p>
            <Button
              onClick={() => navigate('/explore')}
              className="bg-primary hover:bg-primary/90"
            >
              Explore Trending Topics
            </Button>
          </div>
        </main>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1 container max-w-5xl mx-auto px-4">
        <div className="py-4 border-b border-[#1a2747]">
          <div className="flex items-center justify-between mb-2">
            <button 
              onClick={() => navigate("/")} 
              className="flex items-center text-gray-400 hover:text-primary transition-colors"
            >
              <ChevronLeft className="h-5 w-5 mr-1" />
              <span>Back</span>
            </button>
          </div>
          <div className="flex items-center gap-2 mb-1">
            <Hash className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-bold crypto-text-gradient">#{hashtag}</h1>
          </div>
          
          <div className="flex space-x-4 mt-2 text-gray-400">
            <div className="flex items-center gap-1">
              <TrendingUp className="h-4 w-4" />
              <span>{postCount} posts</span>
            </div>
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              <span>{userCount} users talking about this</span>
            </div>
          </div>
        </div>
        
        <Tabs defaultValue="posts" className="mt-4">
          <TabsList className="bg-[#141e33] border-b border-[#1a2747] mb-4">
            <TabsTrigger value="posts">Posts</TabsTrigger>
            <TabsTrigger value="media">Media</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
          </TabsList>
          
          <TabsContent value="posts">
            {isLoadingPosts ? (
              <div className="flex justify-center items-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : posts && posts.length > 0 ? (
              <div className="divide-y divide-[#1a2747]">
                {posts.map(post => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <h2 className="text-xl font-bold mb-2">No posts found</h2>
                <p className="text-gray-400 mb-6">Be the first to post about #{hashtag}</p>
                <Button
                  onClick={() => navigate('/')}
                  className="bg-primary hover:bg-primary/90"
                >
                  Create a Post
                </Button>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="media">
            {isLoadingPosts ? (
              <div className="flex justify-center items-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : posts && posts.filter(post => post.image || post.video).length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {posts
                  .filter(post => post.image || post.video)
                  .map(post => (
                    <div 
                      key={post.id} 
                      className="aspect-square bg-[#141e33] rounded-xl overflow-hidden cursor-pointer hover:ring-2 hover:ring-primary transition-all"
                      onClick={() => navigate(`/post/${post.id}`)}
                    >
                      {post.image && (
                        <img 
                          src={post.image} 
                          alt={`Post by ${post.user.username}`}
                          className="w-full h-full object-cover" 
                        />
                      )}
                      {post.video && (
                        <div className="relative w-full h-full">
                          <video
                            src={post.video}
                            className="w-full h-full object-cover"
                            preload="metadata"
                          />
                          <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30">
                            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white opacity-80">
                              <polygon points="5 3 19 12 5 21 5 3"/>
                            </svg>
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                }
              </div>
            ) : (
              <div className="text-center py-12">
                <h2 className="text-xl font-bold mb-2">No media found</h2>
                <p className="text-gray-400 mb-6">Be the first to post media about #{hashtag}</p>
                <Button
                  onClick={() => navigate('/')}
                  className="bg-primary hover:bg-primary/90"
                >
                  Create a Post
                </Button>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="users">
            {isLoadingPosts ? (
              <div className="flex justify-center items-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : posts && posts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Array.from(new Map(posts.map(post => [post.userId, post.user])).values()).map(user => {
                  // Count how many posts this user has made with this hashtag
                  const userPostCount = posts.filter(post => post.userId === user.id).length;
                  
                  return (
                    <div 
                      key={user.id} 
                      className="p-4 bg-[#141e33] rounded-xl border border-[#1a2747] hover:border-primary transition-colors cursor-pointer"
                      onClick={() => navigate(`/profile/${user.username}`)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="h-12 w-12 rounded-full overflow-hidden ring-2 ring-primary flex-shrink-0">
                          {user.avatar ? (
                            <img 
                              src={user.avatar} 
                              alt={`${user.displayName}'s avatar`}
                              className="h-full w-full object-cover" 
                            />
                          ) : (
                            <div className="h-full w-full bg-[#1a2747] flex items-center justify-center">
                              <span className="text-primary font-bold">{user.displayName.charAt(0)}</span>
                            </div>
                          )}
                        </div>
                        <div>
                          <h3 className="font-bold">{user.displayName}</h3>
                          <p className="text-gray-400 text-sm">@{user.username}</p>
                          <p className="text-xs text-primary mt-1">
                            {userPostCount} {userPostCount === 1 ? 'post' : 'posts'} about #{hashtag}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <h2 className="text-xl font-bold mb-2">No users found</h2>
                <p className="text-gray-400 mb-6">Be the first to post about #{hashtag}</p>
                <Button
                  onClick={() => navigate('/')}
                  className="bg-primary hover:bg-primary/90"
                >
                  Create a Post
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}