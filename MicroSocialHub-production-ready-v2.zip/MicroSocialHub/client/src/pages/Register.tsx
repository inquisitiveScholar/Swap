import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters").max(30, "Username cannot exceed 30 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  displayName: z.string().min(1, "Display name is required"),
  bio: z.string().optional(),
  avatar: z.string().optional(),
});

type RegisterFormValues = z.infer<typeof registerSchema>;

export default function Register() {
  const [, navigate] = useLocation();
  const { register } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      displayName: "",
      bio: "",
      avatar: "",
    },
  });

  async function onSubmit(values: RegisterFormValues) {
    setIsLoading(true);
    try {
      await register(values);
      toast({
        title: "Registration successful",
        description: "Your account has been created",
      });
      navigate("/");
    } catch (error) {
      console.error("Registration error:", error);
    } finally {
      setIsLoading(false);
    }
  }

  // For demo purposes only - this would normally be replaced with a proper image upload functionality
  const avatarOptions = [
    { value: "", label: "No Avatar" },
    { value: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50", label: "Avatar 1" },
    { value: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50", label: "Avatar 2" },
    { value: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50", label: "Avatar 3" },
    { value: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50", label: "Avatar 4" },
    { value: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50", label: "Avatar 5" },
    { value: "https://images.unsplash.com/photo-1463453091185-61582044d556?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50", label: "Avatar 6" },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#0f172a]">
      <Card className="w-full max-w-md bg-[#141e33] border border-[#1a2747] rounded-xl">
        <CardHeader className="space-y-2">
          <div className="flex justify-center mb-4">
            <h1 className="text-3xl font-bold text-primary">hey<span className="text-white">.</span></h1>
          </div>
          <CardTitle className="text-2xl text-center font-bold text-white">Create an account</CardTitle>
          <CardDescription className="text-center text-gray-400 text-base">
            Enter your information to create your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-white font-medium">Username</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter a unique username" 
                        className="bg-[#0f172a] border-[#1a2747] h-12 rounded-xl focus-visible:ring-primary" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage className="text-secondary" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-white font-medium">Password</FormLabel>
                    <FormControl>
                      <Input 
                        type="password" 
                        placeholder="Create a password" 
                        className="bg-[#0f172a] border-[#1a2747] h-12 rounded-xl focus-visible:ring-primary" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage className="text-secondary" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="displayName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-white font-medium">Display Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Your name to display" 
                        className="bg-[#0f172a] border-[#1a2747] h-12 rounded-xl focus-visible:ring-primary" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage className="text-secondary" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="bio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-white font-medium">Bio</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Tell us about yourself" 
                        className="bg-[#0f172a] border-[#1a2747] min-h-[100px] rounded-xl resize-none focus-visible:ring-primary" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage className="text-secondary" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="avatar"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-white font-medium">Avatar</FormLabel>
                    <FormControl>
                      <div className="space-y-3">
                        <div className="flex flex-wrap gap-3">
                          {avatarOptions.map((option) => (
                            <div 
                              key={option.value} 
                              className={`h-14 w-14 rounded-full cursor-pointer ${field.value === option.value ? 'ring-2 ring-primary border-4 border-[#141e33]' : 'border-2 border-[#1a2747]'} overflow-hidden flex items-center justify-center ${!option.value ? 'bg-[#0f172a]' : ''}`}
                              onClick={() => field.onChange(option.value)}
                            >
                              {option.value ? (
                                <img src={option.value} alt={option.label} className="h-full w-full object-cover" />
                              ) : (
                                <span className="material-icons text-primary">person</span>
                              )}
                            </div>
                          ))}
                        </div>
                        {field.value && (
                          <div className="flex items-center gap-2">
                            <div className="h-8 w-8 rounded-full overflow-hidden border border-[#1a2747]">
                              <img src={field.value} alt="Selected avatar" className="h-full w-full object-cover" />
                            </div>
                            <span className="text-sm text-gray-400">Selected avatar</span>
                          </div>
                        )}
                      </div>
                    </FormControl>
                    <FormMessage className="text-secondary" />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary/90 text-white py-6 rounded-xl font-bold text-base transition-all mt-2"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <div className="w-5 h-5 border-t-2 border-b-2 border-white rounded-full animate-spin mr-2"></div>
                    Creating account...
                  </div>
                ) : (
                  "Create Account"
                )}
              </Button>
            </form>
          </Form>
          
          <div className="mt-6 text-center">
            <p className="text-gray-400">
              Already have an account?{" "}
              <a 
                href="/login" 
                className="text-primary hover:underline font-medium"
                onClick={(e) => {
                  e.preventDefault();
                  navigate("/login");
                }}
              >
                Sign in
              </a>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
