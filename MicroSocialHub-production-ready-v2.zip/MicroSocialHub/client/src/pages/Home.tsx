import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import MobileNav from "@/components/MobileNav";
import CreatePostInput from "@/components/CreatePostInput";
import PostCard from "@/components/PostCard";
import TrendingSection from "@/components/TrendingSection";
import UserSuggestions from "@/components/UserSuggestions";
import { usePosts } from "@/hooks/usePosts";
import { queryClient } from "@/lib/queryClient";

export default function Home() {
  const [createPostOpen, setCreatePostOpen] = useState(false);
  const { data: posts = [], isLoading, isError, refetch } = usePosts();

  // Auto-refresh posts every 30 seconds to show new content
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
    }, 30000); // 30 seconds

    return () => clearInterval(interval);
  }, [refetch]);

  return (
    <div className="flex flex-col min-h-screen bg-[#0f172a]">
      <Header />
      
      <div className="flex flex-1 relative">
        <Sidebar />
        
        <main className="flex-1 max-w-2xl mx-auto border-l border-r border-[#1a2747] min-h-[calc(100vh-57px)]">
          <CreatePostInput />
          
          <div>
            {isLoading ? (
              <div className="p-6 text-center">
                <div className="animate-spin h-10 w-10 border-t-2 border-b-2 border-primary rounded-full mx-auto"></div>
                <p className="mt-3 text-gray-400">Loading posts...</p>
              </div>
            ) : isError ? (
              <div className="p-6 text-center">
                <p className="text-secondary">Failed to load posts. Please try again.</p>
              </div>
            ) : posts.length === 0 ? (
              <div className="p-6 text-center">
                <p className="text-gray-400">No posts yet. Be the first to post!</p>
              </div>
            ) : (
              posts.map(post => (
                <PostCard key={post.id} post={post} />
              ))
            )}
          </div>
        </main>
        
        <aside className="hidden lg:block w-80 p-4 sticky top-[57px] h-[calc(100vh-57px)] overflow-y-auto scrollbar-hide">
          <TrendingSection />
          <UserSuggestions />
          
          <div className="bg-[#141e33] rounded-xl p-4 border border-[#1a2747] text-sm text-gray-400">
            <div className="mb-4 flex flex-wrap gap-2">
              <a href="#" className="hover:text-primary hover:underline transition-colors">Terms</a>
              <a href="#" className="hover:text-primary hover:underline transition-colors">Privacy</a>
              <a href="#" className="hover:text-primary hover:underline transition-colors">Cookies</a>
              <a href="#" className="hover:text-primary hover:underline transition-colors">About</a>
              <a href="#" className="hover:text-primary hover:underline transition-colors">More</a>
            </div>
            <div>© 2025 Hey, Inc.</div>
          </div>
        </aside>
      </div>
      
      <MobileNav onCreatePost={() => setCreatePostOpen(true)} />
      
      <Dialog open={createPostOpen} onOpenChange={setCreatePostOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl">
          <DialogHeader>
            <DialogTitle className="text-lg text-white font-bold">Create a new post</DialogTitle>
          </DialogHeader>
          <CreatePostInput inDialog onComplete={() => setCreatePostOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
