import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import MobileDrawer from "@/components/MobileDrawer";
import MobileNav from "@/components/MobileNav";
import TrendingSection from "@/components/TrendingSection";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import CreatePostInput from "@/components/CreatePostInput";
import { useQuery } from "@tanstack/react-query";
import { usePosts } from "@/hooks/usePosts";
import PostCard from "@/components/PostCard";

export default function Explore() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [createPostOpen, setCreatePostOpen] = useState(false);
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  // Extract query from URL if present
  useEffect(() => {
    const params = new URLSearchParams(location.split("?")[1] || "");
    const q = params.get("q");
    if (q) {
      setSearchQuery(q);
    }
  }, [location]);

  // Search users if search query is present
  const { data: searchResults = [], isLoading: isLoadingSearch } = useQuery({
    queryKey: ["/api/users/search", searchQuery],
    queryFn: async () => {
      if (!searchQuery.trim()) return [];
      
      const response = await fetch(`/api/users/search?q=${encodeURIComponent(searchQuery)}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to search users");
      }
      
      return response.json();
    },
    enabled: !!searchQuery.trim()
  });

  // Get posts for explore page
  const { data: posts = [], isLoading: isLoadingPosts } = usePosts(10, 0);

  // Filter posts if search query is present
  const filteredPosts = searchQuery.trim()
    ? posts.filter(post => 
        post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.user.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.user.username.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : posts;

  return (
    <div className="flex flex-col min-h-screen">
      <Header openMobileMenu={() => setMobileMenuOpen(true)} />
      
      <div className="flex flex-1 relative">
        <MobileDrawer 
          isOpen={mobileMenuOpen} 
          onClose={() => setMobileMenuOpen(false)} 
        />
        
        <Sidebar />
        
        <main className="flex-1 max-w-2xl mx-auto border-l border-r border-elevation4 min-h-[calc(100vh-4rem)]">
          <div className="p-4 border-b border-elevation4 md:hidden">
            <Input
              type="search"
              placeholder="Search Micro..."
              className="rounded-full bg-elevation2"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          {searchQuery ? (
            <>
              <div className="p-4 border-b border-elevation4">
                <h2 className="text-xl font-medium">Search results for "{searchQuery}"</h2>
              </div>
              
              {isLoadingSearch ? (
                <div className="p-4 text-center">
                  <div className="animate-spin h-8 w-8 border-t-2 border-b-2 border-primary rounded-full mx-auto"></div>
                  <p className="mt-2">Searching...</p>
                </div>
              ) : (
                <>
                  {searchResults.length > 0 && (
                    <div className="p-4 border-b border-elevation4">
                      <h3 className="text-lg font-medium mb-3">People</h3>
                      <div className="space-y-4">
                        {searchResults.map((user: any) => (
                          <a 
                            key={user.id} 
                            href={`/profile/${user.username}`}
                            className="flex items-center p-2 hover:bg-elevation1 rounded-lg"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate(`/profile/${user.username}`);
                            }}
                          >
                            <div className="h-10 w-10 rounded-full overflow-hidden mr-3">
                              {user.avatar ? (
                                <img src={user.avatar} alt={`${user.displayName}'s avatar`} className="h-full w-full object-cover" />
                              ) : (
                                <div className="h-full w-full bg-primary flex items-center justify-center">
                                  <span className="material-icons text-sm text-primary-foreground">person</span>
                                </div>
                              )}
                            </div>
                            <div>
                              <p className="font-medium">{user.displayName}</p>
                              <p className="text-sm text-gray-400">@{user.username}</p>
                            </div>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  <div className="divide-y divide-elevation4">
                    {filteredPosts.length === 0 ? (
                      <div className="p-4 text-center py-10">
                        <span className="material-icons text-4xl text-gray-400 mb-2">search_off</span>
                        <p className="text-gray-400">No posts found matching your search</p>
                      </div>
                    ) : (
                      filteredPosts.map(post => (
                        <PostCard key={post.id} post={post} />
                      ))
                    )}
                  </div>
                </>
              )}
            </>
          ) : (
            <>
              <div className="p-4 border-b border-elevation4">
                <h2 className="text-xl font-medium">Explore</h2>
              </div>
              
              <div className="md:hidden p-4 border-b border-elevation4">
                <TrendingSection />
              </div>
              
              <div className="divide-y divide-elevation4">
                {isLoadingPosts ? (
                  <div className="p-4 text-center">
                    <div className="animate-spin h-8 w-8 border-t-2 border-b-2 border-primary rounded-full mx-auto"></div>
                    <p className="mt-2">Loading posts...</p>
                  </div>
                ) : (
                  posts.map(post => (
                    <PostCard key={post.id} post={post} />
                  ))
                )}
              </div>
            </>
          )}
        </main>
        
        <aside className="hidden lg:block w-80 p-4 sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto scrollbar-hide">
          <TrendingSection />
          
          <div className="material-elevation-1 rounded-lg p-4 mb-6">
            <h2 className="text-lg font-medium mb-3">Explore Topics</h2>
            <div className="flex flex-wrap gap-2">
              <a href="#" className="px-3 py-1 bg-elevation2 rounded-full text-sm hover:bg-elevation4">#Technology</a>
              <a href="#" className="px-3 py-1 bg-elevation2 rounded-full text-sm hover:bg-elevation4">#Design</a>
              <a href="#" className="px-3 py-1 bg-elevation2 rounded-full text-sm hover:bg-elevation4">#WebDev</a>
              <a href="#" className="px-3 py-1 bg-elevation2 rounded-full text-sm hover:bg-elevation4">#UX</a>
              <a href="#" className="px-3 py-1 bg-elevation2 rounded-full text-sm hover:bg-elevation4">#Programming</a>
              <a href="#" className="px-3 py-1 bg-elevation2 rounded-full text-sm hover:bg-elevation4">#AI</a>
              <a href="#" className="px-3 py-1 bg-elevation2 rounded-full text-sm hover:bg-elevation4">#DataScience</a>
              <a href="#" className="px-3 py-1 bg-elevation2 rounded-full text-sm hover:bg-elevation4">#JavaScript</a>
            </div>
          </div>
        </aside>
      </div>
      
      <MobileNav onCreatePost={() => setCreatePostOpen(true)} />
      
      <Dialog open={createPostOpen} onOpenChange={setCreatePostOpen}>
        <DialogContent className="bg-elevation2 border-elevation4">
          <DialogHeader>
            <DialogTitle>Create a new post</DialogTitle>
          </DialogHeader>
          <CreatePostInput inDialog onComplete={() => setCreatePostOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
