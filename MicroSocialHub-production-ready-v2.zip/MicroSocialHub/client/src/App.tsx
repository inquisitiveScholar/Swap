import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ProtectedRoute } from "@/lib/protected-route";
import NotFound from "@/pages/not-found";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { SimpleWeb3Provider } from "./context/simplified-web3-context";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Auth from "./pages/Auth";
import EthWalletAuthPage from "./pages/eth-wallet-auth";
import Profile from "./pages/Profile";
import UserSettings from "./pages/UserSettings";
import Explore from "./pages/Explore";
import TrendingPage from "./pages/TrendingPage";

function Router() {
  const authContext = useAuth();

  return (
    <Switch>
      {/* Authentication & Login Routes */}
      <Route path="/auth" component={Auth} />
      <Route path="/login" component={Login} />
      <Route path="/eth-wallet-auth" component={EthWalletAuthPage} />
      
      {/* Protected Routes */}
      <ProtectedRoute path="/" component={Home} />
      <Route path="/profile/:username" component={({params}) => <Profile username={params.username} />} />
      <ProtectedRoute path="/profile" component={() => (
        <Profile username={authContext.user?.username || ""} />
      )} />
      <ProtectedRoute path="/settings" component={UserSettings} />
      <ProtectedRoute path="/explore" component={Explore} />
      <Route path="/trending/:hashtag" component={TrendingPage} />
      <ProtectedRoute path="/trending" component={TrendingPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

// We're using our SimpleWalletConnect component instead of Web3Modal
// to avoid domain verification issues in development

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <SimpleWeb3Provider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </SimpleWeb3Provider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
