import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Function to prevent duplicate slashes in URLs
export function formatUrl(url: string): string {
  // Remove multiple consecutive slashes, but preserve protocol slashes
  if (url.startsWith('http')) {
    // For URLs with protocol
    const [protocol, rest] = url.split('://')
    return `${protocol}://${rest.replace(/\/+/g, '/')}`
  }
  
  // For relative paths
  return url.replace(/\/+/g, '/')
}
