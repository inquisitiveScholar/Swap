import { ethers } from 'ethers';
import { formatUrl } from './utils';

// Simple wrapper for ethereum provider interactions
export class WalletConnector {
  private provider: ethers.BrowserProvider | null = null;
  private signer: ethers.JsonRpcSigner | null = null;
  
  constructor() {
    // Check if window.ethereum is available
    if (typeof window !== 'undefined' && window.ethereum) {
      this.provider = new ethers.BrowserProvider(window.ethereum);
    }
  }
  
  /**
   * Check if MetaMask or other wallet provider is available
   */
  isWalletAvailable(): boolean {
    return this.provider !== null;
  }
  
  /**
   * Connect to the wallet and return the address
   */
  async connect(): Promise<string> {
    if (!this.provider) {
      throw new Error("No Ethereum wallet detected. Please install MetaMask or another Web3 wallet.");
    }
    
    try {
      // Request account access
      const accounts = await this.provider.send("eth_requestAccounts", []);
      
      // Get the signer
      this.signer = await this.provider.getSigner();
      
      // Return the connected address
      return accounts[0];
    } catch (error) {
      console.error("Error connecting to wallet:", error);
      throw new Error("Failed to connect to your wallet");
    }
  }
  
  /**
   * Get the current connected address
   */
  async getAddress(): Promise<string | null> {
    if (!this.provider) return null;
    
    try {
      const accounts = await this.provider.send("eth_accounts", []);
      return accounts.length > 0 ? accounts[0] : null;
    } catch (error) {
      console.error("Error getting address:", error);
      return null;
    }
  }
  
  /**
   * Get the current network ID
   */
  async getNetworkId(): Promise<string> {
    if (!this.provider) return "1"; // Default to mainnet
    
    try {
      const network = await this.provider.getNetwork();
      return network.chainId.toString();
    } catch (error) {
      console.error("Error getting network:", error);
      return "1"; // Default to mainnet on error
    }
  }
  
  /**
   * Sign a message to verify wallet ownership
   */
  async signMessage(message: string): Promise<string> {
    if (!this.signer) {
      throw new Error("No wallet connected");
    }
    
    try {
      return await this.signer.signMessage(message);
    } catch (error) {
      console.error("Error signing message:", error);
      throw new Error("Failed to sign message with wallet");
    }
  }
  
  /**
   * Check if a wallet is registered with the API
   */
  async checkWalletRegistration(address: string): Promise<boolean> {
    try {
      const response = await fetch(formatUrl(`/api/wallet/${address}/exists`));
      if (!response.ok) {
        throw new Error("Failed to check wallet registration");
      }
      const data = await response.json();
      return data.exists;
    } catch (error) {
      console.error("Error checking wallet:", error);
      return false;
    }
  }
  
  /**
   * Disconnect from the wallet
   */
  disconnect(): void {
    this.signer = null;
    // Note: There's no actual disconnect method in ethers.js
    // The wallet stays connected at the provider level
  }
}

// Create a singleton instance
export const walletConnector = new WalletConnector();

// Type definition for window.ethereum
declare global {
  interface Window {
    ethereum: any;
  }
}