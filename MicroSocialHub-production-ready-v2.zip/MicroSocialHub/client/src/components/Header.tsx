import { useState } from "react";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/context/AuthContext";
import { UserIcon, Settings, LogOut, User, Search, Menu, X, Tag } from "lucide-react";
import { formatUrl } from "@/lib/utils";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import SearchBar from "./SearchBar";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import MetaMaskButton from "./MetaMaskButton";


export default function Header({ openMobileMenu }: { openMobileMenu?: () => void }) {
  const [location, navigate] = useLocation();
  const { user, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchDialogOpen, setIsSearchDialogOpen] = useState(false);
  
  const handleLogout = async () => {
    try {
      await logout();
      navigate(formatUrl('/auth'));
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(formatUrl(`/explore?q=${encodeURIComponent(searchQuery)}`));
    }
  };
  
  const openSearchDialog = () => {
    setIsSearchDialogOpen(true);
  };
  
  const closeSearchDialog = () => {
    setIsSearchDialogOpen(false);
  };

  return (
    <>
      <Dialog open={isSearchDialogOpen} onOpenChange={setIsSearchDialogOpen}>
        <DialogContent className="sm:max-w-md bg-[#0f172a] border-[#1a2747]">
          <div className="flex flex-col space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">Search Users</h2>
              <button 
                onClick={closeSearchDialog}
                className="rounded-full p-2 hover:bg-[#141e33]"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <SearchBar onClose={closeSearchDialog} />
          </div>
        </DialogContent>
      </Dialog>
    
      <header className="bg-[#0f172a] border-b border-[#1a2747] sticky top-0 z-10">
        <div className="flex items-center justify-between px-4 py-3 md:hidden">
          <div className="w-8"></div> {/* Empty div for balanced spacing */}
          <div 
            className="flex items-center cursor-pointer" 
            onClick={() => navigate("/")}
          >
            <img 
              src="https://raw.githubusercontent.com/inquisitiveScholar/decentra-social/refs/heads/main/logo.PNG" 
              alt="Social Logo" 
              className="h-8 w-8 mr-2 rounded-md"
            />
            <h1 className="text-xl font-bold bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">Social</h1>
          </div>
          <div className="flex items-center space-x-1">
            <button 
              className="p-2 rounded-full hover:bg-[#141e33] transition-colors"
              onClick={openSearchDialog}
            >
              <Search className="h-5 w-5" />
            </button>
          
            {user && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="p-1 rounded-full hover:bg-[#141e33] outline-none">
                    <div className="app-avatar-sm">
                      {user.avatar ? (
                        <img src={user.avatar} alt={`${user.displayName}'s avatar`} className="h-full w-full object-cover" />
                      ) : (
                        <UserIcon className="h-4 w-4 text-purple-500" />
                      )}
                    </div>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 bg-[#0f172a] border-[#1a2747]">
                  <DropdownMenuLabel>
                    <div className="flex flex-col">
                      <span className="font-bold">{user.displayName}</span>
                      <span className="text-gray-400 text-xs">@{user.username}</span>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate(`/profile/${user.username}`)}>
                    <User className="mr-2 h-4 w-4 text-purple-400" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate("/settings")}>
                    <Settings className="mr-2 h-4 w-4 text-blue-400" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4 text-gray-400" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
        
        <div className="hidden md:flex items-center justify-between px-6 py-3">
          <div 
            className="flex items-center cursor-pointer" 
            onClick={() => navigate("/")}
          >
            <img 
              src="https://raw.githubusercontent.com/inquisitiveScholar/decentra-social/refs/heads/main/logo.PNG" 
              alt="Social Logo" 
              className="h-10 w-10 mr-3 rounded-md"
            />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">Social</h1>
          </div>
          
          <div className="relative mx-auto w-1/3">
            <button 
              onClick={openSearchDialog}
              className="w-full flex items-center px-4 py-2 rounded-full bg-[#141e33] border border-transparent hover:border-purple-500 text-gray-400 hover:text-white focus:outline-none transition-all"
            >
              <Search className="h-4 w-4 mr-2" />
              <span className="text-gray-400">Search Micro...</span>
            </button>
          </div>
          
          <div className="flex items-center space-x-4">
            <button 
              className="p-2 rounded-full hover:bg-[#141e33] transition-colors"
              onClick={() => navigate(formatUrl("/trending"))}
            >
              <Tag className="h-5 w-5 text-blue-400" />
            </button>

            {/* MetaMask Wallet Button */}
            {!user && (
              <div className="ml-2">
                <MetaMaskButton />
              </div>
            )}
            
            {user && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="hover:bg-[#141e33] rounded-full outline-none">
                    <div className="app-avatar">
                      {user.avatar ? (
                        <img src={user.avatar} alt={`${user.displayName}'s avatar`} className="h-full w-full object-cover" />
                      ) : (
                        <UserIcon className="h-5 w-5 text-purple-500" />
                      )}
                    </div>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 bg-[#0f172a] border-[#1a2747]">
                  <DropdownMenuLabel>
                    <div className="flex flex-col">
                      <span className="font-bold">{user.displayName}</span>
                      <span className="text-gray-400 text-xs">@{user.username}</span>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate(`/profile/${user.username}`)}>
                    <User className="mr-2 h-4 w-4 text-purple-400" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate("/settings")}>
                    <Settings className="mr-2 h-4 w-4 text-blue-400" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4 text-gray-400" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </header>
    </>
  );
}