import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { PostWithUser } from "@shared/schema";
import { useAuth } from "@/context/AuthContext";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { UserIcon, Heart, MessageCircle, Repeat, Share, MoreVertical, Trash, Edit, ExternalLink, Loader2, ChevronLeft } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface PostCardProps {
  post: PostWithUser;
}

export default function PostCard({ post }: PostCardProps) {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(post.likesCount || 0);
  const [retweeted, setRetweeted] = useState(false);
  const [retweetCount, setRetweetCount] = useState(post.retweetCount || 0);
  const [isCommentOpen, setIsCommentOpen] = useState(false);
  const [comment, setComment] = useState("");
  const [commentToEdit, setCommentToEdit] = useState<any>(null);
  const [editedCommentContent, setEditedCommentContent] = useState("");
  const [comments, setComments] = useState<any[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isCommentEditDialogOpen, setIsCommentEditDialogOpen] = useState(false);
  const [isCommentDeleteDialogOpen, setIsCommentDeleteDialogOpen] = useState(false);
  const [showRetweetersDialog, setShowRetweetersDialog] = useState(false);
  const [retweetersList, setRetweetersList] = useState<any[]>([]);
  const [isLoadingRetweeters, setIsLoadingRetweeters] = useState(false);
  const [editedContent, setEditedContent] = useState(post.content);
  const [isEditing, setIsEditing] = useState(false);
  const [location, setLocation] = useState<string | null>(null);
  
  // Check if user is post owner
  const isPostOwner = user?.id === post.userId;
  
  // Check if post is liked when component mounts
  useEffect(() => {
    async function checkIfLiked() {
      if (!user) return;
      
      try {
        const res = await fetch(`/api/posts/${post.id}/like`);
        if (res.ok) {
          const data = await res.json();
          setLiked(data.liked);
        }
      } catch (error) {
        console.error("Error checking like status:", error);
      }
    }
    
    checkIfLiked();
  }, [post.id, user]);
  
  // Check if post is retweeted when component mounts
  useEffect(() => {
    async function checkIfRetweeted() {
      if (!user) return;
      
      try {
        const res = await fetch(`/api/posts/${post.id}/retweet`);
        if (res.ok) {
          const data = await res.json();
          setRetweeted(data.retweeted);
          setRetweetCount(data.retweetCount || 0);
        }
      } catch (error) {
        console.error("Error checking retweet status:", error);
      }
    }
    
    checkIfRetweeted();
  }, [post.id, user]);

  // Format the post date
  const formattedDate = formatDistanceToNow(new Date(post.createdAt), { addSuffix: true });
  
  // Like mutation
  const likeMutation = useMutation({
    mutationFn: () => {
      // Always use POST for toggling like status
      return apiRequest("POST", `/api/posts/${post.id}/like`);
    },
    onSuccess: (response) => {
      const data = response.json();
      // Update state based on response
      data.then(result => {
        setLiked(!!result.liked);
        setLikesCount(result.likesCount || post.likesCount || 0);
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update like status",
      });
    }
  });
  
  // Retweet mutation
  const retweetMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", `/api/posts/${post.id}/retweet`, {
        content: ""  // Can be empty or include additional comment
      });
    },
    onSuccess: (response) => {
      const data = response.json();
      data.then(result => {
        setRetweeted(!!result.retweeted);
        setRetweetCount(result.retweetCount || 0);
        
        // Update the posts list to show the retweet
        queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
        
        toast({
          title: result.retweeted ? "Post reshared!" : "Reshare removed",
          description: result.retweeted ? "The post has been shared to your timeline" : "The post has been removed from your timeline",
        });
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to reshare post",
      });
    }
  });

  // Comment mutation
  const commentMutation = useMutation({
    mutationFn: (content: string) => 
      apiRequest("POST", `/api/posts/${post.id}/comments`, { content }),
    onSuccess: (data) => {
      setComment("");
      // Don't close dialog, just fetch fresh comments
      fetchComments();
      
      toast({
        title: "Comment added",
        description: "Your comment has been posted",
      });
      
      // Invalidate queries to refresh comments count
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to post comment",
      });
    }
  });
  
  // Comment edit mutation
  const editCommentMutation = useMutation({
    mutationFn: () => 
      apiRequest("PATCH", `/api/comments/${commentToEdit?.id}`, { content: editedCommentContent }),
    onSuccess: () => {
      setIsCommentEditDialogOpen(false);
      setCommentToEdit(null);
      setEditedCommentContent("");
      // Refetch comments
      fetchComments();
      toast({
        title: "Comment updated",
        description: "Your comment has been updated successfully",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update comment",
      });
    }
  });
  
  // Comment delete mutation
  const deleteCommentMutation = useMutation({
    mutationFn: () => 
      apiRequest("DELETE", `/api/comments/${commentToEdit?.id}`),
    onSuccess: () => {
      setIsCommentDeleteDialogOpen(false);
      setCommentToEdit(null);
      
      // Refetch comments
      fetchComments();
      
      // Update post comment count locally
      if (post.commentsCount && post.commentsCount > 0) {
        post.commentsCount -= 1;
      }
      
      // Invalidate queries to refresh comments count
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      
      toast({
        title: "Comment deleted",
        description: "Your comment has been deleted",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete comment",
      });
    }
  });
  


  // Check if post is liked on mount
  // This would normally be done with a query, but for this demo we'll keep it simple

  const handleLike = () => {
    if (!user) {
      navigate("/auth");
      return;
    }
    
    likeMutation.mutate();
  };

  // Fetch comments when comment dialog opens
  useEffect(() => {
    if (isCommentOpen) {
      fetchComments();
    }
  }, [isCommentOpen]);
  
  // Function to fetch comments
  const fetchComments = async () => {
    if (!post.id) return;
    
    setLoadingComments(true);
    try {
      const response = await fetch(`/api/posts/${post.id}/comments`);
      if (response.ok) {
        const data = await response.json();
        setComments(data);
      }
    } catch (error) {
      console.error('Error fetching comments:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load comments",
      });
    } finally {
      setLoadingComments(false);
    }
  };
  
  const handleComment = () => {
    if (!user) {
      navigate("/auth");
      return;
    }
    
    setIsCommentOpen(true);
  };

  const submitComment = () => {
    if (!comment.trim()) return;
    commentMutation.mutate(comment);
  };
  
  // Edit and delete mutations
  const editPostMutation = useMutation({
    mutationFn: () => apiRequest("PATCH", `/api/posts/${post.id}`, { content: editedContent }),
    onSuccess: () => {
      setIsEditDialogOpen(false);
      
      // Update the local state to reflect the changes immediately
      post.content = editedContent;
      
      toast({
        title: "Post updated",
        description: "Your post has been updated successfully",
      });
      
      // Refresh posts
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update post",
      });
    }
  });
  
  const deletePostMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", `/api/posts/${post.id}`),
    onSuccess: () => {
      setIsDeleteDialogOpen(false);
      
      toast({
        title: "Post deleted",
        description: "Your post has been deleted successfully",
      });
      
      // Refresh posts in all relevant lists
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      
      // Also refresh user profile posts
      if (post.userId) {
        queryClient.invalidateQueries({ queryKey: [`/api/users/${post.userId}/posts`] });
      }
      
      // If currently on the post detail page, redirect to home
      if (window.location.pathname.includes(`/post/${post.id}`)) {
        navigate('/');
      }
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete post",
      });
    }
  });

  const navigateToProfile = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/profile/${post.user.username}`);
  };
  
  // Navigate to trending hashtag page
  const navigateToHashtag = (hashtag: string, e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    navigate(`/trending/${hashtag.replace('#', '')}`);
  };
  
  // Format content to highlight hashtags
  const formatPostContent = (content: string) => {
    if (!content) return null;
    
    // Regex to match hashtags (#word_with_underscores or #word)
    const hashtagRegex = /#[\w_]+/g;
    
    // Split the content by hashtags
    const parts = content.split(hashtagRegex);
    
    // Extract all hashtags from the content
    const hashtags = content.match(hashtagRegex) || [];
    
    // If no hashtags, return the content as is
    if (hashtags.length === 0) return content;
    
    // Combine parts and hashtags
    return parts.map((part, index) => (
      <React.Fragment key={index}>
        {part}
        {hashtags[index] && (
          <a 
            href={`/trending/${hashtags[index].replace('#', '')}`}
            onClick={(e) => navigateToHashtag(hashtags[index], e)}
            className="text-primary font-semibold hover:underline crypto-text-gradient"
          >
            {hashtags[index]}
          </a>
        )}
      </React.Fragment>
    ));
  };

  return (
    <>
      <article className="p-5 hover:bg-[#141e33] transition-colors border-b border-[#1a2747] cursor-pointer">
        <div className="flex">
          <div className="mr-3 flex-shrink-0">
            <div 
              className="h-11 w-11 rounded-full overflow-hidden cursor-pointer ring-2 ring-primary"
              onClick={navigateToProfile}
            >
              {post.user.avatar ? (
                <img src={post.user.avatar} alt={`${post.user.displayName}'s avatar`} className="h-full w-full object-cover" />
              ) : (
                <div className="h-full w-full bg-[#141e33] flex items-center justify-center">
                  <UserIcon className="h-5 w-5 text-primary" />
                </div>
              )}
            </div>
          </div>
          <div className="flex-1">
            <div className="flex items-center mb-1">
              <h3 
                className="font-bold mr-1 cursor-pointer hover:text-primary transition-colors"
                onClick={navigateToProfile}
              >
                {post.user.displayName}
              </h3>
              <span 
                className="text-gray-400 text-sm cursor-pointer hover:text-primary transition-colors"
                onClick={navigateToProfile}
              >
                @{post.user.username}
              </span>
              <span className="mx-1 text-gray-500">·</span>
              <span className="text-gray-500 text-sm hover:underline cursor-pointer">{formattedDate}</span>
              
              {/* Post actions menu for owner */}
              {isPostOwner && (
                <div className="ml-auto">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
                        <MoreVertical className="h-4 w-4" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-[#0f172a] text-gray-200 border-[#1a2747]">
                      <DropdownMenuItem 
                        className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                        onClick={() => setIsEditDialogOpen(true)}
                      >
                        <Edit className="h-4 w-4" /> 
                        <span>Edit Post</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="flex items-center gap-2 text-red-500 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                        onClick={() => setIsDeleteDialogOpen(true)}
                      >
                        <Trash className="h-4 w-4" /> 
                        <span>Delete Post</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              )}
            </div>
            <p className="mb-3 text-[15px] leading-normal">{formatPostContent(post.content)}</p>
            {post.image && (
              <div className="rounded-xl overflow-hidden mb-3 border border-[#1a2747]">
                <img src={post.image} alt="Post attachment" className="w-full" />
              </div>
            )}
            
            {post.video && (
              <div className="rounded-xl overflow-hidden mb-3 border border-[#1a2747]">
                <video
                  src={post.video}
                  controls
                  className="w-full"
                  style={{ maxHeight: "400px" }}
                  preload="metadata"
                />
              </div>
            )}
            <div className="flex justify-between text-gray-400 pt-1">
              <button 
                className="flex items-center group"
                onClick={handleComment}
              >
                <div className="p-2 rounded-full group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                  <MessageCircle className="h-5 w-5" />
                </div>
                <span className="text-sm ml-1 group-hover:text-primary transition-colors">{post.commentsCount || 0}</span>
              </button>
              <div className="flex items-center">
                <button 
                  className="flex items-center group"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (!user) {
                      navigate("/auth");
                      return;
                    }
                    
                    // Call API directly for retweet functionality
                    apiRequest("POST", `/api/posts/${post.id}/retweet`, {})
                      .then(async (response) => {
                        if (response.ok) {
                          const result = await response.json();
                          setRetweeted(result.retweeted);
                          setRetweetCount(result.retweetCount || 0);
                          
                          // Update the posts list to show the retweet
                          queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
                          
                          toast({
                            title: result.retweeted ? "Post reshared!" : "Reshare removed",
                            description: result.retweeted ? "The post has been shared to your timeline" : "The post has been removed from your timeline",
                          });
                        }
                      })
                      .catch(() => {
                        toast({
                          variant: "destructive",
                          title: "Error",
                          description: "Failed to reshare post",
                        });
                      });
                  }}
                >
                  <div className={`p-2 rounded-full ${retweeted ? 'bg-green-500/10 text-green-500' : 'group-hover:bg-green-500/10 group-hover:text-green-500'} transition-colors`}>
                    <Repeat className={`h-5 w-5 ${retweeted ? 'fill-current' : ''}`} />
                  </div>
                  <span className={`text-sm ml-1 ${retweeted ? 'text-green-500' : 'group-hover:text-green-500'} transition-colors`}>{retweetCount}</span>
                </button>
                {retweetCount > 0 && (
                  <button 
                    className="ml-1 text-xs text-gray-500 hover:text-green-500"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsLoadingRetweeters(true);
                      
                      // Fetch retweeters list
                      apiRequest("GET", `/api/posts/${post.id}/retweeters`)
                        .then(response => response.json())
                        .then(data => {
                          setRetweetersList(data.retweeters || []);
                          setShowRetweetersDialog(true);
                          setIsLoadingRetweeters(false);
                        })
                        .catch(() => {
                          toast({
                            variant: "destructive",
                            title: "Error",
                            description: "Failed to fetch retweeters"
                          });
                          setIsLoadingRetweeters(false);
                        });
                    }}
                  >
                    {isLoadingRetweeters ? (
                      <Loader2 className="h-3 w-3 animate-spin" />
                    ) : (
                      <span>who?</span>
                    )}
                  </button>
                )}
              </div>
              <button 
                className="flex items-center group"
                onClick={handleLike}
              >
                <div className={`p-2 rounded-full ${liked ? 'bg-secondary/10 text-secondary' : 'group-hover:bg-secondary/10 group-hover:text-secondary'} transition-colors`}>
                  <Heart className={`h-5 w-5 ${liked ? 'fill-current' : ''}`} />
                </div>
                <span className={`text-sm ml-1 ${liked ? 'text-secondary' : 'group-hover:text-secondary'} transition-colors`}>{likesCount}</span>
              </button>
              
              {/* Share button with dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center group">
                    <div className="p-2 rounded-full group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                      <Share className="h-5 w-5" />
                    </div>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-[#0f172a] text-gray-200 border-[#1a2747]">
                  <DropdownMenuItem 
                    className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                    onClick={() => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(`Check out this post: ${post.content.substring(0, 100)}... #microblog`)}`)}
                  >
                    <svg className="h-4 w-4 fill-[#1DA1F2]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 5.8a8.6 8.6 0 0 1-2.4.7 4.1 4.1 0 0 0 1.8-2.3c-.8.5-1.6.8-2.6 1a4.1 4.1 0 0 0-7 3.7c-3.5-.1-6.5-1.8-8.6-4.3a4.1 4.1 0 0 0 1.3 5.4 4 4 0 0 1-1.9-.5v.1a4 4 0 0 0 3.3 4 4.2 4.2 0 0 1-1.9.1 4.1 4.1 0 0 0 3.8 2.8 8.2 8.2 0 0 1-5.1 1.8H2A11.7 11.7 0 0 0 8 21c7.2 0 11.1-6 11.1-11.1v-.5a7.6 7.6 0 0 0 2-2z"/></svg>
                    <span>Share on Twitter</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                    onClick={() => window.open(`https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(post.content.substring(0, 100))}...`)}
                  >
                    <svg className="h-4 w-4 fill-[#0088cc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm4.9 7.3l-1.7 8c-.1.6-.5.7-1.1.4l-3-2.2-1.5 1.4c-.2.2-.3.3-.6.3l.2-3.1 5.6-5c.2-.2-.1-.3-.3-.1L8 13.6l-3-.9c-.6-.2-.6-.6.1-.8l11.7-4.5c.5-.1.9.2.9.9z"/></svg>
                    <span>Share on Telegram</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                    onClick={() => {
                      navigator.clipboard.writeText(window.location.origin + `/post/${post.id}`);
                      toast({
                        title: "Link copied",
                        description: "Post link copied to clipboard",
                      });
                    }}
                  >
                    <ExternalLink className="h-4 w-4 text-gray-400" />
                    <span>Copy link</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </article>

      <Dialog open={isCommentOpen} onOpenChange={setIsCommentOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg">Comments on @{post.user.username}'s post</DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <div className="mb-4 pl-4 border-l-2 border-[#1a2747]">
              <p className="text-gray-300">{post.content}</p>
              {post.image && (
                <img src={post.image} alt="Post attachment" className="w-full h-auto max-h-40 object-cover mt-2 rounded-md" />
              )}
              {post.video && (
                <video 
                  src={post.video} 
                  controls 
                  className="w-full max-h-40 mt-2 rounded-md" 
                  preload="metadata" 
                />
              )}
            </div>
            
            {/* Comments list */}
            <div className="mb-6 space-y-4">
              <h3 className="text-sm font-medium text-gray-400 mb-2">{comments.length} Comments</h3>
              
              {loadingComments ? (
                <div className="flex justify-center p-4">
                  <div className="animate-spin h-6 w-6 border-t-2 border-b-2 border-primary rounded-full"></div>
                </div>
              ) : comments.length === 0 ? (
                <div className="text-center py-4 text-gray-500">
                  <p>No comments yet. Be the first to comment!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {comments.map(comment => (
                    <div key={comment.id} className="flex space-x-3 p-2 rounded-md hover:bg-[#141e33]/50 transition-colors">
                      <div className="flex-shrink-0">
                        {comment.user?.avatar ? (
                          <img 
                            src={comment.user.avatar} 
                            alt={`${comment.user.displayName}'s avatar`} 
                            className="app-avatar-sm" 
                          />
                        ) : (
                          <div className="app-avatar-sm">
                            <UserIcon className="h-4 w-4 text-primary" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center justify-between gap-1 mb-1 w-full">
                          <div>
                            <span className="font-bold text-sm">{comment.user?.displayName}</span>
                            <span className="text-gray-400 text-xs">@{comment.user?.username}</span>
                            <span className="text-gray-500 text-xs">· {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}</span>
                          </div>
                          {user?.id === comment.userId && (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button className="p-1 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
                                  <MoreVertical className="h-4 w-4" />
                                </button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="bg-[#0f172a] text-gray-200 border-[#1a2747]">
                                <DropdownMenuItem 
                                  className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                                  onClick={() => {
                                    // Edit comment functionality
                                    setCommentToEdit(comment);
                                    setEditedCommentContent(comment.content);
                                    setIsCommentEditDialogOpen(true);
                                  }}
                                >
                                  <Edit className="h-4 w-4" />
                                  <span>Edit</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747] text-red-500"
                                  onClick={() => {
                                    // Delete comment functionality
                                    setCommentToEdit(comment);
                                    setIsCommentDeleteDialogOpen(true);
                                  }}
                                >
                                  <Trash className="h-4 w-4" />
                                  <span>Delete</span>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}
                        </div>
                        <p className="text-sm text-gray-300">{comment.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            {/* Add new comment */}
            {user && (
              <div className="border-t border-[#1a2747] pt-4">
                <div className="flex">
                  <div className="mr-3">
                    {user?.avatar ? (
                      <img src={user.avatar} alt={`${user.displayName}'s avatar`} className="h-11 w-11 rounded-full ring-2 ring-primary" />
                    ) : (
                      <div className="app-avatar-lg">
                        <UserIcon className="h-5 w-5 text-primary" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <Textarea
                      placeholder="Write your comment..."
                      className="w-full bg-transparent border-b border-[#1a2747] resize-none focus:outline-none focus:border-primary mb-3"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                    />
                    <div className="flex justify-end">
                      <Button
                        className="bg-primary text-primary-foreground px-5 py-2 rounded-xl font-bold hover:bg-primary/90 transition-colors"
                        onClick={submitComment}
                        disabled={!comment.trim() || commentMutation.isPending}
                      >
                        {commentMutation.isPending ? "Posting..." : "Comment"}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Comment Edit Dialog */}
      <Dialog open={isCommentEditDialogOpen} onOpenChange={setIsCommentEditDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Edit Comment</DialogTitle>
            <DialogDescription className="text-gray-400">
              Make changes to your comment below.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <Textarea
              placeholder="Edit your comment..."
              className="w-full bg-[#1a2747]/50 border-[#1a2747] resize-none focus:outline-none focus:border-primary"
              value={editedCommentContent}
              onChange={(e) => setEditedCommentContent(e.target.value)}
            />
          </div>
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747]/50"
              onClick={() => setIsCommentEditDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              className="bg-primary text-primary-foreground px-5 py-2 rounded-xl font-bold hover:bg-primary/90 transition-colors"
              onClick={() => editCommentMutation.mutate()}
              disabled={!editedCommentContent.trim() || editCommentMutation.isPending}
            >
              {editCommentMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Comment Delete Dialog */}
      <Dialog open={isCommentDeleteDialogOpen} onOpenChange={setIsCommentDeleteDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Delete Comment</DialogTitle>
            <DialogDescription className="text-gray-400">
              Are you sure you want to delete this comment? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747]/50"
              onClick={() => setIsCommentDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={() => deleteCommentMutation.mutate()}
              disabled={deleteCommentMutation.isPending}
            >
              {deleteCommentMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : "Delete Comment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Post Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Edit Post</DialogTitle>
            <DialogDescription className="text-gray-400">
              Make changes to your post content below.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <Textarea
              value={editedContent}
              onChange={(e) => setEditedContent(e.target.value)}
              className="min-h-[120px] w-full bg-[#141e33] border-[#1a2747] rounded-lg p-3 text-white resize-none focus:border-primary"
              placeholder="What's on your mind?"
            />
            {post.image && (
              <div className="mt-3 rounded-lg overflow-hidden border border-[#1a2747]">
                <img src={post.image} alt="Post attachment" className="w-full h-40 object-cover" />
              </div>
            )}
            {post.video && (
              <div className="mt-3 rounded-lg overflow-hidden border border-[#1a2747]">
                <video 
                  src={post.video} 
                  controls 
                  className="w-full max-h-40" 
                  preload="metadata" 
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsEditDialogOpen(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => editPostMutation.mutate()}
              disabled={!editedContent.trim() || editPostMutation.isPending}
              className="bg-primary text-white hover:bg-primary/90"
            >
              {editPostMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Delete Post Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Delete Post</DialogTitle>
            <DialogDescription className="text-gray-400">
              Are you sure you want to delete this post? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => {
                deletePostMutation.mutate();
                // Close dialog immediately to prevent page locking issue
                setIsDeleteDialogOpen(false);
              }}
              disabled={deletePostMutation.isPending}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {deletePostMutation.isPending ? (
                <div className="flex items-center">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  <span>Deleting...</span>
                </div>
              ) : "Delete Post"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Retweeters Dialog */}
      <Dialog open={showRetweetersDialog} onOpenChange={setShowRetweetersDialog}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Reshared by</DialogTitle>
            <DialogDescription className="text-gray-400">
              Users who shared this post
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-[300px] overflow-y-auto py-2">
            {retweetersList.length > 0 ? (
              retweetersList.map((retweeter) => (
                <div 
                  key={retweeter.id} 
                  className="flex items-center gap-3 p-3 hover:bg-[#1a2747] cursor-pointer transition-colors rounded-lg"
                  onClick={() => {
                    setShowRetweetersDialog(false);
                    navigate(`/profile/${retweeter.username}`);
                  }}
                >
                  <Avatar className="h-10 w-10">
                    <AvatarImage 
                      src={retweeter.avatar || undefined} 
                      alt={retweeter.displayName}
                    />
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {retweeter.displayName ? retweeter.displayName.charAt(0).toUpperCase() : "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <span className="font-medium">{retweeter.displayName}</span>
                    <span className="text-gray-400 text-sm">@{retweeter.username}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-gray-400">
                No users have reshared this post yet
              </div>
            )}
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowRetweetersDialog(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
