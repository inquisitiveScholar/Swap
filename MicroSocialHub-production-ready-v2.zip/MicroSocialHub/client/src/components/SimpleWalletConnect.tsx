import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { ethers } from 'ethers';

// Simple wallet connect component that works in development environment
const SimpleWalletConnect = () => {
  const { toast } = useToast();
  const [address, setAddress] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [provider, setProvider] = useState<any>(null);
  const { checkWalletRegistration } = useAuth();

  useEffect(() => {
    // Initialize provider
    const setupProvider = async () => {
      if (window.ethereum) {
        try {
          const ethersProvider = new ethers.BrowserProvider(window.ethereum);
          setProvider(ethersProvider);
          
          // Check if already connected
          const accounts = await ethersProvider.listAccounts();
          if (accounts.length > 0) {
            setAddress(accounts[0].address);
          }
        } catch (error) {
          console.error("Error setting up provider:", error);
        }
      }
    };
    
    setupProvider();
  }, []);

  const connectWallet = async () => {
    setIsConnecting(true);
    
    try {
      if (!window.ethereum) {
        toast({
          title: "No Ethereum wallet found",
          description: "Please install MetaMask or another Ethereum wallet.",
          variant: "destructive",
        });
        return;
      }
      
      if (!provider) {
        const ethersProvider = new ethers.BrowserProvider(window.ethereum);
        setProvider(ethersProvider);
      }
      
      // Request accounts
      const accounts = await provider.send("eth_requestAccounts", []);
      const signer = await provider.getSigner();
      const walletAddress = await signer.getAddress();
      
      setAddress(walletAddress);
      
      // Check if wallet is registered
      const isRegistered = await checkWalletRegistration(walletAddress);
      
      if (isRegistered) {
        toast({
          title: "Wallet connected!",
          description: "This wallet is already registered with an account.",
        });
      } else {
        toast({
          title: "Wallet connected!",
          description: "Please register to continue using your wallet.",
          variant: "default",
        });
      }
    } catch (error) {
      console.error("Wallet connection error:", error);
      toast({
        title: "Connection Failed",
        description: "Failed to connect wallet. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnectWallet = () => {
    setAddress(null);
    toast({
      title: "Wallet disconnected",
      description: "Your wallet has been disconnected.",
    });
  };

  return (
    <div className="flex flex-col space-y-2">
      {address ? (
        <div className="flex flex-col items-center space-y-2">
          <div className="text-sm font-medium">
            <span className="text-muted-foreground">Connected: </span>
            <span className="text-foreground">{address.slice(0, 6)}...{address.slice(-4)}</span>
          </div>
          <Button variant="outline" size="sm" onClick={disconnectWallet}>
            Disconnect
          </Button>
        </div>
      ) : (
        <Button 
          onClick={connectWallet} 
          disabled={isConnecting}
          className="bg-primary text-white hover:bg-primary/90"
        >
          {isConnecting ? "Connecting..." : "Connect Wallet"}
        </Button>
      )}
    </div>
  );
};

export default SimpleWalletConnect;