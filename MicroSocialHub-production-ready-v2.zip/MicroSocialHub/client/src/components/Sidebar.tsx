import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/context/AuthContext";
import CreatePostInput from "./CreatePostInput";

export default function Sidebar() {
  const [location, navigate] = useLocation();
  const { user, logout } = useAuth();

  const isActive = (path: string) => {
    return location === path ? "bg-[#141e33] text-purple-500 font-bold" : "text-gray-100";
  };

  return (
    <aside className="hidden md:block w-72 border-r border-[#1a2747] p-5 sticky top-[57px] h-[calc(100vh-57px)]">
      
      <nav className="space-y-1">
        <a 
          href="/" 
          className={`flex items-center p-3 rounded-xl hover:bg-[#141e33] transition-colors mb-1 ${isActive("/")}`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/");
          }}
        >
          <span className="material-icons mr-3">home</span>
          <span>Home</span>
        </a>
        <a 
          href="/explore" 
          className={`flex items-center p-3 rounded-xl hover:bg-[#141e33] transition-colors mb-1 ${isActive("/explore")}`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/explore");
          }}
        >
          <span className="material-icons mr-3">explore</span>
          <span>Explore</span>
        </a>
        <a 
          href="/trending" 
          className={`flex items-center p-3 rounded-xl hover:bg-[#141e33] transition-colors mb-1 ${isActive("/trending")}`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/trending");
          }}
        >
          <span className="material-icons mr-3">tag</span>
          <span>Trending</span>
        </a>
        <a 
          href={`/profile/${user?.username}`}
          className={`flex items-center p-3 rounded-xl hover:bg-[#141e33] transition-colors mb-1 ${isActive(`/profile/${user?.username}`) || isActive('/profile')}`}
          onClick={(e) => {
            e.preventDefault();
            if (user?.username) {
              navigate(`/profile/${user.username}`);
            } else {
              navigate("/profile");
            }
          }}
        >
          <span className="material-icons mr-3">person</span>
          <span>Profile</span>
        </a>
        <a 
          href="/settings" 
          className={`flex items-center p-3 rounded-xl hover:bg-[#141e33] transition-colors mb-1 ${isActive("/settings")}`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/settings");
          }}
        >
          <span className="material-icons mr-3">settings</span>
          <span>Settings</span>
        </a>
        <a 
          href="#" 
          className="flex items-center p-3 rounded-xl hover:bg-[#141e33] transition-colors mb-1 text-gray-100"
          onClick={(e) => {
            e.preventDefault();
            logout();
            navigate("/auth");
          }}
        >
          <span className="material-icons mr-3">logout</span>
          <span>Logout</span>
        </a>
      </nav>
      
      <Dialog>
        <DialogTrigger asChild>
          <Button className="mt-6 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white w-full py-6 rounded-xl font-bold text-base transition-all shadow-md">
            Create Post
          </Button>
        </DialogTrigger>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl">
          <DialogHeader>
            <DialogTitle>Create a new post</DialogTitle>
          </DialogHeader>
          <CreatePostInput inDialog />
        </DialogContent>
      </Dialog>

      {user && (
        <div className="absolute bottom-5 left-5 right-5">
          <div className="bg-[#141e33] p-4 rounded-xl border border-[#1a2747]">
            <div className="flex items-center space-x-3">
              <div className="app-avatar-lg">
                {user.avatar ? (
                  <img src={user.avatar} alt={`${user.displayName}'s avatar`} className="h-full w-full object-cover" />
                ) : (
                  <span className="material-icons text-purple-500">person</span>
                )}
              </div>
              <div>
                <p className="font-bold">{user.displayName}</p>
                <p className="text-sm text-gray-400">@{user.username}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}
