import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface UseWalletConnectReturn {
  walletAddress: string | null;
  walletConnected: boolean;
  isConnecting: boolean;
  isRegistering: boolean;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  registerWithWallet: (userData: RegisterData) => Promise<void>;
  checkWalletRegistration: (address: string) => Promise<boolean>;
}

interface RegisterData {
  username: string;
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
}

// Simple hook for wallet connection that doesn't rely on WalletConnect
export const useWalletConnect = (): UseWalletConnectReturn => {
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const { toast } = useToast();
  const { registerWithWallet, checkWalletRegistration: checkRegistration } = useAuth();

  // Check for existing connection on mount
  useEffect(() => {
    const checkExistingConnection = async () => {
      if (typeof window !== 'undefined' && window.ethereum) {
        try {
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          if (accounts && accounts.length > 0) {
            setWalletAddress(accounts[0]);
          }
        } catch (error) {
          console.error('Error checking wallet connection:', error);
        }
      }
    };

    checkExistingConnection();
  }, []);

  // Connect wallet
  const connectWallet = async (): Promise<void> => {
    setIsConnecting(true);
    try {
      if (typeof window !== 'undefined' && window.ethereum) {
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        if (accounts && accounts.length > 0) {
          setWalletAddress(accounts[0]);
          toast({
            title: 'Wallet Connected',
            description: `Connected: ${accounts[0].slice(0, 6)}...${accounts[0].slice(-4)}`,
          });
        }
      } else {
        toast({
          title: 'Wallet Not Found',
          description: 'Please install MetaMask or another Ethereum wallet extension',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error connecting wallet:', error);
      toast({
        title: 'Connection Failed',
        description: 'Failed to connect to wallet. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsConnecting(false);
    }
  };

  // Disconnect wallet
  const disconnectWallet = (): void => {
    setWalletAddress(null);
    toast({
      title: 'Wallet Disconnected',
      description: 'Your wallet has been disconnected',
    });
  };

  // Register with wallet
  const handleRegisterWithWallet = async (userData: RegisterData): Promise<void> => {
    if (!walletAddress) {
      toast({
        title: 'Wallet Not Connected',
        description: 'Please connect your wallet first',
        variant: 'destructive',
      });
      return;
    }

    setIsRegistering(true);
    try {
      // Add wallet address to user data
      await registerWithWallet({
        ...userData,
        walletAddress,
        network: 'ethereum', // Default to Ethereum
      });

      toast({
        title: 'Account Created',
        description: 'Your account has been created successfully',
      });
    } catch (error) {
      console.error('Registration error:', error);
      toast({
        title: 'Registration Failed',
        description: 'Failed to create account. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsRegistering(false);
    }
  };

  // Check if wallet is registered
  const checkWalletRegistration = async (address: string): Promise<boolean> => {
    return checkRegistration(address);
  };

  return {
    walletAddress,
    walletConnected: !!walletAddress,
    isConnecting,
    isRegistering,
    connectWallet,
    disconnectWallet,
    registerWithWallet: handleRegisterWithWallet,
    checkWalletRegistration,
  };
};