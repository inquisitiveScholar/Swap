import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { createConfig, WagmiConfig, useAccount, useDisconnect } from 'wagmi';
import { sepolia } from 'wagmi/chains';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
// We'll integrate with WalletAuthContext from the component that uses both contexts
import { createWeb3Modal, defaultWagmiConfig, useWeb3Modal, useWeb3ModalState } from '@web3modal/wagmi/react';

// Use the provided WalletConnect project ID
const walletConnectProjectId = "8137aad45a92f2eb9a42812ee05af00c";

const chains = [sepolia];
const projectId = walletConnectProjectId;

// Create wagmi config
const metadata = {
  name: import.meta.env.NEXT_PUBLIC_APP_NAME || 'Web3 Social App',
  description: 'A Web3-enabled social media platform',
  url: window.location.host,
  icons: ['https://avatars.githubusercontent.com/u/37784886']
}

const wagmiConfig = defaultWagmiConfig({
  chains,
  projectId,
  metadata
})

// Create modal
createWeb3Modal({
  wagmiConfig,
  projectId,
  chains,
  themeMode: 'dark',
  themeVariables: {
    '--w3m-accent': 'var(--primary)'
  }
});

interface Web3ContextProps {
  address: string | undefined;
  chainId: number | undefined;
  isConnected: boolean;
  openModal: () => void;
  disconnect: () => void;
  walletLogin: (username?: string, displayName?: string, bio?: string, avatar?: string) => Promise<any>;
}

const Web3Context = createContext<Web3ContextProps | undefined>(undefined);

export function useWeb3() {
  const context = useContext(Web3Context);
  if (!context) {
    throw new Error('useWeb3 must be used within a Web3Provider');
  }
  return context;
}

function Web3ContextProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const { open } = useWeb3Modal();
  const { address, isConnected, chainId, status } = useAccount();
  const { disconnect: wagmiDisconnect } = useDisconnect();
  const { toast } = useToast();
  // Remove the Auth dependency for now
  // const { login } = useAuth();

  // Wait for the component to be mounted before setting ready to true
  useEffect(() => {
    setReady(true);
  }, []);

  const openModal = () => {
    open();
  };

  const disconnect = () => {
    wagmiDisconnect();
  };

  // Remove wallet login auto attempt since it depends on AuthContext
  // useEffect(() => {
  //  if (isConnected && address && chainId) {
  //    walletLogin();
  //  }
  // }, [isConnected, address, chainId]);

  const walletLogin = async (
    username?: string,
    displayName?: string,
    bio?: string,
    avatar?: string
  ) => {
    if (!address || !chainId) {
      toast({
        title: 'Error',
        description: 'Wallet not connected',
        variant: 'destructive'
      });
      return;
    }

    try {
      const payload = {
        walletAddress: address,
        network: chainId.toString(),
        username,
        displayName,
        bio,
        avatar
      };

      const response = await apiRequest('POST', '/api/auth/wallet', payload);
      const data = await response.json();

      if (response.ok) {
        toast({
          title: 'Success',
          description: 'Logged in with wallet successfully'
        });
        
        return data;
      } else if (response.status === 404 && data.registered === false) {
        // Wallet not registered yet, we need additional information
        toast({
          title: 'Wallet not registered',
          description: 'Please complete your profile to continue'
        });
        
        return { registered: false, walletAddress: address };
      } else {
        throw new Error(data.message || 'Failed to login with wallet');
      }
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to login with wallet',
        variant: 'destructive'
      });
      
      return null;
    }
  };

  const contextValue: Web3ContextProps = {
    address,
    chainId,
    isConnected,
    openModal,
    disconnect,
    walletLogin
  };

  if (!ready) {
    return <>{children}</>;
  }

  return (
    <Web3Context.Provider value={contextValue}>
      {children}
    </Web3Context.Provider>
  );
}

export function Web3Provider({ children }: { children: ReactNode }) {
  return (
    <WagmiConfig config={wagmiConfig}>
      <Web3ContextProvider>{children}</Web3ContextProvider>
    </WagmiConfig>
  );
}