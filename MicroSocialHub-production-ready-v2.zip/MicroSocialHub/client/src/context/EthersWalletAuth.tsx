import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";
import { walletConnector } from "@/lib/walletConnect";
import { formatUrl } from "@/lib/utils";

interface WalletAuthContextType {
  user: User | null;
  isLoading: boolean;
  isConnecting: boolean;
  isRegistering: boolean;
  walletAddress: string | null;
  walletConnected: boolean;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  registerWithWallet: (userData: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  checkWalletRegistration: (address: string) => Promise<boolean>;
}

interface RegisterData {
  username: string;
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
}

const WalletAuthContext = createContext<WalletAuthContextType | null>(null);

export function EthersWalletAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [walletConnected, setWalletConnected] = useState(false);
  
  const { toast } = useToast();

  // Check session on initial load
  useEffect(() => {
    async function checkSession() {
      try {
        setIsLoading(true);
        const response = await fetch(formatUrl("/api/auth/session"));
        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
          
          // If user is logged in with wallet, check if wallet is still connected
          if (data.user?.walletAddress) {
            const address = await walletConnector.getAddress();
            setWalletAddress(address);
            setWalletConnected(!!address);
          }
        } else {
          setUser(null);
          // Check if wallet is connected
          const address = await walletConnector.getAddress();
          setWalletAddress(address);
          setWalletConnected(!!address);
        }
      } catch (error) {
        console.error("Session check failed:", error);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    }
    
    checkSession();
  }, []);

  // Auto login with wallet when it connects
  useEffect(() => {
    if (walletConnected && walletAddress && !user && !isLoading) {
      checkWalletRegistration(walletAddress)
        .then(isRegistered => {
          if (isRegistered) {
            // Wallet is registered, try to login
            tryWalletLogin(walletAddress);
          }
          // If not registered, user will need to complete registration
        })
        .catch(err => {
          console.error("Wallet check failed:", err);
        });
    }
  }, [walletConnected, walletAddress, user, isLoading]);

  const connectWallet = async () => {
    if (!walletConnector.isWalletAvailable()) {
      toast({
        variant: "destructive",
        title: "Wallet Not Found",
        description: "Please install MetaMask or another Ethereum wallet to continue"
      });
      return;
    }
    
    setIsConnecting(true);
    try {
      const address = await walletConnector.connect();
      setWalletAddress(address);
      setWalletConnected(true);
      
      toast({
        title: "Wallet Connected",
        description: `Connected to wallet ${address.substring(0, 6)}...${address.substring(address.length - 4)}`
      });
    } catch (error: any) {
      console.error("Failed to connect wallet:", error);
      toast({
        variant: "destructive",
        title: "Connection Error",
        description: error.message || "Could not connect to wallet"
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnectWallet = () => {
    walletConnector.disconnect();
    setWalletAddress(null);
    setWalletConnected(false);
    
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected"
    });
  };

  const checkWalletRegistration = async (address: string): Promise<boolean> => {
    return await walletConnector.checkWalletRegistration(address);
  };

  const tryWalletLogin = async (walletAddress: string) => {
    try {
      const network = await walletConnector.getNetworkId();
      const nonce = Date.now().toString();
      const signature = await walletConnector.signMessage(
        `Sign this message to login to the app with nonce: ${nonce}`
      );
      
      const response = await apiRequest("POST", "/api/auth/wallet", {
        walletAddress,
        network,
        signature,
        nonce
      });
      
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        
        toast({
          title: "Welcome back!",
          description: `You're logged in as ${userData.displayName || userData.username}`
        });
        
        return userData;
      }
      return null;
    } catch (error) {
      console.error("Wallet login failed:", error);
      return null;
    }
  };

  const registerWithWallet = async (userData: RegisterData) => {
    if (!walletAddress) {
      toast({
        variant: "destructive",
        title: "Wallet not connected",
        description: "Please connect your wallet first"
      });
      return;
    }
    
    setIsRegistering(true);
    try {
      const network = await walletConnector.getNetworkId();
      const nonce = Date.now().toString();
      const signature = await walletConnector.signMessage(
        `Sign this message to register with our app with nonce: ${nonce}`
      );
      
      const response = await apiRequest("POST", "/api/auth/wallet", {
        ...userData,
        walletAddress,
        network,
        signature,
        nonce
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Registration failed");
      }
      
      const newUser = await response.json();
      setUser(newUser);
      
      toast({
        title: "Registration successful!",
        description: `Welcome to the platform, ${newUser.displayName}!`
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: error.message || "Could not complete registration"
      });
      throw error;
    } finally {
      setIsRegistering(false);
    }
  };

  const logout = async () => {
    try {
      const response = await apiRequest("POST", "/api/auth/logout");
      if (response.ok) {
        setUser(null);
        
        toast({
          title: "Logged out",
          description: "You have been logged out successfully"
        });
      } else {
        throw new Error("Logout failed");
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: "There was an error logging out"
      });
    }
  };

  return (
    <WalletAuthContext.Provider
      value={{
        user,
        isLoading,
        isConnecting,
        isRegistering,
        walletAddress,
        walletConnected,
        connectWallet,
        disconnectWallet,
        registerWithWallet,
        logout,
        checkWalletRegistration
      }}
    >
      {children}
    </WalletAuthContext.Provider>
  );
}

export function useWalletAuth() {
  const context = useContext(WalletAuthContext);
  if (!context) {
    throw new Error("useWalletAuth must be used within a EthersWalletAuthProvider");
  }
  return context;
}