import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertPostSchema, 
  insertCommentSchema, 
  insertLikeSchema, 
  insertFollowSchema,
  walletLoginSchema
} from "@shared/schema";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import MemoryStore from "memorystore";
import { setupApiRoutes } from "./api-routes";
import bcrypt from "bcryptjs";
import path from "path";
import express from "express";
import { WebSocketServer, WebSocket } from 'ws';

const SessionStore = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve WalletConnect verification file
  app.use('/.well-known', express.static(path.join(process.cwd(), '.well-known')));
  
  // Configure session
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "micro-session-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
      store: new SessionStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
    })
  );

  // Configure passport
  app.use(passport.initialize());
  app.use(passport.session());
  
  // Setup all API routes from the separate file
  setupApiRoutes(app);

  // Passport local strategy
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Incorrect username." });
        }
        
        // Check if this is a wallet-only user (has no password because wallet-connected)
        if (user.walletAddress && !user.password) {
          return done(null, false, { message: "Please login with your wallet" });
        }
        
        // For now, allow plaintext password comparison for testing
        let isMatch = false;
        
        // Try with bcrypt first (for hashed passwords)
        try {
          if (user.password.startsWith('$2a$')) {
            isMatch = await bcrypt.compare(password, user.password);
          } else {
            // Direct comparison for plaintext password (only for testing)
            isMatch = password === user.password;
          }
        } catch (err) {
          console.error('Password comparison error:', err);
          // Fallback to direct comparison if bcrypt fails
          isMatch = password === user.password;
        }
        
        if (!isMatch) {
          console.log('Password mismatch:', { provided: password, hashedStored: user.password });
          return done(null, false, { message: "Incorrect password." });
        }
        
        return done(null, user);
      } catch (err) {
        console.error('Authentication error:', err);
        return done(err);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // Wallet-only authentication - removed traditional login endpoints

  // Endpoint to check if a wallet is already registered
  app.get("/api/wallet/:address/exists", async (req, res) => {
    try {
      const walletAddress = req.params.address;
      const user = await storage.getUserByWalletAddress(walletAddress);
      
      return res.json({
        exists: !!user,
        user: user ? {
          id: user.id,
          username: user.username,
          displayName: user.displayName
        } : null
      });
    } catch (error) {
      console.error("Error checking wallet:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });
  
  // Wallet login/registration endpoint
  app.post("/api/auth/wallet", async (req, res) => {
    try {
      const walletData = walletLoginSchema.parse(req.body);
      
      // Check if a user with this wallet address already exists
      let user = await storage.getUserByWalletAddress(walletData.walletAddress);
      
      if (user) {
        // Update network if needed
        if (user.network !== walletData.network) {
          user = await storage.updateUser(user.id, { network: walletData.network });
        }
      } else {
        // If user doesn't exist, check if we need to create a new one
        if (!walletData.username || !walletData.displayName) {
          // Just return that the wallet is not registered yet
          return res.status(404).json({ 
            message: "Wallet not registered",
            walletAddress: walletData.walletAddress,
            registered: false 
          });
        }
        
        // Create a new user with the wallet address
        // Generate a random password since passport local requires it
        const randomPassword = Math.random().toString(36).slice(-10);
        
        user = await storage.createUser({
          username: walletData.username,
          displayName: walletData.displayName,
          password: randomPassword, // We won't use this for wallet logins
          bio: walletData.bio || null,
          avatar: walletData.avatar || null,
          walletAddress: walletData.walletAddress,
          network: walletData.network,
        });
      }
      
      // Log the user in
      if (!user) {
        return res.status(500).json({ message: "Failed to create or retrieve user" });
      }
      
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Error logging in" });
        }
        return res.json({
          ...user,
          registered: true
        });
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      // Check if wallet address is already registered
      if (userData.walletAddress) {
        const existingWallet = await storage.getUserByWalletAddress(userData.walletAddress);
        if (existingWallet) {
          return res.status(409).json({ message: "Wallet address already registered" });
        }
      }
      
      // Hash password if not using wallet authentication
      if (!userData.walletAddress) {
        userData.password = await bcrypt.hash(userData.password, 10);
      }
      
      const newUser = await storage.createUser(userData);
      
      // Log the user in
      req.login(newUser, (err) => {
        if (err) {
          return res.status(500).json({ message: "Error logging in" });
        }
        return res.status(201).json(newUser);
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  // Session check endpoint
  app.get("/api/auth/session", (req, res) => {
    if (req.isAuthenticated()) {
      res.status(200).json({ authenticated: true, user: req.user });
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });
  
  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/session", (req, res) => {
    if (req.isAuthenticated()) {
      res.json(req.user);
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });

  // User routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(parseInt(req.params.id));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      // Don't send password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Query parameter required" });
      }
      
      const users = await storage.searchUsers(query);
      
      // Remove passwords
      const sanitizedUsers = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.json(sanitizedUsers);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Post routes
  app.post("/api/posts", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postData = insertPostSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const newPost = await storage.createPost(postData);
      res.status(201).json(newPost);
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  app.get("/api/posts", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const posts = await storage.getPosts(limit, offset);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/posts/:id", async (req, res) => {
    try {
      const post = await storage.getPost(parseInt(req.params.id));
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const user = await storage.getUser(post.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send user password
      const { password, ...userWithoutPassword } = user;
      
      res.json({ ...post, user: userWithoutPassword });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users/:id/posts", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const posts = await storage.getPostsByUser(userId, limit, offset);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Comment routes
  app.post("/api/posts/:id/comments", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const commentData = insertCommentSchema.parse({
        ...req.body,
        postId: parseInt(req.params.id),
        userId: user.id
      });
      
      const newComment = await storage.createComment(commentData);
      
      // Get user data for response
      const commentUser = await storage.getUser(newComment.userId);
      const { password, ...userWithoutPassword } = commentUser!;
      
      res.status(201).json({
        ...newComment,
        user: userWithoutPassword
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  app.get("/api/posts/:id/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const comments = await storage.getCommentsByPost(postId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Like routes
  app.post("/api/posts/:id/like", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const likeData = insertLikeSchema.parse({
        postId: parseInt(req.params.id),
        userId: user.id
      });
      
      const newLike = await storage.createLike(likeData);
      res.status(201).json(newLike);
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  app.delete("/api/posts/:id/like", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      const success = await storage.deleteLike(postId, user.id);
      if (!success) {
        return res.status(404).json({ message: "Like not found" });
      }
      
      res.json({ message: "Like removed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/posts/:id/like", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      const like = await storage.getLike(postId, user.id);
      if (!like) {
        return res.json({ liked: false });
      }
      
      res.json({ liked: true });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Follow routes
  app.post("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const followingId = parseInt(req.params.id);
      
      // Can't follow yourself
      if (user.id === followingId) {
        return res.status(400).json({ message: "Cannot follow yourself" });
      }
      
      const followData = insertFollowSchema.parse({
        followerId: user.id,
        followingId
      });
      
      const newFollow = await storage.createFollow(followData);
      res.status(201).json(newFollow);
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  app.delete("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const followingId = parseInt(req.params.id);
      
      const success = await storage.deleteFollow(user.id, followingId);
      if (!success) {
        return res.status(404).json({ message: "Follow relationship not found" });
      }
      
      res.json({ message: "Unfollowed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const followingId = parseInt(req.params.id);
      
      const follow = await storage.getFollow(user.id, followingId);
      if (!follow) {
        return res.json({ following: false });
      }
      
      res.json({ following: true });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // User suggestions
  app.get("/api/users/suggestions", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
      
      const suggestions = await storage.getUserSuggestions(user.id, limit);
      
      // Remove passwords
      const sanitizedSuggestions = suggestions.map(suggestion => {
        const { password, ...userWithoutPassword } = suggestion;
        return userWithoutPassword;
      });
      
      res.json(sanitizedSuggestions);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  const httpServer = createServer(app);
  
  // Set up WebSocket server on a different path than Vite's HMR
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Track connected clients
  const clients = new Map<WebSocket, { userId?: number }>();
  
  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');
    
    // Add client to the clients map
    clients.set(ws, {});
    
    // Handle messages from clients
    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message);
        
        // Handle different message types
        switch (data.type) {
          case 'auth':
            // Authenticate the client
            if (data.userId) {
              clients.set(ws, { userId: data.userId });
              console.log(`User ${data.userId} authenticated via WebSocket`);
            }
            break;
            
          case 'newPost':
            // Broadcast new post to all clients
            broadcastMessage({
              type: 'newPost',
              post: data.post
            });
            break;
            
          case 'newLike':
            // Notify specific user about a like
            if (data.targetUserId) {
              sendToUser(data.targetUserId, {
                type: 'notification',
                action: 'like',
                postId: data.postId,
                userId: data.userId
              });
            }
            break;
            
          case 'newComment':
            // Notify specific user about a comment
            if (data.targetUserId) {
              sendToUser(data.targetUserId, {
                type: 'notification',
                action: 'comment',
                postId: data.postId,
                userId: data.userId
              });
            }
            break;
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });
    
    // Handle client disconnection
    ws.on('close', () => {
      clients.delete(ws);
      console.log('WebSocket client disconnected');
    });
    
    // Send welcome message
    ws.send(JSON.stringify({ 
      type: 'welcome',
      message: 'Connected to Web3 Social WebSocket server'
    }));
  });
  
  // Helper function to broadcast message to all clients
  function broadcastMessage(message: any) {
    const messageStr = JSON.stringify(message);
    
    clients.forEach((client, ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(messageStr);
      }
    });
  }
  
  // Helper function to send message to specific user
  function sendToUser(userId: number, message: any) {
    const messageStr = JSON.stringify(message);
    
    clients.forEach((client, ws) => {
      if (client.userId === userId && ws.readyState === WebSocket.OPEN) {
        ws.send(messageStr);
      }
    });
  }
  
  return httpServer;
}
