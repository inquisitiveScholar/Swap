import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { X } from "lucide-react";
import { getAvatarSrc } from "./AvatarSelector";

interface MobileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileDrawer({ isOpen, onClose }: MobileDrawerProps) {
  const [location, navigate] = useLocation();
  const { user, logout } = useAuth();

  const handleNavigation = (path: string) => {
    navigate(path);
    onClose();
  };

  const handleLogout = async () => {
    await logout();
    navigate("/auth");
    onClose();
  };

  return (
    <div 
      className={`fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden ${isOpen ? '' : 'hidden'}`}
      onClick={onClose}
    >
      <div 
        className={`w-72 h-full bg-[#0f172a] transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-4 border-b border-[#1a2747]">
          <div className="flex items-center">
            <img 
              src="https://raw.githubusercontent.com/inquisitiveScholar/decentra-social/refs/heads/main/logo.PNG" 
              alt="Indian X Social Logo" 
              className="h-8 w-8 mr-2 rounded-md"
            />
            <h2 className="text-xl font-bold bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">
              Menu
            </h2>
          </div>
          <button 
            onClick={onClose}
            className="rounded-full p-2 hover:bg-[#141e33] text-gray-400"
          >
            <X size={20} />
          </button>
        </div>
        
        {user && (
          <div className="p-4 border-b border-[#1a2747]">
            <div className="flex items-center space-x-3">
              <div className="app-avatar">
                {user.avatar ? (
                  <img src={getAvatarSrc(user.avatar)} alt={`${user.displayName}'s avatar`} className="h-full w-full object-cover" />
                ) : (
                  <span className="material-icons text-purple-500">person</span>
                )}
              </div>
              <div>
                <p className="font-medium">{user.displayName}</p>
                <p className="text-sm text-gray-400">@{user.username}</p>
              </div>
            </div>
            <div className="flex mt-3">
              <div className="mr-4">
                <div className="font-medium">{user.followingCount || 0}</div>
                <div className="text-xs text-gray-400">Following</div>
              </div>
              <div>
                <div className="font-medium">{user.followersCount || 0}</div>
                <div className="text-xs text-gray-400">Followers</div>
              </div>
            </div>
          </div>
        )}
        
        <nav className="p-2">
          <a 
            href="#" 
            className="flex items-center p-3 rounded-xl hover:bg-[#141e33] transition-colors mb-1"
            onClick={(e) => {
              e.preventDefault();
              handleNavigation("/settings");
            }}
          >
            <span className="material-icons mr-3 text-blue-400">settings</span>
            <span>Settings</span>
          </a>
          <a 
            href="#" 
            className="flex items-center p-3 rounded-xl hover:bg-[#141e33] transition-colors mb-1"
            onClick={(e) => {
              e.preventDefault();
              handleNavigation("/trending");
            }}
          >
            <span className="material-icons mr-3 text-purple-400">tag</span>
            <span>All Trending Topics</span>
          </a>
          <div className="border-t border-[#1a2747] my-2"></div>
          <a 
            href="#" 
            className="flex items-center p-3 rounded-xl hover:bg-[#141e33] transition-colors mb-1"
            onClick={(e) => {
              e.preventDefault();
              handleLogout();
            }}
          >
            <span className="material-icons mr-3 text-gray-400">logout</span>
            <span>Logout</span>
          </a>
        </nav>
      </div>
    </div>
  );
}
