import React from "react";
import { useLocation } from "wouter";
import { ArrowLeft, Mail, MessageCircle, HelpCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function SupportPage() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-[#0f172a] pb-20 md:pb-0">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-[#0f172a] border-b border-[#1a2747] px-4 py-4">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => navigate("/")}
            className="p-2 rounded-full hover:bg-[#1a2747] transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            <HelpCircle className="h-6 w-6 text-purple-400" />
            <h1 className="text-xl font-bold">Support</h1>
          </div>
        </div>
      </div>

      <div className="px-4 py-6 max-w-2xl mx-auto">
        {/* Welcome Section */}
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-2">Need Help?</h2>
          <p className="text-gray-400">
            Contact our support team for assistance.
          </p>
        </div>

        {/* Contact Methods */}
        <div className="space-y-4 mb-8">
          <Card className="bg-[#1a2747] border-[#2a3759]">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-blue-400" />
                Email Support
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-400 mb-4">
                Send us an email and we'll get back to you within 24 hours.
              </p>
              <p className="text-sm text-gray-300 mb-4">support@dcsocial.io</p>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => window.location.href = 'mailto:support@dcsocial.io'}
              >
                Send Email
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-[#1a2747] border-[#2a3759]">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <MessageCircle className="h-5 w-5 text-green-400" />
                Live Chat
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-400 mb-4">
                Chat with our support team during business hours.
              </p>
              <p className="text-sm text-gray-300 mb-4">Available: 9 AM - 6 PM UTC</p>
              <Button 
                variant="outline" 
                className="w-full"
                disabled
              >
                Coming Soon
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Common Issues */}
        <Card className="bg-[#1a2747] border-[#2a3759]">
          <CardHeader>
            <CardTitle>Common Issues</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <h4 className="font-medium text-white mb-1">Wallet Connection Issues</h4>
                <p className="text-sm text-gray-400">Make sure you're on the correct network and your wallet is unlocked.</p>
              </div>
              <div>
                <h4 className="font-medium text-white mb-1">Login Problems</h4>
                <p className="text-sm text-gray-400">Try refreshing the page or clearing your browser cache.</p>
              </div>
              <div>
                <h4 className="font-medium text-white mb-1">Transaction Errors</h4>
                <p className="text-sm text-gray-400">Ensure you have sufficient balance and gas fees.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}