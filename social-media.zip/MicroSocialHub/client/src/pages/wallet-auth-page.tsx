import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useWalletAuth } from "@/context/EthersWalletAuth";
import { Loader2 } from "lucide-react";
import { useAccount } from "wagmi";
import { formatUrl } from "@/lib/utils";

// List of predefined crypto-themed avatars
import { getAvatarSrc } from "@/components/AvatarSelector";

const avatarOptions = [
  "DC_avtar1",
  "DC_avtar2", 
  "DC_avtar3",
  "DC_avtar4",
  "DC_avtar5",
  "DC_avtar6",
  "DC_avtar7",
  "DC_avtar8",
  "DC_avtar9",
  "DC_avtar10",
  "DC_avtar11",
  "DC_avtar12",
  "DC_avtar13",
  "DC_avtar14"
];

export default function WalletAuthPage() {
  const [, navigate] = useLocation();
  const { 
    connectWallet, 
    user, 
    registerWithWallet, 
    checkWalletRegistration,
    isConnecting, 
    isRegistering
  } = useWalletAuth();
  const { address, isConnected } = useAccount();
  const { toast } = useToast();
  
  // Registration form state
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [selectedAvatar, setSelectedAvatar] = useState(avatarOptions[0]);
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const [isWalletRegistered, setIsWalletRegistered] = useState<boolean | null>(null);
  const [isCheckingUsername, setIsCheckingUsername] = useState(false);
  const [isRegisteringForm, setIsRegisteringForm] = useState(false);
  
  // Use address as walletAddress for compatibility
  const walletAddress = address;
  const walletConnected = isConnected;

  // If user is already logged in, redirect to home
  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  // Check if wallet is registered when address is available
  useEffect(() => {
    async function checkWallet() {
      if (walletAddress && walletConnected) {
        const isRegistered = await checkWalletRegistration(walletAddress);
        setIsWalletRegistered(isRegistered);
        
        if (isRegistered) {
          toast({
            title: "Wallet recognized",
            description: "Your wallet is connected and logged in automatically",
          });
        }
      } else {
        setIsWalletRegistered(null);
      }
    }
    
    checkWallet();
  }, [walletAddress, walletConnected, checkWalletRegistration, toast]);

  // Handle username availability check
  const checkUsernameAvailability = useCallback(async () => {
    if (!username || username.length < 3) return;
    
    setIsCheckingUsername(true);
    try {
      const url = walletAddress 
        ? `/api/users/check-username?username=${username}&walletAddress=${walletAddress}`
        : `/api/users/check-username?username=${username}`;
      
      console.log("Checking username availability with URL:", url);
      const response = await fetch(url);
      const data = await response.json();
      console.log("Username check response:", data);
      
      setUsernameAvailable(data.available);
      
      // Check if wallet is already registered
      if (data.walletAlreadyRegistered && data.existingWalletUser) {
        toast({
          variant: "destructive",
          title: "Wallet Already Registered",
          description: `This wallet is already registered to ${data.existingWalletUser.displayName} (@${data.existingWalletUser.username}). Please use the login option instead.`,
        });
        
        // Redirect to login after a short delay
        setTimeout(() => {
          navigate('/login');
        }, 3000);
        return;
      }
      
      if (!data.available) {
        toast({
          variant: "destructive",
          title: "Username unavailable",
          description: "This username is already taken. Please choose another one."
        });
      }
    } catch (error) {
      console.error("Error checking username:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to check username availability. Please try again."
      });
    } finally {
      setIsCheckingUsername(false);
    }
  }, [username, walletAddress, toast, navigate]);

  // Debounced username check effect
  useEffect(() => {
    if (username && username.length >= 3) {
      const timer = setTimeout(() => {
        checkUsernameAvailability();
      }, 500); // 500ms delay after user stops typing
      
      return () => clearTimeout(timer);
    } else {
      setUsernameAvailable(null);
    }
  }, [username, checkUsernameAvailability]);

  // Handle registration
  const handleRegister = async () => {
    if (!address || !isConnected) {
      toast({
        variant: "destructive",
        title: "Wallet not connected",
        description: "Please connect your wallet first"
      });
      return;
    }
    
    if (!username || !displayName) {
      toast({
        variant: "destructive",
        title: "Missing information",
        description: "Please fill in all required fields"
      });
      return;
    }
    
    if (username.length < 3) {
      toast({
        variant: "destructive",
        title: "Username too short",
        description: "Username must be at least 3 characters long"
      });
      return;
    }
    
    setIsRegisteringForm(true);
    try {
      await registerWithWallet({
        username,
        displayName,
        bio: bio || null,
        avatar: selectedAvatar,
        walletAddress: address!,
        network: "0x4b18" // DCSM network
      });
      
      // Successful registration will update the user context and trigger redirect
    } catch (error) {
      console.error("Registration error:", error);
    } finally {
      setIsRegisteringForm(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
      <div className="max-w-5xl w-full mx-auto flex flex-col lg:flex-row gap-8">
        {/* Hero section */}
        <div className="flex-1 flex flex-col justify-center">
          <h1 className="text-4xl font-bold tracking-tight text-primary mb-3">
            Web3 Social Platform
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            Connect with crypto enthusiasts, share ideas, and join the decentralized social revolution
          </p>
          <div className="space-y-4">
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M19 12a7 7 0 11-14 0 7 7 0 0114 0z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                  <path d="M21.54 15a10 10 0 01-4.53 5.1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Web3 Wallet Authentication</h3>
                <p className="text-sm text-muted-foreground">Connect and sign in with your favorite wallet</p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 12h.01M12 12h.01M15 12h.01M9 16h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                  <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12c0 1.821.487 3.53 1.338 5L2.5 21.5l4.5-.838A9.955 9.955 0 0012 22z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Share Ideas</h3>
                <p className="text-sm text-muted-foreground">Post thoughts, memes, and more with crypto community</p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                  <path d="M8.5 11a4 4 0 100-8 4 4 0 000 8zM20 8v6M23 11h-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Connect with Others</h3>
                <p className="text-sm text-muted-foreground">Follow, comment, and discover like-minded enthusiasts</p>
              </div>
            </div>
          </div>
        </div>

        {/* Auth section */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <Card className="w-full max-w-md p-6 bg-card border-border">
            <h2 className="text-2xl font-bold mb-6 text-center">Connect Your Wallet</h2>
            
            {!isConnected ? (
              <div className="space-y-4">
                <p className="text-muted-foreground text-center mb-4">
                  Connect your Web3 wallet to login or create a new account
                </p>
                <Button 
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                  onClick={() => connectWallet()}
                >
                  Connect Wallet
                </Button>
              </div>
            ) : isWalletRegistered ? (
              <div className="space-y-4 text-center">
                <div className="p-4 bg-green-500/10 rounded-md border border-green-500/20">
                  <p className="text-green-500 mb-2">Wallet Connected!</p>
                  <p className="text-muted-foreground text-sm">
                    Your wallet is recognized. You're being logged in automatically.
                  </p>
                </div>
                <p className="text-sm text-muted-foreground">
                  Address: {address?.slice(0, 6)}...{address?.slice(-4)}
                </p>
                <Button 
                  className="w-full"
                  onClick={() => navigate("/")}
                >
                  Go to Home
                </Button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="p-3 bg-blue-500/10 rounded-md border border-blue-500/20 mb-4">
                  <p className="text-blue-500 text-sm">
                    <span className="font-medium">Wallet Connected:</span> {address?.slice(0, 6)}...{address?.slice(-4)}
                  </p>
                </div>
                
                <div className="space-y-4">
                  {/* Registration Form */}
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <div className="flex gap-2">
                      <Input
                        id="username"
                        placeholder="Choose a unique username"
                        value={username}
                        onChange={(e) => {
                          setUsername(e.target.value.toLowerCase());
                          setUsernameAvailable(null);
                        }}
                        onBlur={checkUsernameAvailability}
                      />
                      {isCheckingUsername && (
                        <Button variant="outline" size="icon" disabled>
                          <Loader2 className="h-4 w-4 animate-spin" />
                        </Button>
                      )}
                    </div>
                    {usernameAvailable === true && (
                      <p className="text-xs text-green-500">Username is available!</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="displayName">Display Name</Label>
                    <Input
                      id="displayName"
                      placeholder="Your display name"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio (Optional)</Label>
                    <Textarea
                      id="bio"
                      placeholder="Tell us about yourself"
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      className="resize-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Choose an Avatar</Label>
                    <div className="grid grid-cols-3 gap-2">
                      {avatarOptions.map((avatar, index) => (
                        <div
                          key={index}
                          className={`cursor-pointer p-1 rounded-md ${
                            selectedAvatar === avatar ? "bg-primary/20 ring-2 ring-primary" : ""
                          }`}
                          onClick={() => setSelectedAvatar(avatar)}
                        >
                          <Avatar className="h-16 w-16 mx-auto">
                            <AvatarImage src={getAvatarSrc(avatar)} alt="Avatar" />
                            <AvatarFallback>AVT</AvatarFallback>
                          </Avatar>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button 
                    className="w-full mt-6" 
                    onClick={handleRegister}
                    disabled={isRegistering || !username || !displayName || usernameAvailable !== true}
                  >
                    {isRegistering ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating Account...
                      </>
                    ) : (
                      "Create Account"
                    )}
                  </Button>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}