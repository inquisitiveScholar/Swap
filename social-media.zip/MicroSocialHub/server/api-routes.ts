import { Express, Request, Response } from "express";
import { storage } from "./storage";
import { insertPostSchema, insertCommentSchema, insertLikeSchema, insertFollowSchema } from "@shared/schema";

// Middleware to ensure user is authenticated
const isAuthenticated = (req: Request, res: Response, next: any) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export function setupApiRoutes(app: Express) {
  // Get users who retweeted a post
  app.get("/api/posts/:id/retweeters", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      
      // Get all posts 
      const allPosts = await storage.getPosts(100, 0);
      
      // Find all posts that are retweets of the specified post
      const retweets = allPosts.filter(post => 
        post.originalPostId === postId
      );
      
      // Extract unique user information
      const retweeters = retweets.map(post => ({
        id: post.user.id,
        username: post.user.username,
        displayName: post.user.displayName,
        avatar: post.user.avatar
      }));
      
      res.json({ retweeters });
    } catch (error) {
      console.error('Error fetching retweeters:', error);
      res.status(500).json({ message: "Failed to fetch retweeters" });
    }
  });
  // Authentication check endpoint
  app.get("/api/auth/session", (req, res) => {
    if (req.isAuthenticated()) {
      res.status(200).json({ authenticated: true, user: req.user });
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });

  // User routes
  app.get("/api/user", isAuthenticated, (req, res) => {
    res.json(req.user);
  });

  // Update user profile
  app.patch("/api/auth/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const { displayName, bio, avatar } = req.body;
      
      const updatedUser = await storage.updateUser(userId, {
        displayName,
        bio,
        avatar
      });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Check username availability and wallet registration status
  app.get("/api/users/check-username", async (req, res) => {
    try {
      const username = req.query.username as string;
      const walletAddress = req.query.walletAddress as string;
      
      if (!username) {
        return res.status(400).json({ message: "Username is required" });
      }
      
      // Check username availability (case-insensitive)
      const normalizedUsername = username.toLowerCase();
      const existingUser = await storage.getUserByUsername(normalizedUsername);
      const usernameAvailable = !existingUser;
      
      // If wallet address is provided, check if it's already registered
      let walletAlreadyRegistered = false;
      let existingWalletUser = null;
      
      if (walletAddress) {
        existingWalletUser = await storage.getUserByWalletAddress(walletAddress);
        walletAlreadyRegistered = !!existingWalletUser;
      }
      
      res.json({ 
        available: usernameAvailable,
        walletAlreadyRegistered,
        existingWalletUser: existingWalletUser ? {
          username: existingWalletUser.username,
          displayName: existingWalletUser.displayName
        } : null
      });
    } catch (error) {
      console.error("Error checking username:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

// User search
  app.get("/api/users/search", async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const users = await storage.searchUsers(query);
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Get user profile by username with follow counts
  app.get("/api/users/profile/:username", async (req, res) => {
    try {
      const username = req.params.username;
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get all follows
      const follows = await storage.getAllFollows();
      
      // Count followers (users following this user)
      const followersCount = follows.filter(follow => follow.followingId === user.id).length;
      
      // Count following (users this user follows)
      const followingCount = follows.filter(follow => follow.followerId === user.id).length;
      
      // Return user with follow counts
      res.json({
        ...user,
        followersCount,
        followingCount
      });
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // User suggestions
  app.get("/api/users/suggestions", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 3;
      
      const suggestions = await storage.getUserSuggestions(user.id, limit);
      res.json(suggestions);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // User posts by ID
  app.get("/api/users/:id/posts", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      const posts = await storage.getPostsByUser(user.id, limit, offset);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Get user by ID
  app.get("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Check follow status
  app.get("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const followingId = parseInt(req.params.id);
      
      const follow = await storage.getFollow(user.id, followingId);
      res.json({ following: !!follow });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Follow a user
  app.post("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const followingId = parseInt(req.params.id);
      
      if (user.id === followingId) {
        return res.status(400).json({ message: "Cannot follow yourself" });
      }
      
      const follow = await storage.createFollow({
        followerId: user.id,
        followingId,
      });
      
      res.status(201).json(follow);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Unfollow a user
  app.delete("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const followingId = parseInt(req.params.id);
      
      const result = await storage.deleteFollow(user.id, followingId);
      
      if (!result) {
        return res.status(404).json({ message: "Follow relationship not found" });
      }
      
      res.status(200).json({ message: "Unfollowed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Update user profile
  app.patch("/api/users/profile", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const { displayName, bio, avatar } = req.body;
      
      const updatedUser = await storage.updateUser(user.id, {
        displayName,
        bio,
        avatar
      });
      
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Update user wallet
  app.patch("/api/users/wallet", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const { walletAddress, network } = req.body;
      
      const updatedUser = await storage.updateUser(user.id, {
        walletAddress,
        network
      });
      
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Disconnect wallet
  app.delete("/api/users/wallet", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      
      const updatedUser = await storage.updateUser(user.id, {
        walletAddress: null,
        network: null
      });
      
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Post routes
  // Trending posts endpoint - must come before /api/posts/:id
  app.get("/api/posts/trending", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      
      const trendingPosts = await storage.getTrendingPosts(limit);
      res.json(trendingPosts);
    } catch (error) {
      console.error("Error fetching trending posts:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/posts", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postData = insertPostSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const newPost = await storage.createPost(postData);
      res.status(201).json(newPost);
    } catch (error) {
      console.error('Post creation error:', error);
      res.status(400).json({ message: "Invalid input data" });
    }
  });
  
  // Update a post
  app.patch("/api/posts/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      // Get post first
      const post = await storage.getPost(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Check post ownership
      if (post.userId !== user.id) {
        return res.status(403).json({ message: "Not authorized to edit this post" });
      }
      
      // Update post
      const updatedPost = await storage.updatePost(postId, req.body);
      res.json(updatedPost);
    } catch (error) {
      console.error('Post update error:', error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Delete a post
  app.delete("/api/posts/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      // Get post first
      const post = await storage.getPost(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Check post ownership
      if (post.userId !== user.id) {
        return res.status(403).json({ message: "Not authorized to delete this post" });
      }
      
      // Delete post
      const result = await storage.deletePost(postId);
      if (result) {
        res.json({ message: "Post deleted successfully" });
      } else {
        res.status(500).json({ message: "Failed to delete post" });
      }
    } catch (error) {
      console.error('Post deletion error:', error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Get single post with user data (public endpoint)
  app.get("/api/posts/:id", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      
      if (isNaN(postId)) {
        return res.status(400).json({ message: "Invalid post ID" });
      }
      
      // Get the post
      const post = await storage.getPost(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Get user data for the post author
      const user = await storage.getUser(post.userId);
      if (!user) {
        return res.status(404).json({ message: "Post author not found" });
      }
      
      // Get reaction counts for the post
      const reactionCounts = await storage.getReactionCounts(postId);
      
      // Get tip total for the post
      const tipData = await storage.getTipsByPost(postId);
      
      // Construct the response with all necessary data
      const postWithUserData = {
        ...post,
        user: {
          id: user.id,
          username: user.username,
          displayName: user.displayName,
          avatar: user.avatar,
          bio: user.bio
        },
        likesCount: reactionCounts.likes,
        dislikesCount: reactionCounts.dislikes,
        tipTotal: tipData.total || "0"
      };
      
      res.json(postWithUserData);
    } catch (error) {
      console.error('Error fetching single post:', error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/posts", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      const userId = (req.user as any)?.id;
      
      // Always use the regular getPosts query with userId for user reactions
      // Pass userId even for unauthenticated users (will be undefined/null)
      const posts = await storage.getPosts(limit, offset, userId);
      res.json(posts);
    } catch (error) {
      console.error('Error fetching posts:', error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Get posts by hashtag
  app.get("/api/posts/hashtag/:hashtag", async (req, res) => {
    try {
      const { hashtag } = req.params;
      if (!hashtag) {
        return res.status(400).json({ message: "Hashtag parameter is required" });
      }
      
      // Get all posts
      const allPosts = await storage.getPosts(100, 0);
      
      // Filter posts that contain the hashtag
      const hashtagPattern = new RegExp(`#${hashtag}\\b`, 'i');
      const filteredPosts = allPosts.filter(post => hashtagPattern.test(post.content));
      
      // Count unique users
      const uniqueUserIds = new Set(filteredPosts.map(post => post.userId));
      
      res.json({ 
        posts: filteredPosts,
        postCount: filteredPosts.length,
        userCount: uniqueUserIds.size,
        hashtag
      });
    } catch (error) {
      console.error("Error fetching hashtag posts:", error);
      res.status(500).json({ message: "Failed to fetch hashtag posts" });
    }
  });

  app.get("/api/posts/:id", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const post = await storage.getPost(postId);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      res.json(post);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Comments
  app.post("/api/posts/:id/comments", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      const commentData = insertCommentSchema.parse({
        ...req.body,
        userId: user.id,
        postId,
      });
      
      const comment = await storage.createComment(commentData);
      
      // Update comment count
      await storage.updateCommentCount(postId, 1);
      
      // Create notification for post owner (if not commenting on own post)
      const post = await storage.getPost(postId);
      if (post && post.userId !== user.id) {
        await storage.createNotification({
          userId: post.userId,
          fromUserId: user.id,
          type: 'comment',
          postId: postId,
          message: `${user.displayName || user.username} commented on your post`,
          read: false
        });
      }
      
      res.status(201).json(comment);
    } catch (error) {
      res.status(400).json({ message: "Invalid input data" });
    }
  });
  
  // Edit a comment
  app.patch("/api/comments/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const commentId = parseInt(req.params.id);
      const { content } = req.body;
      
      if (!content || content.trim() === "") {
        return res.status(400).json({ message: "Comment cannot be empty" });
      }
      
      // Verify the comment exists and belongs to the user
      const comment = await storage.getComment(commentId);
      if (!comment) {
        return res.status(404).json({ message: "Comment not found" });
      }
      
      if (comment.userId !== user.id) {
        return res.status(403).json({ message: "You can only edit your own comments" });
      }
      
      // Update the comment with new content and edit flags
      const updatedComment = await storage.updateComment(commentId, {
        content,
        updatedAt: new Date(),
        isEdited: true
      });
      
      res.json(updatedComment);
    } catch (error) {
      console.error('Error editing comment:', error);
      res.status(500).json({ message: "Failed to edit comment" });
    }
  });
  
  // Delete a comment
  app.delete("/api/comments/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const commentId = parseInt(req.params.id);
      
      // Verify the comment exists and belongs to the user
      const comment = await storage.getComment(commentId);
      if (!comment) {
        return res.status(404).json({ message: "Comment not found" });
      }
      
      if (comment.userId !== user.id) {
        return res.status(403).json({ message: "You can only delete your own comments" });
      }
      
      // Delete the comment
      const result = await storage.deleteComment(commentId);
      
      // Update post comment count
      await storage.updateCommentCount(comment.postId, -1);
      
      res.json({ success: true, message: "Comment deleted successfully" });
    } catch (error) {
      console.error('Error deleting comment:', error);
      res.status(500).json({ message: "Failed to delete comment" });
    }
  });

  app.get("/api/posts/:id/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const comments = await storage.getCommentsByPost(postId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Likes
  app.post("/api/posts/:id/like", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      // Check if already liked
      const existingLike = await storage.getLike(postId, user.id);
      const post = await storage.getPost(postId);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      if (existingLike) {
        // Toggle like: if it exists, remove it
        await storage.deleteLike(postId, user.id);
        
        // Get updated post to return accurate likesCount
        const updatedPost = await storage.getPost(postId);
        return res.status(200).json({ 
          message: "Like removed", 
          liked: false,
          likesCount: updatedPost?.likesCount || 0
        });
      }
      
      // Otherwise create a new like
      const like = await storage.createLike({
        postId,
        userId: user.id,
      });
      
      // Create notification for post owner (if not liking own post)
      if (post.userId !== user.id) {
        await storage.createNotification({
          userId: post.userId,
          fromUserId: user.id,
          type: 'like',
          postId: postId,
          message: `${user.displayName || user.username} liked your post`,
          read: false
        });
      }
      
      // Get updated post to return accurate likesCount
      const updatedPost = await storage.getPost(postId);
      res.status(200).json({ 
        ...like, 
        liked: true, 
        likesCount: updatedPost?.likesCount || 0
      });
    } catch (error) {
      console.error('Error handling like:', error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/posts/:id/like", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      const result = await storage.deleteLike(postId, user.id);
      
      if (!result) {
        return res.status(404).json({ message: "Like not found" });
      }
      
      res.status(200).json({ message: "Unliked successfully" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.get("/api/posts/:id/like", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      const like = await storage.getLike(postId, user.id);
      res.json({ liked: !!like });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Retweet endpoints
  app.post("/api/posts/:id/retweet", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const originalPostId = parseInt(req.params.id);
      
      // Check if the original post exists
      const originalPost = await storage.getPost(originalPostId);
      if (!originalPost) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      // Check if the user has already retweeted this post
      const existingRetweet = await storage.getUserRetweetOfPost(user.id, originalPostId);
      
      if (existingRetweet) {
        // If already retweeted, remove the retweet
        await storage.deletePost(existingRetweet.id);
        
        // Decrement the original post's retweet count
        await storage.updateRetweetCount(originalPostId, -1);
        
        return res.status(200).json({ 
          message: "Retweet removed",
          retweeted: false,
          retweetCount: (originalPost.retweetCount || 1) - 1
        });
      }
      
      // Create a new retweet post
      const newRetweet = await storage.createPost({
        userId: user.id,
        content: req.body.content || originalPost.content,
        originalPostId: originalPostId,
        image: originalPost.image,
        video: originalPost.video
      });
      
      // Increment the original post's retweet count
      await storage.updateRetweetCount(originalPostId, 1);
      
      // Get the updated post with current retweet count
      const updatedOriginalPost = await storage.getPost(originalPostId);
      
      res.status(201).json({
        message: "Post retweeted successfully",
        retweeted: true,
        post: newRetweet,
        retweetCount: updatedOriginalPost?.retweetCount || 1
      });
    } catch (error) {
      console.error('Error handling retweet:', error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Check if a post has been retweeted by the user
  app.get("/api/posts/:id/retweet", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      const retweet = await storage.getUserRetweetOfPost(user.id, postId);
      const originalPost = await storage.getPost(postId);
      
      res.json({
        retweeted: !!retweet,
        retweetId: retweet ? retweet.id : null,
        retweetCount: originalPost?.retweetCount || 0
      });
    } catch (error) {
      console.error('Error checking retweet status:', error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Follow functionality 
  app.post("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const originalPostId = parseInt(req.params.id);
      
      // Check if the original post exists
      const originalPost = await storage.getPost(originalPostId);
      if (!originalPost) {
        return res.status(404).json({ message: "Original post not found" });
      }
      
      // Check if the user has already retweeted this post
      const existingRetweet = await storage.getUserRetweetOfPost(user.id, originalPostId);
      
      if (existingRetweet) {
        // If already retweeted, remove the retweet
        await storage.deletePost(existingRetweet.id);
        
        // Decrement the original post's retweet count
        await storage.updateRetweetCount(originalPostId, -1);
        
        return res.status(200).json({ 
          message: "Retweet removed",
          retweeted: false,
          retweetCount: (originalPost.retweetCount || 1) - 1
        });
      }
      
      // Create a new retweet post
      const newRetweet = await storage.createPost({
        userId: user.id,
        content: req.body.content || originalPost.content,
        originalPostId: originalPostId,
        image: originalPost.image,
        video: originalPost.video
      });
      
      // Increment the original post's retweet count
      await storage.updateRetweetCount(originalPostId, 1);
      
      // Get the updated post with current retweet count
      const updatedOriginalPost = await storage.getPost(originalPostId);
      
      res.status(201).json({
        message: "Post retweeted successfully",
        retweeted: true,
        post: newRetweet,
        retweetCount: updatedOriginalPost?.retweetCount || 1
      });
    } catch (error) {
      console.error('Error handling retweet:', error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // Check if a post has been retweeted by the user
  app.get("/api/posts/:id/retweet", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      const retweet = await storage.getUserRetweetOfPost(user.id, postId);
      const originalPost = await storage.getPost(postId);
      
      res.json({
        retweeted: !!retweet,
        retweetId: retweet ? retweet.id : null,
        retweetCount: originalPost?.retweetCount || 0
      });
    } catch (error) {
      console.error('Error checking retweet status:', error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Follow/Unfollow functionality
  app.post("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const targetUserId = parseInt(req.params.id);
      
      if (user.id === targetUserId) {
        return res.status(400).json({ message: "Cannot follow yourself" });
      }
      
      // Check if already following
      const existingFollow = await storage.getFollow(user.id, targetUserId);
      
      if (existingFollow) {
        // Unfollow
        await storage.deleteFollow(user.id, targetUserId);
        return res.json({ following: false, message: "Unfollowed successfully" });
      } else {
        // Follow
        await storage.createFollow({
          followerId: user.id,
          followingId: targetUserId
        });
        
        // Create notification for the followed user
        await storage.createNotification({
          userId: targetUserId,
          fromUserId: user.id,
          type: 'follow',
          message: `${user.displayName || user.username} started following you`,
          read: false
        });
        
        return res.json({ following: true, message: "Followed successfully" });
      }
    } catch (error) {
      console.error('Error handling follow:', error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Get follow status
  app.get("/api/users/:id/follow", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const targetUserId = parseInt(req.params.id);
      
      const follow = await storage.getFollow(user.id, targetUserId);
      res.json({ following: !!follow });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // Enhanced Posts endpoint with proper feed logic
  app.get("/api/posts", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;
      const feedType = req.query.feedType as string || 'home';
      
      let posts;
      
      if (feedType === 'explore') {
        // Explore feed: Show all posts globally except user's own
        posts = await storage.getPosts(limit, offset, user.id);
      } else {
        // Home feed: Show posts from followed users only
        posts = await storage.getPostsOptimized(limit, offset, user.id);
      }
      
      res.json(posts);
    } catch (error) {
      console.error('Error fetching posts:', error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Enhanced post deletion with proper cleanup
  app.delete("/api/posts/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postId = parseInt(req.params.id);
      
      const post = await storage.getPost(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      if (post.userId !== user.id) {
        return res.status(403).json({ message: "You can only delete your own posts" });
      }
      
      // Delete the post
      const result = await storage.deletePost(postId);
      
      if (result) {
        res.json({ 
          success: true, 
          message: "Post deleted successfully",
          postId: postId
        });
      } else {
        res.status(500).json({ message: "Failed to delete post" });
      }
    } catch (error) {
      console.error('Error deleting post:', error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Enhanced report post with proper cleanup
  app.post("/api/reports", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const { reportedPostId, reason, description } = req.body;
      
      if (!reportedPostId || !reason) {
        return res.status(400).json({ message: "Post ID and reason are required" });
      }
      
      const post = await storage.getPost(reportedPostId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      const report = await storage.createReport({
        reporterId: user.id,
        reportedPostId: reportedPostId,
        reportedUserId: post.userId,
        reason: reason,
        description: description || "",
      });
      
      res.status(201).json({ 
        success: true, 
        message: "Report submitted successfully",
        report: report
      });
    } catch (error) {
      console.error('Error creating report:', error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // Post creation with activity notifications
  app.post("/api/posts", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const postData = insertPostSchema.parse({
        ...req.body,
        userId: user.id,
      });
      
      const post = await storage.createPost(postData);
      
      // Get user's followers to notify them of new post
      const follows = await storage.getAllFollows();
      const followers = follows
        .filter(follow => follow.followingId === user.id)
        .map(follow => follow.followerId);
      
      // Create notifications for all followers about new post
      for (const followerId of followers) {
        await storage.createNotification({
          userId: followerId,
          fromUserId: user.id,
          type: 'post',
          postId: post.id,
          message: `${user.displayName || user.username} shared a new post`,
          read: false
        });
      }
      
      res.status(201).json(post);
    } catch (error) {
      console.error('Error creating post:', error);
      res.status(400).json({ message: "Invalid input data" });
    }
  });

  // Notification endpoints
  app.get("/api/notifications", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const notifications = await storage.getNotificationsByUser(user.id);
      res.json(notifications);
    } catch (error) {
      console.error('Error fetching notifications:', error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/notifications/:id/read", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const notificationId = parseInt(req.params.id);
      
      const notification = await storage.markNotificationAsRead(notificationId, user.id);
      if (!notification) {
        return res.status(404).json({ message: "Notification not found" });
      }
      
      res.json(notification);
    } catch (error) {
      console.error('Error marking notification as read:', error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/notifications/mark-all-read", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      await storage.markAllNotificationsAsRead(user.id);
      res.json({ message: "All notifications marked as read" });
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
      res.status(500).json({ message: "Server error" });
    }
  });
}