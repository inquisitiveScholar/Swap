import { normalizeUsdInput } from '../utils/currency.js';
import pino from 'pino';
import { Contract, JsonRpcProvider, formatUnits } from 'ethers';

type DexScreenerPair = {
  chainId?: string;
  dexId?: string;
  priceUsd?: string;
  liquidity?: { usd?: number };
};

type DexScreenerResponse = {
  pairs?: DexScreenerPair[];
};

type CoinGeckoTokenPriceResponse = {
  [contract: string]: {
    usd?: number;
  };
};

type GeckoTerminalPoolsResponse = {
  data?: Array<{
    attributes?: {
      token_price_usd?: string;
      price_usd?: string;
      base_token_price_usd?: string;
      reserve_in_usd?: string;
      dex_name?: string;
    };
  }>;
};

const DEFAULT_CHAIN = (process.env.PRICE_CHAIN || 'bsc').toLowerCase();
const PRICE_DEX_HINT = (process.env.PRICE_DEX_HINT || 'pancakeswap').toLowerCase();
const REQUEST_TIMEOUT_MS = Number(process.env.REQUEST_TIMEOUT_MS || 8000);
const FETCH_RETRIES = Number(process.env.FETCH_RETRIES || 2);
const RETRY_BASE_DELAY_MS = Number(process.env.RETRY_BASE_DELAY_MS || 500);
const BSC_RPC_URL = process.env.BSC_RPC_URL || 'https://bsc-dataseed.binance.org';
const logger = pino();

export type PriceProvider =
  | 'AUTO'
  | 'ONCHAIN_PANCAKE'
  | 'DEXSCREENER'
  | 'GECKOTERMINAL'
  | 'COINGECKO';

type PriceConfidence = 'LOW' | 'MEDIUM' | 'HIGH';

type PriceQuote = {
  price: string | null;
  providerUsed: Exclude<PriceProvider, 'AUTO'> | null;
  trace: string[];
  confidence?: PriceConfidence;
  confidenceReason?: string;
  medianPrice?: string | null;
  deviationPctFromMedian?: string | null;
};

const provider = new JsonRpcProvider(BSC_RPC_URL);

const ERC20_ABI = ['function decimals() view returns (uint8)'];
const ROUTER_V2_ABI = ['function getAmountsOut(uint256 amountIn, address[] memory path) view returns (uint256[] memory amounts)'];
const V3_FACTORY_ABI = ['function getPool(address tokenA, address tokenB, uint24 fee) view returns (address pool)'];
const V3_QUOTER_V2_ABI = [
  'function quoteExactInputSingle((address tokenIn,address tokenOut,uint256 amountIn,uint24 fee,uint160 sqrtPriceLimitX96) params) returns (uint256 amountOut,uint160 sqrtPriceX96After,uint32 initializedTicksCrossed,uint256 gasEstimate)'
];
const PANCAKE_ROUTER_V2 = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
const PANCAKE_V3_FACTORY = process.env.PANCAKE_V3_FACTORY || '0x0BFbCF9fa4f9C56B0F40a671Ad40E0805A091865';
const PANCAKE_V3_QUOTER_V2 = process.env.PANCAKE_V3_QUOTER_V2 || '0xB048Bbc1Ee6b733FFfCFb9e9CeF7375518e25997';
const WBNB = '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c';
const USDT = '0x55d398326f99059fF775485246999027B3197955';
const PANCAKE_V3_FEE_TIERS: number[] = [100, 500, 2500, 10000];

function pickBestPair(pairs: DexScreenerPair[], chain: string): DexScreenerPair | null {
  const inChain = pairs.filter((p) => (p.chainId || '').toLowerCase() === chain);
  if (!inChain.length) return null;

  const withDexHint = inChain.filter((p) =>
    (p.dexId || '').toLowerCase().includes(PRICE_DEX_HINT)
  );
  const source = withDexHint.length ? withDexHint : inChain;

  source.sort((a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0));
  return source[0] || null;
}

function mapChainToCoinGeckoPlatform(chain: string): string | null {
  const c = chain.toLowerCase();
  if (c === 'bsc' || c === 'bnb' || c === 'binance-smart-chain') return 'binance-smart-chain';
  if (c === 'eth' || c === 'ethereum') return 'ethereum';
  if (c === 'polygon' || c === 'matic') return 'polygon-pos';
  if (c === 'arbitrum' || c === 'arbitrum-one') return 'arbitrum-one';
  if (c === 'base') return 'base';
  return null;
}

async function fetchJson<T>(url: string): Promise<T | null> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        accept: 'application/json',
        'user-agent': 'poodl-telegram-bot/1.0',
      },
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function fetchWithRetry<T>(url: string): Promise<T | null> {
  for (let attempt = 0; attempt <= FETCH_RETRIES; attempt++) {
    const data = await fetchJson<T>(url);
    if (data) return data;
    if (attempt < FETCH_RETRIES) {
      await sleep(RETRY_BASE_DELAY_MS * (attempt + 1));
    }
  }
  return null;
}

async function fetchFromDexScreener(addr: string, chain: string): Promise<string | null> {
  const url = `https://api.dexscreener.com/latest/dex/tokens/${addr}`;
  const data = await fetchWithRetry<DexScreenerResponse>(url);
  if (!data) return null;
  const pairs = Array.isArray(data.pairs) ? data.pairs : [];
  const best = pickBestPair(pairs, chain);
  return best?.priceUsd ? normalizeUsdInput(best.priceUsd) : null;
}

async function fetchFromCoinGecko(addr: string, chain: string): Promise<string | null> {
  const platform = mapChainToCoinGeckoPlatform(chain);
  if (!platform) return null;
  const url =
    `https://api.coingecko.com/api/v3/simple/token_price/${platform}` +
    `?contract_addresses=${encodeURIComponent(addr)}` +
    '&vs_currencies=usd';
  const data = await fetchWithRetry<CoinGeckoTokenPriceResponse>(url);
  if (!data) return null;
  const row = data[addr.toLowerCase()];
  if (!row || row.usd == null) return null;
  return normalizeUsdInput(String(row.usd));
}

async function fetchFromGeckoTerminal(addr: string, chain: string): Promise<string | null> {
  // GeckoTerminal uses "bsc" as network slug for BNB Smart Chain.
  const network = chain === 'bsc' ? 'bsc' : chain;
  const url = `https://api.geckoterminal.com/api/v2/networks/${network}/tokens/${addr}/pools`;
  const data = await fetchWithRetry<GeckoTerminalPoolsResponse>(url);
  const pools = Array.isArray(data?.data) ? data!.data! : [];
  if (!pools.length) return null;

  pools.sort((a, b) => {
    const ar = Number(a.attributes?.reserve_in_usd || 0);
    const br = Number(b.attributes?.reserve_in_usd || 0);
    return br - ar;
  });

  for (const pool of pools) {
    const attrs = pool.attributes;
    const priceCandidates = [
      attrs?.token_price_usd,
      attrs?.price_usd,
      attrs?.base_token_price_usd,
    ];
    for (const raw of priceCandidates) {
      const normalized = raw ? normalizeUsdInput(raw) : null;
      if (normalized) return normalized;
    }
  }
  return null;
}

async function fetchFromPancakeOnchain(addr: string, chain: string): Promise<string | null> {
  if (chain !== 'bsc') return null;
  try {
    const token = new Contract(addr, ERC20_ABI, provider);
    const router = new Contract(PANCAKE_ROUTER_V2, ROUTER_V2_ABI, provider);
    const v3Factory = new Contract(PANCAKE_V3_FACTORY, V3_FACTORY_ABI, provider);
    const v3Quoter = new Contract(PANCAKE_V3_QUOTER_V2, V3_QUOTER_V2_ABI, provider);
    let decimals = 18;
    try {
      decimals = Number(await token.decimals());
      if (!Number.isFinite(decimals) || decimals < 0 || decimals > 36) decimals = 18;
    } catch {
      decimals = 18;
    }

    const oneToken = 10n ** BigInt(decimals);
    const normalizeUsdtAmount = (amount: bigint): string | null =>
      normalizeUsdInput(formatUnits(amount, 18));

    const quoteV3SingleBest = async (tokenIn: string, tokenOut: string, amountIn: bigint): Promise<bigint | null> => {
      let bestOut: bigint | null = null;
      for (const fee of PANCAKE_V3_FEE_TIERS) {
        try {
          const pool: string = await v3Factory.getPool(tokenIn, tokenOut, fee);
          if (!pool || pool === '0x0000000000000000000000000000000000000000') continue;
          const out = await v3Quoter.quoteExactInputSingle.staticCall({
            tokenIn,
            tokenOut,
            amountIn,
            fee,
            sqrtPriceLimitX96: 0n,
          });
          const amountOut = (Array.isArray(out) ? out[0] : out?.amountOut) as bigint | undefined;
          if (amountOut && amountOut > 0n && (!bestOut || amountOut > bestOut)) {
            bestOut = amountOut;
          }
        } catch {}
      }
      return bestOut;
    };

    // Preferred path: token -> USDT
    try {
      const amounts: bigint[] = await router.getAmountsOut(oneToken, [addr, USDT]);
      const usdtOut = amounts?.[amounts.length - 1];
      if (usdtOut && usdtOut > 0n) {
        const normalized = normalizeUsdtAmount(usdtOut);
        if (normalized) return normalized;
      }
    } catch {}

    // V3 direct path: token -> USDT using all supported fee tiers.
    try {
      const v3DirectUsdtOut = await quoteV3SingleBest(addr, USDT, oneToken);
      if (v3DirectUsdtOut && v3DirectUsdtOut > 0n) {
        const normalized = normalizeUsdtAmount(v3DirectUsdtOut);
        if (normalized) return normalized;
      }
    } catch {}

    // Fallback path (V2): token -> WBNB, then WBNB -> USDT
    try {
      const tokToWbnb: bigint[] = await router.getAmountsOut(oneToken, [addr, WBNB]);
      const wbnbOut = tokToWbnb?.[tokToWbnb.length - 1];
      if (!wbnbOut || wbnbOut <= 0n) return null;
      const wbnbToUsdt: bigint[] = await router.getAmountsOut(wbnbOut, [WBNB, USDT]);
      const usdtOut = wbnbToUsdt?.[wbnbToUsdt.length - 1];
      if (!usdtOut || usdtOut <= 0n) return null;
      const normalized = normalizeUsdtAmount(usdtOut);
      if (normalized) return normalized;
    } catch {}

    // Final fallback (V3 multi-hop): token -> WBNB, then WBNB -> USDT.
    try {
      const v3WbnbOut = await quoteV3SingleBest(addr, WBNB, oneToken);
      if (v3WbnbOut && v3WbnbOut > 0n) {
        const v3UsdtOut = await quoteV3SingleBest(WBNB, USDT, v3WbnbOut);
        if (v3UsdtOut && v3UsdtOut > 0n) {
          const normalized = normalizeUsdtAmount(v3UsdtOut);
          if (normalized) return normalized;
        }
      }
    } catch {}

    return null;
  } catch {
    return null;
  }
}

function providerOrder(provider: PriceProvider): Exclude<PriceProvider, 'AUTO'>[] {
  if (provider === 'ONCHAIN_PANCAKE') return ['ONCHAIN_PANCAKE'];
  if (provider === 'DEXSCREENER') return ['DEXSCREENER'];
  if (provider === 'GECKOTERMINAL') return ['GECKOTERMINAL'];
  if (provider === 'COINGECKO') return ['COINGECKO'];
  return ['ONCHAIN_PANCAKE', 'DEXSCREENER', 'GECKOTERMINAL', 'COINGECKO'];
}

function toFinitePositiveNumber(input: string): number | null {
  const n = Number(input);
  if (!Number.isFinite(n) || n <= 0) return null;
  return n;
}

function calculateMedian(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 0) {
    return (sorted[mid - 1] + sorted[mid]) / 2;
  }
  return sorted[mid];
}

function calculateDeviationPct(value: number, reference: number): number | null {
  if (!Number.isFinite(value) || !Number.isFinite(reference) || reference <= 0) return null;
  return Math.abs((value - reference) / reference) * 100;
}

function classifyConfidence(
  successCount: number,
  selectedDeviationPct: number | null
): { level: PriceConfidence; reason: string } {
  if (successCount <= 1) {
    return { level: 'LOW', reason: 'single source only' };
  }
  if (selectedDeviationPct == null) {
    return { level: 'LOW', reason: 'cannot compute deviation from median' };
  }
  if (successCount >= 3 && selectedDeviationPct <= 3) {
    return { level: 'HIGH', reason: `multi-source agreement within ${selectedDeviationPct.toFixed(2)}%` };
  }
  if (successCount >= 2 && selectedDeviationPct <= 8) {
    return { level: 'MEDIUM', reason: `partial agreement within ${selectedDeviationPct.toFixed(2)}%` };
  }
  return { level: 'LOW', reason: `high cross-source deviation (${selectedDeviationPct.toFixed(2)}%)` };
}

/**
 * Live current token price in USD for a token contract.
 * Uses DexScreener first, then CoinGecko fallback.
 */
export async function getCurrentPriceQuote(
  tokenAddress: string | null | undefined,
  chain: string = DEFAULT_CHAIN,
  provider: PriceProvider = 'AUTO'
): Promise<PriceQuote> {
  const addr = (tokenAddress || '').trim().toLowerCase();
  if (!addr) {
    return { price: null, providerUsed: null, trace: ['missing token address'] };
  }
  const chainNorm = (chain || DEFAULT_CHAIN).trim().toLowerCase();

  const sources = providerOrder(provider);
  const sourceValues: Partial<Record<Exclude<PriceProvider, 'AUTO'>, string>> = {};
  const trace: string[] = [];
  for (const source of sources) {
    try {
      const price =
        source === 'ONCHAIN_PANCAKE'
          ? await fetchFromPancakeOnchain(addr, chainNorm)
          : source === 'DEXSCREENER'
          ? await fetchFromDexScreener(addr, chainNorm)
          : source === 'GECKOTERMINAL'
            ? await fetchFromGeckoTerminal(addr, chainNorm)
          : await fetchFromCoinGecko(addr, chainNorm);
      if (price) {
        sourceValues[source] = price;
        trace.push(`${source}: ${price}`);
      } else {
        trace.push(`${source}: no price`);
        logger.warn(
          { tokenAddress: addr, chain: chainNorm, providerRequested: provider, source },
          'Live price source returned no value'
        );
      }
    } catch (e: any) {
      trace.push(`${source}: ${e?.message || 'error'}`);
      logger.warn(
        { tokenAddress: addr, chain: chainNorm, providerRequested: provider, source, err: e?.message || String(e) },
        'Live price source failed'
      );
    }
  }

  const successful = sources
    .map((source) => ({ source, price: sourceValues[source] || null }))
    .filter((row): row is { source: Exclude<PriceProvider, 'AUTO'>; price: string } => !!row.price);

  if (!successful.length) {
    return { price: null, providerUsed: null, trace, confidence: 'LOW', confidenceReason: 'no source returned a price' };
  }

  const selected = successful[0];
  const numericValues = successful
    .map((row) => ({ source: row.source, value: toFinitePositiveNumber(row.price), raw: row.price }))
    .filter((row): row is { source: Exclude<PriceProvider, 'AUTO'>; value: number; raw: string } => row.value != null);

  if (!numericValues.length) {
    return {
      price: selected.price,
      providerUsed: selected.source,
      trace,
      confidence: 'LOW',
      confidenceReason: 'selected source returned non-numeric value',
    };
  }

  const medianValue = calculateMedian(numericValues.map((row) => row.value));
  const selectedNumeric = numericValues.find((row) => row.source === selected.source)?.value ?? null;
  const deviationPct =
    selectedNumeric != null ? calculateDeviationPct(selectedNumeric, medianValue) : null;
  const confidence = classifyConfidence(successful.length, deviationPct);

  if (deviationPct != null && deviationPct > 8) {
    trace.push(`warning: selected source deviates ${deviationPct.toFixed(2)}% from median`);
  }

  const quote: PriceQuote = {
    price: selected.price,
    providerUsed: selected.source,
    trace,
    confidence: confidence.level,
    confidenceReason: confidence.reason,
    medianPrice: normalizeUsdInput(String(medianValue)),
    deviationPctFromMedian: deviationPct == null ? null : deviationPct.toFixed(4),
  };

  logger.info(
    {
      tokenAddress: addr,
      chain: chainNorm,
      providerRequested: provider,
      providerUsed: quote.providerUsed,
      price: quote.price,
      confidence: quote.confidence,
      confidenceReason: quote.confidenceReason,
      medianPrice: quote.medianPrice,
      deviationPctFromMedian: quote.deviationPctFromMedian,
    },
    'Live price fetched'
  );

  return quote;
}

export async function getCurrentPriceUsdNormalized(
  tokenAddress: string | null | undefined,
  chain: string = DEFAULT_CHAIN,
  provider: PriceProvider = 'AUTO'
): Promise<string | null> {
  const quote = await getCurrentPriceQuote(tokenAddress, chain, provider);
  return quote.price;
}
