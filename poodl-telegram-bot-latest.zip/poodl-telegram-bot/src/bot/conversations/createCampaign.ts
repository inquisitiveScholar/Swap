import { Conversation, ConversationFlavor } from '@grammyjs/conversations';
import { InlineKeyboard } from 'grammy';
import { MyContext } from '../../index.js';
import prisma from '../../database/client.js';
import { looksLikeBareYear, parseTimeInput, parseUnlockUserText } from '../../utils/time.js';
import { UNLOCK_CREATE_INTRO, UNLOCK_TYPE_MYSELF_PROMPT } from '../../constants/unlockTimeUx.js';
import { normalizeUserUrl } from '../../utils/url.js';
import { messageTextToHtml } from '../../utils/telegramFormat.js';
import { ANNOUNCEMENT_TEXT_LENGTH_HELP_CREATE } from '../../constants/telegramLimits.js';
import {
  computeMarketCapUsd,
  formatUsdDisplay,
  normalizeSupplyInput,
} from '../../utils/currency.js';
import { safeAnswerCallbackQuery } from '../../utils/telegramApi.js';
import {
  getCurrentPriceQuote,
  PriceProvider,
} from '../../services/livePrice.js';
import { imageFileIdFromMessage } from '../../utils/media.js';

type MyConversation = Conversation<MyContext>;


const MAX_LINK_BUTTONS = 12;
const CANCEL_TEXT_RE = /^(?:\/cancel|cancel|back|\/admin)$/i;

function normalizeBscContract(raw: string): string | null {
  const t = raw.trim();
  if (!/^0x[a-fA-F0-9]{40}$/.test(t)) return null;
  return t.toLowerCase();
}

async function collectContractWithConfirmation(
  conversation: MyConversation,
  ctx: MyContext,
  source: PriceProvider
): Promise<{ tokenContract: string | null; currentPrice: string | null; source: PriceProvider; cancelled?: boolean }> {
  while (true) {
    await ctx.reply(
      '🧬 *Token contract (BSC)*\n\n' +
        'Send token contract address (example: `0xC70e8a2d156eAd8AE24EF13E887e75559688722B`).\n\n' +
        'Send `skip` to continue without live current price.',
      { parse_mode: 'Markdown' }
    );
    const addrMsg = await conversation.waitFor(':text');
    const raw = (addrMsg.message?.text || '').trim();
    if (!raw) continue;
    if (CANCEL_TEXT_RE.test(raw)) {
      await sendCreateCancelled(ctx);
      return { tokenContract: null, currentPrice: null, source, cancelled: true };
    }
    if (raw.toLowerCase() === 'skip') {
      return { tokenContract: null, currentPrice: null, source };
    }

    const contract = normalizeBscContract(raw);
    if (!contract) {
      await addrMsg.reply('⚠️ Invalid contract format. Expected `0x` + 40 hex chars.', {
        parse_mode: 'Markdown',
      });
      continue;
    }

    const quote = await getCurrentPriceQuote(contract, 'bsc', source);
    const currentPrice = quote.price;
    if (!currentPrice) {
      await ctx.reply(
        `⚠️ Could not fetch live price (${source}). Try another address or "skip".\n` +
          `Debug: ${quote.trace.join(' | ') || 'no source returned a value'}`
      );
      continue;
    }

    const priceDisp = formatUsdDisplay(currentPrice) || `$${currentPrice}`;
    const sourceUsed = quote.providerUsed || source;
    await ctx.reply(
      `✅ Detected *Current Price:* ${priceDisp}\n` +
        `Source: \`${sourceUsed}\`\n` +
        `Confidence: *${quote.confidence || 'LOW'}*${quote.confidenceReason ? ` (${quote.confidenceReason})` : ''}\n` +
        `${quote.deviationPctFromMedian ? `Deviation vs median: *${quote.deviationPctFromMedian}%*\n` : ''}\n` +
        'Is this correct?',
      {
        parse_mode: 'Markdown',
        reply_markup: new InlineKeyboard()
          .text('✅ Yes, use this', 'contract_ok')
          .row()
          .text('🔁 No, re-enter contract', 'contract_retry'),
      }
    );
    const confirm = (await conversation.waitForCallbackQuery([
      'contract_ok',
      'contract_retry',
    ])) as any;
    await safeAnswerCallbackQuery(confirm);
    if (confirm.callbackQuery.data === 'contract_ok') {
      return { tokenContract: contract, currentPrice, source };
    }
  }
}

async function choosePriceSource(conversation: MyConversation, ctx: MyContext): Promise<PriceProvider | 'CANCEL'> {
  await ctx.reply(
    '📡 *Price source*\n\nChoose where to fetch live current price from:',
    {
      parse_mode: 'Markdown',
      reply_markup: new InlineKeyboard()
        .text('🤖 Auto (recommended)', 'src_auto')
        .row()
        .text('🥞 Pancake Onchain', 'src_onchain')
        .row()
        .text('🟪 DexScreener', 'src_dex')
        .text('🦎 GeckoTerminal', 'src_gt')
        .row()
        .text('🦎 CoinGecko', 'src_cg')
        .row()
        .text('❌ Cancel to Admin', 'create_cancel'),
    }
  );
  const picked = (await conversation.waitForCallbackQuery([
    'src_auto',
    'src_onchain',
    'src_dex',
    'src_gt',
    'src_cg',
    'create_cancel',
  ])) as any;
  await safeAnswerCallbackQuery(picked);
  const data = picked.callbackQuery?.data;
  if (data === 'create_cancel') return 'CANCEL';
  if (data === 'src_onchain') return 'ONCHAIN_PANCAKE';
  if (data === 'src_dex') return 'DEXSCREENER';
  if (data === 'src_gt') return 'GECKOTERMINAL';
  if (data === 'src_cg') return 'COINGECKO';
  return 'AUTO';
}

async function sendCreateCancelled(ctx: MyContext) {
  await ctx.reply('🛑 Campaign creation cancelled.', {
    parse_mode: 'Markdown',
    reply_markup: new InlineKeyboard().text('🛡 Back to Admin Menu', 'admin_main'),
  });
}

async function collectCampaignLinks(
  conversation: MyConversation,
  ctx: MyContext
): Promise<{ label: string; url: string }[] | null> {
  const links: { label: string; url: string }[] = [];

  await ctx.reply(
    '🔗 *Step 7: Buttons under your post*\n\n' +
      'These show as tap-to-open links under your announcement (Dex, X, Telegram, etc.).',
    {
      parse_mode: 'Markdown',
      reply_markup: new InlineKeyboard()
        .text('➕ Add a button', 'link_intro_add')
        .row()
        .text('⏭ Skip — no buttons', 'link_intro_skip')
        .row()
        .text('❌ Cancel to Admin', 'create_cancel'),
    }
  );

  const intro = (await conversation.waitForCallbackQuery([
    'link_intro_add',
    'link_intro_skip',
    'create_cancel',
  ])) as any;
  await safeAnswerCallbackQuery(intro);
  if (intro.callbackQuery.data === 'create_cancel') {
    await sendCreateCancelled(ctx);
    return null;
  }
  if (intro.callbackQuery.data === 'link_intro_skip') {
    return [];
  }

  while (true) {
    if (links.length >= MAX_LINK_BUTTONS) {
      await ctx.reply(`ℹ️ Maximum ${MAX_LINK_BUTTONS} buttons reached. Continuing…`, {
        parse_mode: 'Markdown',
      });
      break;
    }

    await ctx.reply(
      links.length === 0
        ? '✏️ *Button label*\n\nWhat should the button say?\n_(Short text only — e.g. Buy, Chart, Telegram, Website.)_'
        : '✏️ *Next button label*\n\nWhat should this next button say?',
      { parse_mode: 'Markdown' }
    );

    const labelCtx = await conversation.waitFor(':text');
    const label = (labelCtx.message?.text || '').trim();
    if (CANCEL_TEXT_RE.test(label)) {
      await sendCreateCancelled(ctx);
      return null;
    }
    if (!label) {
      await labelCtx.reply('⚠️ Please send a short label for the button.', {
        parse_mode: 'Markdown',
      });
      continue;
    }
    if (label.length > 64) {
      await labelCtx.reply('⚠️ Please use a shorter label (under ~64 characters).', {
        parse_mode: 'Markdown',
      });
      continue;
    }

    let url: string | null = null;
    while (!url) {
      await ctx.reply(
        '🔗 *Link address*\n\n' +
          'Paste the **full URL** for this button.\n\n' +
          'Examples:\n' +
          '`https://dexscreener.com/...`\n' +
          '`pump.fun/...` _(https will be added if missing)_',
        { parse_mode: 'Markdown' }
      );
      const urlCtx = await conversation.waitFor(':text');
      const rawUrl = (urlCtx.message?.text || '').trim();
      if (CANCEL_TEXT_RE.test(rawUrl)) {
        await sendCreateCancelled(ctx);
        return null;
      }
      url = normalizeUserUrl(rawUrl);
      if (!url) {
        await urlCtx.reply(
          '⚠️ That does not look like a valid web link. Try again with something like `https://…` or `site.com/path`.',
          { parse_mode: 'Markdown' }
        );
      }
    }

    links.push({ label, url });

    if (links.length >= MAX_LINK_BUTTONS) {
      await ctx.reply(`✅ Added *${links.length}* button(s).`, { parse_mode: 'Markdown' });
      break;
    }

    await ctx.reply(
      `✅ *Button saved* (${links.length} total).\n\nAdd another, or continue to the next step.`,
      {
        parse_mode: 'Markdown',
        reply_markup: new InlineKeyboard()
          .text('➕ Add another button', 'link_more_add')
          .row()
          .text('✅ Continue', 'link_more_done')
          .row()
          .text('❌ Cancel to Admin', 'create_cancel'),
      }
    );

    const next = (await conversation.waitForCallbackQuery([
      'link_more_add',
      'link_more_done',
      'create_cancel',
    ])) as any;
    await safeAnswerCallbackQuery(next);
    if (next.callbackQuery.data === 'create_cancel') {
      await sendCreateCancelled(ctx);
      return null;
    }
    if (next.callbackQuery.data === 'link_more_done') {
      break;
    }
  }

  return links;
}

/**
 * Handles the guided flow for creating a new campaign.
 */
export async function createCampaignConversation(conversation: MyConversation, ctx: MyContext) {
  try {
    await ctx.reply(
      '_Tip: send `cancel` anytime to stop and go back to admin._',
      { parse_mode: 'Markdown' }
    );

    // 1. Heading (posted as-is; formatting from Telegram is preserved)
    await ctx.reply(
      '📰 *Step 1: Heading*\n\n' +
        'Optional title line above the announcement. It is posted **exactly** as you send it — ' +
        'including **bold**, _italic_, links, and emoji — with no extra decoration added.',
      { parse_mode: 'Markdown' }
    );
    const nameMsg = await conversation.waitFor(':text');
    if (CANCEL_TEXT_RE.test(nameMsg.message?.text || '')) {
      await sendCreateCancelled(ctx);
      return;
    }
    const tokenName = messageTextToHtml(nameMsg.message);

    // 2. Main announcement body
    await ctx.reply(
      '✍️ *Step 2: Announcement text*\n\n' +
        'The main message. **Bold**, _italic_, and other Telegram formatting are kept when posted.' +
        ANNOUNCEMENT_TEXT_LENGTH_HELP_CREATE,
      { parse_mode: 'Markdown' }
    );
    const textMsg = await conversation.waitFor(':text');
    if (CANCEL_TEXT_RE.test(textMsg.message?.text || '')) {
      await sendCreateCancelled(ctx);
      return;
    }
    const text = messageTextToHtml(textMsg.message);

    // 3–4. Market stats inputs
    await ctx.reply(
      '📈 *Step 3: Total supply* (optional)\n\n' +
        'Token amount (example: `1000000000`). Type `skip` if unknown.',
      { parse_mode: 'Markdown' }
    );
    const supMsg = await conversation.waitFor(':text');
    if (CANCEL_TEXT_RE.test(supMsg.message?.text || '')) {
      await sendCreateCancelled(ctx);
      return;
    }
    const supRaw = (supMsg.message?.text || '').trim();
    let circulatingSupply: string | null = null;
    if (supRaw && supRaw.toLowerCase() !== 'skip') {
      circulatingSupply = normalizeSupplyInput(supRaw);
      if (!circulatingSupply) {
        await ctx.reply('⚠️ Could not parse total supply — leaving it empty.', { parse_mode: 'Markdown' });
      }
    }

    await ctx.reply('💵 *Step 4: Current price source*\n\nWe need token contract to fetch live BSC price.', {
      parse_mode: 'Markdown',
    });
    const priceSource = await choosePriceSource(conversation, ctx);
    if (priceSource === 'CANCEL') {
      await sendCreateCancelled(ctx);
      return;
    }
    const { tokenContract, currentPrice, cancelled } = await collectContractWithConfirmation(
      conversation,
      ctx,
      priceSource
    );
    if (cancelled) return;
    const price = currentPrice;
    const marketCap =
      price && circulatingSupply ? computeMarketCapUsd(price, circulatingSupply) : null;

    // 6. Enter Unlock Time — presets + one “type myself” path
    const timeKeyboard = new InlineKeyboard()
      .text('1 day', 'time_1d')
      .text('3 days', 'time_3d')
      .text('7 days', 'time_7d')
      .row()
      .text('15 days', 'time_15d')
      .text('30 days', 'time_30d')
      .text('1 month', 'time_1m')
      .row()
      .text('✏️ Type myself', 'time_custom')
      .row()
      .text('❌ Cancel to Admin', 'create_cancel');

    await ctx.reply(`📌 *Step 5 of 9*\n\n${UNLOCK_CREATE_INTRO}`, {
      parse_mode: 'Markdown',
      reply_markup: timeKeyboard,
    });

    let unlockTime: Date | null = null;
    const timeChoice = await conversation.waitForCallbackQuery([
      'time_1d',
      'time_3d',
      'time_7d',
      'time_15d',
      'time_30d',
      'time_1m',
      'time_custom',
      'create_cancel',
    ]) as any;
    await safeAnswerCallbackQuery(timeChoice);
    if (timeChoice.callbackQuery.data === 'create_cancel') {
      await sendCreateCancelled(ctx);
      return;
    }

    if (timeChoice.callbackQuery.data === 'time_custom') {
      await ctx.reply(UNLOCK_TYPE_MYSELF_PROMPT, { parse_mode: 'Markdown' });
      const customMsg = await conversation.waitFor(':text');
      if (CANCEL_TEXT_RE.test(customMsg.message?.text || '')) {
        await sendCreateCancelled(ctx);
        return;
      }
      const raw = customMsg.message?.text || '';
      unlockTime = parseUnlockUserText(raw);
      if (!unlockTime) {
        if (looksLikeBareYear(raw)) {
          await ctx.reply(
            '❌ Send a full date, e.g. `2026-04-26 10:00`, or a number of *days* like `14`.',
            { parse_mode: 'Markdown' }
          );
        } else {
          await ctx.reply(
            '❌ Not recognized. Examples: `14` (days), `2026-04-26 10:00`, or `in 2 hours`.',
            { parse_mode: 'Markdown' }
          );
        }
        return;
      }
    } else {
      const mapping: Record<string, string> = {
        time_1d: 'in 1 day',
        time_3d: 'in 3 days',
        time_7d: 'in 7 days',
        time_15d: 'in 15 days',
        time_30d: 'in 30 days',
        time_1m: 'in 1 month',
      };
      unlockTime = parseTimeInput(mapping[timeChoice.callbackQuery.data]);
    }

    if (!unlockTime) {
      await ctx.reply('❌ *Invalid time.* Please start again from /admin.', { parse_mode: 'Markdown' });
      return;
    }

    // 6. Media Type
    await ctx.reply('🖼 *Step 6: Visual Style*\n\nChoose how your message should be posted.', {
      parse_mode: 'Markdown',
      reply_markup: new InlineKeyboard()
        .text('📣 Announcement + Countdown', 'media_with_countdown')
        .row()
        .text('🖼 Announcement Only', 'media_announcement_only')
        .row()
        .text('❌ Cancel to Admin', 'create_cancel'),
    });
    const mediaChoice = await conversation.waitForCallbackQuery([
      'media_with_countdown',
      'media_announcement_only',
      'create_cancel',
    ]) as any;
    if (mediaChoice.callbackQuery.data === 'create_cancel') {
      await safeAnswerCallbackQuery(mediaChoice);
      await sendCreateCancelled(ctx);
      return;
    }
    const mediaType = mediaChoice.callbackQuery.data === 'media_announcement_only' ? 'IMAGE_ONLY' : 'IMAGE';
    await safeAnswerCallbackQuery(mediaChoice);

    let imageFileId: string | null = null;
    if (mediaType === 'IMAGE' || mediaType === 'IMAGE_ONLY') {
      await ctx.reply(
        '📸 *Step 6.1: Announcement image*\n\n' +
          'Send your image the usual way:\n' +
          '• Tap the **attachment** icon and pick **Gallery** or **File**, or\n' +
          '• Paste an image from your clipboard.\n\n' +
          'Supported: JPG, PNG, GIF, WebP, etc.',
        { parse_mode: 'Markdown' }
      );
      while (!imageFileId) {
        const imageCtx = (await conversation.waitFor([
          ':photo',
          ':document',
          ':text',
        ])) as MyContext;
        imageFileId = imageFileIdFromMessage(imageCtx);
        if (!imageFileId) {
          await imageCtx.reply(
            '⚠️ Please send an **image** (photo or image file). If you sent a document, make sure it is a picture (PNG, JPG, …), not a PDF or zip.',
            { parse_mode: 'Markdown' }
          );
        }
      }
    }

    // 4. Links (guided: label → URL → inline add / continue)
    const links = await collectCampaignLinks(conversation, ctx);
    if (!links) return;

    // 8. Interval
    const intervalKeyboard = new InlineKeyboard()
      .text('1 Min', 'int_1').text('5 Min', 'int_5').text('15 Min', 'int_15').row()
      .text('30 Min', 'int_30').text('1 Hour', 'int_60').text('⌨️ Custom', 'int_custom')
      .row()
      .text('❌ Cancel to Admin', 'create_cancel');

    await ctx.reply('🔄 *Step 8: Posting Interval*\n\nHow often should the bot update/repost the message?', {
      parse_mode: 'Markdown',
      reply_markup: intervalKeyboard,
    });

    let interval = 5;
    const intChoice = await conversation.waitForCallbackQuery([
      'int_1',
      'int_5',
      'int_15',
      'int_30',
      'int_60',
      'int_custom',
      'create_cancel',
    ]) as any;
    await safeAnswerCallbackQuery(intChoice);
    if (intChoice.callbackQuery.data === 'create_cancel') {
      await sendCreateCancelled(ctx);
      return;
    }

    if (intChoice.callbackQuery.data === 'int_custom') {
      await ctx.reply('⌨️ Enter interval in minutes:');
      const intMsg = await conversation.waitFor(':text');
      if (CANCEL_TEXT_RE.test(intMsg.message?.text || '')) {
        await sendCreateCancelled(ctx);
        return;
      }
      interval = parseInt(intMsg.message?.text || '5');
    } else {
      interval = parseInt(intChoice.callbackQuery.data.replace('int_', ''));
    }

    // 9. Target Chat ID
    await ctx.reply('📣 *Step 9: Target Group/Channel*\n\nTo get the ID:\n1. Add this bot to your group\n2. Make it **Admin**\n3. Forward a message from the group to @userinfobot to get the ID (usually starts with `-100`).\n\n*Enter the Chat ID now:*', {
      parse_mode: 'Markdown',
    });
    const chatMsg = await conversation.waitFor(':text');
    if (CANCEL_TEXT_RE.test(chatMsg.message?.text || '')) {
      await sendCreateCancelled(ctx);
      return;
    }
    let chatId: bigint;
    try {
      chatId = BigInt(chatMsg.message?.text || '');
    } catch {
      await ctx.reply('❌ Invalid Chat ID. Please restart. /admin');
      return;
    }

    // 7. Preview & Save
    await ctx.reply('*Saving campaign…*', { parse_mode: 'Markdown' });

    const campaign = await prisma.campaign.create({
      data: {
        adminId: BigInt(ctx.from?.id || 0),
        chatId: chatId,
        text: text,
        tokenName: tokenName,
        tokenSymbol: null,
        tokenContract: tokenContract,
        priceSource: priceSource,
        price: price,
        circulatingSupply: circulatingSupply,
        marketCap: marketCap,
        templateId: 'HYPE',
        unlockTime: unlockTime,
        mediaType: mediaType,
        imageFileId: imageFileId,
        intervalMinutes: interval,
        links: {
          create: links,
        },
      },
      include: {
        links: true,
      },
    });

    await ctx.reply(`🎉 *Campaign Successfully Created!*\n\n📍 *Chat ID:* \`${campaign.chatId}\`\n⏱ *Updates:* Every ${campaign.intervalMinutes}m\n\nThe scheduler will start posting shortly.`, {
      parse_mode: 'Markdown',
    });
  } catch (err) {
    console.error('Conversation error in createCampaign:', err);
    await ctx.reply('❌ *Oops!* Something went wrong with the campaign creation flow.\n\nError details have been logged. Please ensure the database schema is up to date.');
  }
}
