import { Context } from 'grammy';
import { MyContext } from '../index.js';

/** Telegram sends gallery picks as `photo`; "send as file" often arrives as `document` with an image MIME type. */
export function imageFileIdFromMessage(ctx: MyContext): string | null {
  const m = ctx.message;
  if (!m) return null;
  if (m.photo?.length) {
    return m.photo[m.photo.length - 1].file_id;
  }
  if (m.document) {
    const d = m.document;
    const mime = d.mime_type ?? '';
    const name = (d.file_name ?? '').toLowerCase();
    const isImageMime = mime.startsWith('image/');
    const isImageName = /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(name);
    if (isImageMime || isImageName) {
      return d.file_id;
    }
  }
  const t = m.text?.trim();
  if (t && t.length > 10 && !/\s/.test(t)) {
    return t;
  }
  return null;
}
