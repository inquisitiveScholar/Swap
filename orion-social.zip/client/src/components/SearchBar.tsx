import { useState, useEffect, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, X, Loader2 } from "lucide-react";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function SearchBar({ onClose }: { onClose?: () => void }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  const searchMutation = useMutation({
    mutationFn: async (searchQuery: string) => {
      const response = await apiRequest("GET", `/api/users/search?q=${encodeURIComponent(searchQuery)}`);
      if (!response.ok) {
        throw new Error("Search failed");
      }
      return response.json();
    },
    onSuccess: (data) => {
      setResults(data);
      setIsLoading(false);
    },
    onError: () => {
      setIsLoading(false);
      toast({
        variant: "destructive",
        title: "Search failed",
        description: "Unable to perform search. Please try again.",
      });
    }
  });

  // Handle outside click to close results
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      if (query.trim().length > 1) {
        setIsLoading(true);
        searchMutation.mutate(query);
        setShowResults(true);
      } else {
        setResults([]);
        setShowResults(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [query]);

  const handleClear = () => {
    setQuery("");
    setResults([]);
    setShowResults(false);
  };

  const handleSelect = (username: string) => {
    setShowResults(false);
    if (onClose) onClose();
  };

  return (
    <div className="relative w-full max-w-md" ref={searchRef}>
      <div className="relative">
        <Input
          type="text"
          placeholder="Search users..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-10 pr-10 bg-background border-neutral-800 focus-visible:ring-[#b07c1d]"
          onFocus={() => {
            if (query.trim().length > 1) {
              setShowResults(true);
            }
          }}
        />
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <Search className="h-4 w-4 text-muted-foreground" />
        </div>
        {query && !onClose && (
          <Button
            variant="ghost"
            className="absolute inset-y-0 right-0 flex items-center pr-3 h-full"
            onClick={handleClear}
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {showResults && (
        <Card className="absolute mt-1 w-full z-50 shadow-lg border-neutral-800">
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex justify-center items-center py-4">
                <Loader2 className="h-5 w-5 animate-spin text-[#b07c1d]" />
              </div>
            ) : results.length > 0 ? (
              <div className="max-h-[300px] overflow-y-auto">
                {results.map((result) => (
                  <Link 
                    key={result.id} 
                    href={`/profile/${result.username}`}
                    onClick={() => handleSelect(result.username)}
                  >
                    <div className="flex items-center gap-3 p-3 hover:bg-accent cursor-pointer transition-colors">
                      <Avatar className="h-10 w-10">
                        <AvatarImage 
                          src={result.avatar || undefined} 
                          alt={result.displayName}
                        />
                        <AvatarFallback className="bg-[#b07c1d]/10 text-[#b07c1d]">
                          {result.displayName.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col">
                        <span className="font-medium">{result.displayName}</span>
                        <span className="text-muted-foreground text-sm">@{result.username}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : query.trim().length > 1 ? (
              <div className="p-4 text-center text-muted-foreground">
                No users found
              </div>
            ) : null}
          </CardContent>
        </Card>
      )}
    </div>
  );
}