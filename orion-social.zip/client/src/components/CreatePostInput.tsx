import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/context/AuthContext";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import EmojiPicker, { Theme, EmojiClickData } from "emoji-picker-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Image, Smile, Hash, BarChart, X, UserIcon, Menu, Sticker, Gift } from "lucide-react";
import GifSelector from "./GifSelector";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface CreatePostInputProps {
  inDialog?: boolean;
  onComplete?: () => void;
}

// Crypto-themed meme images and NFT images for posts
const CRYPTO_MEMES = [
  {
    id: 1,
    name: "HODL",
    category: "meme",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=hodl&backgroundColor=0f172a&scale=85",
  },
  {
    id: 2,
    name: "To The Moon",
    category: "meme",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=moon&backgroundColor=0f172a&scale=85",
  },
  {
    id: 3,
    name: "Diamond Hands",
    category: "meme",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=diamond&backgroundColor=0f172a&scale=85",
  },
  {
    id: 4,
    name: "Rekt",
    category: "meme",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=rekt&backgroundColor=0f172a&scale=85",
  },
  {
    id: 5,
    name: "Bull Run",
    category: "meme",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=bull&backgroundColor=0f172a&scale=85",
  },
  {
    id: 6,
    name: "Bear Market",
    category: "meme",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=bear&backgroundColor=0f172a&scale=85",
  },
  {
    id: 7,
    name: "BTC Pizza",
    category: "meme",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=pizza&backgroundColor=0f172a&scale=85",
  },
  {
    id: 8,
    name: "ETH Merge",
    category: "nft",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=merge&backgroundColor=0f172a&scale=85",
  },
  {
    id: 9,
    name: "Gas Fees",
    category: "nft",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=gas&backgroundColor=0f172a&scale=85",
  },
  {
    id: 10,
    name: "Crypto Punk",
    category: "nft",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=punk&backgroundColor=0f172a&scale=85",
  },
  {
    id: 11,
    name: "Metaverse",
    category: "nft",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=metaverse&backgroundColor=0f172a&scale=85",
  },
  {
    id: 12,
    name: "Smart Contract",
    category: "nft",
    url: "https://api.dicebear.com/7.x/bottts/svg?seed=smart&backgroundColor=0f172a&scale=85",
  }
];

export default function CreatePostInput({ inDialog = false, onComplete }: CreatePostInputProps) {
  const [content, setContent] = useState("");
  const [image, setImage] = useState("");
  const [video, setVideo] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showMemeDialog, setShowMemeDialog] = useState(false);
  const [cursorPosition, setCursorPosition] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [mediaType, setMediaType] = useState<"image" | "video" | "meme" | "nft" | "gif" | null>(null);
  const [activeCategory, setActiveCategory] = useState<"all" | "meme" | "nft">("all");
  const [showGifSelector, setShowGifSelector] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const emojiPickerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const isMobile = useIsMobile();
  const { user } = useAuth();
  const { toast } = useToast();

  const createPostMutation = useMutation({
    mutationFn: (postData: { content: string; image?: string; video?: string }) => 
      apiRequest("POST", "/api/posts", postData),
    onSuccess: () => {
      setContent("");
      setImage("");
      setVideo("");
      setMediaType(null);
      
      toast({
        title: "Post created",
        description: "Your post has been published",
      });
      
      // Invalidate posts query to refresh the feed
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      
      if (onComplete) {
        onComplete();
      }
    },
    onError: (error) => {
      console.error("Post creation error:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create post. Please try again.",
      });
    }
  });

  // Close emoji picker when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (emojiPickerRef.current && !emojiPickerRef.current.contains(event.target as Node)) {
        setShowEmojiPicker(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Handle emoji insertion at cursor position
  const handleEmojiClick = (emojiData: EmojiClickData) => {
    const emoji = emojiData.emoji;
    const textBeforeCursor = content.substring(0, cursorPosition);
    const textAfterCursor = content.substring(cursorPosition);
    
    const newText = textBeforeCursor + emoji + textAfterCursor;
    setContent(newText);
    
    // Close picker after selection on mobile
    if (isMobile) {
      setShowEmojiPicker(false);
    }
    
    // Set focus back to textarea and update cursor position
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        const newPosition = cursorPosition + emoji.length;
        textareaRef.current.setSelectionRange(newPosition, newPosition);
        setCursorPosition(newPosition);
      }
    }, 10);
  };

  // Track cursor position in textarea
  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setContent(e.target.value);
    setCursorPosition(e.target.selectionStart);
  };

  // Store cursor position when clicking in textarea
  const handleTextareaClick = () => {
    if (textareaRef.current) {
      setCursorPosition(textareaRef.current.selectionStart);
    }
  };

  // Handle image upload via file input
  const handleImageUpload = () => {
    fileInputRef.current?.click();
  };

  // Process selected image file
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Only accept images
    if (!file.type.startsWith('image/')) {
      toast({
        variant: "destructive",
        title: "Invalid file",
        description: "Please select an image file (PNG, JPEG, GIF)",
      });
      return;
    }
    
    // Show upload indicator
    setIsUploading(true);
    setMediaType("image");
    
    // Clear any existing video
    if (video) {
      setVideo("");
    }
    
    // Simulate file upload (in a real app, you'd upload to a server or cloud storage)
    const reader = new FileReader();
    reader.onload = (event) => {
      setTimeout(() => {
        setImage(event.target?.result as string);
        setIsUploading(false);
      }, 1000); // Simulate network delay
    };
    reader.readAsDataURL(file);
    
    // Reset file input
    e.target.value = '';
  };
  
  // Process selected video file
  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Only accept videos
    if (!file.type.startsWith('video/')) {
      toast({
        variant: "destructive",
        title: "Invalid file",
        description: "Please select a video file (MP4, WebM, etc.)",
      });
      return;
    }
    
    // Check file size limit (10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        variant: "destructive",
        title: "File too large",
        description: "Video size must be under 10MB",
      });
      return;
    }
    
    // Show upload indicator
    setIsUploading(true);
    setMediaType("video");
    
    // Clear any existing image
    if (image) {
      setImage("");
    }
    
    // Simulate file upload (in a real app, you'd upload to a server or cloud storage)
    const reader = new FileReader();
    reader.onload = (event) => {
      setTimeout(() => {
        setVideo(event.target?.result as string);
        setIsUploading(false);
      }, 1500); // Simulate network delay
    };
    reader.readAsDataURL(file);
    
    // Reset file input
    e.target.value = '';
  };

  // Format content to highlight hashtags
  const formatContent = () => {
    // Enhanced regex for hashtag detection (#word_with_underscores or #word)
    const hashtagPattern = /#[\w_]+/g;
    
    // Split by hashtags
    const parts = content.split(hashtagPattern);
    const hashtags = content.match(hashtagPattern) || [];
    
    // If no hashtags, return the content as is
    if (hashtags.length === 0) return content;
    
    // Recombine with highlighted hashtags
    const formatted = [];
    for (let i = 0; i < parts.length; i++) {
      formatted.push(parts[i]);
      if (i < hashtags.length) {
        formatted.push(
          <span key={i} className="text-[#b07c1d] font-semibold crypto-text-gradient cursor-pointer">
            {hashtags[i]}
          </span>
        );
      }
    }
    
    return formatted;
  };

  // Handle video upload
  const handleVideoUpload = () => {
    videoInputRef.current?.click();
  };
  
  // Handle GIF selection
  const handleGifSelect = (gifUrl: string) => {
    setImage(gifUrl);
    setMediaType("gif");
    setShowGifSelector(false);
  };
  
  const handleSubmit = () => {
    if (!content.trim()) return;
    
    const postData = {
      content,
      ...(image && { image }),
      ...(video && { video })
    };
    
    createPostMutation.mutate(postData);
  };

  if (!user) return null;

  return (
    <div className={`${inDialog ? '' : 'p-5 border-b border-[#1a2747]'}`}>
      <div className="flex">
        <div className="mr-3">
          <div className="h-11 w-11 rounded-full ring-2 ring-[#b07c1d] flex items-center justify-center overflow-hidden">
            {user.avatar ? (
              <img src={user.avatar} alt={`${user.displayName}'s avatar`} className="h-full w-full object-cover" />
            ) : (
              <div className="h-full w-full bg-[#141e33] flex items-center justify-center">
                <UserIcon className="h-5 w-5 text-[#b07c1d]" />
              </div>
            )}
          </div>
        </div>
        <div className="flex-1 relative">
          <div className="relative">
            <Textarea
              ref={textareaRef}
              placeholder="What's happening?"
              className="w-full bg-transparent border-b border-[#1a2747] resize-none focus:outline-none focus:ring-0 mb-4 pb-2 text-[15px] min-h-[100px]"
              value={content}
              onChange={handleTextareaChange}
              onClick={handleTextareaClick}
            />
            <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-0">
              {/* This hidden div maintains spacing */}
              <div className="invisible">{content}</div>
              {/* Formatted content overlays on the textarea */}
              <div className="absolute top-0 left-0">{formatContent()}</div>
            </div>
          </div>
          
          {image && (
            <div className="mb-4 relative">
              <img src={image} alt="Post attachment" className="w-full h-52 object-cover rounded-xl border border-[#1a2747]" />
              <button 
                className="absolute top-2 right-2 bg-black bg-opacity-70 rounded-full p-1 hover:bg-opacity-90 transition-colors"
                onClick={() => setImage("")}
                type="button"
              >
                <X className="h-5 w-5 text-white" />
              </button>
            </div>
          )}
          
          {video && (
            <div className="mb-4 relative">
              <video 
                src={video} 
                controls 
                className="w-full rounded-xl border border-[#1a2747]" 
                style={{ maxHeight: "400px" }}
              />
              <button 
                className="absolute top-2 right-2 bg-black bg-opacity-70 rounded-full p-1 hover:bg-opacity-90 transition-colors"
                onClick={() => setVideo("")}
                type="button"
              >
                <X className="h-5 w-5 text-white" />
              </button>
            </div>
          )}
          
          {isUploading && (
            <div className="mb-4 relative">
              <div className="w-full h-52 bg-[#141e33] rounded-xl border border-[#1a2747] flex items-center justify-center">
                <div className="animate-spin h-10 w-10 border-t-2 border-b-2 border-[#b07c1d] rounded-full"></div>
                <p className="ml-3 text-gray-400">Uploading {mediaType}...</p>
              </div>
            </div>
          )}
          
          {/* Emoji picker */}
          {showEmojiPicker && (
            <div 
              ref={emojiPickerRef}
              className="absolute z-10 bottom-16 right-0 shadow-lg rounded-lg overflow-hidden"
              style={{ maxHeight: '350px' }}
            >
              <EmojiPicker
                width={isMobile ? 300 : 350}
                height={350}
                theme={Theme.DARK}
                onEmojiClick={handleEmojiClick}
                searchDisabled={isMobile}
                skinTonesDisabled={isMobile}
                previewConfig={{ showPreview: !isMobile }}
              />
            </div>
          )}
          
          {/* Hidden image file input */}
          <input 
            type="file"
            ref={fileInputRef}
            className="hidden"
            accept="image/*"
            onChange={handleFileChange}
          />
          
          {/* Hidden video file input */}
          <input 
            type="file"
            ref={videoInputRef}
            className="hidden"
            accept="video/*"
            onChange={handleVideoChange}
          />
          
          <div className="flex justify-between items-center">
            <div className="flex space-x-1">
              <button 
                type="button"
                className="p-2 rounded-full hover:bg-[#b07c1d]/10 hover:text-[#b07c1d] transition-colors"
                onClick={handleImageUpload}
                title="Upload image"
              >
                <Image className="h-5 w-5" />
              </button>
              <button 
                type="button"
                className="p-2 rounded-full hover:bg-[#b07c1d]/10 hover:text-[#b07c1d] transition-colors"
                onClick={handleVideoUpload}
                title="Upload video"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m22 8-6 4 6 4V8Z"/><rect width="14" height="12" x="2" y="6" rx="2" ry="2"/>
                </svg>
              </button>
              <button 
                type="button"
                className="p-2 rounded-full hover:bg-[#b07c1d]/10 hover:text-[#b07c1d] transition-colors"
                onClick={() => setShowMemeDialog(true)}
                title="Add NFT/Meme"
              >
                <Sticker className="h-5 w-5" />
              </button>
              <button 
                type="button"
                className="p-2 rounded-full hover:bg-[#b07c1d]/10 hover:text-[#b07c1d] transition-colors"
                onClick={() => setShowGifSelector(true)}
                title="Add Crypto GIF"
              >
                <Gift className="h-5 w-5" />
              </button>
              <button 
                type="button"
                className="p-2 rounded-full hover:bg-[#b07c1d]/10 hover:text-[#b07c1d] transition-colors"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                title="Add emoji"
              >
                <Smile className="h-5 w-5" />
              </button>
              <button 
                type="button"
                className="p-2 rounded-full hover:bg-[#b07c1d]/10 hover:text-[#b07c1d] transition-colors"
                title="Add hashtag"
                onClick={() => {
                  setContent(prev => prev + " #");
                  textareaRef.current?.focus();
                }}
              >
                <Hash className="h-5 w-5" />
              </button>
            </div>
            <Button
              className="bg-[#b07c1d] hover:bg-[#b07c1d]/90 text-white px-5 py-2 rounded-xl text-sm font-bold transition-colors"
              onClick={handleSubmit}
              disabled={!content.trim() || createPostMutation.isPending}
            >
              {createPostMutation.isPending ? "Posting..." : "Post"}
            </Button>
          </div>
          
          {/* NFT/Meme Dialog */}
          <Dialog open={showMemeDialog} onOpenChange={setShowMemeDialog}>
            <DialogContent className="bg-[#0f172a] border-[#1a2747] text-white p-0 max-w-3xl">
              <DialogHeader className="p-4 border-b border-[#1a2747]">
                <DialogTitle className="text-xl font-bold flex items-center">
                  <Sticker className="mr-2 h-5 w-5 text-[#b07c1d]" />
                  Choose a Crypto-Themed Image
                </DialogTitle>
              </DialogHeader>
              
              <div className="p-4">
                <div className="flex items-center justify-center mb-4 space-x-2">
                  <button
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
                      ${activeCategory === 'all' ? 'bg-[#b07c1d] text-white' : 'bg-[#1a2747] text-gray-300 hover:bg-[#283c6a]'}`}
                    onClick={() => setActiveCategory('all')}
                  >
                    All
                  </button>
                  <button
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
                      ${activeCategory === 'meme' ? 'bg-[#b07c1d] text-white' : 'bg-[#1a2747] text-gray-300 hover:bg-[#283c6a]'}`}
                    onClick={() => setActiveCategory('meme')}
                  >
                    Memes
                  </button>
                  <button
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
                      ${activeCategory === 'nft' ? 'bg-[#b07c1d] text-white' : 'bg-[#1a2747] text-gray-300 hover:bg-[#283c6a]'}`}
                    onClick={() => setActiveCategory('nft')}
                  >
                    NFTs
                  </button>
                </div>
                
                <div className="grid grid-cols-3 md:grid-cols-4 gap-3">
                  {CRYPTO_MEMES
                    .filter(meme => activeCategory === 'all' || meme.category === activeCategory)
                    .map(meme => (
                      <div
                        key={meme.id}
                        className="cursor-pointer group relative"
                        onClick={() => {
                          setImage(meme.url);
                          setMediaType('meme');
                          setShowMemeDialog(false);
                          // Clear video if any
                          if (video) setVideo('');
                        }}
                      >
                        <div className="bg-[#141e33] border border-[#1a2747] rounded-lg p-2 group-hover:border-[#b07c1d] transition-all duration-200 overflow-hidden">
                          <img
                            src={meme.url}
                            alt={meme.name}
                            className="w-full aspect-square object-contain rounded"
                          />
                          <p className="text-sm mt-2 font-medium text-center truncate">{meme.name}</p>
                          <p className="text-xs text-gray-400 text-center">{meme.category === 'meme' ? 'Meme' : 'NFT'}</p>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* GIF Selector Dialog */}
      <Dialog open={showGifSelector} onOpenChange={setShowGifSelector}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] text-white p-0 max-w-3xl">
          <DialogHeader className="p-4 border-b border-[#1a2747]">
            <DialogTitle className="text-xl font-bold flex items-center">
              <Gift className="mr-2 h-5 w-5" /> Crypto-Themed GIFs
            </DialogTitle>
          </DialogHeader>
          <div className="p-4">
            <GifSelector onSelect={handleGifSelect} onClose={() => setShowGifSelector(false)} />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
