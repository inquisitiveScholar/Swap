import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Loader2, Search, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

// Crypto-themed memes and reactions
const cryptoMemes = [
  {
    id: 'crypto-moon',
    url: 'https://media.giphy.com/media/trN9ht5RlE3Dcwavg2/giphy.gif',
    alt: 'To the moon'
  },
  {
    id: 'crypto-diamond-hands',
    url: 'https://media.giphy.com/media/mz7iww9tCUnJJeZvGN/giphy.gif',
    alt: 'Diamond hands'
  },
  {
    id: 'crypto-bull-market',
    url: 'https://media.giphy.com/media/q09xyQsU3cETe/giphy.gif',
    alt: 'Bull market'
  },
  {
    id: 'crypto-bear-market',
    url: 'https://media.giphy.com/media/cb7t8mVPkiQDK/giphy.gif',
    alt: 'Bear market'
  },
  {
    id: 'crypto-doge',
    url: 'https://media.giphy.com/media/5OcuJCGflytBLYyNj5/giphy.gif',
    alt: 'Doge coin'
  },
  {
    id: 'crypto-hodl',
    url: 'https://media.giphy.com/media/0L1Fa356hYzIcBPQ6r/giphy.gif',
    alt: 'HODL'
  },
  {
    id: 'crypto-wallet',
    url: 'https://media.giphy.com/media/QvSQUmUCwCYgYQ9FvX/giphy.gif',
    alt: 'Checking wallet'
  },
  {
    id: 'crypto-rich',
    url: 'https://media.giphy.com/media/R8bcfuGTZONyw/giphy.gif',
    alt: 'Got rich'
  }
];

// Crypto stickers
const cryptoStickers = [
  {
    id: 'sticker-btc',
    url: 'https://cdn.dribbble.com/users/375019/screenshots/16566668/media/91f1162f581353583e4e3f1f18abbb2e.png?compress=1&resize=150x150',
    alt: 'Bitcoin'
  },
  {
    id: 'sticker-eth',
    url: 'https://cdn.dribbble.com/users/375019/screenshots/16566709/media/13d26b77c94fb0145c6d09af0aa85d3a.png?compress=1&resize=150x150',
    alt: 'Ethereum'
  },
  {
    id: 'sticker-doge',
    url: 'https://cdn.dribbble.com/users/1281508/screenshots/15282410/media/2f7cce37162a9d255e22471e0cd94df2.jpg?compress=1&resize=150x150',
    alt: 'Dogecoin'
  },
  {
    id: 'sticker-rocket',
    url: 'https://cdn.dribbble.com/users/2270171/screenshots/17028410/media/bf32c1f58452c870aeafd4ffd898e90a.png?compress=1&resize=150x150',
    alt: 'To the moon'
  },
  {
    id: 'sticker-diamond',
    url: 'https://cdn.dribbble.com/users/1281508/screenshots/15364798/media/73d11e208994800db6c9ce6a1739b1b2.jpg?compress=1&resize=150x150',
    alt: 'Diamond hands'
  },
  {
    id: 'sticker-hodl',
    url: 'https://cdn.dribbble.com/users/1281508/screenshots/11986597/media/7daa8f0a0c03ec7daf8be9d5c1dfc4da.jpg?compress=1&resize=150x150',
    alt: 'HODL'
  }
];

interface GifSelectorProps {
  onSelect: (url: string) => void;
  onClose: () => void;
}

export default function GifSelector({ onSelect, onClose }: GifSelectorProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const { toast } = useToast();

  // Filter crypto memes based on search
  const filteredCryptoMemes = cryptoMemes.filter(meme => 
    meme.alt.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Filter crypto stickers based on search
  const filteredCryptoStickers = cryptoStickers.filter(sticker => 
    sticker.alt.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSearch = async () => {
    if (searchQuery.trim().length === 0) {
      setSearchResults([]);
      return;
    }

    setIsLoading(true);
    
    try {
      // For now, combine our predefined memes based on the search
      const combinedResults = [
        ...filteredCryptoMemes,
        ...filteredCryptoStickers
      ];
      
      setSearchResults(combinedResults);
    } catch (error) {
      console.error("Error searching for GIFs:", error);
      toast({
        variant: "destructive",
        title: "Search failed",
        description: "Failed to search for GIFs. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle search when query changes
  useEffect(() => {
    const timer = setTimeout(() => {
      handleSearch();
    }, 500);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  return (
    <div className="w-full h-full bg-[#0f172a] rounded-lg border border-[#1a2747] overflow-hidden">
      <div className="p-3 border-b border-[#1a2747] flex justify-between items-center">
        <h3 className="text-lg font-bold">Crypto Memes & GIFs</h3>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      <div className="p-3">
        <div className="relative">
          <Input
            type="text"
            placeholder="Search crypto memes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-8"
          />
          <Search className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        </div>
      </div>
      
      <Tabs defaultValue="memes" className="w-full">
        <TabsList className="w-full grid grid-cols-3 mt-2">
          <TabsTrigger value="memes">Memes</TabsTrigger>
          <TabsTrigger value="stickers">Stickers</TabsTrigger>
          <TabsTrigger value="search">Search</TabsTrigger>
        </TabsList>
        
        <TabsContent value="memes" className="p-3">
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-[#b07c1d]" />
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              {filteredCryptoMemes.length > 0 ? (
                filteredCryptoMemes.map(meme => (
                  <div 
                    key={meme.id}
                    className="aspect-video bg-[#1a2747]/30 rounded-md overflow-hidden cursor-pointer hover:ring-2 hover:ring-[#b07c1d] transition-all"
                    onClick={() => onSelect(meme.url)}
                  >
                    <img 
                      src={meme.url} 
                      alt={meme.alt}
                      className="w-full h-full object-cover" 
                      loading="lazy"
                    />
                  </div>
                ))
              ) : (
                <div className="col-span-2 h-40 flex items-center justify-center text-muted-foreground">
                  No memes found
                </div>
              )}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="stickers" className="p-3">
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-[#b07c1d]" />
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-2">
              {filteredCryptoStickers.length > 0 ? (
                filteredCryptoStickers.map(sticker => (
                  <div 
                    key={sticker.id}
                    className="aspect-square bg-[#1a2747]/30 rounded-md overflow-hidden cursor-pointer hover:ring-2 hover:ring-[#b07c1d] transition-all"
                    onClick={() => onSelect(sticker.url)}
                  >
                    <img 
                      src={sticker.url} 
                      alt={sticker.alt}
                      className="w-full h-full object-contain" 
                      loading="lazy"
                    />
                  </div>
                ))
              ) : (
                <div className="col-span-3 h-40 flex items-center justify-center text-muted-foreground">
                  No stickers found
                </div>
              )}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="search" className="p-3">
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-[#b07c1d]" />
            </div>
          ) : searchQuery.trim() === "" ? (
            <div className="h-40 flex items-center justify-center text-muted-foreground">
              Enter a search term to find GIFs
            </div>
          ) : searchResults.length > 0 ? (
            <div className="grid grid-cols-2 gap-2">
              {searchResults.map((result, index) => (
                <div 
                  key={`search-${index}`}
                  className="aspect-video bg-[#1a2747]/30 rounded-md overflow-hidden cursor-pointer hover:ring-2 hover:ring-[#b07c1d] transition-all"
                  onClick={() => onSelect(result.url)}
                >
                  <img 
                    src={result.url} 
                    alt={result.alt || "Search result"}
                    className="w-full h-full object-cover" 
                    loading="lazy"
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="h-40 flex items-center justify-center text-muted-foreground">
              No results found
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}