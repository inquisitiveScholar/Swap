import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { PostWithUser } from "@shared/schema";
import { useAuth } from "@/context/AuthContext";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { UserIcon, Heart, MessageCircle, Repeat, Share, MoreVertical, Trash, Edit, ExternalLink, Loader2, ChevronLeft, HandHeart, Flag } from "lucide-react";
import { getNetworkConfig, getCurrentNetwork, switchToNetwork, getDefaultNetwork, getAllNetworks } from "@/lib/networks";
import { sendNativeTransaction, waitForTransaction, getCurrentWalletAddress, getWalletBalance } from "@/lib/web3";
import NetworkManagement from "@/components/NetworkManagement";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface PostCardProps {
  post: PostWithUser;
}

export default function PostCard({ post }: PostCardProps) {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [liked, setLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(post.likesCount || 0);
  const [retweeted, setRetweeted] = useState(false);
  const [retweetCount, setRetweetCount] = useState(post.retweetCount || 0);
  const [isCommentOpen, setIsCommentOpen] = useState(false);
  const [comment, setComment] = useState("");
  const [commentToEdit, setCommentToEdit] = useState<any>(null);
  const [editedCommentContent, setEditedCommentContent] = useState("");
  const [comments, setComments] = useState<any[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isCommentEditDialogOpen, setIsCommentEditDialogOpen] = useState(false);
  const [isCommentDeleteDialogOpen, setIsCommentDeleteDialogOpen] = useState(false);
  const [showRetweetersDialog, setShowRetweetersDialog] = useState(false);
  const [retweetersList, setRetweetersList] = useState<any[]>([]);
  const [isLoadingRetweeters, setIsLoadingRetweeters] = useState(false);
  const [editedContent, setEditedContent] = useState(post.content);
  const [isEditing, setIsEditing] = useState(false);
  const [location, setLocation] = useState<string | null>(null);
  const [isTipDialogOpen, setIsTipDialogOpen] = useState(false);
  const [tipAmount, setTipAmount] = useState("");
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [reportDescription, setReportDescription] = useState("");
  const [postTips, setPostTips] = useState({ total: "0", currency: "ETH" });
  const [currentNetwork, setCurrentNetwork] = useState<string>(getDefaultNetwork());
  const [isSendingTip, setIsSendingTip] = useState(false);
  const [walletBalance, setWalletBalance] = useState<string>("0");
  
  // Check if user is post owner
  const isPostOwner = user?.id === post.userId;

  // Load tip data for this post
  useEffect(() => {
    async function loadTipData() {
      try {
        const res = await fetch(`/api/posts/${post.id}/tips`);
        if (res.ok) {
          const data = await res.json();
          setPostTips(data);
        }
      } catch (error) {
        console.error("Error loading tip data:", error);
      }
    }
    
    loadTipData();
  }, [post.id]);
  
  // Check if post is liked when component mounts
  useEffect(() => {
    async function checkIfLiked() {
      if (!user) return;
      
      try {
        const res = await fetch(`/api/posts/${post.id}/like`);
        if (res.ok) {
          const data = await res.json();
          setLiked(data.liked);
        }
      } catch (error) {
        console.error("Error checking like status:", error);
      }
    }
    
    checkIfLiked();
  }, [post.id, user]);
  
  // Check if post is retweeted when component mounts
  useEffect(() => {
    async function checkIfRetweeted() {
      if (!user) return;
      
      try {
        const res = await fetch(`/api/posts/${post.id}/retweet`);
        if (res.ok) {
          const data = await res.json();
          setRetweeted(data.retweeted);
          setRetweetCount(data.retweetCount || 0);
        }
      } catch (error) {
        console.error("Error checking retweet status:", error);
      }
    }
    
    checkIfRetweeted();
  }, [post.id, user]);

  // Format the post date
  const formattedDate = formatDistanceToNow(new Date(post.createdAt), { addSuffix: true });
  
  // Like mutation
  const likeMutation = useMutation({
    mutationFn: () => {
      // Always use POST for toggling like status
      return apiRequest("POST", `/api/posts/${post.id}/like`);
    },
    onSuccess: (response) => {
      const data = response.json();
      // Update state based on response
      data.then(result => {
        setLiked(!!result.liked);
        setLikesCount(result.likesCount || post.likesCount || 0);
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update like status",
      });
    }
  });
  
  // Retweet mutation
  const retweetMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", `/api/posts/${post.id}/retweet`, {
        content: ""  // Can be empty or include additional comment
      });
    },
    onSuccess: (response) => {
      const data = response.json();
      data.then(result => {
        setRetweeted(!!result.retweeted);
        setRetweetCount(result.retweetCount || 0);
        
        // Update the posts list to show the retweet
        queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
        
        toast({
          title: result.retweeted ? "Post reshared!" : "Reshare removed",
          description: result.retweeted ? "The post has been shared to your timeline" : "The post has been removed from your timeline",
        });
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to reshare post",
      });
    }
  });

  // Comment mutation
  const commentMutation = useMutation({
    mutationFn: (content: string) => 
      apiRequest("POST", `/api/posts/${post.id}/comments`, { content }),
    onSuccess: (data) => {
      setComment("");
      // Don't close dialog, just fetch fresh comments
      fetchComments();
      
      toast({
        title: "Comment added",
        description: "Your comment has been posted",
      });
      
      // Invalidate queries to refresh comments count
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to post comment",
      });
    }
  });
  
  // Comment edit mutation
  const editCommentMutation = useMutation({
    mutationFn: () => 
      apiRequest("PATCH", `/api/comments/${commentToEdit?.id}`, { content: editedCommentContent }),
    onSuccess: () => {
      setIsCommentEditDialogOpen(false);
      setCommentToEdit(null);
      setEditedCommentContent("");
      // Refetch comments
      fetchComments();
      toast({
        title: "Comment updated",
        description: "Your comment has been updated successfully",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update comment",
      });
    }
  });
  
  // Comment delete mutation
  const deleteCommentMutation = useMutation({
    mutationFn: () => 
      apiRequest("DELETE", `/api/comments/${commentToEdit?.id}`),
    onSuccess: () => {
      setIsCommentDeleteDialogOpen(false);
      setCommentToEdit(null);
      
      // Refetch comments
      fetchComments();
      
      // Update post comment count locally
      if (post.commentsCount && post.commentsCount > 0) {
        post.commentsCount -= 1;
      }
      
      // Invalidate queries to refresh comments count
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      
      toast({
        title: "Comment deleted",
        description: "Your comment has been deleted",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete comment",
      });
    }
  });
  


  // Check if post is liked on mount
  // This would normally be done with a query, but for this demo we'll keep it simple

  const handleLike = () => {
    if (!user) {
      navigate("/auth");
      return;
    }
    
    likeMutation.mutate();
  };

  // Fetch comments when comment dialog opens
  useEffect(() => {
    if (isCommentOpen) {
      fetchComments();
    }
  }, [isCommentOpen]);
  
  // Function to fetch comments
  const fetchComments = async () => {
    if (!post.id) return;
    
    setLoadingComments(true);
    try {
      const response = await fetch(`/api/posts/${post.id}/comments`);
      if (response.ok) {
        const data = await response.json();
        setComments(data);
      }
    } catch (error) {
      console.error('Error fetching comments:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load comments",
      });
    } finally {
      setLoadingComments(false);
    }
  };
  
  const handleComment = () => {
    if (!user) {
      navigate("/auth");
      return;
    }
    
    setIsCommentOpen(true);
  };

  const submitComment = () => {
    if (!comment.trim()) return;
    commentMutation.mutate(comment);
  };
  
  // Edit and delete mutations
  const editPostMutation = useMutation({
    mutationFn: () => apiRequest("PATCH", `/api/posts/${post.id}`, { content: editedContent }),
    onSuccess: () => {
      setIsEditDialogOpen(false);
      
      // Update the local state to reflect the changes immediately
      post.content = editedContent;
      
      toast({
        title: "Post updated",
        description: "Your post has been updated successfully",
      });
      
      // Refresh posts
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update post",
      });
    }
  });
  
  const deletePostMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", `/api/posts/${post.id}`),
    onSuccess: () => {
      setIsDeleteDialogOpen(false);
      
      toast({
        title: "Post deleted",
        description: "Your post has been deleted successfully",
      });
      
      // Refresh posts in all relevant lists
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      
      // Also refresh user profile posts
      if (post.userId) {
        queryClient.invalidateQueries({ queryKey: [`/api/users/${post.userId}/posts`] });
      }
      
      // If currently on the post detail page, redirect to home
      if (window.location.pathname.includes(`/post/${post.id}`)) {
        navigate('/');
      }
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete post",
      });
    }
  });

  const navigateToProfile = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/profile/${post.user.username}`);
  };
  
  // Navigate to trending hashtag page
  const navigateToHashtag = (hashtag: string, e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    navigate(`/trending/${hashtag.replace('#', '')}`);
  };
  
  // Format content to highlight hashtags
  const formatPostContent = (content: string) => {
    if (!content) return null;
    
    // Regex to match hashtags (#word_with_underscores or #word)
    const hashtagRegex = /#[\w_]+/g;
    
    // Split the content by hashtags
    const parts = content.split(hashtagRegex);
    
    // Extract all hashtags from the content
    const hashtags = content.match(hashtagRegex) || [];
    
    // If no hashtags, return the content as is
    if (hashtags.length === 0) return content;
    
    // Combine parts and hashtags
    return parts.map((part, index) => (
      <React.Fragment key={index}>
        {part}
        {hashtags[index] && (
          <a 
            href={`/trending/${hashtags[index].replace('#', '')}`}
            onClick={(e) => navigateToHashtag(hashtags[index], e)}
            className="text-[#b07c1d] font-semibold hover:underline crypto-text-gradient"
          >
            {hashtags[index]}
          </a>
        )}
      </React.Fragment>
    ));
  };

  return (
    <>
      <article className="p-5 hover:bg-[#141e33] transition-colors border-b border-[#1a2747] cursor-pointer">
        <div className="flex">
          <div className="mr-3 flex-shrink-0">
            <div 
              className="h-11 w-11 rounded-full overflow-hidden cursor-pointer ring-2 ring-[#b07c1d]"
              onClick={navigateToProfile}
            >
              {post.user.avatar ? (
                <img src={post.user.avatar} alt={`${post.user.displayName}'s avatar`} className="h-full w-full object-cover" />
              ) : (
                <div className="h-full w-full bg-[#141e33] flex items-center justify-center">
                  <UserIcon className="h-5 w-5 text-[#b07c1d]" />
                </div>
              )}
            </div>
          </div>
          <div className="flex-1">
            <div className="flex items-center mb-1">
              <h3 
                className="font-bold mr-1 cursor-pointer hover:text-[#b07c1d] transition-colors"
                onClick={navigateToProfile}
              >
                {post.user.displayName}
              </h3>
              <span 
                className="text-gray-400 text-sm cursor-pointer hover:text-[#b07c1d] transition-colors"
                onClick={navigateToProfile}
              >
                @{post.user.username}
              </span>
              <span className="mx-1 text-gray-500">·</span>
              <span className="text-gray-500 text-sm hover:underline cursor-pointer">{formattedDate}</span>
              
              {/* Post actions menu for owner */}
              {isPostOwner && (
                <div className="ml-auto">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="p-2 rounded-full hover:bg-[#b07c1d]/10 hover:text-[#b07c1d] transition-colors">
                        <MoreVertical className="h-4 w-4" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-[#0f172a] text-gray-200 border-[#1a2747]">
                      <DropdownMenuItem 
                        className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                        onClick={() => setIsEditDialogOpen(true)}
                      >
                        <Edit className="h-4 w-4" /> 
                        <span>Edit Post</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="flex items-center gap-2 text-red-500 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                        onClick={() => setIsDeleteDialogOpen(true)}
                      >
                        <Trash className="h-4 w-4" /> 
                        <span>Delete Post</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              )}
            </div>
            <p className="mb-3 text-[15px] leading-normal">{formatPostContent(post.content)}</p>
            {post.image && (
              <div className="rounded-xl overflow-hidden mb-3 border border-[#1a2747]">
                <img src={post.image} alt="Post attachment" className="w-full" />
              </div>
            )}
            
            {post.video && (
              <div className="rounded-xl overflow-hidden mb-3 border border-[#1a2747]">
                <video
                  src={post.video}
                  controls
                  className="w-full"
                  style={{ maxHeight: "400px" }}
                  preload="metadata"
                />
              </div>
            )}
            <div className="flex justify-between text-gray-400 pt-1">
              <button 
                className="flex items-center group"
                onClick={handleComment}
              >
                <div className="p-2 rounded-full group-hover:bg-[#b07c1d]/10 group-hover:text-[#b07c1d] transition-colors">
                  <MessageCircle className="h-5 w-5" />
                </div>
                <span className="text-sm ml-1 group-hover:text-[#b07c1d] transition-colors">{post.commentsCount || 0}</span>
              </button>
              <div className="flex items-center">
                <button 
                  className="flex items-center group"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (!user) {
                      navigate("/auth");
                      return;
                    }
                    
                    // Call API directly for retweet functionality
                    apiRequest("POST", `/api/posts/${post.id}/retweet`, {})
                      .then(async (response) => {
                        if (response.ok) {
                          const result = await response.json();
                          setRetweeted(result.retweeted);
                          setRetweetCount(result.retweetCount || 0);
                          
                          // Update the posts list to show the retweet
                          queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
                          
                          toast({
                            title: result.retweeted ? "Post reshared!" : "Reshare removed",
                            description: result.retweeted ? "The post has been shared to your timeline" : "The post has been removed from your timeline",
                          });
                        }
                      })
                      .catch(() => {
                        toast({
                          variant: "destructive",
                          title: "Error",
                          description: "Failed to reshare post",
                        });
                      });
                  }}
                >
                  <div className={`p-2 rounded-full ${retweeted ? 'bg-green-500/10 text-green-500' : 'group-hover:bg-green-500/10 group-hover:text-green-500'} transition-colors`}>
                    <Repeat className={`h-5 w-5 ${retweeted ? 'fill-current' : ''}`} />
                  </div>
                  <span className={`text-sm ml-1 ${retweeted ? 'text-green-500' : 'group-hover:text-green-500'} transition-colors`}>{retweetCount}</span>
                </button>
                {retweetCount > 0 && (
                  <button 
                    className="ml-1 text-xs text-gray-500 hover:text-green-500"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsLoadingRetweeters(true);
                      
                      // Fetch retweeters list
                      apiRequest("GET", `/api/posts/${post.id}/retweeters`)
                        .then(response => response.json())
                        .then(data => {
                          setRetweetersList(data.retweeters || []);
                          setShowRetweetersDialog(true);
                          setIsLoadingRetweeters(false);
                        })
                        .catch(() => {
                          toast({
                            variant: "destructive",
                            title: "Error",
                            description: "Failed to fetch retweeters"
                          });
                          setIsLoadingRetweeters(false);
                        });
                    }}
                  >
                    {isLoadingRetweeters ? (
                      <Loader2 className="h-3 w-3 animate-spin" />
                    ) : (
                      <span>who?</span>
                    )}
                  </button>
                )}
              </div>
              <button 
                className="flex items-center group"
                onClick={handleLike}
              >
                <div className={`p-2 rounded-full ${liked ? 'bg-secondary/10 text-secondary' : 'group-hover:bg-secondary/10 group-hover:text-secondary'} transition-colors`}>
                  <Heart className={`h-5 w-5 ${liked ? 'fill-current' : ''}`} />
                </div>
                <span className={`text-sm ml-1 ${liked ? 'text-secondary' : 'group-hover:text-secondary'} transition-colors`}>{likesCount}</span>
              </button>
              
              {/* Tip button */}
              {!isPostOwner && (
                <button 
                  className="flex items-center group"
                  onClick={() => setIsTipDialogOpen(true)}
                >
                  <div className="p-2 rounded-full group-hover:bg-yellow-500/10 group-hover:text-yellow-500 transition-colors">
                    <HandHeart className="h-5 w-5" />
                  </div>
                  <span className="text-sm ml-1 text-yellow-500 group-hover:text-yellow-400 transition-colors">
                    {postTips.total} {postTips.currency}
                  </span>
                </button>
              )}

              {/* Share and More actions */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center group">
                    <div className="p-2 rounded-full group-hover:bg-[#b07c1d]/10 group-hover:text-[#b07c1d] transition-colors">
                      <Share className="h-5 w-5" />
                    </div>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-[#0f172a] text-gray-200 border-[#1a2747]">
                  <DropdownMenuItem 
                    className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                    onClick={() => {
                      navigator.clipboard.writeText(window.location.origin + `/post/${post.id}`);
                      toast({
                        title: "Link copied",
                        description: "Post link copied to clipboard",
                      });
                    }}
                  >
                    <ExternalLink className="h-4 w-4 text-gray-400" />
                    <span>Copy link</span>
                  </DropdownMenuItem>
                  {!isPostOwner && (
                    <DropdownMenuItem 
                      className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747] text-red-400"
                      onClick={() => setIsReportDialogOpen(true)}
                    >
                      <Flag className="h-4 w-4" />
                      <span>Report post</span>
                    </DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </article>

      <Dialog open={isCommentOpen} onOpenChange={setIsCommentOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg">Comments on @{post.user.username}'s post</DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <div className="mb-4 pl-4 border-l-2 border-[#1a2747]">
              <p className="text-gray-300">{post.content}</p>
              {post.image && (
                <img src={post.image} alt="Post attachment" className="w-full h-auto max-h-40 object-cover mt-2 rounded-md" />
              )}
              {post.video && (
                <video 
                  src={post.video} 
                  controls 
                  className="w-full max-h-40 mt-2 rounded-md" 
                  preload="metadata" 
                />
              )}
            </div>
            
            {/* Comments list */}
            <div className="mb-6 space-y-4">
              <h3 className="text-sm font-medium text-gray-400 mb-2">{comments.length} Comments</h3>
              
              {loadingComments ? (
                <div className="flex justify-center p-4">
                  <div className="animate-spin h-6 w-6 border-t-2 border-b-2 border-[#b07c1d] rounded-full"></div>
                </div>
              ) : comments.length === 0 ? (
                <div className="text-center py-4 text-gray-500">
                  <p>No comments yet. Be the first to comment!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {comments.map(comment => (
                    <div key={comment.id} className="flex space-x-3 p-2 rounded-md hover:bg-[#141e33]/50 transition-colors">
                      <div className="flex-shrink-0">
                        {comment.user?.avatar ? (
                          <img 
                            src={comment.user.avatar} 
                            alt={`${comment.user.displayName}'s avatar`} 
                            className="app-avatar-sm" 
                          />
                        ) : (
                          <div className="app-avatar-sm">
                            <UserIcon className="h-4 w-4 text-[#b07c1d]" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center justify-between gap-1 mb-1 w-full">
                          <div>
                            <span className="font-bold text-sm">{comment.user?.displayName}</span>
                            <span className="text-gray-400 text-xs">@{comment.user?.username}</span>
                            <span className="text-gray-500 text-xs">· {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}</span>
                          </div>
                          {user?.id === comment.userId && (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button className="p-1 rounded-full hover:bg-[#b07c1d]/10 hover:text-[#b07c1d] transition-colors">
                                  <MoreVertical className="h-4 w-4" />
                                </button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="bg-[#0f172a] text-gray-200 border-[#1a2747]">
                                <DropdownMenuItem 
                                  className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                                  onClick={() => {
                                    // Edit comment functionality
                                    setCommentToEdit(comment);
                                    setEditedCommentContent(comment.content);
                                    setIsCommentEditDialogOpen(true);
                                  }}
                                >
                                  <Edit className="h-4 w-4" />
                                  <span>Edit</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747] text-red-500"
                                  onClick={() => {
                                    // Delete comment functionality
                                    setCommentToEdit(comment);
                                    setIsCommentDeleteDialogOpen(true);
                                  }}
                                >
                                  <Trash className="h-4 w-4" />
                                  <span>Delete</span>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}
                        </div>
                        <p className="text-sm text-gray-300">{comment.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            {/* Add new comment */}
            {user && (
              <div className="border-t border-[#1a2747] pt-4">
                <div className="flex">
                  <div className="mr-3">
                    {user?.avatar ? (
                      <img src={user.avatar} alt={`${user.displayName}'s avatar`} className="h-11 w-11 rounded-full ring-2 ring-[#b07c1d]" />
                    ) : (
                      <div className="app-avatar-lg">
                        <UserIcon className="h-5 w-5 text-[#b07c1d]" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <Textarea
                      placeholder="Write your comment..."
                      className="w-full bg-transparent border-b border-[#1a2747] resize-none focus:outline-none focus:border-[#b07c1d] mb-3"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                    />
                    <div className="flex justify-end">
                      <Button
                        className="bg-[#b07c1d] text-[#b07c1d]-foreground px-5 py-2 rounded-xl font-bold hover:bg-[#b07c1d]/90 transition-colors"
                        onClick={submitComment}
                        disabled={!comment.trim() || commentMutation.isPending}
                      >
                        {commentMutation.isPending ? "Posting..." : "Comment"}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Comment Edit Dialog */}
      <Dialog open={isCommentEditDialogOpen} onOpenChange={setIsCommentEditDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Edit Comment</DialogTitle>
            <DialogDescription className="text-gray-400">
              Make changes to your comment below.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <Textarea
              placeholder="Edit your comment..."
              className="w-full bg-[#1a2747]/50 border-[#1a2747] resize-none focus:outline-none focus:border-[#b07c1d]"
              value={editedCommentContent}
              onChange={(e) => setEditedCommentContent(e.target.value)}
            />
          </div>
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747]/50"
              onClick={() => setIsCommentEditDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              className="bg-[#b07c1d] text-[#b07c1d]-foreground px-5 py-2 rounded-xl font-bold hover:bg-[#b07c1d]/90 transition-colors"
              onClick={() => editCommentMutation.mutate()}
              disabled={!editedCommentContent.trim() || editCommentMutation.isPending}
            >
              {editCommentMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Comment Delete Dialog */}
      <Dialog open={isCommentDeleteDialogOpen} onOpenChange={setIsCommentDeleteDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Delete Comment</DialogTitle>
            <DialogDescription className="text-gray-400">
              Are you sure you want to delete this comment? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747]/50"
              onClick={() => setIsCommentDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={() => deleteCommentMutation.mutate()}
              disabled={deleteCommentMutation.isPending}
            >
              {deleteCommentMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : "Delete Comment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Post Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Edit Post</DialogTitle>
            <DialogDescription className="text-gray-400">
              Make changes to your post content below.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <Textarea
              value={editedContent}
              onChange={(e) => setEditedContent(e.target.value)}
              className="min-h-[120px] w-full bg-[#141e33] border-[#1a2747] rounded-lg p-3 text-white resize-none focus:border-[#b07c1d]"
              placeholder="What's on your mind?"
            />
            {post.image && (
              <div className="mt-3 rounded-lg overflow-hidden border border-[#1a2747]">
                <img src={post.image} alt="Post attachment" className="w-full h-40 object-cover" />
              </div>
            )}
            {post.video && (
              <div className="mt-3 rounded-lg overflow-hidden border border-[#1a2747]">
                <video 
                  src={post.video} 
                  controls 
                  className="w-full max-h-40" 
                  preload="metadata" 
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsEditDialogOpen(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => editPostMutation.mutate()}
              disabled={!editedContent.trim() || editPostMutation.isPending}
              className="bg-[#b07c1d] text-white hover:bg-[#b07c1d]/90"
            >
              {editPostMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Delete Post Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Delete Post</DialogTitle>
            <DialogDescription className="text-gray-400">
              Are you sure you want to delete this post? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => {
                deletePostMutation.mutate();
                // Close dialog immediately to prevent page locking issue
                setIsDeleteDialogOpen(false);
              }}
              disabled={deletePostMutation.isPending}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {deletePostMutation.isPending ? (
                <div className="flex items-center">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  <span>Deleting...</span>
                </div>
              ) : "Delete Post"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Retweeters Dialog */}
      <Dialog open={showRetweetersDialog} onOpenChange={setShowRetweetersDialog}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Reshared by</DialogTitle>
            <DialogDescription className="text-gray-400">
              Users who shared this post
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-[300px] overflow-y-auto py-2">
            {retweetersList.length > 0 ? (
              retweetersList.map((retweeter) => (
                <div 
                  key={retweeter.id} 
                  className="flex items-center gap-3 p-3 hover:bg-[#1a2747] cursor-pointer transition-colors rounded-lg"
                  onClick={() => {
                    setShowRetweetersDialog(false);
                    navigate(`/profile/${retweeter.username}`);
                  }}
                >
                  <Avatar className="h-10 w-10">
                    <AvatarImage 
                      src={retweeter.avatar || undefined} 
                      alt={retweeter.displayName}
                    />
                    <AvatarFallback className="bg-[#b07c1d]/10 text-[#b07c1d]">
                      {retweeter.displayName ? retweeter.displayName.charAt(0).toUpperCase() : "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <span className="font-medium">{retweeter.displayName}</span>
                    <span className="text-gray-400 text-sm">@{retweeter.username}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-gray-400">
                No users have reshared this post yet
              </div>
            )}
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowRetweetersDialog(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Tip Dialog */}
      <Dialog open={isTipDialogOpen} onOpenChange={setIsTipDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl">
          <DialogHeader>
            <DialogTitle className="text-lg">Send Tip to @{post.user.username}</DialogTitle>
            <DialogDescription className="text-gray-400">
              Support this creator by sending them a tip in cryptocurrency.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-white">Network</Label>
                <NetworkManagement currentNetwork={currentNetwork} onNetworkChange={setCurrentNetwork} />
              </div>
              <Select value={currentNetwork} onValueChange={setCurrentNetwork}>
                <SelectTrigger className="bg-[#1a2747] border-[#2a3f5f] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#1a2747] border-[#2a3f5f]">
                  {Object.entries(getAllNetworks()).map(([networkId, config]) => (
                    <SelectItem key={networkId} value={networkId} className="text-white hover:bg-[#2a3f5f]">
                      {config.name} ({config.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">
                Amount ({getNetworkConfig(currentNetwork)?.symbol || 'ETH'})
              </label>
              <input
                type="number"
                step="0.001"
                min="0"
                value={tipAmount}
                onChange={(e) => setTipAmount(e.target.value)}
                className="w-full bg-[#141e33] border-[#1a2747] rounded-lg p-3 text-white focus:border-[#b07c1d]"
                placeholder="0.01"
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsTipDialogOpen(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={async () => {
                setIsSendingTip(true);
                try {
                  const networkConfig = getNetworkConfig(currentNetwork);
                  if (!networkConfig) {
                    toast({
                      title: "Network Error",
                      description: "Please select a valid network",
                      variant: "destructive"
                    });
                    return;
                  }

                  // Check if user has a wallet address to receive the tip
                  if (!post.user.walletAddress) {
                    toast({
                      title: "No Wallet Address",
                      description: `@${post.user.username} hasn't connected their wallet yet`,
                      variant: "destructive"
                    });
                    return;
                  }

                  // Switch to the correct network if needed
                  const switched = await switchToNetwork(currentNetwork);
                  if (!switched) {
                    toast({
                      title: "Network Switch Failed",
                      description: "Please switch to the correct network in your wallet",
                      variant: "destructive"
                    });
                    return;
                  }

                  // Get current wallet address
                  const walletAddress = await getCurrentWalletAddress();
                  if (!walletAddress) {
                    toast({
                      title: "Wallet Not Connected",
                      description: "Please connect your wallet to send tips",
                      variant: "destructive"
                    });
                    return;
                  }

                  // Check wallet balance
                  const balance = await getWalletBalance(currentNetwork);
                  if (parseFloat(balance) < parseFloat(tipAmount)) {
                    toast({
                      title: "Insufficient Balance",
                      description: `You need at least ${tipAmount} ${networkConfig.symbol}`,
                      variant: "destructive"
                    });
                    return;
                  }

                  toast({
                    title: "Sending Transaction",
                    description: "Please confirm the transaction in your wallet",
                  });

                  // Send the actual blockchain transaction
                  const txHash = await sendNativeTransaction(
                    post.user.walletAddress,
                    tipAmount,
                    currentNetwork
                  );

                  toast({
                    title: "Transaction Sent",
                    description: "Waiting for confirmation...",
                  });

                  // Wait for transaction confirmation
                  const confirmed = await waitForTransaction(txHash);
                  
                  if (confirmed) {
                    // Record the successful tip in the database
                    const tipData = {
                      amount: tipAmount,
                      currency: networkConfig.symbol,
                      network: currentNetwork,
                      txHash: txHash
                    };

                    const response = await fetch(`/api/posts/${post.id}/tip`, {
                      method: "POST",
                      body: JSON.stringify(tipData),
                      headers: {
                        "Content-Type": "application/json",
                      },
                    });

                    if (response.ok) {
                      toast({
                        title: "Tip Sent Successfully!",
                        description: `Successfully sent ${tipAmount} ${networkConfig.symbol} to @${post.user.username}`,
                      });
                      
                      // Refresh tip data
                      const tipRes = await fetch(`/api/posts/${post.id}/tips`);
                      if (tipRes.ok) {
                        const tipData = await tipRes.json();
                        setPostTips(tipData);
                      }
                    } else {
                      toast({
                        title: "Warning",
                        description: "Transaction confirmed but failed to record. Please contact support.",
                        variant: "destructive"
                      });
                    }
                  } else {
                    toast({
                      title: "Transaction Failed",
                      description: "The transaction was not confirmed",
                      variant: "destructive"
                    });
                  }

                  setIsTipDialogOpen(false);
                  setTipAmount("");
                } catch (error: any) {
                  console.error("Error sending tip:", error);
                  toast({
                    title: "Transaction Error",
                    description: error.message || "Failed to send tip. Please try again.",
                    variant: "destructive"
                  });
                } finally {
                  setIsSendingTip(false);
                }
              }}
              disabled={!tipAmount || parseFloat(tipAmount) <= 0 || isSendingTip}
              className="bg-yellow-500 text-black hover:bg-yellow-400 disabled:opacity-50"
            >
              {isSendingTip ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Sending...
                </>
              ) : (
                "Send Tip"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Report Dialog */}
      <Dialog open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl">
          <DialogHeader>
            <DialogTitle className="text-lg">Report Post</DialogTitle>
            <DialogDescription className="text-gray-400">
              Help us keep the community safe by reporting inappropriate content.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">
                Reason for reporting
              </label>
              <select
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                className="w-full bg-[#141e33] border-[#1a2747] rounded-lg p-3 text-white focus:border-[#b07c1d]"
              >
                <option value="">Select a reason</option>
                <option value="spam">Spam</option>
                <option value="harassment">Harassment</option>
                <option value="hate_speech">Hate Speech</option>
                <option value="violence">Violence</option>
                <option value="misinformation">Misinformation</option>
                <option value="inappropriate_content">Inappropriate Content</option>
                <option value="copyright">Copyright Violation</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">
                Additional details (optional)
              </label>
              <textarea
                value={reportDescription}
                onChange={(e) => setReportDescription(e.target.value)}
                className="w-full bg-[#141e33] border-[#1a2747] rounded-lg p-3 text-white focus:border-[#b07c1d] resize-none"
                rows={3}
                placeholder="Provide additional context about why you're reporting this content..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setIsReportDialogOpen(false);
                setReportReason("");
                setReportDescription("");
              }}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={async () => {
                try {
                  const reportData = {
                    reportedPostId: post.id,
                    reason: reportReason,
                    description: reportDescription
                  };

                  const response = await fetch("/api/reports", {
                    method: "POST",
                    body: JSON.stringify(reportData),
                    headers: {
                      "Content-Type": "application/json",
                    },
                  });

                  if (response.ok) {
                    toast({
                      title: "Report submitted",
                      description: "Thank you for helping keep our community safe. We'll review this report soon.",
                    });
                  } else {
                    throw new Error("Failed to submit report");
                  }

                  setIsReportDialogOpen(false);
                  setReportReason("");
                  setReportDescription("");
                } catch (error) {
                  console.error("Error submitting report:", error);
                  toast({
                    title: "Error",
                    description: "Failed to submit report. Please try again.",
                    variant: "destructive"
                  });
                }
              }}
              disabled={!reportReason}
              className="bg-red-500 text-white hover:bg-red-400"
            >
              Submit Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
