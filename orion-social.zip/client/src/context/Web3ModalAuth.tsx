import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { createWeb3Modal } from '@web3modal/wagmi';
import { defaultWagmiConfig } from '@web3modal/wagmi';
import { useAccount, useConnect, useDisconnect } from 'wagmi';
import { sepolia } from 'wagmi/chains';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";
import { formatUrl } from "@/lib/utils";

interface WalletAuthContextType {
  user: User | null;
  isLoading: boolean;
  isConnecting: boolean;
  isRegistering: boolean;
  walletAddress: string | null;
  walletConnected: boolean;
  connectWallet: () => void;
  disconnectWallet: () => void;
  registerWithWallet: (userData: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  checkWalletRegistration: (address: string) => Promise<boolean>;
}

interface RegisterData {
  username: string;
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
}

// WalletConnect configuration
const projectId = '8137aad45a92f2eb9a42812ee05af00c';

// Metadata for wallet modal
const metadata = {
  name: import.meta.env.NEXT_PUBLIC_APP_NAME || 'Web3 Social',
  description: 'Web3 Social Platform',
  url: window.location.origin,
  icons: ['https://avatars.githubusercontent.com/u/37784886']
}

// Create wagmi config with type assertion to ensure proper chain formatting
const wagmiConfig = defaultWagmiConfig({
  chains: [sepolia] as readonly [typeof sepolia],
  projectId,
  metadata
});

// Initialize Web3Modal
createWeb3Modal({
  wagmiConfig,
  projectId,
  themeMode: 'dark',
  themeVariables: {
    '--w3m-accent': 'var(--primary)'
  }
});

const WalletAuthContext = createContext<WalletAuthContextType | null>(null);

export function Web3ModalAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRegistering, setIsRegistering] = useState(false);
  
  const { address, isConnected } = useAccount();
  const { connect, connectors, isPending } = useConnect();
  const { disconnect } = useDisconnect();
  const { toast } = useToast();

  // Check session on initial load
  useEffect(() => {
    async function checkSession() {
      try {
        setIsLoading(true);
        const response = await fetch(formatUrl("/api/auth/session"));
        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error("Session check failed:", error);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    }
    
    checkSession();
  }, []);

  // Auto login with wallet when it connects
  useEffect(() => {
    if (isConnected && address && !user && !isLoading) {
      checkWalletRegistration(address)
        .then(isRegistered => {
          if (isRegistered) {
            // Wallet is registered, try to login
            tryWalletLogin(address);
          }
          // If not registered, user will need to complete registration
        })
        .catch(err => {
          console.error("Wallet check failed:", err);
        });
    }
  }, [isConnected, address, user, isLoading]);

  const connectWallet = () => {
    // Find the WalletConnect connector
    const connector = connectors.find(c => c.ready);
    if (connector) {
      connect({ connector });
    } else {
      toast({
        variant: "destructive",
        title: "Connection Error",
        description: "No wallet connector found. Please install MetaMask or another Web3 wallet."
      });
    }
  };

  const disconnectWallet = () => {
    disconnect();
  };

  const checkWalletRegistration = async (address: string): Promise<boolean> => {
    try {
      const response = await fetch(formatUrl(`/api/wallet/${address}/exists`));
      if (!response.ok) {
        throw new Error("Failed to check wallet registration");
      }
      const data = await response.json();
      return data.exists;
    } catch (error) {
      console.error("Error checking wallet:", error);
      return false;
    }
  };

  const tryWalletLogin = async (walletAddress: string) => {
    try {
      const response = await apiRequest("POST", "/api/auth/wallet", {
        walletAddress,
        network: "sepolia" // Using sepolia chain
      });
      
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        
        toast({
          title: "Welcome back!",
          description: `You're logged in as ${userData.displayName || userData.username}`
        });
        
        return userData;
      }
      return null;
    } catch (error) {
      console.error("Wallet login failed:", error);
      return null;
    }
  };

  const registerWithWallet = async (userData: RegisterData) => {
    if (!address) {
      toast({
        variant: "destructive",
        title: "Wallet not connected",
        description: "Please connect your wallet first"
      });
      return;
    }
    
    setIsRegistering(true);
    try {
      const response = await apiRequest("POST", "/api/auth/wallet", {
        ...userData,
        walletAddress: address,
        network: "sepolia" // Using sepolia chain
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Registration failed");
      }
      
      const newUser = await response.json();
      setUser(newUser);
      
      toast({
        title: "Registration successful!",
        description: `Welcome to the platform, ${newUser.displayName}!`
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: error.message || "Could not complete registration"
      });
      throw error;
    } finally {
      setIsRegistering(false);
    }
  };

  const logout = async () => {
    try {
      const response = await apiRequest("POST", "/api/auth/logout");
      if (response.ok) {
        setUser(null);
        disconnectWallet();
        
        toast({
          title: "Logged out",
          description: "You have been logged out successfully"
        });
      } else {
        throw new Error("Logout failed");
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: "There was an error logging out"
      });
    }
  };

  return (
    <WalletAuthContext.Provider
      value={{
        user,
        isLoading,
        isConnecting: isPending,
        isRegistering,
        walletAddress: address || null,
        walletConnected: isConnected,
        connectWallet,
        disconnectWallet,
        registerWithWallet,
        logout,
        checkWalletRegistration
      }}
    >
      {children}
    </WalletAuthContext.Provider>
  );
}

export function useWalletAuth() {
  const context = useContext(WalletAuthContext);
  if (!context) {
    throw new Error("useWalletAuth must be used within a Web3ModalAuthProvider");
  }
  return context;
}