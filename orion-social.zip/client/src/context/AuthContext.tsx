import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  // Remove traditional login
  // login: (username: string, password: string) => Promise<void>; 
  registerWithWallet: (userData: WalletRegisterData) => Promise<void>;
  loginWithWallet: (walletAddress: string, network?: string) => Promise<User | null>;
  // Remove traditional register
  // register: (userData: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (user: User) => void;
  refreshUserData: () => Promise<User | null>;
  checkWalletRegistration: (walletAddress: string) => Promise<boolean>;
}

interface RegisterData {
  username: string;
  password: string;
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
  walletAddress?: string | null;
  network?: string | null;
}

interface WalletRegisterData {
  username: string;
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
  walletAddress: string;
  network: string;
}

interface ThemeProviderProps {
  children: ReactNode;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  
  // Check authentication status on initial load
  useEffect(() => {
    const checkAuthStatus = async () => {
      setIsLoading(true);
      try {
        const response = await fetch('/api/auth/session', {
          credentials: 'include'
        });
        
        if (response.ok) {
          const data = await response.json();
          if (data.authenticated && data.user) {
            setUser(data.user);
          } else {
            // If not authenticated, ensure user is set to null
            setUser(null);
          }
        } else {
          // If response is not ok (e.g., 401), clear user state
          setUser(null);
        }
      } catch (error) {
        console.error("Failed to check auth status:", error);
        // On error, clear user state for safety
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };
    
    checkAuthStatus();
    
    // Set up an interval to periodically check auth status (every 5 minutes)
    const intervalId = setInterval(checkAuthStatus, 5 * 60 * 1000);
    
    return () => clearInterval(intervalId);
  }, []);

  // Function to refresh user data from the server
  const refreshUserData = async (): Promise<User | null> => {
    try {
      const response = await fetch("/api/auth/session", {
        credentials: "include",
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.authenticated && data.user) {
          setUser(data.user);
          return data.user;
        } else {
          // Session is not valid anymore
          setUser(null);
          return null;
        }
      } else {
        // Handle 401 or other error responses
        setUser(null);
        return null;
      }
    } catch (error) {
      console.error("Session check failed:", error);
      setUser(null);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Function to update user data in context
  const updateUser = (updatedUser: User) => {
    console.log("Updating user in context:", updatedUser);
    setUser(updatedUser);
  };

  useEffect(() => {
    // Only check authentication if we're not on auth pages
    const currentPath = window.location.pathname;
    const isAuthPage = currentPath === '/auth' || currentPath === '/login' || currentPath === '/register';
    
    if (!isAuthPage) {
      refreshUserData();
    } else {
      setIsLoading(false); // Set loading to false on auth pages
    }
  }, []);

  // Function to check if a wallet address is already registered
  const checkWalletRegistration = async (walletAddress: string): Promise<boolean> => {
    try {
      const response = await apiRequest("GET", `/api/wallet/${walletAddress}/exists`);
      if (response.ok) {
        const data = await response.json();
        return data.exists;
      }
      return false;
    } catch (error) {
      console.error("Error checking wallet registration:", error);
      return false;
    }
  };
  
  // Function to login with wallet
  const loginWithWallet = async (walletAddress: string, network: string = "ethereum"): Promise<User | null> => {
    try {
      const response = await apiRequest("POST", "/api/auth/wallet", {
        walletAddress,
        network
      });
      
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        
        toast({
          title: "Wallet Login Successful",
          description: `Welcome back, ${userData.displayName}!`,
        });
        
        return userData;
      }
      return null;
    } catch (error) {
      console.error("Wallet login failed:", error);
      toast({
        variant: "destructive",
        title: "Login Failed",
        description: "Failed to login with your wallet. Please try again.",
      });
      return null;
    }
  };

  const register = async (userData: RegisterData) => {
    try {
      const response = await apiRequest("POST", "/api/auth/register", userData);
      const newUser = await response.json();
      setUser(newUser);
      
      toast({
        title: "Registration successful",
        description: `Welcome to Micro, ${newUser.displayName}!`,
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: "Username may already be taken",
      });
      throw error;
    }
  };

  const logout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout", {});
      setUser(null);
      
      toast({
        title: "Logged out",
        description: "See you again soon!",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: "An unexpected error occurred",
      });
      throw error;
    }
  };

  const registerWithWallet = async (userData: WalletRegisterData) => {
    try {
      const response = await apiRequest("POST", "/api/auth/wallet", userData);
      const newUser = await response.json();
      setUser(newUser);
      
      toast({
        title: "Wallet registration successful",
        description: `Welcome to ${import.meta.env.NEXT_PUBLIC_APP_NAME || 'our platform'}, ${newUser.displayName}!`,
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Wallet registration failed",
        description: "An error occurred during wallet registration",
      });
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isLoading, 
      registerWithWallet,
      loginWithWallet,
      logout,
      updateUser,
      refreshUserData,
      checkWalletRegistration
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

// Material UI Dark Theme Provider
export function ThemeProvider({ children }: ThemeProviderProps) {
  return (
    <div className="min-h-screen bg-background font-roboto text-foreground">
      {children}
    </div>
  );
}
