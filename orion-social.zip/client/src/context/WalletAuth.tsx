import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useAccount, useDisconnect } from "wagmi";
import { useWeb3Modal } from "@web3modal/wagmi/react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";

// Auth context type definition for wallet-only authentication
interface WalletAuthContextType {
  user: User | null;
  isLoading: boolean;
  registerWithWallet: (userData: WalletRegisterData) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (user: User) => void;
  refreshUserData: () => Promise<User | null>;
  checkWalletRegistration: (walletAddress: string) => Promise<boolean>;
  isConnected: boolean;
  connectWallet: () => Promise<void>;
}

// Registration data for wallet-based signup
interface WalletRegisterData {
  username: string;
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
  walletAddress: string;
  network: string;
}

// Create context
const WalletAuthContext = createContext<WalletAuthContextType | null>(null);

// Provider component
export function WalletAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  
  // Web3 wallet hooks
  const { address, isConnected } = useAccount();
  const { disconnect } = useDisconnect();
  const { open: openConnectModal } = useWeb3Modal();
  
  // Function to connect wallet
  const connectWallet = async () => {
    try {
      await openConnectModal();
    } catch (error) {
      console.error("Error connecting wallet:", error);
      toast({
        variant: "destructive",
        title: "Connection failed",
        description: "Failed to connect your wallet. Please try again."
      });
    }
  };
  
  // Function to refresh user data from the server
  const refreshUserData = async (): Promise<User | null> => {
    try {
      const response = await fetch("/api/auth/session", {
        credentials: "include",
      });
      
      if (response.ok) {
        const userData = await response.json();
        if (userData.user) {
          setUser(userData.user);
          return userData.user;
        }
      }
      setUser(null);
      return null;
    } catch (error) {
      console.error("Session check failed:", error);
      setUser(null);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Check if user is logged in on mount
  useEffect(() => {
    refreshUserData();
  }, []);
  
  // Try to login with wallet when connected
  useEffect(() => {
    async function autoLoginWithWallet() {
      if (isConnected && address && !user) {
        try {
          // Try to login with the connected wallet
          const isRegistered = await checkWalletRegistration(address);
          
          if (isRegistered) {
            const response = await apiRequest("POST", "/api/auth/wallet", {
              walletAddress: address,
              network: "1" // Default to Ethereum mainnet
            });
            
            if (response.ok) {
              const userData = await response.json();
              setUser(userData);
              toast({
                title: "Welcome back!",
                description: `You are now logged in as ${userData.displayName}`
              });
            }
          }
        } catch (error) {
          console.error("Auto wallet login failed:", error);
        }
      }
    }
    
    autoLoginWithWallet();
  }, [isConnected, address, user, toast]);

  // Function to update user data in context
  const updateUser = (updatedUser: User) => {
    setUser(updatedUser);
  };
  
  // Function to check if a wallet is already registered
  const checkWalletRegistration = async (walletAddress: string): Promise<boolean> => {
    try {
      const response = await apiRequest("GET", `/api/wallet/${walletAddress}/exists`);
      if (!response.ok) {
        throw new Error("Failed to check wallet registration");
      }
      const data = await response.json();
      return data.exists;
    } catch (error) {
      console.error("Error checking wallet registration:", error);
      return false;
    }
  };

  // Register with wallet data
  const registerWithWallet = async (userData: WalletRegisterData) => {
    try {
      const response = await apiRequest("POST", "/api/auth/wallet", userData);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Registration failed");
      }
      
      const newUser = await response.json();
      setUser(newUser);
      
      toast({
        title: "Registration successful",
        description: `Welcome, ${newUser.displayName}!`,
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: error.message || "Username may already be taken or there was a server error",
      });
      throw error;
    }
  };
  
  // Logout function
  const logout = async () => {
    try {
      const response = await apiRequest("POST", "/api/auth/logout");
      if (response.ok) {
        // Disconnect wallet
        disconnect();
        
        // Clear user data
        setUser(null);
        
        // Clear any cached queries
        queryClient.clear();
        
        toast({
          title: "Logged out",
          description: "You have been logged out successfully",
        });
      } else {
        throw new Error("Logout failed");
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: "There was an error logging out",
      });
      throw error;
    }
  };

  return (
    <WalletAuthContext.Provider
      value={{
        user,
        isLoading,
        registerWithWallet,
        logout,
        updateUser,
        refreshUserData,
        checkWalletRegistration,
        isConnected,
        connectWallet
      }}
    >
      {children}
    </WalletAuthContext.Provider>
  );
}

// Hook to use the auth context
export function useWalletAuth() {
  const context = useContext(WalletAuthContext);
  if (!context) {
    throw new Error("useWalletAuth must be used within a WalletAuthProvider");
  }
  return context;
}