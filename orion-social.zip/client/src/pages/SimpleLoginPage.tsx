import { useState } from 'react';
import { useLocation } from 'wouter';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';

// Login Schema
const loginSchema = z.object({
  username: z.string().min(3, { message: 'Username must be at least 3 characters' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters' }),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export default function SimpleLoginPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });

  async function onSubmit(values: LoginFormValues) {
    setIsLoading(true);
    try {
      // Simple API call - using the standard API path 
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(values),
      });
      
      if (!response.ok) {
        throw new Error('Login failed');
      }
      
      const userData = await response.json();
      console.log('Login successful, user data:', userData);
      
      toast({
        title: 'Login successful',
        description: 'Welcome back!',
      });
      
      // Wait briefly for the session to be established
      setTimeout(() => {
        setLocation('/');
      }, 500);
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Login failed',
        description: error.message || 'Invalid credentials',
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen bg-[#0f172a]">
      {/* Form Section */}
      <div className="flex flex-col justify-center px-4 py-12 sm:px-6 lg:flex-none lg:px-10 xl:px-20 w-full lg:w-1/2 relative">
        <div className="absolute inset-0 opacity-10" style={{ 
          backgroundImage: 'radial-gradient(circle at 25px 25px, rgba(0, 255, 208, 0.3) 2px, transparent 0)',
          backgroundSize: '50px 50px'
        }}></div>
        <div className="w-full max-w-sm mx-auto lg:w-96 relative z-10">
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-r from-teal-400 to-indigo-500 flex items-center justify-center mb-6">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
            </div>
            <h2 className="mt-2 text-3xl font-extrabold text-white">
              Sign in to your account
            </h2>
            <p className="mt-2 text-sm text-center text-gray-400">
              Welcome back! Enter your credentials to continue
            </p>
          </div>

          <div className="mt-8">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Username</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="username" 
                          {...field} 
                          className="bg-[#1a2747] border-[#2a3c6a] text-white placeholder:text-gray-500 focus:border-teal-400 focus:ring-teal-400/20" 
                        />
                      </FormControl>
                      <FormMessage className="text-red-400" />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="••••••" 
                          {...field} 
                          className="bg-[#1a2747] border-[#2a3c6a] text-white placeholder:text-gray-500 focus:border-teal-400 focus:ring-teal-400/20" 
                        />
                      </FormControl>
                      <FormMessage className="text-red-400" />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-teal-500 to-indigo-600 hover:from-teal-600 hover:to-indigo-700 text-white shadow-lg shadow-indigo-500/20 hover:shadow-indigo-500/40 transition-all" 
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span className="flex items-center justify-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Signing in...
                    </span>
                  ) : 'Sign in'}
                </Button>
              </form>
            </Form>
            
            <div className="mt-8">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-[#2a3c6a]"></div>
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="px-2 text-gray-500 bg-[#0f172a]">Or continue with</span>
                </div>
              </div>
              
              <div className="mt-4">
                <button
                  type="button"
                  className="w-full bg-[#1a2747] border border-[#2a3c6a] rounded-md py-2.5 px-4 flex justify-center items-center text-sm font-medium text-gray-300 hover:bg-[#243260] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 focus:ring-offset-[#0f172a]"
                >
                  <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M11.9993 2L11.8047 2.65593V16.3047L11.9993 16.4993L18.5173 12.615L11.9993 2Z" fill="#39A1FF"/>
                    <path d="M11.999 2L5.48096 12.615L11.999 16.4993V9.723V2Z" fill="#91CBF5"/>
                    <path d="M11.9993 17.8961L11.8906 18.0292V22.5383L11.9993 22.852L18.5213 14.0151L11.9993 17.8961Z" fill="#39A1FF"/>
                    <path d="M11.999 22.8519V17.8961L5.48096 14.015L11.999 22.8519Z" fill="#91CBF5"/>
                    <path d="M11.999 16.4993L18.5171 12.6151L11.999 9.72305V16.4993Z" fill="#1D62E0"/>
                    <path d="M5.48096 12.6151L11.999 16.4993V9.72305L5.48096 12.6151Z" fill="#7BA6E7"/>
                  </svg>
                  Connect Wallet
                </button>
              </div>
              
              <p className="text-center text-sm mt-6 text-gray-500">
                Don't have an account?{' '}
                <button 
                  type="button" 
                  onClick={() => setLocation('/auth')}
                  className="text-[#b07c1d]/10 hover:text-[#b07c1d] font-medium"
                >
                  Register now
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <div className="hidden lg:block relative lg:w-1/2">
        <div className="absolute inset-0 bg-gradient-to-tr from-[#0f172a] to-[#1e2a4a] flex flex-col justify-center px-10">
          <div className="absolute inset-0 opacity-20" style={{ 
            backgroundImage: 'radial-gradient(circle at 25px 25px, rgba(0, 255, 208, 0.15) 2px, transparent 0), radial-gradient(circle at 75px 75px, rgba(128, 90, 213, 0.15) 2px, transparent 0)',
            backgroundSize: '100px 100px'
          }}></div>
          <div className="max-w-lg mx-auto">
            <h1 className="text-4xl font-bold text-white mb-6">
              Connect with friends and the world around you
            </h1>
            <p className="text-white/90 text-lg mb-8">
              Share your thoughts, join conversations, and discover content from people and communities that match your interests.
            </p>
            <div className="grid grid-cols-2 gap-4 text-white/80">
              <div className="flex items-start space-x-2">
                <div className="rounded-full p-1 bg-white/20 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span>Connect with friends and family</span>
              </div>
              <div className="flex items-start space-x-2">
                <div className="rounded-full p-1 bg-white/20 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span>Discover trending topics</span>
              </div>
              <div className="flex items-start space-x-2">
                <div className="rounded-full p-1 bg-white/20 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span>Share your moments</span>
              </div>
              <div className="flex items-start space-x-2">
                <div className="rounded-full p-1 bg-white/20 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span>Join communities of interest</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}