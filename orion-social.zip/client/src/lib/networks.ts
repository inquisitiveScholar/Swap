// Network configuration for Web3 wallet connections
export interface NetworkConfig {
  chainId: string;
  name: string;
  currency: string;
  symbol: string;
  rpcUrl: string;
  blockExplorer: string;
  decimals?: number;
  iconUrl?: string;
}

// Default supported networks
export const DEFAULT_NETWORKS: Record<string, NetworkConfig> = {
  ethereum: {
    chainId: "0x1",
    name: "Ethereum Mainnet",
    currency: "Ethereum",
    symbol: "ETH",
    rpcUrl: "https://mainnet.infura.io/v3/",
    blockExplorer: "https://etherscan.io",
    decimals: 18
  },
  bsc: {
    chainId: "0x38",
    name: "BSC Mainnet",
    currency: "Binance Coin",
    symbol: "BNB",
    rpcUrl: "https://bsc-dataseed.binance.org/",
    blockExplorer: "https://bscscan.com",
    decimals: 18
  },
  polygon: {
    chainId: "0x89",
    name: "Polygon Mainnet",
    currency: "Polygon",
    symbol: "MATIC",
    rpcUrl: "https://polygon-rpc.com/",
    blockExplorer: "https://polygonscan.com",
    decimals: 18
  }
};

// Custom networks storage
let customNetworks: Record<string, NetworkConfig> = {};

// Load custom networks from localStorage
function loadCustomNetworks() {
  try {
    const stored = localStorage.getItem('customNetworks');
    if (stored) {
      customNetworks = JSON.parse(stored);
    }
  } catch (error) {
    console.error('Error loading custom networks:', error);
  }
}

// Save custom networks to localStorage
function saveCustomNetworks() {
  try {
    localStorage.setItem('customNetworks', JSON.stringify(customNetworks));
  } catch (error) {
    console.error('Error saving custom networks:', error);
  }
}

// Get all supported networks (default + custom)
export function getAllNetworks(): Record<string, NetworkConfig> {
  loadCustomNetworks();
  return { ...DEFAULT_NETWORKS, ...customNetworks };
}

// Add custom network
export function addCustomNetwork(networkId: string, config: NetworkConfig): boolean {
  try {
    loadCustomNetworks();
    customNetworks[networkId] = config;
    saveCustomNetworks();
    return true;
  } catch (error) {
    console.error('Error adding custom network:', error);
    return false;
  }
}

// Remove custom network
export function removeCustomNetwork(networkId: string): boolean {
  try {
    loadCustomNetworks();
    if (customNetworks[networkId]) {
      delete customNetworks[networkId];
      saveCustomNetworks();
      return true;
    }
    return false;
  } catch (error) {
    console.error('Error removing custom network:', error);
    return false;
  }
}

export function getDefaultNetwork(): string {
  return import.meta.env.VITE_DEFAULT_NETWORK || "ethereum";
}

export function getSupportedNetworks(): string[] {
  const supportedNetworksEnv = import.meta.env.VITE_SUPPORTED_NETWORKS;
  if (supportedNetworksEnv) {
    return supportedNetworksEnv.split(",").map((n: string) => n.trim());
  }
  return ["ethereum"];
}

export function getNetworkConfig(network: string): NetworkConfig | null {
  const allNetworks = getAllNetworks();
  return allNetworks[network] || null;
}

export async function switchToNetwork(network: string): Promise<boolean> {
  const networkConfig = getNetworkConfig(network);
  if (!networkConfig || !window.ethereum) {
    return false;
  }

  try {
    // Try to switch to the network
    await window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: networkConfig.chainId }],
    });
    return true;
  } catch (switchError: any) {
    // If the network doesn't exist, add it
    if (switchError.code === 4902) {
      try {
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [{
            chainId: networkConfig.chainId,
            chainName: networkConfig.name,
            nativeCurrency: {
              name: networkConfig.currency,
              symbol: networkConfig.symbol,
              decimals: 18,
            },
            rpcUrls: [networkConfig.rpcUrl],
            blockExplorerUrls: [networkConfig.blockExplorer],
          }],
        });
        return true;
      } catch (addError) {
        console.error('Failed to add network:', addError);
        return false;
      }
    }
    console.error('Failed to switch network:', switchError);
    return false;
  }
}

export async function getCurrentNetwork(): Promise<string | null> {
  if (!window.ethereum) return null;
  
  try {
    const chainId = await window.ethereum.request({ method: 'eth_chainId' });
    const allNetworks = getAllNetworks();
    for (const [network, config] of Object.entries(allNetworks)) {
      if (config.chainId === chainId) {
        return network;
      }
    }
    return null;
  } catch (error) {
    console.error('Error getting current network:', error);
    return null;
  }
}

declare global {
  interface Window {
    ethereum?: {
      request: (args: { method: string; params?: any[] }) => Promise<any>;
      on: (event: string, callback: (...args: any[]) => void) => void;
      removeListener: (event: string, callback: (...args: any[]) => void) => void;
      isMetaMask?: boolean;
    };
  }
}