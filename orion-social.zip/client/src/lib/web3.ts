// Web3 transaction utilities for tip functionality
import { getNetworkConfig } from './networks';

// Convert amount to Wei (for 18 decimal networks)
export function toWei(amount: string, decimals: number = 18): string {
  const factor = Math.pow(10, decimals);
  return (parseFloat(amount) * factor).toString(16);
}

// Convert Wei to readable amount
export function fromWei(weiAmount: string, decimals: number = 18): string {
  const factor = Math.pow(10, decimals);
  return (parseInt(weiAmount, 16) / factor).toString();
}

// Send native cryptocurrency transaction
export async function sendNativeTransaction(
  toAddress: string,
  amount: string,
  network: string
): Promise<string> {
  if (!window.ethereum) {
    throw new Error('MetaMask is not installed');
  }

  const networkConfig = getNetworkConfig(network);
  if (!networkConfig) {
    throw new Error(`Network ${network} not found`);
  }

  try {
    // Request account access
    const accounts = await window.ethereum.request({
      method: 'eth_requestAccounts'
    });

    if (accounts.length === 0) {
      throw new Error('No accounts available');
    }

    const fromAddress = accounts[0];

    // Convert amount to Wei
    const amountInWei = '0x' + toWei(amount, networkConfig.decimals || 18);

    // Prepare transaction
    const transactionParameters = {
      to: toAddress,
      from: fromAddress,
      value: amountInWei,
      gas: '0x5208', // 21000 gas for simple transfer
    };

    // Send transaction
    const txHash = await window.ethereum.request({
      method: 'eth_sendTransaction',
      params: [transactionParameters],
    });

    return txHash;
  } catch (error: any) {
    console.error('Transaction failed:', error);
    throw new Error(error.message || 'Transaction failed');
  }
}

// Wait for transaction confirmation
export async function waitForTransaction(txHash: string): Promise<boolean> {
  if (!window.ethereum) {
    throw new Error('MetaMask is not installed');
  }

  try {
    let receipt = null;
    let attempts = 0;
    const maxAttempts = 60; // Wait up to 60 seconds

    while (!receipt && attempts < maxAttempts) {
      try {
        receipt = await window.ethereum.request({
          method: 'eth_getTransactionReceipt',
          params: [txHash],
        });

        if (receipt) {
          return receipt.status === '0x1'; // Success if status is 1
        }

        // Wait 1 second before next attempt
        await new Promise(resolve => setTimeout(resolve, 1000));
        attempts++;
      } catch (error) {
        // Transaction might not be mined yet
        await new Promise(resolve => setTimeout(resolve, 1000));
        attempts++;
      }
    }

    throw new Error('Transaction confirmation timeout');
  } catch (error: any) {
    console.error('Error waiting for transaction:', error);
    throw new Error(error.message || 'Failed to confirm transaction');
  }
}

// Get wallet balance
export async function getWalletBalance(network: string): Promise<string> {
  if (!window.ethereum) {
    throw new Error('MetaMask is not installed');
  }

  const networkConfig = getNetworkConfig(network);
  if (!networkConfig) {
    throw new Error(`Network ${network} not found`);
  }

  try {
    const accounts = await window.ethereum.request({
      method: 'eth_requestAccounts'
    });

    if (accounts.length === 0) {
      throw new Error('No accounts available');
    }

    const balance = await window.ethereum.request({
      method: 'eth_getBalance',
      params: [accounts[0], 'latest'],
    });

    return fromWei(balance, networkConfig.decimals || 18);
  } catch (error: any) {
    console.error('Error getting balance:', error);
    throw new Error(error.message || 'Failed to get wallet balance');
  }
}

// Get current wallet address
export async function getCurrentWalletAddress(): Promise<string | null> {
  if (!window.ethereum) {
    return null;
  }

  try {
    const accounts = await window.ethereum.request({
      method: 'eth_requestAccounts'
    });

    return accounts.length > 0 ? accounts[0] : null;
  } catch (error) {
    console.error('Error getting wallet address:', error);
    return null;
  }
}

// Validate Ethereum address
export function isValidEthereumAddress(address: string): boolean {
  return /^0x[a-fA-F0-9]{40}$/.test(address);
}