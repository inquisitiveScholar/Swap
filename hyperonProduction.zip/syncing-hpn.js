#!/usr/bin/env nodejs
const mysql = require('mysql');
const util = require('util');
const Web3 = require("web3");

var DB_CONFIG = {
    host: "localhost",
    user: "root",
    password: "hyper@@n$%^&kk@!;b^56@@dk",
    database: "bridge",
    connectTimeout: 100000,
    port: 3306
};

const options = {
    timeout: 30000,
    reconnect: {
        auto: true,
        delay: 5000,
        maxAttempts: 10,
        onTimeout: true,
    },
    clientConfig: {
        keepalive: true,
        keepaliveInterval: 60000,
        maxReceivedFrameSize: 100000000,
        maxReceivedMessageSize: 100000000,
    },
};


var fromBridgeContract = '0xc3582394580e950fa702bf694a383e6f8286c85a';
var toBridgeContract = '0xec4885FC84021De0cAC9Aecd5c304Ba696D651f3';


var fromChainID = 500; // This is the chain ID for the from network
var toChainID =56 ; // This is the chain ID for the to network
var fromChainNativeCoin = "HPN";
var toChainNativeCoin = "BNB";
var fromWeb3Provider = "https://mainnet-rpc.hyperonchain.com";
var  toWeb3Provider = "https://bsc-mainnet.nodereal.io/v1/59d8dbe6ea474ee885ccb42ac2343a7a";


 var hpnTokenContract = "0xe3D2Ba4eBcc6e9AE3569d6418BC2eaABB8FeEf60";    // HPN Token on To Network

var usdtContractFromChain = "0x55d398326f99059fF775485246999027B3197955";   // USDT Token contract address of FROM CHAIN

var nativeCoinAddress = "0x0000000000000000000000000000000000000000";       // Native coin


var BRIDGE_CONTRACT_ABI = [{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"orderID","type":"uint256"},{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"},{"indexed":false,"internalType":"address","name":"outputCurrency","type":"address"}],"name":"CoinIn","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"orderID","type":"uint256"},{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"CoinOut","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"orderID","type":"uint256"},{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"}],"name":"CoinOutFailed","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"_from","type":"address"},{"indexed":true,"internalType":"address","name":"_to","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"signer","type":"address"},{"indexed":true,"internalType":"bool","name":"status","type":"bool"}],"name":"SignerUpdated","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"orderID","type":"uint256"},{"indexed":true,"internalType":"address","name":"tokenAddress","type":"address"},{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"chainID","type":"uint256"},{"indexed":false,"internalType":"address","name":"outputCurrency","type":"address"}],"name":"TokenIn","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"orderID","type":"uint256"},{"indexed":true,"internalType":"address","name":"tokenAddress","type":"address"},{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"chainID","type":"uint256"}],"name":"TokenOut","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"orderID","type":"uint256"},{"indexed":true,"internalType":"address","name":"tokenAddress","type":"address"},{"indexed":true,"internalType":"address","name":"user","type":"address"},{"indexed":false,"internalType":"uint256","name":"value","type":"uint256"},{"indexed":false,"internalType":"uint256","name":"chainID","type":"uint256"}],"name":"TokenOutFailed","type":"event"},{"inputs":[],"name":"acceptOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_signer","type":"address"},{"internalType":"bool","name":"_status","type":"bool"}],"name":"changeSigner","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"outputCurrency","type":"address"}],"name":"coinIn","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"user","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"},{"internalType":"uint256","name":"_orderID","type":"uint256"}],"name":"coinOut","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"orderID","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"signer","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"tokenAddress","type":"address"},{"internalType":"uint256","name":"tokenAmount","type":"uint256"},{"internalType":"uint256","name":"chainID","type":"uint256"},{"internalType":"address","name":"outputCurrency","type":"address"}],"name":"tokenIn","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"tokenAddress","type":"address"},{"internalType":"address","name":"user","type":"address"},{"internalType":"uint256","name":"tokenAmount","type":"uint256"},{"internalType":"uint256","name":"_orderID","type":"uint256"},{"internalType":"uint256","name":"chainID","type":"uint256"}],"name":"tokenOut","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"stateMutability":"payable","type":"receive"}];




var fromWeb3 = new Web3(new Web3.providers.HttpProvider(fromWeb3Provider, options));
var toWeb3 = new Web3(new Web3.providers.HttpProvider(toWeb3Provider, options));


const fromBridgeInstance = new fromWeb3.eth.Contract(BRIDGE_CONTRACT_ABI, fromBridgeContract.toString());
const toBridgeInstance = new toWeb3.eth.Contract(BRIDGE_CONTRACT_ABI, toBridgeContract.toString());



execute();


async function execute() {
    var fromChainCurrentBlock = await fromWeb3.eth.getBlockNumber();
    var toChainCurrentBlock = await toWeb3.eth.getBlockNumber();
        
    var dbConn = mysql.createConnection(DB_CONFIG);
    try {
        const myquery = util.promisify(dbConn.query).bind(dbConn);
        var select_wallet_query = "SELECT * FROM lastblock";
        var lastBlockData = await myquery(select_wallet_query).catch(console.log);

        if (lastBlockData[0]) {
            
//=================================================================================
//   Change following networks accordingly when changing network in the script
//=================================================================================
            var fromChainLastBlockDB = lastBlockData[0].bsc;
            var toChainLastBlockDB = lastBlockData[0].bsc_ourChain;
            
            console.log("fromChainLastBlockDB, fromChainCurrentBlock ", fromChainLastBlockDB, fromChainCurrentBlock);
            console.log("toChainLastBlockDB, toChainCurrentBlock", toChainLastBlockDB, toChainCurrentBlock);

            //updating the current block in the database
            await lastBlockWorked(fromChainCurrentBlock, toChainCurrentBlock);

            //toChainLastBlockDB = 3345470
            
            await getEventData_CoinIn(fromChainLastBlockDB, fromChainCurrentBlock);
            await getEventData_TokenIn(fromChainLastBlockDB, fromChainCurrentBlock);
            await getEventData_CoinOut(toChainLastBlockDB, toChainCurrentBlock);
            await getEventData_TokenOut(toChainLastBlockDB, toChainCurrentBlock);
        }

    } catch (e) {
        console.log(e);
    } finally {
        dbConn.end();
    }
}

async function getEventData_CoinIn(_fromBlock, _toBlock) {
    try {
        await fromBridgeInstance.getPastEvents('CoinIn', {
            fromBlock: _fromBlock,
            toBlock: _toBlock
        }, async function(error, events) {
            try {
                console.log(error);
                var eventlen = events.length;
                console.log("COIN IN >>> eventlen >>>>", eventlen);
                const waitsec = (ms) => new Promise(resolve => setTimeout(resolve, ms));
                for (var i = 0; i < eventlen; i++) {
                    await waitsec(3500);
                    var eve = events[i];
                    console.log(eve);
                    var _blkNumber = eve.blockNumber;
                    var _txnHash = eve.transactionHash;
                    var _orderid = eve.returnValues.orderID;
                    var _userWallet = eve.returnValues.user;
                    var _amount = eve.returnValues.value;
                    var _outputCurrency = eve.returnValues.outputCurrency;
                    var _toTxnHash = '';
                    var _toAmount = 0.0;
                    var _toCoin = toChainNativeCoin;
                    
//=================================================================================
//   Change following outputCurrency accordingly when changing network in the script
//=================================================================================
                    if(fromWeb3.utils.toChecksumAddress(_outputCurrency) === fromWeb3.utils.toChecksumAddress(bnbContractToChain)){
                        var _toCoin = fromChainNativeCoin;
                    }

                    if (parseInt(_amount)) {
                        try {
                            var sp_query = "INSERT INTO `bridge_transactions` (`userWallet`,`orderID`,`fromChain`,`fromCurrency`,`fromTxnHash`,`fromAmount`,`toChain`,`toCurrency`,`toTxnHash`,`toAmount`) VALUES ('" + _userWallet + "'," + _orderid + "," + fromChainID + ",'"+ fromChainNativeCoin +"','" + _txnHash + "','" + _amount + "'," + toChainID + ",'" + _toCoin + "','" + _toTxnHash + "'," + _toAmount + ")";
                            console.log("-----------------------------------------------------------------------------");
                            console.log(">>>>> SP_Query >>>>>", sp_query);
                            console.log("-----------------------------------------------------------------------------");
                            await db_query(sp_query).catch(console.log);
                        } catch (e) {
                            console.log(">>>>>Catch >>>>", e);
                        }
                    } else {
                        console.log(">>>> CoinIn >>>>In for loop, _orderid, _txnHash,  _amount, i >>>>", _orderid, _txnHash, _amount, i);
                    }
                }
            } catch (e) {
                console.log(e);
            }
        });
        ////
    } catch (e) {
        console.log("<<<< Error >>>>", e);
    }
}


async function getEventData_TokenIn(_fromBlock, _toBlock) {
    try {
        await fromBridgeInstance.getPastEvents('TokenIn', {
            fromBlock: _fromBlock,
            toBlock: _toBlock
        }, async function(error, events) {
            try {
                console.log(error);
                var eventlen = events.length;
                console.log("TOKEN IN >>> eventlen >>>>", eventlen);
                const waitsec = (ms) => new Promise(resolve => setTimeout(resolve, ms));
                for (var i = 0; i < eventlen; i++) {
                    await waitsec(3500);
                    var eve = events[i];
                    var tokenAddress = eve.returnValues.tokenAddress;
                    if (fromWeb3.utils.toChecksumAddress(tokenAddress) === fromWeb3.utils.toChecksumAddress(usdtContractFromChain)) {
                        FROM_TOKEN = "USDT";
                    } else {
                        FROM_TOKEN = "INVALID_TOKEN_ADDR";
                    }

                    var _blkNumber = eve.blockNumber;
                    var _txnHash = eve.transactionHash;
                    var _orderid = eve.returnValues.orderID;
                    var _userWallet = eve.returnValues.user;
                    var _amount = eve.returnValues.value;
                    var _outputCurrency = eve.returnValues.outputCurrency;
                    var _toTxnHash = '';
                    var _toAmount = 0.0;
                    var _toCoin = fromChainNativeCoin;
                    
                    
                    if(fromWeb3.utils.toChecksumAddress(_outputCurrency) === fromWeb3.utils.toChecksumAddress(nativeCoinAddress)){
                        var _toCoin = toChainNativeCoin;
                    }

                    if (parseInt(_amount)) {
                        try {
                            var sp_query = "INSERT INTO `bridge_transactions` (`userWallet`,`orderID`,`fromChain`,`fromCurrency`,`fromTxnHash`,`fromAmount`,`toChain`,`toCurrency`,`toTxnHash`,`toAmount`) VALUES ('" + _userWallet + "'," + _orderid + "," + fromChainID + ",'" + FROM_TOKEN + "','" + _txnHash + "','" + _amount + "'," + toChainID + ",'" + _toCoin + "','" + _toTxnHash + "'," + _toAmount + ")";
                            console.log("-----------------------------------------------------------------------------");
                            console.log(">>>>> SP_Query >>>>>", sp_query);
                            console.log("-----------------------------------------------------------------------------");
                            await db_query(sp_query).catch(console.log);
                        } catch (e) {
                            console.log(">>>>>Catch >>>>", e);
                        }
                    } else {
                        console.log(">>>> CoinIn >>>>In for loop, _orderid, _txnHash,  _amount, i >>>>", _orderid, _txnHash, _amount, i);
                    }
                }
            } catch (e) {
                console.log(e);
            }
        });
        ////
    } catch (e) {
        console.log("<<<< Error >>>>", e);
    }
}




async function getEventData_CoinOut(_fromBlock, _toBlock) {
    
        
    try {
        var dbConn = mysql.createConnection(DB_CONFIG);
        const myquery = util.promisify(dbConn.query).bind(dbConn);
        await toBridgeInstance.getPastEvents('CoinOut', {
            fromBlock: _fromBlock,
            toBlock: _toBlock
        }, async function(error, events) {
            try {

                var eventlen = events.length;
                console.log("COIN OUT >>> eventlen >>>>", eventlen);
                const waitsec = (ms) => new Promise(resolve => setTimeout(resolve, ms));
                for (var i = 0; i < eventlen; i++) {
                    await waitsec(1500);
                    var eve = events[i];
                    console.log(">>>> Eve >>>>", eve);
                    var _txnHash = eve.transactionHash;
                    var _orderid = eve.returnValues.orderID;
                    var _userWallet = eve.returnValues.user;
                    var _amount = eve.returnValues.value;

                    if (parseInt(_amount)) {
                        try {
                            var select_from_txn_query = "SELECT * FROM bridge_transactions where fromChain=" + fromChainID + " and orderID=" + _orderid + " and status='Pending'";
                            var fromTxnData = await myquery(select_from_txn_query).catch(console.log);
                            
                            //take the first result. Even any duplicate by mistake, then also it will take first one.
                            if ((typeof fromTxnData) != 'undefined' && fromTxnData[0]) {
                                var update_query = "UPDATE `bridge_transactions` SET `toTxnHash`='" + _txnHash + "',`toAmount`='" + _amount + "',`status`='Completed' WHERE `fromChain`='" + fromChainID + "' && `orderID`='" + _orderid + "'";
                                console.log(">>> Updating record, orderid, transactionHash >>>", _orderid, _txnHash);
                                await myquery(update_query).catch(console.log);
                            } else {
                                //just in case, the order ID and chain ID are not found in the db, then it will log it. This is very rare to happen.
                                console.log("Unprocessed Transaction: chain, Hash: " + fromChainID + " - " + _txnHash);
                            }

                        } catch (e) {
                            console.log(">>>>>Catch >>>>", e);
                        }
                    } else {
                        console.log(">>>> CoinIn >>>>In for loop, _orderid, _txnHash,  _amount, i >>>>", _orderid, _txnHash, _amount, i);
                    }
                }
            } catch (e) {
                console.log(e);
            }
            finally{
                dbConn.end();
            }
        });
        ////
    } catch (e) {
        console.log("<<<< Error >>>>", e);
    }
    
}




async function getEventData_TokenOut(_fromBlock, _toBlock) {
    try {
        
        var dbConn = mysql.createConnection(DB_CONFIG);
        const myquery = util.promisify(dbConn.query).bind(dbConn);
        
        await toBridgeInstance.getPastEvents('TokenOut', {
            fromBlock: _fromBlock,
            toBlock: _toBlock
        }, async function(error, events) {
            try {

                var eventlen = events.length;
                console.log("TOKEN OUT >>> eventlen >>>>", eventlen);
                const waitsec = (ms) => new Promise(resolve => setTimeout(resolve, ms));
                for (var i = 0; i < eventlen; i++) {
                    await waitsec(1500);
                    var eve = events[i];

                    var _txnHash = eve.transactionHash;
                    var _orderid = eve.returnValues.orderID;
                    var _userWallet = eve.returnValues.user;
                    var _amount = eve.returnValues.value;


                    if (parseInt(_amount)) {
                        try {

                            var select_from_txn_query = "SELECT * FROM bridge_transactions where fromChain='" + fromChainID + "' && orderID='" + _orderid + "' && status='Pending'";
                            var fromTxnData = await myquery(select_from_txn_query).catch(console.log);


                            //take the first result. Even any duplicate by mistake, then also it will take first one.
                            if (fromTxnData[0]) {
                                var update_query = "UPDATE `bridge_transactions` SET `toTxnHash`='" + _txnHash + "',`toAmount`='" + _amount + "',`status`='Completed' WHERE `fromChain`='" + fromChainID + "' && `orderID`='" + _orderid + "'";
                                console.log(">>> Updating record, orderid, transactionHash >>>", _orderid, _txnHash);
                                await myquery(update_query).catch(console.log);
                            } else {
                                //just in case, the order ID and chain ID are not found in the db, then it will log it. This is very rare to happen.
                                console.log("Unprocessed Transaction: chain, Hash: " + fromChainID + " - " + _txnHash);
                            }


                        } catch (e) {
                            console.log(">>>>>Catch >>>>", e);
                        }
                    } else {
                        console.log(">>>> CoinIn >>>>In for loop, _orderid, _txnHash,  _amount, i >>>>", _orderid, _txnHash, _amount, i);
                    }
                }
            } catch (e) {
                console.log(e);
            }
            finally{
                dbConn.end();
            }
        });
        ////
    } catch (e) {
        console.log("<<<< Error >>>>", e);
    }
}




async function lastBlockWorked(fromChainCurrentBlock, toChainCurrentBlock) {
    
    
//=================================================================================
//   Change following table field accordingly when changing network in the script
//=================================================================================

    var sql = "UPDATE lastblock SET bsc=" + fromChainCurrentBlock + ", bsc_ourChain=" + toChainCurrentBlock + " LIMIT 1";
    console.log("<<< SQL >>>", sql);
    return db_query(sql, "UpdateQuery");
}


async function db_query(_sql, _querytype) {
    var con = mysql.createConnection(DB_CONFIG);
    try {
        con.connect(function(err) {
            if (err) {
                console.log(">>> Error DB connect:", err);
            }
            console.log(">>> Connected to database:>>>");
            try {
                con.query(_sql, function(err, result) {
                    if (err) {
                        console.log(">>> Error Occured:", err);
                    } else {
                        console.log(">>> Query Executed >>", _querytype);
                        con.end();
                    }
                    setTimeout(() => {}, 2000);
                });
            } catch (e) {
                console.log(">>>In catchblock>>>", e);
            }
        });
    } catch (e) {
        console.log(">>>>>>EEEEEEE>>>>>", e);
    }
}

