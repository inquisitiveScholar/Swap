-- SQLite 3.35+
ALTER TABLE "Campaign" DROP COLUMN "subtitle";
