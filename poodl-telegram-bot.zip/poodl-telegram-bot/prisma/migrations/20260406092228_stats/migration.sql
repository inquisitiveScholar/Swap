/*
  Warnings:

  - You are about to drop the column `imageFileId` on the `Campaign` table. All the data in the column will be lost.
  - You are about to drop the column `mediaType` on the `Campaign` table. All the data in the column will be lost.
  - You are about to drop the column `mode` on the `Campaign` table. All the data in the column will be lost.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Campaign" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "adminId" BIGINT NOT NULL,
    "chatId" BIGINT NOT NULL,
    "text" TEXT NOT NULL,
    "unlockTime" DATETIME NOT NULL,
    "intervalMinutes" INTEGER NOT NULL DEFAULT 5,
    "tokenName" TEXT,
    "tokenSymbol" TEXT,
    "price" TEXT,
    "marketCap" TEXT,
    "templateId" TEXT NOT NULL DEFAULT 'HYPE',
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "messageId" BIGINT,
    "lastPostTime" DATETIME,
    "lastEditTime" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_Campaign" ("adminId", "chatId", "createdAt", "id", "intervalMinutes", "isActive", "lastEditTime", "lastPostTime", "messageId", "text", "unlockTime", "updatedAt") SELECT "adminId", "chatId", "createdAt", "id", "intervalMinutes", "isActive", "lastEditTime", "lastPostTime", "messageId", "text", "unlockTime", "updatedAt" FROM "Campaign";
DROP TABLE "Campaign";
ALTER TABLE "new_Campaign" RENAME TO "Campaign";
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
