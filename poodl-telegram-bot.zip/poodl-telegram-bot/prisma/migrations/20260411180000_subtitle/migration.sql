-- AlterTable
ALTER TABLE "Campaign" ADD COLUMN "subtitle" TEXT;
