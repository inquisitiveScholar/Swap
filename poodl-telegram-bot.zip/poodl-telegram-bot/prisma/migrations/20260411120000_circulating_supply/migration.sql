-- AlterTable
ALTER TABLE "Campaign" ADD COLUMN "circulatingSupply" TEXT;
