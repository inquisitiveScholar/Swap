# Telegram Liquidity Countdown & Auto-Promotion Bot

A professional, scalable Telegram bot built with Node.js, grammY, and Prisma to manage liquidity countdowns and automated promotional campaigns.

## 🚀 Features

- **Automated Countdowns**: Real-time updates to liquidity unlock events.
- **Auto-Promotion**: Switches to "Advertisement Mode" automatically after the unlock.
- **Admin Control**: Fully managed via Telegram UI (Inline buttons & guided FSM).
- **Customizable**: Dynamic text, links, and media support.
- **Scalable**: Built with TypeScript and Prisma (SQLite/PostgreSQL).

## 🛠 Tech Stack

- **Runtime**: Node.js (TypeScript)
- **Framework**: [grammY](https://grammy.dev/)
- **ORM**: Prisma
- **Database**: SQLite (Default) / PostgreSQL
- **Scheduler**: node-cron

## 📦 Installation

1. **Clone the repository**:
   ```bash
   git clone <repo-url>
   cd poodl-telegram-bot
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Configure Environment**:
   Copy `.env.example` to `.env` and add your `BOT_TOKEN`.
   ```bash
   cp .env.example .env
   ```

4. **Initialize Database**:
   ```bash
   npx prisma migrate dev --name init
   ```

5. **Build & Start**:
   ```bash
   npm run build
   npm start
   ```

## 🧑‍💼 Admin Usage

1. Send `/start` to the bot.
2. The first user to interact with the bot becomes the **Super Admin**.
3. Use `/admin` to open the control panel.
4. Follow the guided flow to create and manage campaigns.

## 📁 Project Structure

- `src/bot`: Telegram-specific logic (handlers, conversations, middleware).
- `src/services`: Business logic (scheduler, renderer, database).
- `src/utils`: Reusable helpers (time formatting).
- `prisma`: Database schema and migrations.
