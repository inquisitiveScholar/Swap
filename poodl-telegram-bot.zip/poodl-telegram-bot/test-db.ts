import 'dotenv/config';
import { PrismaClient } from './src/generated/client/index.js';

console.log('Testing DB connection...');
console.log('DATABASE_URL:', process.env.DATABASE_URL);

const prisma = new PrismaClient({
  datasourceUrl: process.env.DATABASE_URL,
});

async function main() {
  try {
    const admins = await prisma.admin.findMany();
    console.log('Admins count:', admins.length);
  } catch (err) {
    console.error('Error during query:', err);
  } finally {
    await prisma.$disconnect();
  }
}

main();
