import Database from 'better-sqlite3';
import path from 'path';

const dbPath = path.resolve('prisma/dev.db');
console.log('Connecting to database at:', dbPath);

const db = new Database(dbPath);

try {
  console.log('Adding column mediaType...');
  db.prepare("ALTER TABLE Campaign ADD COLUMN mediaType TEXT NOT NULL DEFAULT 'TIMER'").run();
  console.log('Adding column imageFileId...');
  db.prepare("ALTER TABLE Campaign ADD COLUMN imageFileId TEXT").run();
  console.log('Database patched successfully!');
} catch (err) {
  if (err.message.includes('duplicate column name')) {
    console.log('Columns already exist, no patch needed.');
  } else {
    console.error('Error patching database:', err.message);
    process.exit(1);
  }
} finally {
  db.close();
}
