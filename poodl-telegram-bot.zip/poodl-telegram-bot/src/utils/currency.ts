/**
 * Normalize user-entered USD-like value (e.g. "$1,200.50") to plain numeric string.
 * Returns null for invalid numeric input.
 */
export function normalizeUsdInput(input: string): string | null {
  const cleaned = input.trim().replace(/\$/g, '').replace(/,/g, '').replace(/\s+/g, '');
  if (!cleaned) return null;
  if (!/^(?:\d+\.?\d*|\.\d+)$/.test(cleaned)) return null;

  const numeric = Number(cleaned);
  if (!Number.isFinite(numeric) || numeric < 0) return null;

  if (numeric === 0) return '0';
  const asFixed = numeric.toFixed(12);
  return asFixed.replace(/\.?0+$/, '');
}

/**
 * Token / coin supply: positive number, optional scientific notation for large amounts.
 */
export function normalizeSupplyInput(input: string): string | null {
  const cleaned = input.trim().replace(/,/g, '').replace(/\s+/g, '');
  if (!cleaned) return null;
  if (!/^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/.test(cleaned)) return null;

  const numeric = Number(cleaned);
  if (!Number.isFinite(numeric) || numeric < 0) return null;

  if (numeric === 0) return '0';
  const asFixed = numeric.toFixed(18);
  return asFixed.replace(/\.?0+$/, '');
}

/**
 * Market cap in USD from price (USD per token) × circulating supply (tokens).
 */
export function computeMarketCapUsd(priceNormalized: string, supplyNormalized: string): string | null {
  const p = Number(priceNormalized);
  const s = Number(supplyNormalized);
  if (!Number.isFinite(p) || !Number.isFinite(s) || p < 0 || s < 0) return null;
  const m = p * s;
  if (!Number.isFinite(m) || m < 0) return null;
  if (m === 0) return '0';
  return m.toFixed(12).replace(/\.?0+$/, '');
}

function formatUsdNumber(n: number): string {
  const abs = Math.abs(n);
  let maxFrac = 2;
  if (abs > 0 && abs < 1) maxFrac = abs < 0.0001 ? 8 : 6;
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: abs < 1 && abs > 0 ? 0 : 2,
    maximumFractionDigits: maxFrac,
  }).format(n);
}

function formatCompactNumber(n: number): string {
  return new Intl.NumberFormat('en-US', {
    notation: 'compact',
    compactDisplay: 'short',
    maximumFractionDigits: 2,
  }).format(n);
}

/**
 * Format normalized numeric string as USD with proper grouping (commas) and decimals.
 */
export function formatUsdDisplay(value: string | null | undefined): string | null {
  if (!value) return null;
  const normalized = normalizeUsdInput(value);
  if (!normalized) return null;
  const n = Number(normalized);
  if (!Number.isFinite(n)) return `$${normalized}`;
  return formatUsdNumber(n);
}

/**
 * Format normalized USD value using compact units (K/M/B/T).
 * Example: 125000 -> "$125K"
 */
export function formatUsdCompactDisplay(value: string | null | undefined): string | null {
  if (!value) return null;
  const normalized = normalizeUsdInput(value);
  if (!normalized) return null;
  const n = Number(normalized);
  if (!Number.isFinite(n)) return `$${normalized}`;
  if (Math.abs(n) < 1000) return formatUsdNumber(n);
  return `$${formatCompactNumber(n)}`;
}

/**
 * Format token supply for display (grouped, no currency symbol).
 */
export function formatSupplyDisplay(value: string | null | undefined): string | null {
  if (!value) return null;
  const n = normalizeSupplyInput(value);
  if (!n) return null;
  const num = Number(n);
  if (!Number.isFinite(num)) return null;
  return new Intl.NumberFormat('en-US', { maximumFractionDigits: 8 }).format(num);
}

/**
 * Format token supply using compact units (K/M/B/T).
 * Example: 1000000000 -> "1B"
 */
export function formatSupplyCompactDisplay(value: string | null | undefined): string | null {
  if (!value) return null;
  const n = normalizeSupplyInput(value);
  if (!n) return null;
  const num = Number(n);
  if (!Number.isFinite(num)) return null;
  if (Math.abs(num) < 1000) {
    return new Intl.NumberFormat('en-US', { maximumFractionDigits: 8 }).format(num);
  }
  return formatCompactNumber(num);
}

/** Prefer price × supply; otherwise legacy stored market cap. */
export function resolveMarketCapNormalized(campaign: {
  price: string | null;
  circulatingSupply: string | null;
  marketCap: string | null;
}): string | null {
  const p = campaign.price ? normalizeUsdInput(campaign.price) : null;
  const s = campaign.circulatingSupply ? normalizeSupplyInput(campaign.circulatingSupply) : null;
  if (p && s) {
    return computeMarketCapUsd(p, s);
  }
  if (campaign.marketCap) {
    return normalizeUsdInput(campaign.marketCap);
  }
  return null;
}
