import type { MessageEntity } from 'grammy/types';

export function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeAttr(s: string): string {
  return escapeHtml(s);
}

function plainSliceToHtml(text: string, from: number, to: number): string {
  // Telegram HTML does not support <br>; use real newlines in the string.
  return escapeHtml(text.slice(from, to));
}

function wrapEntity(e: MessageEntity, inner: string): string {
  switch (e.type) {
    case 'bold':
      return `<b>${inner}</b>`;
    case 'italic':
      return `<i>${inner}</i>`;
    case 'underline':
      return `<u>${inner}</u>`;
    case 'strikethrough':
      return `<s>${inner}</s>`;
    case 'code':
      return `<code>${inner}</code>`;
    case 'pre':
      return `<pre>${inner}</pre>`;
    case 'text_link':
      return `<a href="${escapeAttr((e as MessageEntity & { url?: string }).url || '')}">${inner}</a>`;
    case 'text_mention':
    case 'mention':
    case 'url':
    case 'hashtag':
    case 'cashtag':
    case 'bot_command':
    case 'phone_number':
    case 'email':
    case 'custom_emoji':
      return inner;
    case 'spoiler':
      return `<tg-spoiler>${inner}</tg-spoiler>`;
    case 'blockquote':
      return `<blockquote>${inner}</blockquote>`;
    default:
      return inner;
  }
}

/**
 * Build HTML for a slice [from, to) using entities that lie fully inside the range (excluding container).
 */
function buildHtmlSlice(text: string, all: MessageEntity[], from: number, to: number): string {
  const relevant = all.filter((e) => e.offset >= from && e.offset + e.length <= to);
  if (!relevant.length) {
    return plainSliceToHtml(text, from, to);
  }

  let pos = from;
  const parts: string[] = [];

  while (pos < to) {
    const candidates = relevant.filter((e) => e.offset >= pos && e.offset < to);
    if (!candidates.length) {
      parts.push(plainSliceToHtml(text, pos, to));
      break;
    }

    const nextStart = Math.min(...candidates.map((e) => e.offset));
    const atStart = candidates.filter((e) => e.offset === nextStart);
    const outer = atStart.reduce((a, b) => (a.length >= b.length ? a : b));

    if (outer.offset > pos) {
      parts.push(plainSliceToHtml(text, pos, outer.offset));
    }

    const innerFrom = outer.offset;
    const innerTo = outer.offset + outer.length;
    const innerEntities = relevant.filter(
      (e) => e !== outer && e.offset >= innerFrom && e.offset + e.length <= innerTo
    );

    const innerHtml =
      innerEntities.length === 0
        ? plainSliceToHtml(text, innerFrom, innerTo)
        : buildHtmlSlice(text, innerEntities, innerFrom, innerTo);

    parts.push(wrapEntity(outer, innerHtml));
    pos = innerTo;
  }

  return parts.join('');
}

/**
 * Convert Telegram message text + entities to HTML (Telegram Bot API HTML parse mode).
 */
export function entitiesToHtml(text: string, entities?: MessageEntity[]): string {
  if (!entities?.length) {
    return escapeHtml(text);
  }
  return buildHtmlSlice(text, entities, 0, text.length);
}

/**
 * Prefer formatted HTML when the user applied bold/italic/etc. in Telegram.
 */
export function messageTextToHtml(msg: { text?: string; entities?: MessageEntity[] } | undefined): string {
  if (!msg?.text) return '';
  return entitiesToHtml(msg.text, msg.entities);
}

/** Strip unsupported tags from older saved content (e.g. &lt;br/&gt; from a previous version). */
export function sanitizeTelegramHtml(s: string): string {
  return s.replace(/<br\s*\/?>/gi, '\n');
}

/**
 * Legacy DB text may be plain (no tags). New rows store HTML from messageTextToHtml.
 */
export function storedBodyToHtml(stored: string): string {
  if (!stored) return '';
  const t = stored.trim();
  if (!t) return '';
  // Already HTML from our pipeline or user paste with tags
  if (/<[a-z][\s\S]*>/i.test(t) && /<\/?(b|i|u|s|code|pre|a|tg-spoiler|blockquote)\b/i.test(t)) {
    return sanitizeTelegramHtml(stored);
  }
  return sanitizeTelegramHtml(escapeHtml(stored));
}

/**
 * First line of the post (heading): same rules as the body — Telegram HTML is kept;
 * plain text is escaped only (no forced bold or extra characters).
 */
export function headingLineHtml(stored: string | null | undefined): string {
  return storedBodyToHtml(stored ?? '');
}

/** Admin / logs: show stored HTML as plain text. */
export function stripHtmlTags(s: string): string {
  return s.replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
}
