import { DateTime, Duration } from 'luxon';

/** All calendar date + clock inputs without an explicit offset are interpreted as UK local time. */
export const UNLOCK_TIMEZONE = 'Europe/London';

/**
 * Pretty-print a stored unlock instant as seen in London (GMT/BST).
 */
export function formatUnlockDateLondon(date: Date): string {
  return DateTime.fromMillis(date.getTime())
    .setZone(UNLOCK_TIMEZONE)
    .toFormat("yyyy-MM-dd HH:mm 'London' (ZZZZ)");
}

/**
 * Formats a given duration in milliseconds to a human-readable countdown string.
 * Example: "02h 45m 12s"
 */
export function formatCountdown(ms: number): string {
  if (ms <= 0) return '00h 00m 00s';

  const duration = Duration.fromMillis(ms).shiftTo('hours', 'minutes', 'seconds');
  
  const h = Math.floor(duration.hours).toString().padStart(2, '0');
  const m = Math.floor(duration.minutes).toString().padStart(2, '0');
  const s = Math.floor(duration.seconds).toString().padStart(2, '0');

  return `${h}h ${m}m ${s}s`;
}

/**
 * Creates a visual progress bar using Unicode block characters.
 */
function buildProgressBar(progress: number, length: number = 12): string {
  const clamped = Math.max(0, Math.min(1, progress));
  const filled = Math.round(clamped * length);
  const empty = length - filled;
  
  return '▓'.repeat(filled) + '░'.repeat(empty);
}

/**
 * Clean, organized countdown display.
 * Each piece of info on its own line with emoji prefix (matching the reference style).
 */
export function formatLiveCountdown(ms: number, totalDurationMs?: number): string {
  if (ms <= 0) {
    return '🟢 *Status:* UNLOCKED\n🔥 *TRADING IS LIVE!*';
  }

  const duration = Duration.fromMillis(ms).shiftTo('days', 'hours', 'minutes', 'seconds');
  const days = Math.floor(duration.days);
  const hours = Math.floor(duration.hours);
  const minutes = Math.floor(duration.minutes);
  const seconds = Math.floor(duration.seconds);

  // Urgency color
  const totalMinutes = ms / 60000;
  let statusEmoji: string;
  let statusText: string;
  
  if (totalMinutes <= 5) {
    statusEmoji = '🔴';
    statusText = 'IMMINENT';
  } else if (totalMinutes <= 30) {
    statusEmoji = '🟠';
    statusText = 'SOON';
  } else if (totalMinutes <= 120) {
    statusEmoji = '🟡';
    statusText = 'UPCOMING';
  } else {
    statusEmoji = '🟢';
    statusText = 'SCHEDULED';
  }

  // Bold math unicode conversion for visual impact
  const toBoldD = (n: number) => {
    const map: any = { '0': '𝟬', '1': '𝟭', '2': '𝟮', '3': '𝟯', '4': '𝟰', '5': '𝟱', '6': '𝟲', '7': '𝟳', '8': '𝟴', '9': '𝟵' };
    return n.toString().padStart(2, '0').split('').map(c => map[c] || c).join('');
  };

  const dStr = toBoldD(days);
  const hStr = toBoldD(hours);
  const mStr = toBoldD(minutes);
  const sStr = toBoldD(seconds);

  const lines: string[] = [];
  lines.push(`*⏳ L I Q U I D I T Y  U N L O C K S  I N:*`);
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  if (days > 0) {
    lines.push(`   \`${dStr}\`  |  \`${hStr}\`  |  \`${mStr}\`  |  \`${sStr}\`   `);
    lines.push(` DAYS |  HRS | MINS | SECS `);
  } else {
    lines.push(`       \`${hStr}\`  |  \`${mStr}\`  |  \`${sStr}\`       `);
    lines.push(`       HRS  | MINS | SECS `);
  }
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  
  lines.push(`${statusEmoji} *Status:* ${statusText}`);

  // Progress bar
  if (totalDurationMs && totalDurationMs > 0) {
    const elapsed = totalDurationMs - ms;
    const progress = elapsed / totalDurationMs;
    const bar = buildProgressBar(progress);
    const pct = Math.min(100, Math.round(progress * 100));
    lines.push(`⏳ \`${bar}\` ${pct}%`);
  }

  return lines.join('\n');
}

/**
 * Compact inline countdown for minimal template.
 */
export function formatCompactCountdown(ms: number): string {
  if (ms <= 0) return '✅ `00:00:00` LIVE';

  const duration = Duration.fromMillis(ms).shiftTo('hours', 'minutes', 'seconds');
  const h = Math.floor(duration.hours).toString().padStart(2, '0');
  const m = Math.floor(duration.minutes).toString().padStart(2, '0');
  const s = Math.floor(duration.seconds).toString().padStart(2, '0');

  const totalMin = ms / 60000;
  const urgency = totalMin <= 5 ? '🔴' : totalMin <= 30 ? '🟠' : '🟢';

  return `${urgency} ⏱ \`${h}:${m}:${s}\``;
}

/**
 * Parses calendar date+time as wall clock in Europe/London (GMT/BST).
 */
function parseAbsoluteAsLondonWallClock(s: string): Date | null {
  const t = s.trim().replace(/\//g, '-').replace(/\s+/g, ' ');

  // Explicit UTC / offset in string — honour it
  if (/[zZ]$|[+-]\d{2}:?\d{2}$/.test(t)) {
    const iso = t.includes('T') ? t : t.replace(/^(\d{4}-\d{2}-\d{2})\s(\d)/, '$1T$2');
    const dt = DateTime.fromISO(iso, { setZone: true });
    if (dt.isValid) {
      return dt.toUTC().toJSDate();
    }
  }

  const formats = ['yyyy-MM-dd HH:mm:ss', 'yyyy-MM-dd HH:mm', 'yyyy-MM-dd H:mm', 'yyyy-MM-dd'];
  for (const fmt of formats) {
    const dt = DateTime.fromFormat(t, fmt, { zone: UNLOCK_TIMEZONE });
    if (dt.isValid) {
      return dt.toUTC().toJSDate();
    }
  }

  const isoish = t.includes('T') ? t : t.replace(/^(\d{4}-\d{2}-\d{2})\s+/, '$1T');
  const dt2 = DateTime.fromISO(isoish, { zone: UNLOCK_TIMEZONE });
  if (dt2.isValid) {
    return dt2.toUTC().toJSDate();
  }

  return null;
}

/**
 * Parses various date/time formats into an absolute instant (stored in DB as UTC).
 * - Relative phrases (`in 2 hours`, …) are from *now* on the server.
 * - Date+time **without** a `Z` or `±hh:mm` suffix is **Europe/London** wall time (UK, GMT/BST).
 */
export function parseTimeInput(input: string): Date | null {
  const normalized = input.trim();
  if (!normalized) {
    return null;
  }

  const inMinutesMatch = normalized.match(/in (\d+) min(?:ute)?s?/i);
  if (inMinutesMatch) {
    const min = parseInt(inMinutesMatch[1], 10);
    return new Date(Date.now() + min * 60000);
  }

  const inHoursMatch = normalized.match(/in (\d+) hour?s?/i);
  if (inHoursMatch) {
    const hour = parseInt(inHoursMatch[1], 10);
    return new Date(Date.now() + hour * 3600000);
  }

  const inDaysMatch = normalized.match(/in (\d+) day?s?/i);
  if (inDaysMatch) {
    const days = parseInt(inDaysMatch[1], 10);
    return new Date(Date.now() + days * 24 * 3600000);
  }

  const inWeeksMatch = normalized.match(/in (\d+) week?s?/i);
  if (inWeeksMatch) {
    const weeks = parseInt(inWeeksMatch[1], 10);
    return new Date(Date.now() + weeks * 7 * 24 * 3600000);
  }

  const inMonthsMatch = normalized.match(/in (\d+) month?s?/i);
  if (inMonthsMatch) {
    const months = parseInt(inMonthsMatch[1], 10);
    const date = new Date();
    date.setMonth(date.getMonth() + months);
    return date;
  }

  const london = parseAbsoluteAsLondonWallClock(normalized);
  if (london) {
    return london;
  }

  const fallback = new Date(normalized);
  return isNaN(fallback.getTime()) ? null : fallback;
}

/**
 * Unified “type yourself” parser for unlock UX:
 * - Whole number 1…3650 → that many days from now (not bare years like 2026).
 * - Anything else → {@link parseTimeInput} (London dates, relative phrases, UTC with Z).
 */
export function parseUnlockUserText(raw: string): Date | null {
  const t = raw.trim();
  if (!t) {
    return null;
  }
  if (/^\d+$/.test(t)) {
    const n = parseInt(t, 10);
    if (t.length === 4 && n >= 2000 && n <= 2100) {
      return null;
    }
    if (n >= 1 && n <= 3650) {
      return parseTimeInput(`in ${n} days`);
    }
    return null;
  }
  return parseTimeInput(t);
}

/** If bare year was sent instead of days or a full date. */
export function looksLikeBareYear(raw: string): boolean {
  const t = raw.trim();
  return /^\d{4}$/.test(t) && +t >= 2000 && +t <= 2100;
}
