/**
 * Normalize user-pasted URLs for link buttons (https added if missing).
 */
export function normalizeUserUrl(input: string): string | null {
  const s = input.trim();
  if (!s) return null;
  let candidate = s;
  if (!/^https?:\/\//i.test(candidate)) {
    candidate = 'https://' + candidate.replace(/^\/+/, '');
  }
  try {
    const u = new URL(candidate);
    if (!u.hostname.includes('.')) return null;
    return u.href;
  } catch {
    return null;
  }
}
