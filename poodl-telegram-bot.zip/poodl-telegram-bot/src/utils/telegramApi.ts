import { Context } from 'grammy';

type AnswerPayload = Parameters<Context['answerCallbackQuery']>[0];

function callbackQueryIsExpiredError(error: unknown): boolean {
  const err = error as {
    method?: unknown;
    description?: unknown;
    error?: { method?: unknown; description?: unknown };
  };

  const method = (err?.method ?? err?.error?.method) as string | undefined;
  const description = (err?.description ?? err?.error?.description) as string | undefined;
  if (method !== 'answerCallbackQuery') return false;
  if (!description) return false;

  const msg = description.toLowerCase();
  return msg.includes('query is too old') || msg.includes('query id is invalid');
}

/**
 * Answers callback queries without crashing on Telegram's expired query error.
 */
export async function safeAnswerCallbackQuery(
  ctx: Context,
  payload?: AnswerPayload
): Promise<void> {
  try {
    await ctx.answerCallbackQuery(payload as any);
  } catch (error) {
    if (callbackQueryIsExpiredError(error)) return;
    throw error;
  }
}
