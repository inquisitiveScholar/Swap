import { DateTime } from 'luxon';

/**
 * Unlock instant for countdown / mode switch.
 *
 * If `LIQUIDITY_UNLOCK_LONDON` is set (ISO local time in Europe/London, e.g. 2026-04-26T10:00:00),
 * that wall-clock moment is used so the timer matches London time regardless of server TZ.
 * Otherwise uses `campaign.unlockTime` from the database (UTC instant).
 */
export function getEffectiveUnlockDate(campaign: { unlockTime: Date }): Date {
  const raw = process.env.LIQUIDITY_UNLOCK_LONDON?.trim();
  if (raw) {
    const dt = DateTime.fromISO(raw, { zone: 'Europe/London' });
    if (dt.isValid) {
      return dt.toUTC().toJSDate();
    }
  }
  return new Date(campaign.unlockTime);
}
