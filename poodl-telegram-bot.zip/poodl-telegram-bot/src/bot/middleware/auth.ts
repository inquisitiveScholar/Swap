import { Context, NextFunction } from 'grammy';
import prisma from '../../database/client.js';

/**
 * Ensures only whitelisted admins can access the bot.
 */
export async function authMiddleware(ctx: Context, next: NextFunction): Promise<void> {
  const userId = ctx.from?.id;
  if (!userId) return;

  const envAdminId = process.env.ADMIN_ID;
  const isAdminInteraction = ctx.hasCommand('admin') || !!ctx.callbackQuery;

  // 1. Strict Check: If ADMIN_ID is in .env, only that ID is allowed for admin features.
  if (envAdminId) {
    if (userId.toString() !== envAdminId.trim()) {
      if (isAdminInteraction) {
        console.warn(`[SECURITY] Unauthorized admin access attempt from user: ${userId}`);
        await ctx.reply('⚠️ *Security Alert*\n\nYou are not authorized to access this panel. Your attempt has been logged.', { parse_mode: 'Markdown' });
        return;
      }
      // Non-admin interactions (like /start) for other users are still allowed to continue
      return next();
    }
    // Is the authenticated admin
    return next();
  }

  // 2. Safety Fallback: If no ADMIN_ID is set, block all admin interactions as a precaution.
  if (isAdminInteraction) {
    console.warn(`[SECURITY] Admin interaction attempted but ADMIN_ID is not configured in .env`);
    await ctx.reply('🚫 *System Configuration Error*\n\nAdmin ID is not configured. Access is temporarily restricted for security.', { parse_mode: 'Markdown' });
    return;
  }

  return next();
}
