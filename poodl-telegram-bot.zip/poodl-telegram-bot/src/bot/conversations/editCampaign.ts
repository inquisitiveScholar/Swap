import { InlineKeyboard } from 'grammy';
import { MyContext } from '../../index.js';
import prisma from '../../database/client.js';
import {
  formatUnlockDateLondon,
  looksLikeBareYear,
  parseTimeInput,
  parseUnlockUserText,
} from '../../utils/time.js';
import { UNLOCK_EDIT_INTRO, UNLOCK_TYPE_MYSELF_PROMPT } from '../../constants/unlockTimeUx.js';
import { showCampaignDetail } from '../admin.js';
import { normalizeUserUrl } from '../../utils/url.js';
import { messageTextToHtml } from '../../utils/telegramFormat.js';
import { announcementTextLengthHelpEdit } from '../../constants/telegramLimits.js';
import { safeAnswerCallbackQuery } from '../../utils/telegramApi.js';
import {
  computeMarketCapUsd,
  formatUsdDisplay,
  normalizeSupplyInput,
  normalizeUsdInput,
} from '../../utils/currency.js';
import { getCurrentPriceQuote, PriceProvider } from '../../services/livePrice.js';

const MAX_LINK_BUTTONS = 12;

function normalizeBscContract(raw: string): string | null {
  const t = raw.trim();
  if (!/^0x[a-fA-F0-9]{40}$/.test(t)) return null;
  return t.toLowerCase();
}

/**
 * Shows the edit menu for a specific campaign.
 * Embeds the campaign ID directly in callback data to avoid session issues.
 */
export async function showEditMenu(ctx: MyContext, campaignId: string) {
  await ctx.editMessageText('🔧 *Edit Campaign Settings*\n\nWhat would you like to update?', {
    parse_mode: 'Markdown',
    reply_markup: new InlineKeyboard()
      .text('✍️ Edit Text', `edit_field:text:${campaignId}`)
      .text('⏳ Edit Time', `edit_field:time:${campaignId}`)
      .row()
      .text('📰 Heading', `edit_field:headline:${campaignId}`)
      .text('🧬 Token Contract', `edit_field:token_contract:${campaignId}`)
      .row()
      .text('📡 Price Source', `edit_field:price_source:${campaignId}`)
      .row()
      .text('📊 Total Supply', `edit_field:supply:${campaignId}`)
      .text('💵 Current Price', `edit_field:price:${campaignId}`)
      .row()
      .text('🔄 Edit Interval', `edit_field:interval:${campaignId}`)
      .row()
      .text('🔗 Edit Links', `edit_field:links:${campaignId}`)
      .row()
      .text('🔙 Back', `manage_cam:${campaignId}`),
  });
}

/**
 * Handles the edit field selection — prompts the user for input.
 * Uses session state machine instead of conversations plugin to avoid replay bugs.
 */
export async function handleEditFieldSelection(ctx: MyContext, field: string, campaignId: string) {
  // Save editing state in session
  ctx.session.editingCampaignId = campaignId;
  ctx.session.editingField = field as any;
  ctx.session.awaitingEditInput = true;

  switch (field) {
    case 'text': {
      const campaign = await prisma.campaign.findUnique({ where: { id: campaignId } });
      const usesImageCaption =
        !!campaign &&
        (campaign.mediaType === 'IMAGE' || campaign.mediaType === 'IMAGE_ONLY') &&
        !!campaign.imageFileId;
      await ctx.editMessageText(
        '✍️ *Edit announcement text*\n\n' +
          'Send the new message below. **Bold**, _italic_, and other Telegram formatting are preserved when posted.' +
          announcementTextLengthHelpEdit(usesImageCaption),
        { parse_mode: 'Markdown' }
      );
      break;
    }

    case 'time':
      ctx.session.awaitingEditInput = false;
      await ctx.editMessageText(`⏳ *Unlock time*\n\n${UNLOCK_EDIT_INTRO}`, {
        parse_mode: 'Markdown',
        reply_markup: new InlineKeyboard()
          .text('1h', `set_time:1h:${campaignId}`)
          .text('1d', `set_time:1d:${campaignId}`)
          .text('3d', `set_time:3d:${campaignId}`)
          .row()
          .text('7d', `set_time:7d:${campaignId}`)
          .text('15d', `set_time:15d:${campaignId}`)
          .text('30d', `set_time:30d:${campaignId}`)
          .row()
          .text('1w', `set_time:1w:${campaignId}`)
          .text('1mo', `set_time:1m:${campaignId}`)
          .row()
          .text('✏️ Type myself', `edit_field:custom_time:${campaignId}`)
          .row()
          .text('🔙 Cancel', `edit_cam_menu:${campaignId}`),
      });
      break;

    case 'custom_time':
      ctx.session.awaitingEditInput = true;
      ctx.session.editingField = 'custom_time' as any;
      await ctx.editMessageText(UNLOCK_TYPE_MYSELF_PROMPT, {
        parse_mode: 'Markdown',
        reply_markup: new InlineKeyboard().text('🔙 Cancel', `edit_cam_menu:${campaignId}`),
      });
      break;

    case 'interval':
      // For interval, use inline buttons instead of text input
      ctx.session.awaitingEditInput = false;
      await ctx.editMessageText('🔄 *Edit Posting Interval*\n\nChoose a new frequency:', {
        parse_mode: 'Markdown',
        reply_markup: new InlineKeyboard()
          .text('1 Min', `set_interval:1:${campaignId}`)
          .text('5 Min', `set_interval:5:${campaignId}`)
          .text('15 Min', `set_interval:15:${campaignId}`)
          .row()
          .text('30 Min', `set_interval:30:${campaignId}`)
          .text('1 Hour', `set_interval:60:${campaignId}`)
          .row()
          .text('🔙 Cancel', `edit_cam_menu:${campaignId}`),
      });
      break;

    case 'headline':
      await ctx.editMessageText(
        '📰 *Edit heading*\n\n' +
          'Send the new heading. It is posted **as you type it** — **bold**, _italic_, links, and emoji stay as set.',
        { parse_mode: 'Markdown' }
      );
      break;

    case 'price':
      await ctx.editMessageText(
        '💵 *Edit current price (fallback)*\n\n' +
          'This is used if live fetch is unavailable.\n' +
          'Send USD price per token (examples: `0.0042`, `1.50`).\n\n' +
          'Send `skip` to clear it.',
        { parse_mode: 'Markdown' }
      );
      break;

    case 'supply':
      await ctx.editMessageText(
        '📊 *Edit total supply*\n\n' +
          'Send token amount (example: `1000000000`).\n\n' +
          'Send `skip` to clear it.',
        { parse_mode: 'Markdown' }
      );
      break;

    case 'token_contract':
      await ctx.editMessageText(
        '🧬 *Edit token contract (BSC)*\n\n' +
          'Send contract like `0xC70e8a2d156eAd8AE24EF13E887e75559688722B`.\n\n' +
          'After fetch, send `yes` to confirm detected price or `no` to retry.\n\n' +
          'Send `skip` to clear it.',
        { parse_mode: 'Markdown' }
      );
      break;

    case 'price_source': {
      const campaignForSource = await prisma.campaign.findUnique({ where: { id: campaignId } });
      const currentSource = (campaignForSource as any)?.priceSource || 'AUTO';
      await ctx.editMessageText(
        '📡 *Edit price source*\n\n' +
          `Current: \`${currentSource}\`\n\n` +
          'Send one value:\n' +
          '• `AUTO`\n' +
          '• `DEXSCREENER`\n' +
          '• `COINGECKO`',
        { parse_mode: 'Markdown' }
      );
      break;
    }

    case 'links':
      ctx.session.awaitingEditInput = false;
      ctx.session.editingField = undefined;
      ctx.session.linksEditCampaignId = campaignId;
      ctx.session.editingCampaignId = campaignId;
      await showLinksEditor(ctx, campaignId);
      break;

    default:
      await ctx.reply('❌ Unknown editing field.');
      break;
  }
}

/**
 * Processes text input when the user is in an editing state.
 * Called from the main bot's message handler.
 */
export async function processEditInput(ctx: MyContext): Promise<boolean> {
  if (!ctx.session.awaitingEditInput) return false;

  const campaignId = ctx.session.editingCampaignId;
  const field = ctx.session.editingField as string | undefined;
  const inputText = ctx.message?.text;

  if (!campaignId || !inputText) {
    await ctx.reply('❌ No campaign selected or empty input.');
    return true;
  }

  if (/^(?:\/cancel|cancel|back|\/admin)$/i.test(inputText.trim())) {
    ctx.session.awaitingEditInput = false;
    ctx.session.editingField = undefined;
    await ctx.reply('🛑 Edit cancelled.', {
      parse_mode: 'Markdown',
      reply_markup: new InlineKeyboard().text('🔧 Back to Edit Menu', `edit_cam_menu:${campaignId}`),
    });
    return true;
  }

  // Two-step "add link" flow (keep session between messages)
  if (field === 'links_label') {
    const label = inputText.trim();
    if (!label) {
      await ctx.reply('⚠️ Send a short label for the button.');
      return true;
    }
    if (label.length > 64) {
      await ctx.reply('⚠️ Use a shorter label (max ~64 characters).');
      return true;
    }
    ctx.session.linksDraftLabel = label;
    ctx.session.editingField = 'links_url';
    await ctx.reply(
      '🔗 *Link URL*\n\nPaste the full address (e.g. `https://dexscreener.com/...`).',
      { parse_mode: 'Markdown' }
    );
    return true;
  }

  if (field === 'links_url') {
    const label = ctx.session.linksDraftLabel;
    if (!label) {
      ctx.session.awaitingEditInput = false;
      ctx.session.editingField = undefined;
      ctx.session.editingCampaignId = undefined;
      await ctx.reply('❌ Session expired. Open *Edit Links* again.', { parse_mode: 'Markdown' });
      return true;
    }
    const url = normalizeUserUrl(inputText);
    if (!url) {
      await ctx.reply(
        '⚠️ Invalid URL. Send a full link like `https://…` or `example.com/path`.',
        { parse_mode: 'Markdown' }
      );
      return true;
    }
    const count = await prisma.link.count({ where: { campaignId } });
    if (count >= MAX_LINK_BUTTONS) {
      ctx.session.awaitingEditInput = false;
      ctx.session.editingField = undefined;
      ctx.session.editingCampaignId = undefined;
      ctx.session.linksDraftLabel = undefined;
      await ctx.reply(`ℹ️ Maximum ${MAX_LINK_BUTTONS} links. Remove one in *Edit Links* first.`, {
        parse_mode: 'Markdown',
      });
      return true;
    }
    await prisma.link.create({
      data: { campaignId, label, url },
    });
    ctx.session.linksDraftLabel = undefined;
    ctx.session.awaitingEditInput = false;
    ctx.session.editingField = undefined;
    ctx.session.editingCampaignId = undefined;
    await ctx.reply('✅ *Link added.*', { parse_mode: 'Markdown' });
    await showLinksEditorReply(ctx, campaignId);
    return true;
  }

  // Contract confirmation sub-flow
  if (field === 'token_contract_confirm') {
    const t = inputText.trim().toLowerCase();
    if (t === 'no') {
      ctx.session.editingField = 'token_contract' as any;
      await ctx.reply('🔁 Send another contract address.', { parse_mode: 'Markdown' });
      return true;
    }
    if (t !== 'yes') {
      await ctx.reply('Type `yes` to confirm, or `no` to re-enter contract.', {
        parse_mode: 'Markdown',
      });
      return true;
    }
    const draft = (ctx.session as any).tokenContractDraft as string | undefined;
    const draftPrice = (ctx.session as any).tokenContractDraftPrice as string | null | undefined;
    if (!draft) {
      ctx.session.awaitingEditInput = false;
      ctx.session.editingCampaignId = undefined;
      ctx.session.editingField = undefined;
      await ctx.reply('❌ Contract draft expired. Open edit again.');
      return true;
    }
    const campaign = await prisma.campaign.findUnique({ where: { id: campaignId } });
    const supplyNorm = normalizeSupplyInput(campaign?.circulatingSupply || '');
    const mcap = draftPrice && supplyNorm ? computeMarketCapUsd(draftPrice, supplyNorm) : null;
    await prisma.campaign.update({
      where: { id: campaignId },
      data: { tokenContract: draft, price: draftPrice || null, marketCap: mcap || null },
    });
    (ctx.session as any).tokenContractDraft = undefined;
    (ctx.session as any).tokenContractDraftPrice = undefined;
    ctx.session.awaitingEditInput = false;
    ctx.session.editingCampaignId = undefined;
    ctx.session.editingField = undefined;
    await ctx.reply('✅ *Token contract updated and live price confirmed.*', { parse_mode: 'Markdown' });
    await showCampaignDetail(ctx, campaignId);
    return true;
  }

  // Custom unlock: keep session on parse error so the user can retry immediately
  if (field === 'custom_time') {
    const newTime = parseUnlockUserText(inputText);
    if (!newTime) {
      if (looksLikeBareYear(inputText)) {
        await ctx.reply(
          '❌ Use a full date (`2026-04-26 10:00`) or days (`14`), not a year alone.',
          { parse_mode: 'Markdown' }
        );
      } else {
        await ctx.reply(
          '❌ Try: `14` (days), `2026-04-26 10:00` (London), or `in 2 hours`.',
          { parse_mode: 'Markdown' }
        );
      }
      return true;
    }
    ctx.session.awaitingEditInput = false;
    ctx.session.editingCampaignId = undefined;
    ctx.session.editingField = undefined;
    try {
      await prisma.campaign.update({
        where: { id: campaignId },
        data: { unlockTime: newTime },
      });
      await ctx.reply(
        `✅ *Unlock time updated!*\n_${formatUnlockDateLondon(newTime)}_`,
        { parse_mode: 'Markdown' }
      );
      await showCampaignDetail(ctx, campaignId);
    } catch (err) {
      console.error('Edit input processing error:', err);
      await ctx.reply('❌ An error occurred while updating the campaign.');
    }
    return true;
  }

  // Other fields: clear editing state before handling
  ctx.session.awaitingEditInput = false;
  ctx.session.editingCampaignId = undefined;
  ctx.session.editingField = undefined;

  try {
    switch (field) {
      case 'text':
        await prisma.campaign.update({
          where: { id: campaignId },
          data: { text: messageTextToHtml(ctx.message) },
        });
        await ctx.reply('✅ *Announcement text updated!*', { parse_mode: 'Markdown' });
        break;

      case 'headline':
        await prisma.campaign.update({
          where: { id: campaignId },
          data: { tokenName: messageTextToHtml(ctx.message) },
        });
        await ctx.reply('✅ *Heading updated!*', { parse_mode: 'Markdown' });
        break;

      case 'price': {
        const raw = inputText.trim();
        const clear = raw.toLowerCase() === 'skip';
        const parsed = clear ? null : normalizeUsdInput(raw);
        if (!clear && !parsed) {
          await ctx.reply('⚠️ Could not parse initial price. Use values like `0.0042` or `1.50`.', {
            parse_mode: 'Markdown',
          });
          return true;
        }
        await prisma.campaign.update({
          where: { id: campaignId },
          data: { price: parsed },
        });
        await ctx.reply(clear ? '✅ *Current price fallback cleared.*' : '✅ *Current price fallback updated!*', {
          parse_mode: 'Markdown',
        });
        break;
      }

      case 'supply': {
        const raw = inputText.trim();
        const clear = raw.toLowerCase() === 'skip';
        const parsed = clear ? null : normalizeSupplyInput(raw);
        if (!clear && !parsed) {
          await ctx.reply('⚠️ Could not parse total supply. Use values like `1000000000`.', {
            parse_mode: 'Markdown',
          });
          return true;
        }
        await prisma.campaign.update({
          where: { id: campaignId },
          data: { circulatingSupply: parsed },
        });
        await ctx.reply(clear ? '✅ *Total supply cleared.*' : '✅ *Total supply updated!*', {
          parse_mode: 'Markdown',
        });
        break;
      }

      case 'price_source': {
        const raw = inputText.trim().toUpperCase();
        if (!['AUTO', 'DEXSCREENER', 'COINGECKO'].includes(raw)) {
          await ctx.reply('⚠️ Send exactly: `AUTO`, `DEXSCREENER`, or `COINGECKO`.', {
            parse_mode: 'Markdown',
          });
          return true;
        }
        await prisma.campaign.update({
          where: { id: campaignId },
          data: { priceSource: raw },
        });
        await ctx.reply(`✅ *Price source set:* \`${raw}\``, { parse_mode: 'Markdown' });
        break;
      }

      case 'token_contract': {
        const raw = inputText.trim();
        if (raw.toLowerCase() === 'skip') {
          await prisma.campaign.update({
            where: { id: campaignId },
            data: { tokenContract: null },
          });
          await ctx.reply('✅ *Token contract cleared.*', { parse_mode: 'Markdown' });
          break;
        }
        const contract = normalizeBscContract(raw);
        if (!contract) {
          await ctx.reply('⚠️ Invalid contract format. Expected `0x` + 40 hex chars.', {
            parse_mode: 'Markdown',
          });
          return true;
        }
        const campaign = await prisma.campaign.findUnique({ where: { id: campaignId } });
        const provider = ((campaign?.priceSource || 'AUTO') as PriceProvider);
        const quote = await getCurrentPriceQuote(contract, 'bsc', provider);
        const livePrice = quote.price;
        if (!livePrice) {
          await ctx.reply(
            `⚠️ Could not fetch live price (${provider}). Send another contract or \`skip\`.\n` +
              `Debug: ${quote.trace.join(' | ') || 'no source returned a value'}`,
            { parse_mode: 'Markdown' }
          );
          return true;
        }
        (ctx.session as any).tokenContractDraft = contract;
        (ctx.session as any).tokenContractDraftPrice = livePrice;
        ctx.session.editingField = 'token_contract_confirm' as any;
        const priceDisp = formatUsdDisplay(livePrice) || `$${livePrice}`;
        const sourceUsed = quote.providerUsed || provider;
        const freshness = quote.fromStaleCache ? ' (cached fallback)' : '';
        await ctx.reply(
          `✅ Detected *Current Price:* ${priceDisp}\n` +
            `Source: \`${sourceUsed}\`${freshness}\n\n` +
            'Type `yes` to confirm or `no` to retry.',
          {
            parse_mode: 'Markdown',
          }
        );
        ctx.session.awaitingEditInput = true;
        ctx.session.editingCampaignId = campaignId;
        return true;
      }

      case 'mcap': {
        const raw = inputText.trim();
        const clear = raw.toLowerCase() === 'skip';
        const parsed = clear ? null : normalizeUsdInput(raw);
        if (!clear && !parsed) {
          await ctx.reply('⚠️ Could not parse market cap. Use values like `125000`.', {
            parse_mode: 'Markdown',
          });
          return true;
        }
        await prisma.campaign.update({
          where: { id: campaignId },
          data: { marketCap: parsed },
        });
        await ctx.reply(clear ? '✅ *Market cap cleared.*' : '✅ *Market cap updated!*', {
          parse_mode: 'Markdown',
        });
        break;
      }

      default:
        await ctx.reply('❌ Unknown field.');
        return true;
    }

    await showCampaignDetail(ctx, campaignId);
  } catch (err) {
    console.error('Edit input processing error:', err);
    await ctx.reply('❌ An error occurred while updating the campaign.');
  }

  return true;
}

/**
 * Handles interval selection via inline buttons.
 */
export async function handleIntervalUpdate(ctx: MyContext, interval: number, campaignId: string) {
  try {
    await prisma.campaign.update({
      where: { id: campaignId },
      data: { intervalMinutes: interval },
    });
    await safeAnswerCallbackQuery(ctx, `✅ Interval set to ${interval} min`);
    await showCampaignDetail(ctx, campaignId);
  } catch (err) {
    console.error('Interval update error:', err);
    await safeAnswerCallbackQuery(ctx, '❌ Failed to update interval');
  }
}

/**
 * Handles quick selection of unlock time preset offsets.
 */
const UNLOCK_PRESET_TO_OFFSET: Record<string, string> = {
  '1h': 'in 1 hour',
  '1d': 'in 1 day',
  '3d': 'in 3 days',
  '7d': 'in 7 days',
  '15d': 'in 15 days',
  '30d': 'in 30 days',
  '1w': 'in 1 week',
  '1m': 'in 1 month',
};

export async function handleTimeUpdatePreset(ctx: MyContext, preset: string, campaignId: string) {
  const offsetStr = UNLOCK_PRESET_TO_OFFSET[preset];
  if (!offsetStr) {
    await safeAnswerCallbackQuery(ctx, '❌ Unknown preset');
    return;
  }

  const newTime = parseTimeInput(offsetStr);
  if (!newTime) {
    await safeAnswerCallbackQuery(ctx, '❌ Error parsing time preset');
    return;
  }

  try {
    await prisma.campaign.update({
      where: { id: campaignId },
      data: { unlockTime: newTime },
    });
    await safeAnswerCallbackQuery(ctx, '✅ Updated');
    await showCampaignDetail(ctx, campaignId);
  } catch (err) {
    console.error('Time offset update error:', err);
    await safeAnswerCallbackQuery(ctx, '❌ Failed to update time');
  }
}

function truncateForButton(s: string, max: number): string {
  const t = s.trim();
  if (t.length <= max) return t;
  return t.slice(0, max - 1) + '…';
}

function buildLinksPanel(
  campaignId: string,
  links: { id: string; label: string; url: string }[]
): { text: string; reply_markup: InlineKeyboard } {
  let text = '🔗 Edit link buttons\n\n';
  if (links.length === 0) {
    text += 'No buttons yet. Tap ➕ Add button below.';
  } else {
    links.forEach((l, i) => {
      text += `${i + 1}. ${l.label}\n   ${l.url}\n\n`;
    });
    text = text.trimEnd();
  }
  const kb = new InlineKeyboard();
  links.forEach((l, i) => {
    kb.text(`🗑 ${truncateForButton(l.label, 28)}`, `link_del:${i}`).row();
  });
  if (links.length < MAX_LINK_BUTTONS) {
    kb.text('➕ Add button', `lnk_add:${campaignId}`).row();
  }
  kb.text('🔙 Back to edit menu', `edit_cam_menu:${campaignId}`);
  return { text, reply_markup: kb };
}

/**
 * Shows the links editor (uses editMessageText when opened from a callback).
 */
export async function showLinksEditor(ctx: MyContext, campaignId: string) {
  const campaign = await prisma.campaign.findUnique({
    where: { id: campaignId },
    include: { links: { orderBy: { id: 'asc' } } },
  });
  if (!campaign) {
    await ctx.reply('❌ Campaign not found.');
    return;
  }
  ctx.session.linksEditCampaignId = campaignId;
  const { text, reply_markup } = buildLinksPanel(campaignId, campaign.links);
  if (ctx.callbackQuery) {
    try {
      await ctx.editMessageText(text, { reply_markup });
    } catch (e: any) {
      if (!e.message?.includes('message is not modified')) throw e;
    }
  } else {
    await ctx.reply(text, { reply_markup });
  }
}

async function showLinksEditorReply(ctx: MyContext, campaignId: string) {
  const campaign = await prisma.campaign.findUnique({
    where: { id: campaignId },
    include: { links: { orderBy: { id: 'asc' } } },
  });
  if (!campaign) return;
  ctx.session.linksEditCampaignId = campaignId;
  const { text, reply_markup } = buildLinksPanel(campaignId, campaign.links);
  await ctx.reply(text, { reply_markup });
}

/**
 * Callback: Add button — start label → URL flow.
 */
export async function handleLinkAddStart(ctx: MyContext, campaignId: string) {
  const count = await prisma.link.count({ where: { campaignId } });
  if (count >= MAX_LINK_BUTTONS) {
    await ctx.reply(`ℹ️ Maximum ${MAX_LINK_BUTTONS} links. Remove one first.`);
    await showLinksEditorReply(ctx, campaignId);
    return;
  }
  ctx.session.editingCampaignId = campaignId;
  ctx.session.editingField = 'links_label';
  ctx.session.awaitingEditInput = true;
  ctx.session.linksDraftLabel = undefined;
  ctx.session.linksEditCampaignId = campaignId;
  await ctx.reply(
    '✏️ *New button — label*\n\nWhat should the button say? _(one short line)_',
    { parse_mode: 'Markdown' }
  );
}

/**
 * Callback: Remove link by list index (order matches editor).
 */
export async function handleLinkDeleteByIndex(ctx: MyContext, index: number) {
  const campaignId = ctx.session.linksEditCampaignId;
  if (!campaignId) {
    await safeAnswerCallbackQuery(ctx, {
      text: 'Open Edit Links again from the campaign menu.',
      show_alert: true,
    });
    return;
  }
  const campaign = await prisma.campaign.findUnique({
    where: { id: campaignId },
    include: { links: { orderBy: { id: 'asc' } } },
  });
  if (!campaign || index < 0 || index >= campaign.links.length) {
    await safeAnswerCallbackQuery(ctx, { text: 'Invalid link', show_alert: true });
    return;
  }
  const linkId = campaign.links[index].id;
  await prisma.link.delete({ where: { id: linkId } });
  await safeAnswerCallbackQuery(ctx, 'Removed');
  await showLinksEditor(ctx, campaignId);
}
