import { InlineKeyboard } from 'grammy';
import { MyContext } from '../index.js';
import prisma from '../database/client.js';
import { stripHtmlTags } from '../utils/telegramFormat.js';
import { safeAnswerCallbackQuery } from '../utils/telegramApi.js';

/**
 * Lists all campaigns with their current status.
 */
export async function listCampaigns(ctx: MyContext) {
  const campaigns = await prisma.campaign.findMany({
    orderBy: { createdAt: 'desc' },
  });

  if (campaigns.length === 0) {
    const text = '📂 *No Campaigns Found*\n\nYou haven\'t created any campaigns yet. Use the button below to start.';
    const keyboard = new InlineKeyboard()
      .text('➕ Create New', 'create_campaign')
      .row()
      .text('🔙 Back to Menu', 'admin_main');

    // Use reply if no callback query, otherwise editMessageText
    if (ctx.callbackQuery) {
      try {
        return await ctx.editMessageText(text, { parse_mode: 'Markdown', reply_markup: keyboard });
      } catch (e: any) {
        if (!e.message?.includes('message is not modified')) throw e;
        return;
      }
    }
    return ctx.reply(text, { parse_mode: 'Markdown', reply_markup: keyboard });
  }

  const keyboard = new InlineKeyboard();
  campaigns.forEach((c) => {
    const status = c.isActive ? '🟢' : '🔴';
    const label = c.tokenName
      ? stripHtmlTags(c.tokenName).slice(0, 24) + (stripHtmlTags(c.tokenName).length > 24 ? '…' : '')
      : 'Campaign';
    keyboard.text(`${status} ${label}`, `manage_cam:${c.id}`).row();
  });
  keyboard.row().text('🔄 Refresh List', 'list_campaigns').text('🔙 Back to Menu', 'admin_main');

  const text = '📂 *Campaign Manager*\n\nSelect a campaign below to manage its settings or toggle status.';

  if (ctx.callbackQuery) {
    try {
      await ctx.editMessageText(text, { parse_mode: 'Markdown', reply_markup: keyboard });
    } catch (e: any) {
      if (!e.message?.includes('message is not modified')) throw e;
    }
  } else {
    await ctx.reply(text, { parse_mode: 'Markdown', reply_markup: keyboard });
  }
}

/**
 * Shows details for a specific campaign.
 * Works from both callback queries (editMessageText) and text messages (reply).
 */
export async function showCampaignDetail(ctx: MyContext, campaignId: string) {
  const campaign = await prisma.campaign.findUnique({
    where: { id: campaignId },
    include: { links: true },
  });

  if (!campaign) {
    if (ctx.callbackQuery) {
      return safeAnswerCallbackQuery(ctx, '❌ Campaign not found.');
    }
    return ctx.reply('❌ Campaign not found.');
  }

  const status = campaign.isActive ? '🟢 Active' : '🔴 Paused';
  const headlinePreview = campaign.tokenName
    ? stripHtmlTags(campaign.tokenName).slice(0, 80) + (stripHtmlTags(campaign.tokenName).length > 80 ? '…' : '')
    : 'Not set';
  const text = `📊 *Campaign Details*\n\n` +
    `📰 *Heading:* ${headlinePreview}\n` +
    `📍 *Chat ID:* \`${campaign.chatId}\`\n` +
    `⏱ *Interval:* Every ${campaign.intervalMinutes}m\n` +
    `⚡ *Status:* ${status}\n\n` +
    `🔗 *Links:* ${campaign.links.length} total`;

  const keyboard = new InlineKeyboard()
    .text(campaign.isActive ? '⏸ Pause' : '▶️ Resume', `toggle_cam:${campaign.id}`)
    .text('🗑 Delete', `delete_cam:${campaign.id}`)
    .row()
    .text('🔧 Edit Settings', `edit_cam_menu:${campaign.id}`)
    .text('🔄 Refresh', `manage_cam:${campaign.id}`)
    .row()
    .text('🔙 Back to List', 'list_campaigns');

  // Use editMessageText for callback queries, reply for text messages
  if (ctx.callbackQuery) {
    try {
      await ctx.editMessageText(text, { parse_mode: 'Markdown', reply_markup: keyboard });
    } catch (e: any) {
      if (!e.message?.includes('message is not modified')) throw e;
    }
  } else {
    await ctx.reply(text, { parse_mode: 'Markdown', reply_markup: keyboard });
  }
}

/**
 * Shows the settings menu.
 */
export async function showSettings(ctx: MyContext) {
  const campaignCount = await prisma.campaign.count();
  const activeCount = await prisma.campaign.count({ where: { isActive: true } });

  const text = `⚙️ *Bot Settings & Stats*\n\n` +
    `👤 *Admin ID:* \`${process.env.ADMIN_ID}\`\n` +
    `📂 *Total Campaigns:* ${campaignCount}\n` +
    `🚀 *Active Now:* ${activeCount}\n\n` +
    `_More settings coming soon..._`;

  try {
    await ctx.editMessageText(text, {
      parse_mode: 'Markdown',
      reply_markup: new InlineKeyboard().text('🔙 Back to Menu', 'admin_main'),
    });
  } catch (e: any) {
    if (!e.message?.includes('message is not modified')) throw e;
  }
}
