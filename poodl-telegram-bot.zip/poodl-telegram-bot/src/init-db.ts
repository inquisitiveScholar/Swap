import Database from 'better-sqlite3';
import path from 'path';

const dbPath = path.resolve('d:/company-projects/poodl-telegram-bot/prisma/dev.db');
const db = new Database(dbPath);

console.log('Initializing Database at:', dbPath);

// 🆘 Manual Table Creation to bypass Prisma 7 CLI issues
db.exec(`
  CREATE TABLE IF NOT EXISTS "Admin" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" BIGINT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE UNIQUE INDEX IF NOT EXISTS "Admin_userId_key" ON "Admin"("userId");

  CREATE TABLE IF NOT EXISTS "Campaign" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "adminId" BIGINT NOT NULL,
    "chatId" BIGINT NOT NULL,
    "text" TEXT NOT NULL,
    "unlockTime" DATETIME NOT NULL,
    "intervalMinutes" INTEGER NOT NULL DEFAULT 5,
    "tokenName" TEXT,
    "tokenSymbol" TEXT,
    "tokenContract" TEXT,
    "priceSource" TEXT DEFAULT 'AUTO',
    "price" TEXT,
    "circulatingSupply" TEXT,
    "marketCap" TEXT,
    "mode" TEXT NOT NULL DEFAULT 'COUNTDOWN',
    "templateId" TEXT NOT NULL DEFAULT 'HYPE',
    "isActive" BOOLEAN NOT NULL DEFAULT 1,
    "messageId" BIGINT,
    "lastPostTime" DATETIME,
    "lastEditTime" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS "Link" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "campaignId" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    CONSTRAINT "Link_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES "Campaign" ("id") ON DELETE CASCADE ON UPDATE CASCADE
  );
`);

console.log('✅ Database Tables Initialized Successfully!');
db.close();
