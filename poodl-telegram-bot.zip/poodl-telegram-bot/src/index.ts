import 'dotenv/config';
import { Bot, Context, session, InlineKeyboard } from 'grammy';
import { conversations, createConversation, ConversationFlavor } from '@grammyjs/conversations';
import { hydrate, HydrateFlavor } from '@grammyjs/hydrate';
import { SessionFlavor } from 'grammy';
import pino from 'pino';

import { createCampaignConversation } from './bot/conversations/createCampaign.js';
import {
  showEditMenu,
  handleEditFieldSelection,
  processEditInput,
  handleIntervalUpdate,
  handleTimeUpdatePreset,
  handleLinkAddStart,
  handleLinkDeleteByIndex,
} from './bot/conversations/editCampaign.js';
import { authMiddleware } from './bot/middleware/auth.js';
import { startScheduler } from './services/scheduler.js';
import { listCampaigns, showCampaignDetail, showSettings } from './bot/admin.js';
import prisma from './database/client.js';
import { safeAnswerCallbackQuery } from './utils/telegramApi.js';

const logger = pino({
  transport: {
    target: 'pino-pretty',
  },
});

interface SessionData {
  editingCampaignId?: string;
  editingField?:
    | 'text'
    | 'time'
    | 'interval'
    | 'style'
    | 'custom_time'
    | 'headline'
    | 'token_contract'
    | 'token_contract_confirm'
    | 'price_source'
    | 'price'
    | 'supply'
    | 'mcap'
    | 'links_label'
    | 'links_url';
  awaitingEditInput?: boolean;
  /** Draft label while adding a link (step 1 of 2). */
  linksDraftLabel?: string;
  /** Campaign whose links are being edited (for delete-by-index callbacks). */
  linksEditCampaignId?: string;
  /** Draft contract awaiting yes/no confirmation. */
  tokenContractDraft?: string;
  tokenContractDraftPrice?: string | null;
}

export type MyContext = Context & HydrateFlavor<Context> & ConversationFlavor<Context> & SessionFlavor<SessionData>;
const bot = new Bot<MyContext>(process.env.BOT_TOKEN || '');

// Middleware
bot.use(hydrate());
bot.use(session({ initial: () => ({}) }));
bot.use(conversations());
bot.use(authMiddleware);

// Conversations (only for create — edit uses session state machine)
bot.use(createConversation(createCampaignConversation as any, 'create-campaign'));

// Commands
bot.command('start', (ctx) => ctx.reply('🚀 *Welcome to the Poodl Liquidity Bot!*\n\nThis bot helps you manage automated countdowns and ad campaigns for your pool.\n\nType /admin to get started.', { parse_mode: 'Markdown' }));

const ADMIN_MENU_TEXT = '🛡 *Poodl Administration*\n\nWelcome back, Commander. What would you like to do today?';
const ADMIN_MENU_KEYBOARD = new InlineKeyboard()
  .text('➕ Create New Campaign', 'create_campaign')
  .row()
  .text('📂 Manage Campaigns', 'list_campaigns')
  .text('⚙️ Settings', 'admin_settings');

bot.command('admin', async (ctx) => {
  await ctx.reply(ADMIN_MENU_TEXT, {
    parse_mode: 'Markdown',
    reply_markup: ADMIN_MENU_KEYBOARD,
  });
});

// Callbacks
bot.callbackQuery('admin_main', async (ctx) => {
  await safeAnswerCallbackQuery(ctx);
  await ctx.editMessageText(ADMIN_MENU_TEXT, {
    parse_mode: 'Markdown',
    reply_markup: ADMIN_MENU_KEYBOARD,
  });
});

bot.callbackQuery('create_campaign', async (ctx) => {
  await safeAnswerCallbackQuery(ctx);
  await ctx.conversation.enter('create-campaign');
});

bot.callbackQuery('list_campaigns', async (ctx) => {
  await safeAnswerCallbackQuery(ctx);
  await listCampaigns(ctx);
});

bot.callbackQuery('admin_settings', async (ctx) => {
  await safeAnswerCallbackQuery(ctx);
  await showSettings(ctx);
});

bot.callbackQuery(/^manage_cam:(.+)$/, async (ctx) => {
  const id = ctx.match[1];
  await safeAnswerCallbackQuery(ctx);
  ctx.session.linksEditCampaignId = undefined;
  await showCampaignDetail(ctx, id);
});

bot.callbackQuery(/^toggle_cam:(.+)$/, async (ctx) => {
  const id = ctx.match[1];
  const cam = await prisma.campaign.findUnique({ where: { id } });
  if (cam) {
    await prisma.campaign.update({
      where: { id },
      data: { isActive: !cam.isActive },
    });
    await safeAnswerCallbackQuery(ctx, `Status: ${!cam.isActive ? 'Active' : 'Paused'}`);
    await showCampaignDetail(ctx, id);
  }
});

bot.callbackQuery(/^toggle_ctg:(.+)$/, async (ctx) => {
  const id = ctx.match[1];
  const cam = await prisma.campaign.findUnique({ where: { id } });
  if (cam) {
    const current = (cam as any).hasCountdown !== false;
    await prisma.campaign.update({
      where: { id },
      data: { hasCountdown: !current } as any,
    });
    await safeAnswerCallbackQuery(ctx, `Countdown Image ${!current ? 'Enabled' : 'Disabled'}`);
    await showCampaignDetail(ctx, id);
  }
});

bot.callbackQuery(/^delete_cam:(.+)$/, async (ctx) => {
  const id = ctx.match[1];
  await prisma.campaign.delete({ where: { id } });
  await safeAnswerCallbackQuery(ctx, 'Successfully Deleted');
  await listCampaigns(ctx);
});

// --- Edit Campaign Handlers (session state machine, no conversations) ---

bot.callbackQuery(/^edit_cam_menu:(.+)$/, async (ctx) => {
  const id = ctx.match[1];
  await safeAnswerCallbackQuery(ctx);
  ctx.session.linksEditCampaignId = undefined;
  await showEditMenu(ctx, id);
});

bot.callbackQuery(/^lnk_add:(.+)$/, async (ctx) => {
  const campaignId = ctx.match[1];
  await safeAnswerCallbackQuery(ctx);
  await handleLinkAddStart(ctx, campaignId);
});

bot.callbackQuery(/^link_del:(\d+)$/, async (ctx) => {
  const index = parseInt(ctx.match[1], 10);
  await handleLinkDeleteByIndex(ctx, index);
});

bot.callbackQuery(/^edit_field:(\w+):(.+)$/, async (ctx) => {
  const field = ctx.match[1];
  const campaignId = ctx.match[2];
  await safeAnswerCallbackQuery(ctx);
  await handleEditFieldSelection(ctx, field, campaignId);
});

bot.callbackQuery(/^set_interval:(\d+):(.+)$/, async (ctx) => {
  const interval = parseInt(ctx.match[1]);
  const campaignId = ctx.match[2];
  await handleIntervalUpdate(ctx, interval, campaignId);
});

bot.callbackQuery(/^set_time:(.+?):(.+)$/, async (ctx) => {
  const preset = ctx.match[1];
  const campaignId = ctx.match[2];
  await safeAnswerCallbackQuery(ctx);
  await handleTimeUpdatePreset(ctx, preset, campaignId);
});

// --- Text input handler for edit state machine ---
bot.on('message:text', async (ctx, next) => {
  // Check if user is in editing mode
  const handled = await processEditInput(ctx);
  if (!handled) {
    await next();
  }
});

bot.catch((err) => {
  logger.error(
    {
      updateId: err.ctx?.update?.update_id,
      error: err.error,
    },
    'Unhandled bot middleware error'
  );
});

// Start bot
async function main() {
  logger.info('Starting bot...');

  try {
    await bot.start({
      onStart: (info) => {
        logger.info(`Bot @${info.username} is running!`);
        // Start scheduler only on the instance that successfully acquired polling.
        startScheduler(bot as any);
      },
    });
  } catch (err: any) {
    const message = String(err?.description || err?.message || '');
    const is409 = err?.error_code === 409 || message.includes('terminated by other getUpdates request');
    if (is409) {
      logger.error(
        'Bot polling conflict (409): another instance is already running with this BOT_TOKEN. Stop the other instance first.'
      );
      return;
    }
    throw err;
  }
}

main().catch((err) => {
  logger.error(err, 'Fatal error');
  process.exit(1);
});
