/** Telegram Bot API: max length for photo/video document captions. */
export const TELEGRAM_CAPTION_MAX_CHARS = 1024;
/** Telegram Bot API: max length for sendMessage text. */
export const TELEGRAM_MESSAGE_MAX_CHARS = 4096;

/**
 * Shown when the user hasn't chosen image vs text yet (create flow).
 * Markdown parse_mode — explains totals include heading + body + status.
 */
export const ANNOUNCEMENT_TEXT_LENGTH_HELP_CREATE =
  '\n\n' +
  '📏 *Length (Telegram):*\n' +
  `• *With a photo:* the full caption (heading + body + optional stats) is at most *${TELEGRAM_CAPTION_MAX_CHARS}* characters.\n` +
  `• *Text only (no image):* the full post may be up to *${TELEGRAM_MESSAGE_MAX_CHARS}* characters total.\n` +
  '_Anything beyond that is trimmed when posted._';

/**
 * Edit flow — campaign already has media settings.
 */
export function announcementTextLengthHelpEdit(usesImageCaption: boolean): string {
  if (usesImageCaption) {
    return (
      '\n\n' +
      '📏 *Limit:* This campaign is sent *with an image*. Telegram allows at most ' +
      `*${TELEGRAM_CAPTION_MAX_CHARS}* characters for the *entire* caption (heading + body + stats). ` +
      'Longer content is trimmed when posted.'
    );
  }
  return (
    '\n\n' +
    '📏 *Limit:* Text-only posts may be up to ' +
    `*${TELEGRAM_MESSAGE_MAX_CHARS}* characters *in total* (heading + body + stats). ` +
    'Longer content is trimmed when posted.'
  );
}
