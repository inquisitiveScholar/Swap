/**
 * Short, consistent copy for unlock time (create + edit). Keep under ~2–3 screenfuls on mobile.
 */

export const UNLOCK_CREATE_INTRO =
  'Choose how long from *now*, or tap *Type myself* if you already know the date/time.';

/** Shown after user taps “Type myself” (create or edit). */
export const UNLOCK_TYPE_MYSELF_PROMPT =
  '✏️ *Your unlock time*\n\n' +
  'Send *one* message:\n\n' +
  '• `14` → 14 days from now\n' +
  '• `2026-04-26 10:00` → that moment in *London* (UK time)\n' +
  '• `in 2 hours` or `in 5 days` → from now\n\n' +
  '_Add `Z` for UTC instead of London (e.g. `2026-04-26T09:00:00Z`)._';

export const UNLOCK_EDIT_INTRO =
  'Quick taps count from *now*. *Type myself* = days, London date/time, or e.g. `in 2 hours`.';
