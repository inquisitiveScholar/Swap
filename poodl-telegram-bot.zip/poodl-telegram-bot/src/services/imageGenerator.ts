import satori from 'satori';
import { html } from 'satori-html';
import { Resvg } from '@resvg/resvg-js';
import { Duration } from 'luxon';
import { Api } from 'grammy';
import { readFile } from 'node:fs/promises';

let fontData: Buffer | null = null;

async function fetchWithRetry(url: string, retries = 3): Promise<Response> {
  let lastErr;
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetch(url);
      if (res.ok) return res;
      throw new Error(`HTTP error ${res.status}`);
    } catch (e: any) {
      lastErr = e;
      await new Promise(r => setTimeout(r, 1000 * (i + 1)));
    }
  }
  throw lastErr;
}

const LOCAL_FONT_PATHS = [
  // Windows common fonts
  'C:/Windows/Fonts/arialbd.ttf',
  'C:/Windows/Fonts/arial.ttf',
  // Linux common fonts
  '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
  '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
  // macOS common fonts
  '/System/Library/Fonts/Supplemental/Arial Bold.ttf',
  '/System/Library/Fonts/Supplemental/Arial.ttf',
];

const REMOTE_FONT_URLS = [
  'https://raw.githubusercontent.com/googlefonts/roboto/main/src/hinted/Roboto-Bold.ttf',
  'https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfBBc4.ttf',
];

async function tryLoadLocalFont(): Promise<Buffer | null> {
  for (const fontPath of LOCAL_FONT_PATHS) {
    try {
      const data = await readFile(fontPath);
      console.log(`Loaded local font: ${fontPath}`);
      return data;
    } catch {
      // Try next candidate path.
    }
  }
  return null;
}

async function tryLoadRemoteFont(): Promise<Buffer | null> {
  for (const url of REMOTE_FONT_URLS) {
    try {
      console.log(`Downloading font from: ${url}`);
      const res = await fetchWithRetry(url);
      const buffer = await res.arrayBuffer();
      return Buffer.from(buffer);
    } catch (err: any) {
      console.warn(`Font download failed from ${url}: ${err?.message || err}`);
    }
  }
  return null;
}

async function getFontData() {
  if (fontData) return fontData;

  const localFont = await tryLoadLocalFont();
  if (localFont) {
    fontData = localFont;
    return fontData;
  }

  const remoteFont = await tryLoadRemoteFont();
  if (remoteFont) {
    fontData = remoteFont;
    return fontData;
  }

  throw new Error('Unable to load any usable TTF font (local and remote sources failed).');
}

export async function generateCountdownImageBuffer(timeRemainingMs: number): Promise<Buffer> {
  const font = await getFontData();
  
  if (timeRemainingMs <= 0) {
    const markupLive = html`
      <div style="display: flex; width: 100%; height: 100%; flex-direction: column; align-items: center; justify-content: center; background-color: #0a0a0a; font-family: 'Roboto'; padding: 40px; color: white;">
        <div style="display: flex; font-size: 72px; font-weight: bold; color: #00ff7f; margin-bottom: 20px;">
           🟢 UNLOCKED!
        </div>
        <div style="display: flex; font-size: 48px; color: #ffffff;">
           LIQUIDITY HAS BEEN BURNED
        </div>
      </div>
    `;
    const svgLive = await satori(markupLive as any, { width: 1200, height: 400, fonts: [{ name: 'Roboto', data: font, weight: 700 }] });
    return new Resvg(svgLive, { fitTo: { mode: 'width', value: 1200 } }).render().asPng();
  }

  const duration = Duration.fromMillis(timeRemainingMs).shiftTo('days', 'hours', 'minutes', 'seconds');
  const d = Math.floor(duration.days).toString().padStart(2, '0');
  const h = Math.floor(duration.hours).toString().padStart(2, '0');
  const m = Math.floor(duration.minutes).toString().padStart(2, '0');
  const s = Math.floor(duration.seconds).toString().padStart(2, '0');

  const markup = html`
    <div style="display: flex; width: 100%; height: 100%; flex-direction: column; align-items: center; justify-content: center; background: radial-gradient(circle at 14% 12%, rgba(109, 92, 255, 0.92) 0%, rgba(109, 92, 255, 0) 38%), radial-gradient(circle at 86% 16%, rgba(255, 72, 58, 0.9) 0%, rgba(255, 72, 58, 0) 38%), radial-gradient(circle at 18% 82%, rgba(67, 244, 208, 0.92) 0%, rgba(67, 244, 208, 0) 40%), radial-gradient(circle at 86% 84%, rgba(255, 226, 76, 0.92) 0%, rgba(255, 226, 76, 0) 42%), linear-gradient(145deg, #6670ff 0%, #49e0d4 42%, #ffd95b 74%, #ff7c3a 100%); font-family: 'Roboto'; padding: 50px; color: white;">
      
      <div style="display: flex; align-items: center; font-size: 48px; font-weight: bold; color: #ffffff; letter-spacing: 4px; margin-bottom: 60px; text-shadow: 0 4px 18px rgba(0, 0, 0, 0.5);">
         LIQUIDITY UNLOCKS IN
      </div>
      
      <div style="display: flex; justify-content: center; align-items: center;">
         <!-- Days -->
         <div style="display: flex; flex-direction: column; align-items: center; background-color: rgba(8, 12, 28, 0.78); border-radius: 20px; padding: 30px 40px; border: 3px solid rgba(255, 255, 255, 0.45); box-shadow: 0 8px 30px rgba(0, 0, 0, 0.35);">
           <div style="font-size: 96px; font-weight: bold; line-height: 1;">${d}</div>
           <div style="font-size: 26px; color: #e8efff; letter-spacing: 6px; margin-top: 15px;">DAYS</div>
         </div>
         <div style="display: flex; font-size: 96px; font-weight: bold; color: #ffffff; margin: 0 25px; margin-top: -30px; text-shadow: 0 4px 14px rgba(0, 0, 0, 0.45);">:</div>

         <!-- Hours -->
         <div style="display: flex; flex-direction: column; align-items: center; background-color: rgba(8, 12, 28, 0.78); border-radius: 20px; padding: 30px 40px; border: 3px solid rgba(255, 255, 255, 0.45); box-shadow: 0 8px 30px rgba(0, 0, 0, 0.35);">
           <div style="font-size: 96px; font-weight: bold; line-height: 1;">${h}</div>
           <div style="font-size: 26px; color: #e8efff; letter-spacing: 6px; margin-top: 15px;">HRS</div>
         </div>
         <div style="display: flex; font-size: 96px; font-weight: bold; color: #ffffff; margin: 0 25px; margin-top: -30px; text-shadow: 0 4px 14px rgba(0, 0, 0, 0.45);">:</div>

         <!-- Minutes -->
         <div style="display: flex; flex-direction: column; align-items: center; background-color: rgba(8, 12, 28, 0.78); border-radius: 20px; padding: 30px 40px; border: 3px solid rgba(255, 255, 255, 0.45); box-shadow: 0 8px 30px rgba(0, 0, 0, 0.35);">
           <div style="font-size: 96px; font-weight: bold; line-height: 1;">${m}</div>
           <div style="font-size: 26px; color: #e8efff; letter-spacing: 6px; margin-top: 15px;">MIN</div>
         </div>
         <div style="display: flex; font-size: 96px; font-weight: bold; color: #ffffff; margin: 0 25px; margin-top: -30px; text-shadow: 0 4px 14px rgba(0, 0, 0, 0.45);">:</div>

         <!-- Seconds -->
         <div style="display: flex; flex-direction: column; align-items: center; background-color: rgba(8, 12, 28, 0.78); border-radius: 20px; padding: 30px 40px; border: 3px solid rgba(255, 255, 255, 0.45); box-shadow: 0 8px 30px rgba(0, 0, 0, 0.35);">
           <div style="font-size: 96px; font-weight: bold; line-height: 1;">${s}</div>
           <div style="font-size: 26px; color: #e8efff; letter-spacing: 6px; margin-top: 15px;">SEC</div>
         </div>
      </div>

    </div>
  `;

  const svg = await satori(markup as any, {
    width: 1200,
    height: 600,
    fonts: [
      {
        name: 'Roboto',
        data: font,
        weight: 700,
        style: 'normal',
      },
    ],
  });

  const resvg = new Resvg(svg, {
    fitTo: { mode: 'width', value: 1200 },
  });

  const image = resvg.render();
  return image.asPng();
}
