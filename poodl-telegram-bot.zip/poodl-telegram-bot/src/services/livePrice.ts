import { normalizeUsdInput } from '../utils/currency.js';
import pino from 'pino';

type DexScreenerPair = {
  chainId?: string;
  dexId?: string;
  priceUsd?: string;
  liquidity?: { usd?: number };
};

type DexScreenerResponse = {
  pairs?: DexScreenerPair[];
};

type CoinGeckoTokenPriceResponse = {
  [contract: string]: {
    usd?: number;
  };
};

const DEFAULT_CHAIN = (process.env.PRICE_CHAIN || 'bsc').toLowerCase();
const PRICE_DEX_HINT = (process.env.PRICE_DEX_HINT || 'pancakeswap').toLowerCase();
const CACHE_TTL_MS = Number(process.env.PRICE_CACHE_TTL_MS || 30000);
const STALE_CACHE_MAX_AGE_MS = Number(process.env.STALE_CACHE_MAX_AGE_MS || 15 * 60 * 1000);
const REQUEST_TIMEOUT_MS = Number(process.env.REQUEST_TIMEOUT_MS || 8000);
const FETCH_RETRIES = Number(process.env.FETCH_RETRIES || 2);
const RETRY_BASE_DELAY_MS = Number(process.env.RETRY_BASE_DELAY_MS || 500);
const logger = pino();

export type PriceProvider = 'AUTO' | 'DEXSCREENER' | 'COINGECKO';

type PriceQuote = {
  price: string | null;
  providerUsed: Exclude<PriceProvider, 'AUTO'> | null;
  trace: string[];
  fromStaleCache?: boolean;
};

const cache = new Map<string, { fetchedAt: number; quote: PriceQuote }>();

function pickBestPair(pairs: DexScreenerPair[], chain: string): DexScreenerPair | null {
  const inChain = pairs.filter((p) => (p.chainId || '').toLowerCase() === chain);
  if (!inChain.length) return null;

  const withDexHint = inChain.filter((p) =>
    (p.dexId || '').toLowerCase().includes(PRICE_DEX_HINT)
  );
  const source = withDexHint.length ? withDexHint : inChain;

  source.sort((a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0));
  return source[0] || null;
}

function mapChainToCoinGeckoPlatform(chain: string): string | null {
  const c = chain.toLowerCase();
  if (c === 'bsc' || c === 'bnb' || c === 'binance-smart-chain') return 'binance-smart-chain';
  if (c === 'eth' || c === 'ethereum') return 'ethereum';
  if (c === 'polygon' || c === 'matic') return 'polygon-pos';
  if (c === 'arbitrum' || c === 'arbitrum-one') return 'arbitrum-one';
  if (c === 'base') return 'base';
  return null;
}

async function fetchJson<T>(url: string): Promise<T | null> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        accept: 'application/json',
        'user-agent': 'poodl-telegram-bot/1.0',
      },
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function fetchWithRetry<T>(url: string): Promise<T | null> {
  for (let attempt = 0; attempt <= FETCH_RETRIES; attempt++) {
    const data = await fetchJson<T>(url);
    if (data) return data;
    if (attempt < FETCH_RETRIES) {
      await sleep(RETRY_BASE_DELAY_MS * (attempt + 1));
    }
  }
  return null;
}

async function fetchFromDexScreener(addr: string, chain: string): Promise<string | null> {
  const url = `https://api.dexscreener.com/latest/dex/tokens/${addr}`;
  const data = await fetchWithRetry<DexScreenerResponse>(url);
  if (!data) return null;
  const pairs = Array.isArray(data.pairs) ? data.pairs : [];
  const best = pickBestPair(pairs, chain);
  return best?.priceUsd ? normalizeUsdInput(best.priceUsd) : null;
}

async function fetchFromCoinGecko(addr: string, chain: string): Promise<string | null> {
  const platform = mapChainToCoinGeckoPlatform(chain);
  if (!platform) return null;
  const url =
    `https://api.coingecko.com/api/v3/simple/token_price/${platform}` +
    `?contract_addresses=${encodeURIComponent(addr)}` +
    '&vs_currencies=usd';
  const data = await fetchWithRetry<CoinGeckoTokenPriceResponse>(url);
  if (!data) return null;
  const row = data[addr.toLowerCase()];
  if (!row || row.usd == null) return null;
  return normalizeUsdInput(String(row.usd));
}

function providerOrder(provider: PriceProvider): Exclude<PriceProvider, 'AUTO'>[] {
  if (provider === 'DEXSCREENER') return ['DEXSCREENER'];
  if (provider === 'COINGECKO') return ['COINGECKO'];
  return ['DEXSCREENER', 'COINGECKO'];
}

/**
 * Live current token price in USD for a token contract.
 * Uses DexScreener first, then CoinGecko fallback.
 */
export async function getCurrentPriceQuote(
  tokenAddress: string | null | undefined,
  chain: string = DEFAULT_CHAIN,
  provider: PriceProvider = 'AUTO'
): Promise<PriceQuote> {
  const addr = (tokenAddress || '').trim().toLowerCase();
  if (!addr) {
    return { price: null, providerUsed: null, trace: ['missing token address'] };
  }
  const chainNorm = (chain || DEFAULT_CHAIN).trim().toLowerCase();
  const cacheKey = `${chainNorm}:${provider}:${addr}`;

  const now = Date.now();
  const cached = cache.get(cacheKey);
  if (cached?.quote.price && now - cached.fetchedAt < CACHE_TTL_MS) {
    return cached.quote;
  }

  const trace: string[] = [];
  for (const source of providerOrder(provider)) {
    try {
      const price =
        source === 'DEXSCREENER'
          ? await fetchFromDexScreener(addr, chainNorm)
          : await fetchFromCoinGecko(addr, chainNorm);
      if (price) {
        const quote: PriceQuote = { price, providerUsed: source, trace };
        cache.set(cacheKey, { fetchedAt: now, quote });
        logger.info(
          { tokenAddress: addr, chain: chainNorm, providerRequested: provider, providerUsed: source, price },
          'Live price fetched'
        );
        return quote;
      }
      trace.push(`${source}: no price`);
      logger.warn(
        { tokenAddress: addr, chain: chainNorm, providerRequested: provider, source },
        'Live price source returned no value'
      );
    } catch (e: any) {
      trace.push(`${source}: ${e?.message || 'error'}`);
      logger.warn(
        { tokenAddress: addr, chain: chainNorm, providerRequested: provider, source, err: e?.message || String(e) },
        'Live price source failed'
      );
    }
  }

  const quote: PriceQuote = { price: null, providerUsed: null, trace };
  if (cached?.quote.price && now - cached.fetchedAt < STALE_CACHE_MAX_AGE_MS) {
    const staleQuote: PriceQuote = {
      price: cached.quote.price,
      providerUsed: cached.quote.providerUsed,
      fromStaleCache: true,
      trace: [...trace, 'using stale cached quote'],
    };
    cache.set(cacheKey, { fetchedAt: now, quote: staleQuote });
    logger.warn(
      {
        tokenAddress: addr,
        chain: chainNorm,
        providerRequested: provider,
        providerUsed: staleQuote.providerUsed,
        price: staleQuote.price,
      },
      'Live price fetch failed, using stale cached quote'
    );
    return staleQuote;
  }
  cache.set(cacheKey, { fetchedAt: now, quote });
  return quote;
}

export async function getCurrentPriceUsdNormalized(
  tokenAddress: string | null | undefined,
  chain: string = DEFAULT_CHAIN,
  provider: PriceProvider = 'AUTO'
): Promise<string | null> {
  const quote = await getCurrentPriceQuote(tokenAddress, chain, provider);
  return quote.price;
}
