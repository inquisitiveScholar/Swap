import cron from 'node-cron';
import { Bot, Context, InputFile } from 'grammy';
import prisma from '../database/client.js';
import { renderCampaign } from './renderer.js';
import { generateCountdownImageBuffer } from './imageGenerator.js';
import { getEffectiveUnlockDate } from '../utils/effectiveUnlock.js';
import { getCurrentPriceUsdNormalized } from './livePrice.js';
import pino from 'pino';

const logger = pino({
  transport: { target: 'pino-pretty' },
});

// In-memory store for countdown widget message IDs (no DB schema changes needed)
const countdownMsgIds = new Map<string, number>();

/** Prevents two cron ticks from running at once (would interleave sends again). */
let schedulerTickInProgress = false;

/**
 * Starts the global scheduler that checks for active campaigns every minute.
 */
export function startScheduler(bot: Bot) {
  cron.schedule('* * * * *', async () => {
    if (schedulerTickInProgress) {
      logger.warn('Scheduler tick skipped: previous tick still in progress');
      return;
    }
    schedulerTickInProgress = true;
    logger.info('Scheduler heartbeat: Checking campaigns...');
    try {
      const activeCampaigns = await prisma.campaign.findMany({
        where: { isActive: true },
        include: { links: true },
      });

      logger.info(`Found ${activeCampaigns.length} active campaign(s).`);

      // Strict ordering: finish announcement + countdown (all sends) for one campaign before any other.
      // Parallel ticks or parallel chats both caused interleaved Telegram messages in the same group.
      activeCampaigns.sort((a, b) => {
        const ca = String(a.chatId);
        const cb = String(b.chatId);
        if (ca !== cb) return ca.localeCompare(cb);
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      });

      for (const c of activeCampaigns) {
        await processCampaign(c, bot);
      }
    } catch (err) {
      logger.error(err, 'Scheduler critical sync error');
    } finally {
      schedulerTickInProgress = false;
    }
  });
}

/**
 * Dual-message strategy:
 *  Message 1 — Announcement photo/text (no buttons)
 *  Message 2 — Dynamic SVG countdown widget (with inline buttons)
 * Both old messages are deleted before reposting.
 */
async function processCampaign(campaign: any, bot: Bot) {
  const now = new Date();
  const lastPostTime = campaign.lastPostTime ? new Date(campaign.lastPostTime) : null;
  const intervalMs = campaign.intervalMinutes * 60 * 1000;
  const gracePeriodMs = 10000;

  // 1. Check if it's time to post
  if (lastPostTime && (now.getTime() - lastPostTime.getTime() + gracePeriodMs) < intervalMs) {
    return;
  }

  // 2. Determine Mode Switch (unlock instant: DB or LIQUIDITY_UNLOCK_LONDON in Europe/London)
  const unlockDate = getEffectiveUnlockDate(campaign);
  let mode = campaign.mode;
  if (now >= unlockDate && campaign.mode === 'COUNTDOWN') {
    mode = 'ADVERTISEMENT';
    logger.info(`Campaign ${campaign.id} switched to AD mode!`);
  }

  // 3. Render the updated message text + keyboard
  const currentPriceUsd = await getCurrentPriceUsdNormalized(
    campaign.tokenContract,
    'bsc',
    (campaign.priceSource || 'AUTO') as any
  );
  const { text, reply_markup, hasImage, imageFileId, parse_mode } = renderCampaign(campaign, {
    currentPriceUsd,
  });

  try {
    const chatId = String(campaign.chatId);
    
    // 4. Delete old announcement message
    if (campaign.messageId) {
      try { await bot.api.deleteMessage(chatId, Number(campaign.messageId)); } catch (_) {}
    }
    // Delete old countdown widget (tracked in memory)
    const oldCountdownId = countdownMsgIds.get(campaign.id);
    if (oldCountdownId) {
      try { await bot.api.deleteMessage(chatId, oldCountdownId); } catch (_) {}
    }

    // 5. Send Announcement (image + caption, or plain text)
    let announcementMsgId: number | null = null;
    if (hasImage && imageFileId) {
      const msg1 = await bot.api.sendPhoto(chatId, imageFileId, {
        caption: text,
        parse_mode,
      });
      announcementMsgId = msg1.message_id;
    } else {
      const msg1 = await bot.api.sendMessage(chatId, text, { parse_mode });
      announcementMsgId = msg1.message_id;
    }

    // 6. Send Countdown Widget only when mode is not "announcement only"
    let countdownMessageId: number | null = null;
    if (campaign.mediaType !== 'IMAGE_ONLY') {
      const timeRemainingMs = unlockDate.getTime() - now.getTime();
      const buffer = await generateCountdownImageBuffer(timeRemainingMs);
      const msg2 = await bot.api.sendPhoto(chatId, new InputFile(buffer, 'countdown.png'), {
        reply_markup,
      });
      countdownMessageId = msg2.message_id;
      countdownMsgIds.set(campaign.id, msg2.message_id);
    } else {
      countdownMsgIds.delete(campaign.id);
    }

    logger.info(
      `Campaign ${campaign.id}: Sent announcement ${announcementMsgId}` +
      (countdownMessageId ? ` + countdown ${countdownMessageId}` : ' (announcement only)') +
      ` to ${chatId}`
    );

    // 7. Persist only the announcement message ID (no schema changes needed)
    await prisma.campaign.update({
      where: { id: campaign.id },
      data: {
        messageId: announcementMsgId ? BigInt(announcementMsgId) : null,
        mode: mode,
        lastPostTime: now,
      },
    });

  } catch (err: any) {
    logger.error(`Error processing campaign ${campaign.id}: ${err.description || err.message}`);
  }
}
