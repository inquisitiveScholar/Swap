import { Campaign, Link } from '../generated/client/index.js';
import { InlineKeyboard } from 'grammy';
import {
  TELEGRAM_CAPTION_MAX_CHARS,
  TELEGRAM_MESSAGE_MAX_CHARS,
} from '../constants/telegramLimits.js';
import {
  escapeHtml,
  headingLineHtml,
  sanitizeTelegramHtml,
  storedBodyToHtml,
} from '../utils/telegramFormat.js';
import {
  computeMarketCapUsd,
  formatSupplyCompactDisplay,
  formatSupplyDisplay,
  formatUsdCompactDisplay,
  formatUsdDisplay,
  normalizeSupplyInput,
  normalizeUsdInput,
} from '../utils/currency.js';

/**
 * Fits announcement body HTML so heading + body + stats stay within `maxTotal`.
 */
function clipBodyHtmlForAnnounceBlock(
  bodyHtml: string,
  campaign: Campaign,
  maxTotal: number,
  statsBlockHtml: string
): string {
  const headingLine = headingLineHtml(campaign.tokenName);
  const headingPart = headingLine ? `${headingLine}\n\n` : '';
  const suffix = statsBlockHtml ? `\n\n${statsBlockHtml}` : '';
  const fixed = headingPart + suffix;
  const available = maxTotal - fixed.length;
  if (available <= 0) {
    return '';
  }
  if (bodyHtml.length <= available) {
    return bodyHtml;
  }
  const ellipsis = '…';
  const take = Math.max(0, available - ellipsis.length);
  return bodyHtml.slice(0, take) + ellipsis;
}

/**
 * Stats block — spaced rows, bold labels (Telegram HTML).
 * CURRENT PRICE (live preferred) + MARKET CAP / TOTAL SUPPLY.
 */
function renderStatsBlockHtml(
  campaign: Campaign,
  opts?: { currentPriceUsd?: string | null }
): string {
  const rows: string[] = [];

  const currentPriceNorm =
    normalizeUsdInput(opts?.currentPriceUsd || '') ||
    normalizeUsdInput(campaign.price || '');
  const currentPriceDisp = currentPriceNorm ? formatUsdDisplay(currentPriceNorm) : null;

  if (currentPriceDisp) {
    rows.push(`💵 <b>CURRENT PRICE:</b> ${escapeHtml(currentPriceDisp)}`);
  }

  const supplyDisp = formatSupplyCompactDisplay(campaign.circulatingSupply) ||
    formatSupplyDisplay(campaign.circulatingSupply);
  const supplyNorm = normalizeSupplyInput(campaign.circulatingSupply || '');
  if (supplyDisp) {
    rows.push(`📊 <b>TOTAL SUPPLY:</b> ${escapeHtml(supplyDisp)}`);
  }

  const mcapNorm =
    currentPriceNorm && supplyNorm
      ? computeMarketCapUsd(currentPriceNorm, supplyNorm)
      : normalizeUsdInput(campaign.marketCap || '');
  const mcapDisp = mcapNorm ? (formatUsdCompactDisplay(mcapNorm) || formatUsdDisplay(mcapNorm)) : null;
  if (mcapDisp) {
    rows.push(`🏦 <b>MARKET CAP:</b> ${escapeHtml(mcapDisp)}`);
  }

  if (!rows.length) {
    return '';
  }
  return rows.join('\n\n');
}

interface RenderedMessage {
  text: string;
  reply_markup: InlineKeyboard;
  /** Whether this campaign has an image to send */
  hasImage: boolean;
  /** Telegram file_id for the image (if any) */
  imageFileId: string | null;
  parse_mode: 'HTML';
}

/**
 * Renders the campaign message (HTML): optional heading, main body, optional market stats, link keyboard.
 */
export function renderCampaign(
  campaign: Campaign & { links: Link[] },
  opts?: { currentPriceUsd?: string | null }
): RenderedMessage {
  const hasImage =
    (campaign.mediaType === 'IMAGE' || campaign.mediaType === 'IMAGE_ONLY') &&
    !!campaign.imageFileId;

  const keyboard = new InlineKeyboard();
  campaign.links.forEach((link, index) => {
    let safeUrl = link.url.trim();
    if (!/^https?:\/\//i.test(safeUrl) && !/^tg:\/\//i.test(safeUrl)) {
      safeUrl = 'https://' + safeUrl;
    }
    keyboard.url(link.label, safeUrl);
    if ((index + 1) % 2 === 0) keyboard.row();
  });
  if (campaign.links.length % 2 !== 0) keyboard.row();

  const raw = hasImage
    ? renderImageCaption(campaign, opts)
    : renderFullMessage(campaign, opts);
  const text = sanitizeTelegramHtml(raw);

  return {
    text,
    reply_markup: keyboard,
    hasImage,
    imageFileId: campaign.imageFileId,
    parse_mode: 'HTML',
  };
}

function renderImageCaption(
  campaign: Campaign & { links: Link[] },
  opts?: { currentPriceUsd?: string | null }
): string {
  const statsBlock = renderStatsBlockHtml(campaign, opts);
  const headingLine = headingLineHtml(campaign.tokenName);
  const bodyRaw = storedBodyToHtml(campaign.text);
  const body = clipBodyHtmlForAnnounceBlock(
    bodyRaw,
    campaign,
    TELEGRAM_CAPTION_MAX_CHARS,
    statsBlock
  );
  const parts: string[] = [];
  if (headingLine) {
    parts.push(headingLine);
    parts.push('');
  }
  parts.push(body);
  if (statsBlock) {
    parts.push('');
    parts.push('');
    parts.push(statsBlock);
  }
  return parts.join('\n');
}

function renderFullMessage(
  campaign: Campaign & { links: Link[] },
  opts?: { currentPriceUsd?: string | null }
): string {
  const statsBlock = renderStatsBlockHtml(campaign, opts);
  const headingLine = headingLineHtml(campaign.tokenName);
  const bodyRaw = storedBodyToHtml(campaign.text);
  const body = clipBodyHtmlForAnnounceBlock(
    bodyRaw,
    campaign,
    TELEGRAM_MESSAGE_MAX_CHARS,
    statsBlock
  );
  const parts: string[] = [];
  if (headingLine) {
    parts.push(headingLine);
    parts.push('');
  }
  parts.push(body);
  if (statsBlock) {
    parts.push('');
    parts.push('');
    parts.push(statsBlock);
  }
  return parts.join('\n');
}
