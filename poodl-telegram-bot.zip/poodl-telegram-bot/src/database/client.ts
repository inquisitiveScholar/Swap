import 'dotenv/config';
import { PrismaClient } from '../generated/client/index.js';
import { PrismaBetterSqlite3 } from '@prisma/adapter-better-sqlite3';

const dbUrl = process.env.DATABASE_URL || 'file:./prisma/dev.db';
console.log('--- DB Init --- URL:', dbUrl);

// Prisma 7 with better-sqlite3 adapter expects the URL in the config object
const adapter = new PrismaBetterSqlite3({ url: dbUrl });

const prisma = new PrismaClient({ adapter });

export default prisma;
export * from '../generated/client/index.js';
