import fetch from 'node-fetch';
import { COIN_PRICE_QUERY,TOKEN_BASE_STATS_QUERY,TOKEN_DAILY_STATS_QUERY,GET_BLOCK_FROM_TIMESTAMP_QUERY,ETH_MARKET_STATS_QUERY,TOKEN_MARKET_STATS_QUERY,TOKEN_PAIR_VALIDATION_QUERY,USER_TOKEN_INFO_QUERY } from './queries.js';  // Make sure the file extension is correctly specified


const RESERVED_COIN_WALLETS= ['0xB21Cc3F573A178016e1E87Dc743797f9F038Be56','0x000000000000000000000000000000000000f000'];


const fetchGraphQL = async (query,isBlockCall=false) => {

  try {
    const response = await fetch( isBlockCall==true?process.env.GRAPH_SUBGRAPH_BLOCK: process.env.GRAPH_SUBGRAPH_CLIENT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({ query })
    });

    const { data, errors } = await response.json();
    if (errors) {
      console.error(errors);
      throw new Error('Failed to fetch data');
    }
    return data;
  } catch (error) {
    console.error('Network error:', error);
    throw new Error('Network error');
  }
};

export const getTokenPrice = async (tokenAddress = process.env.WPOODL, block = null) => {
  try {
    const STABLECOINS = [process.env.USDT];
    const NATIVE_TOKENS = [process.env.WPOODL];
    let tokenPriceUSD = 0;
    let nativeTokenPriceUSD = null;

    // If the token address is USDT, return a price of 1
    if (tokenAddress.toLowerCase() === process.env.USDT.toLowerCase()) {
      return { price: '1.000000' };
    }

    let checkResult = null;

    // Step 1: Check for direct pair with USDT (both token0/token1 and token1/token0)
    for (let stablecoin of STABLECOINS) {
      checkResult = await checkPair(tokenAddress, stablecoin, block);

      if (checkResult.isPairValid) {
        tokenPriceUSD = checkResult.tokenPrice;
        break;
      }

      // Check reverse pair (stablecoin/tokenAddress)
      checkResult = await checkPair(stablecoin, tokenAddress, block);
      if (checkResult.isPairValid) {
        tokenPriceUSD = checkResult.tokenPrice;  // Inverse price for reverse pair
        break;
      }
    }

    // Step 2: If no direct pair with USDT, check with native token (e.g., WPOODL)
    if (!checkResult.isPairValid) {
      for (let nativeToken of NATIVE_TOKENS) {
        checkResult = await checkPair(tokenAddress, nativeToken, block);
        if (checkResult.isPairValid) {
          // Fetch native token's price in USDT (both token0/token1 and token1/token0)
          for (let stablecoin of STABLECOINS) {
            let nativeToStableResult = await checkPair(nativeToken, stablecoin, block);
            if (nativeToStableResult.isPairValid) {
              nativeTokenPriceUSD = nativeToStableResult.tokenPrice;
              tokenPriceUSD = checkResult.tokenPrice * nativeTokenPriceUSD;
              break;
            }

            // Check reverse pair (stablecoin/nativeToken)
            nativeToStableResult = await checkPair(stablecoin, nativeToken, block);
            if (nativeToStableResult.isPairValid) {
              nativeTokenPriceUSD = nativeToStableResult.tokenPrice;
              tokenPriceUSD = checkResult.tokenPrice * nativeTokenPriceUSD;
              break;
            }
          }
          if (nativeTokenPriceUSD) break;
        }

        // Check reverse pair (nativeToken/tokenAddress)
        checkResult = await checkPair(nativeToken, tokenAddress, block);
        if (checkResult.isPairValid) {
          // Fetch native token's price in USDT
          for (let stablecoin of STABLECOINS) {
            let nativeToStableResult = await checkPair(nativeToken, stablecoin, block);
            if (nativeToStableResult.isPairValid) {
              nativeTokenPriceUSD = nativeToStableResult.tokenPrice;
              tokenPriceUSD = checkResult.tokenPrice * nativeTokenPriceUSD;
              break;
            }

            // Check reverse pair (stablecoin/nativeToken)
            nativeToStableResult = await checkPair(stablecoin, nativeToken, block);
            if (nativeToStableResult.isPairValid) {
              nativeTokenPriceUSD = nativeToStableResult.tokenPrice;
              tokenPriceUSD = checkResult.tokenPrice * nativeTokenPriceUSD;
              break;
            }
          }
          if (nativeTokenPriceUSD) break;
        }
      }
    }

    // Step 3: Return the token price (0 if no pair found), ensuring precision
    const finalTokenPriceUSD = tokenPriceUSD ? Number(tokenPriceUSD).toFixed(20) : '0';

    console.log("=============price=================")

    console.log(finalTokenPriceUSD)

    console.log("==================================")

    return {
      price: finalTokenPriceUSD
    };

  } catch (error) {
    console.error('Error fetching token price:', error);
    return { price: '0.000000' };  // Return price as 0 in case of any error
  }
};






export const getTokenPriceData = async (tokenAddress, days) => {
  try {
    // Step 1: Get the current price without block
    const currentPriceData = await getTokenPrice(tokenAddress);
    const currentPrice = currentPriceData.price;

    // Step 2: Calculate the timestamp for the given number of days in the past
    const currentTimestamp = Math.floor(Date.now() / 1000); 
    const pastTimestamp = currentTimestamp - days * 86400;  

    // Step 3: Get the block number for the past timestamp
    const blockQuery = GET_BLOCK_FROM_TIMESTAMP_QUERY(pastTimestamp);
    const blockData = await fetchGraphQL(blockQuery, true);
    let blockNumber;
    if (!blockData || !blockData.blocks || !blockData.blocks[0]) {
      blockNumber = process.env.GRAPH_SYNC_START_BLOCK;
    } else {
      blockNumber = blockData.blocks[0].number;
    }

    // Step 4: Get the price at the past block
    const pastPriceData = await getTokenPrice(tokenAddress, blockNumber);
    const pastPrice = pastPriceData?.price ?? 0; // Ensure a fallback value

    // Step 5: Log the prices for debugging
    console.log(`Current Price: ${currentPrice}, Past Price: ${pastPrice}`);

    // Step 6: Calculate the price change percentage, handle division by zero
    let priceChangePercent = 0;
    if (pastPrice == 0) {
      // Avoid division by zero, return 100% increase if currentPrice > 0
      priceChangePercent = currentPrice > 0 ? 100 : 0;
    } else {
      priceChangePercent = calculateRateOfChange(pastPrice, currentPrice);
    }

    // Step 7: Return the result
    return {
      currentPrice,
      pastPrice,
      priceChangePercent,  // Already formatted by calculateRateOfChange
      daysAgo: days
    };

  } catch (error) {
    console.error('Error fetching token price change percent:', error);
    return { error: 'Failed to fetch token price change percent.' };
  }
};



//===================================CORE FUNCTION FOR MARKET CHARTS==============




//============================CHART-ANALYTICS-CORE-MOBILE-APP=====================

// Main function to get market chart data
export const marketChartsForApp = async (
  tokenID = process.env.WPOODL,
  days = 1,
  interval = "5m"
) => {
  const now = Math.floor(new Date().getTime() / 1000);
  const oneDayInSeconds = 86400;
  const startTimestamp = now - days * oneDayInSeconds;
  const intervalDuration = getIntervalDuration(days);
   let isUSDTToken= false;

  const timestampRange = {
    start: startTimestamp,
    end: now,
    interval: intervalDuration,
  };

  console.log(timestampRange)

  const STABLECOINS = [process.env.USDT];
  const NATIVE_TOKENS = [process.env.WPOODL];

  let checkResult = null;
  let nativePrice = null;

      // If the token address is USDT, return a price of 1
      if (tokenID.toLowerCase() === process.env.USDT.toLowerCase()) {

        isUSDTToken=true;
      }


  // Step 1: Check direct pairs (TokenID/Stablecoin and Stablecoin/TokenID)
  for (let stablecoin of STABLECOINS) {
    checkResult = await checkPair(tokenID, stablecoin);
    if (checkResult.isPairValid) break;

    checkResult = await checkPair(stablecoin, tokenID);
    if (checkResult.isPairValid) break;
  }

  // Step 2: If no direct pair found, check native/token pair
  if (!checkResult.isPairValid) {
    for (let nativeToken of NATIVE_TOKENS) {
      checkResult = await checkPair(tokenID, nativeToken);
      if (checkResult.isPairValid) {
        // Step 3: If native/token pair found, check native/stable pair to fetch price
        for (let stablecoin of STABLECOINS) {
          let nativeToStableResult = await checkPair(nativeToken, stablecoin);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            break;
          }

          nativeToStableResult = await checkPair(stablecoin, nativeToken);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            break;
          }
        }
        break;
      }

      // Alternative check: Native/TokenID
      checkResult = await checkPair(nativeToken, tokenID);
      if (checkResult.isPairValid) {
        for (let stablecoin of STABLECOINS) {
          let nativeToStableResult = await checkPair(nativeToken, stablecoin);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            break;
          }

          nativeToStableResult = await checkPair(stablecoin, nativeToken);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            break;
          }
        }
        break;
      }
    }
  }

  // Step 4: Return market data or invalid pair
  if (checkResult.isPairValid) {
    console.log('native price ');
    console.log(nativePrice);

    const marketData = await calculateMarketDataForAnalyticsChart(
      checkResult.validToken0,
      checkResult.validToken1,
      checkResult.tokenPriceId,
      checkResult.tokenStatsId,
      nativePrice,
      isUSDTToken,
      timestampRange,
      tokenID
    );

    console.log("data...")
    console.log(marketData)
    // date: timestamp,
    // value: priceUSD,
    // volume: totalTradeVolume,
    // market_cap: totalMarketCap,

    // Transform marketData into the new format
    const transformedMarketData = {
      prices: marketData.map(dataPoint => [dataPoint.date * 1000, dataPoint.value]),
      market_caps: marketData.map(dataPoint => [dataPoint.date * 1000, dataPoint.market_cap]),
      total_volumes: marketData.map(dataPoint => [dataPoint.date * 1000, dataPoint.volume]),
    };

    console.log("===========data============")
    console.log(transformedMarketData);
    return transformedMarketData;
  } else {
    // Return empty data in the new format or indicate invalid pair
    const emptyMarketData = {
      prices: [],
      market_caps: [],
      total_volumes: []
    };
    for (let timestamp = timestampRange.start; timestamp <= now; timestamp += intervalDuration) {
      emptyMarketData.prices.push([timestamp * 1000, 0]);
      emptyMarketData.market_caps.push([timestamp * 1000, 0]);
      emptyMarketData.total_volumes.push([timestamp * 1000, 0]);
    }
    return emptyMarketData;
  }
};





//==========================================CHART-ANALYTICS-CORE-FUNCTION================



//========================================================================================





export const priceDataWithTimestamps = async (tokenID = process.env.WPOODL, days = 1, interval = "1h") => {
  const now = Math.floor(Date.now() / 1000);
  const oneDayInSeconds = 86400;
  const startTimestamp = now - days * oneDayInSeconds;
  const intervalDuration = parseInterval(interval);
  let isUSDTToken = false;

  const timestampRange = {
    start: startTimestamp,
    end: now,
    interval: intervalDuration,
  };

  const STABLECOINS = [process.env.USDT];
  const NATIVE_TOKENS = [process.env.WPOODL];

  let checkResult = null;
  let nativePrice = null;

  // If the token address is USDT, return a price of 1
  if (tokenID.toLowerCase() === process.env.USDT.toLowerCase()) {
    isUSDTToken = true;
  }

  // Step 1: Check direct pairs (TokenID/Stablecoin and Stablecoin/TokenID)
  for (let stablecoin of STABLECOINS) {
    checkResult = await checkPair(tokenID, stablecoin);
    if (checkResult.isPairValid) break;

    checkResult = await checkPair(stablecoin, tokenID);
    if (checkResult.isPairValid) break;
  }

  // Step 2: If no direct pair found, check native/token pair
  if (!checkResult.isPairValid) {
    for (let nativeToken of NATIVE_TOKENS) {
      checkResult = await checkPair(tokenID, nativeToken);
      if (checkResult.isPairValid) {
        // Step 3: If native/token pair found, check native/stable pair to fetch price
        for (let stablecoin of STABLECOINS) {
          let nativeToStableResult = await checkPair(nativeToken, stablecoin);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            break;
          }

          nativeToStableResult = await checkPair(stablecoin, nativeToken);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            break;
          }
        }
        break;
      }

      // Alternative check: Native/TokenID
      checkResult = await checkPair(nativeToken, tokenID);
      if (checkResult.isPairValid) {
        for (let stablecoin of STABLECOINS) {
          let nativeToStableResult = await checkPair(nativeToken, stablecoin);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            break;
          }

          nativeToStableResult = await checkPair(stablecoin, nativeToken);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            break;
          }
        }
        break;
      }
    }
  }

  // Step 4: Return only the price data with timestamps using the simplified function
  if (checkResult.isPairValid) {
    const marketData = await calculateMarketDataForSimpleChart(
      checkResult.validToken0,
      checkResult.validToken1,
      checkResult.tokenPriceId,
      checkResult.tokenStatsId,
      nativePrice,
      isUSDTToken,
      timestampRange
    );

    // Return only prices and their corresponding timestamps
    return marketData.map(dataPoint => ({
      timestamp: dataPoint.date,
      price: dataPoint.price
    }));
  } else {
    // Return empty price data in case of invalid pair
    const emptyPriceData = [];
    for (let timestamp = timestampRange.start; timestamp <= now; timestamp += intervalDuration) {
      emptyPriceData.push({ timestamp: timestamp * 1000, price: 0 });
    }
    return emptyPriceData;
  }
};









// Main function to get market chart data
export const marketChartForAnalytics = async (tokenID = process.env.WPOODL, days = 1, interval = "1h") => {
  const now = Math.floor(new Date().getTime() / 1000);
  const oneDayInSeconds = 86400;
  const startTimestamp = now - (days * oneDayInSeconds);
  const intervalDuration = parseInterval(interval);
  let isUSDTToken=false;

  const timestampRange = {
    start: startTimestamp,
    end: now,
    interval: intervalDuration,
  };

  const STABLECOINS = [process.env.USDT];
  const NATIVE_TOKENS = [process.env.WPOODL];

  let checkResult = null;
  let nativePrice = null;

        // If the token address is USDT, return a price of 1
        if (tokenID.toLowerCase() === process.env.USDT.toLowerCase()) {

          isUSDTToken=true;
        }

  // Step 1: Check direct pairs (TokenID/Stablecoin and Stablecoin/TokenID)
  for (let stablecoin of STABLECOINS) {
    checkResult = await checkPair(tokenID, stablecoin);
    if (checkResult.isPairValid) break;

    checkResult = await checkPair(stablecoin, tokenID);
    if (checkResult.isPairValid) break;
  }

  // Step 2: If no direct pair found, check native/token pair
  if (!checkResult.isPairValid) {
    for (let nativeToken of NATIVE_TOKENS) {
      checkResult = await checkPair(tokenID, nativeToken);
      if (checkResult.isPairValid) {
        // Step 3: If native/token pair found, check native/stable pair to fetch price
        for (let stablecoin of STABLECOINS) {
          let nativeToStableResult = await checkPair(nativeToken, stablecoin);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            //checkResult.tokenPrice *= nativePrice;
            break;
          }

          nativeToStableResult = await checkPair(stablecoin, nativeToken);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            //checkResult.tokenPrice *= nativePrice;
            break;
          }
        }
        break;
      }

      // Alternative check: Native/TokenID
      checkResult = await checkPair(nativeToken, tokenID);
      if (checkResult.isPairValid) {
        for (let stablecoin of STABLECOINS) {
          let nativeToStableResult = await checkPair(nativeToken, stablecoin);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            //checkResult.tokenPrice *= nativePrice;
            break;
          }

          nativeToStableResult = await checkPair(stablecoin, nativeToken);
          if (nativeToStableResult.isPairValid) {
            nativePrice = nativeToStableResult.tokenPrice;
            //checkResult.tokenPrice *= nativePrice;
            break;
          }
        }
        break;
      }
    }
  }

  // Step 4: Return market data or invalid pair
  if (checkResult.isPairValid) {

    console.log('native price ')
    console.log(nativePrice)
    const marketData = await calculateMarketDataForAnalyticsChart(
      checkResult.validToken0,
      checkResult.validToken1,
      checkResult.tokenPriceId,
      checkResult.tokenStatsId,
      nativePrice,
      isUSDTToken,
      timestampRange,
      tokenID
    );

    return marketData;
  } else {

    console.log("pairInvalid");
    // Return empty data or indicate invalid pair
    const emptyMarketData = [];
    for (let timestamp = timestampRange.start; timestamp <= now; timestamp += intervalDuration) {


      addMarketDataForChart(emptyMarketData, timestamp * 1000, 0, 0, 0);
    }
    return emptyMarketData;
  }
};




//================================Helper functions=========================================


const calculateRateOfChange = (pastPrice, currentPrice) => {
  if (!pastPrice || pastPrice === 0) {
    return currentPrice > 0 ? 100 : 0; // Prevent division by zero
  }
  
  const change = ((currentPrice - pastPrice) / pastPrice) * 100;
  return change.toFixed(5);  // Round to 2 decimal places
};




const parseInterval = (interval) => {
  const unit = interval.slice(-1);
  const value = parseInt(interval.slice(0, -1), 10);

  if (unit === 'm') {
    return value * 60; // Convert minutes to seconds
  } else if (unit === 'h') {
    return value * 3600; // Convert hours to seconds
  } else {
    throw new Error('Invalid interval format');
  }
};



const getIntervalDuration = (days) => {
  if (days >= 365) {
    return 86400; // 1 year
  } else if (days >= 91) {
    return 86400; // 91 days 
  } else if (days >= 30) {
    return 3600; // 30 days 
  } else if (days >= 7) {
    return 4740; // 7 days 
  } else if (days >= 1) {
    return 300; // 1 day 
  } else {
    throw new Error('Invalid number of days');
  }
};


// Function to check the validity of a token pair
const checkPair = async (tokenA, tokenB, block = null) => {
  console.log("inside pair")
  // Pass the block parameter to the TOKEN_PAIR_VALIDATION_QUERY function
  let query = TOKEN_PAIR_VALIDATION_QUERY(tokenA, tokenB, block);
  const result = await fetchGraphQL(query);

  console.log(tokenA)
  console.log(tokenB)
  console.log(result)

  if (result && result.pairs.length > 0) {
    const pair = result.pairs[0];
    let tokenPrice, tokenPriceId, tokenStatsId;

    if (pair.token0.id.toLowerCase() === tokenB.toLowerCase() || (pair.token0.id.toLowerCase()!=process.env.USDT && pair.token1.id.toLowerCase()==process.env.WPOODL)  ) {
      tokenPrice = pair.token1Price;
      tokenPriceId = 'token1';
      tokenStatsId = 'token0';
    } else if (pair.token1.id.toLowerCase() === tokenB.toLowerCase()) {
      tokenPrice = pair.token0Price;
      tokenPriceId = 'token0';
      tokenStatsId = 'token1';
    }



    console.log("testing")

    console.log(tokenPrice)
   

    return {
      isPairValid: true,
      tokenPrice,
      tokenPriceId,
      tokenStatsId,
      validToken0: pair.token0.id,
      validToken1: pair.token1.id,
    };
  }

  return { isPairValid: false };
};






const calculateMarketDataForAnalyticsChart = async (validToken0, validToken1, tokenPriceId, tokenStatsId, nativeCoinPrice,isUSDTToken, timestampRange,tokenID) => {
  const marketData = [];
  const timestampPromises = [];

  // Step 1: Fetch all block numbers in parallel for the given timestamps
  for (let timestamp = timestampRange.start; timestamp <= timestampRange.end; timestamp += timestampRange.interval) {
    timestampPromises.push(fetchBlockNumberForTimestamp(timestamp));
  }

  const blockNumbers = await Promise.all(timestampPromises);

  // Step 2: Fetch market data in parallel using block numbers
  const marketDataPromises = blockNumbers.map((blockNumber, index) => {
    const timestamp = timestampRange.start + index * timestampRange.interval;
    return fetchMarketDataForBlock(validToken0, validToken1, tokenPriceId, blockNumber, tokenStatsId, timestamp,isUSDTToken, nativeCoinPrice,tokenID);
  
  });

  const marketDataResults = await Promise.all(marketDataPromises);

  // Step 3: Process and return market data
  return marketDataResults;
};

const fetchBlockNumberForTimestamp = async (timestamp) => {
  try {
    const blockQuery = GET_BLOCK_FROM_TIMESTAMP_QUERY(timestamp);
    const blockData = await fetchGraphQL(blockQuery, true);
    if (!blockData || !blockData.blocks || !blockData.blocks[0]) {
      //console.error('Failed to fetch block data for timestamp:', timestamp);
      return process.env.GRAPH_SYNC_START_BLOCK;  // Handle missing block data
    }
    return blockData.blocks[0].number;
  } catch (error) {
    console.error('Error fetching block number:', error);
    return null;
  }
};

const fetchMarketDataForBlock = async (validToken0, validToken1, tokenPriceId, blockNumber, tokenStatsId, timestamp,isUSDTToken, nativeCoinPrice,tokenID) => {
  if (!blockNumber) {
    // Handle missing block number by returning default/zero data
    return { date: timestamp * 1000, value: 0, volume: 0, market_cap: 0 };
  }

  try {
    let query = TOKEN_MARKET_STATS_QUERY(validToken0, validToken1, tokenPriceId, blockNumber, undefined, tokenStatsId);
    const result = await fetchGraphQL(query);

    if (result && result.swaps.length > 0) {
      const swap = result.swaps[0];  // Use the first swap if available


      let priceUSD = isUSDTToken==false? (nativeCoinPrice == null ? parseFloat(swap.pair.price) || 0 : parseFloat(swap.pair.price) * nativeCoinPrice || 0):1;
     
      priceUSD= priceUSD.toFixed(12);
      
      let totalSupply = 0;

      if (swap.pair.tokens.tokenID == process.env.WPOODL) {
        try {
          totalSupply = await getTotalSupply();  // Fetch total supply only if token is WPOODL
        } catch (error) {
          console.error("Error fetching total supply for WPOODL:", error);
          // totalSupply = 0;  // Fallback to 0 if fetching total supply fails
        }
      } else {
        totalSupply = await getTokenSupply(swap.pair.tokens.tokenID) || 0;  // Use supplyTotal if not WPOODL

        console.log("==================totalSUpply==========");
        console.log(totalSupply);

      }

      const totalTradeVolume = ((swap.pair.tokens.totalTradeVolume) * priceUSD).toFixed(3);
      const totalMarketCap = (totalSupply * priceUSD).toFixed(3);

      return { date: timestamp * 1000, value: priceUSD, volume: totalTradeVolume, market_cap: totalMarketCap };
    } else {
      // Fill with default/zero data if no swap is available


      const tokenDefaultPrice = await getTokenPrice(tokenID);

      let tokenDefaultSupply=0;

        console.log("tokenID..........");

        console.log(tokenID);

        console.log(tokenDefaultSupply);

      if (tokenID.toLowerCase()==process.env.WPOODL){

        console.log("nativeSupply");

         tokenDefaultSupply = await getTotalSupply();


      }else {

        console.log("tokenSupply....")
         tokenDefaultSupply = await getTokenSupply(tokenID);
         console.log(tokenDefaultSupply);

      }




      const totalMarketCap = (tokenDefaultSupply * tokenDefaultPrice).toFixed(3);


      return { date: timestamp * 1000, value: tokenDefaultPrice.price, volume: 0, market_cap: totalMarketCap };
    

    }
  } catch (error) {
    console.error('Error fetching market data for block:', blockNumber, error);
    return { date: timestamp * 1000, value: 0, volume: 0, market_cap: 0 };
  }
};




const calculateMarketDataForSimpleChart = async (validToken0, validToken1, tokenPriceId, tokenStatsId, nativeCoinPrice, isUSDTToken, timestampRange) => {
  const simpleMarketData = [];
  const timestampPromises = [];

  // Step 1: Fetch all block numbers in parallel for the given timestamps
  for (let timestamp = timestampRange.start; timestamp <= timestampRange.end; timestamp += timestampRange.interval) {
    timestampPromises.push(fetchSimpleBlockNumberForTimestamp(timestamp));
  }

  const blockNumbers = await Promise.all(timestampPromises);

  // Step 2: Fetch market data in parallel using block numbers
  const simpleMarketDataPromises = blockNumbers.map((blockNumber, index) => {
    const timestamp = timestampRange.start + index * timestampRange.interval;
    return fetchSimpleMarketDataForBlock(validToken0, validToken1, tokenPriceId, blockNumber, tokenStatsId, timestamp, isUSDTToken, nativeCoinPrice);
  });

  const simpleMarketDataResults = await Promise.all(simpleMarketDataPromises);

  // Step 3: Process and return market data
  return simpleMarketDataResults;
};


const fetchSimpleBlockNumberForTimestamp = async (timestamp) => {
  try {
    const blockQuery = GET_BLOCK_FROM_TIMESTAMP_QUERY(timestamp);
    const blockData = await fetchGraphQL(blockQuery, true);
    if (!blockData || !blockData.blocks || !blockData.blocks[0]) {
      return process.env.GRAPH_SYNC_START_BLOCK;  // Handle missing block data
    }
    return blockData.blocks[0].number;
  } catch (error) {
    console.error('Error fetching block number:', error);
    return null;
  }
};

const fetchSimpleMarketDataForBlock = async (validToken0, validToken1, tokenPriceId, blockNumber, tokenStatsId, timestamp, isUSDTToken, nativeCoinPrice) => {
  if (!blockNumber) {
    // Handle missing block number by returning default/zero data
    return { date: timestamp * 1000, price: 0 };
  }

  try {
    let query = TOKEN_MARKET_STATS_QUERY(validToken0, validToken1, tokenPriceId, blockNumber, undefined, tokenStatsId);
    const result = await fetchGraphQL(query);

    if (result && result.swaps.length > 0) {
      const swap = result.swaps[0];  // Use the first swap if available

      let priceUSD = isUSDTToken === false ? (nativeCoinPrice == null ? parseFloat(swap.pair.price) || 0 : parseFloat(swap.pair.price) * nativeCoinPrice || 0) : 1;

      return { date: timestamp * 1000, price: priceUSD };
    } else {
      // Fill with default/zero data if no swap is available
      return { date: timestamp * 1000, price: 0 };
    }
  } catch (error) {
    console.error('Error fetching market data for block:', blockNumber, error);
    return { date: timestamp * 1000, price: 0 };
  }
};






export const getTokenFullStats = async (tokenID) => {

  try {
    console.log(`Fetching full stats for token: ${tokenID}`);

    // Step 1: Fetch Basic Token Info (name, symbol, totalSupply, tradeVolume)
    console.log("Fetching basic token info...");
    const tokenBaseDataQuery = TOKEN_BASE_STATS_QUERY(tokenID);
    const tokenBaseData = await fetchGraphQL(tokenBaseDataQuery);
    let { name, symbol, totalSupply, tradeVolume } = tokenBaseData.tokens[0];



    if (symbol=='WPOODL'){

        symbol='POODL';
        name=Symbol;

        totalSupply = await getTotalSupply();

    }else {

        totalSupply = await getTokenSupply(tokenID);


        console.log("==================totalSUpply==========");
        console.log(totalSupply);

    }

    console.log(tokenBaseData);
    console.log(`Token Info: Name=${name}, Symbol=${symbol}`);

    // Step 2: Fetch Current Price and Calculate Percent Changes
    console.log("Fetching current price and calculating percent changes...");
    const currentPriceData = await getTokenPriceData(tokenID, 1); // for 24h percent change
    const price = (currentPriceData.currentPrice);
    const percent_change_24h = currentPriceData.priceChangePercent;

    console.log(`Current Price: ${price}, 24h Percent Change: ${percent_change_24h}`);

    // Fetch price changes for other time frames
    const percent_change_7d = (await getTokenPriceData(tokenID, 7)).priceChangePercent;
    console.log(`7d Percent Change: ${percent_change_7d}`);

    const percent_change_30d = (await getTokenPriceData(tokenID, 30)).priceChangePercent;
    console.log(`30d Percent Change: ${percent_change_30d}`);

    const percent_change_1y = (await getTokenPriceData(tokenID, 365)).priceChangePercent;
    console.log(`1y Percent Change: ${percent_change_1y}`);

    // Step 3: Fetch Market Data for the past 7 days
    console.log("Fetching market data...");
    const marketDataForWeek = await priceDataWithTimestamps(tokenID, 7, "370m"); // Fetch 7 days of data with a daily interval
    const pricesForWeek = marketDataForWeek.map(dataPoint => dataPoint.price);


    const marketDataForYear = await priceDataWithTimestamps(tokenID, 365, "24h"); // Fetch 7 days of data with a daily interval
    const pricesForYears = marketDataForWeek.map(dataPoint => dataPoint.price);


    // Step 4: Serialize weekly price data in the required format
    const serializedWeeklyPriceData = serializePrices(pricesForWeek);

    // Step 5: Fetch Market Cap and Total Volume (could be part of price data)
    console.log("Fetching market cap and total volume...");
    const market_cap = (totalSupply) * (price);
    const total_volume = (tradeVolume) * (price);

    console.log(`Market Cap: ${market_cap}, Total Volume: ${tradeVolume}`);

    let circulating_supply;

    if (tokenID === process.env.WPOODL) {
      circulating_supply = await getTotalCirculationSupply(totalSupply, RESERVED_COIN_WALLETS);
    } else {
      circulating_supply = totalSupply;
    }


    // Calculate high/low in the last 24 hours from marketData
    const high_24h = Math.max(...pricesForWeek).toFixed(15); // Adjust 2 to the number of decimal places you want
    const low_24h = Math.min(...pricesForWeek).toFixed(15);

    // Calculate ATH (All Time High)
    const ath = Math.max(...pricesForYears).toFixed(15);

    const ath_change_percentage = calculateRateOfChange(ath, price);

    console.log(`Weekly Price Data: ${serializedWeeklyPriceData}`);
    console.log(`High 24h: ${high_24h}, Low 24h: ${low_24h}`);
    console.log(`ATH: ${ath}, ATH Change Percentage: ${ath_change_percentage}`);

    // Step 7: Populate Additional Info and return the result
    const result = [{
      name,
      symbol,
      price,
      percent_change_24h,
      percent_change_7d,
      percent_change_30d,
      percent_change_1y,
      market_cap,
      total_volume,
      circulating_supply,
      weekly_price_data: serializedWeeklyPriceData,
      high_24h,
      low_24h,
      ath,
      ath_change_percentage
    }];

    console.log("Final Result:", JSON.stringify(result, null, 2));
    return result;

  } catch (error) {
    console.error('Error fetching token full stats:', error);
    return [{ error: 'Failed to fetch token full stats' }];
  }
};

// Helper function to serialize prices in the specified format
const serializePrices = (prices) => {
  let serialized = `a:${prices.length}:{`;
  prices.forEach((price, index) => {
    const formattedPrice = parseFloat(price).toFixed(13); // Format the price to two decimal places
    serialized += `i:${index};s:${formattedPrice.length}:"${formattedPrice}";`;
  });
  serialized += '}';
  return serialized;
};


// name varchar(30) NOT NULL,
//   symbol varchar(20) NOT NULL,
//   logo text DEFAULT NULL,
//   price decimal(30,18) DEFAULT NULL,
//   percent_change_24h decimal(6,2) DEFAULT NULL,
//   percent_change_1y decimal(20,2) DEFAULT NULL,
//   percent_change_30d decimal(6,2) DEFAULT NULL,
//   percent_change_7d decimal(6,2) DEFAULT NULL,
//   market_cap decimal(24,2) DEFAULT NULL,
//   total_volume decimal(24,2) DEFAULT NULL,
//   circulating_supply varchar(250) DEFAULT NULL,
//   weekly_price_data longtext NOT NULL,
//   coin_status varchar(20) NOT NULL DEFAULT 'enable',
//   coin_category longtext DEFAULT NULL,
//   last_updated timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
//   high_24h decimal(30,18) DEFAULT NULL,
//   low_24h decimal(30,18) DEFAULT NULL,
//   ath decimal(30,18) DEFAULT NULL,
//   ath_change_percentage decimal(20,6) DEFAULT NULL,
//   ath_date timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
//   extradata longtext DEFAULT NULL

// ath = (all time high)


// Helper function to fetch the balance of an individual account using the Explorer API
const getAccountBalance = async (accountAddress) => {
  try {
    const response = await fetch(`${process.env.EXPLORER_API_BASE_URL}?module=account&action=balance&address=${accountAddress}`);
    const result = await response.json();

    if (result && result.result) {
      // Convert the balance to the correct decimal format
      const decimals = process.env.NATIVE_COIN_DECIMALS || 18;  // Default to 18 decimals if not specified
      const balance = (parseFloat(result.result) / Math.pow(10, decimals)).toFixed(decimals);
      return parseFloat(balance);  // Return the balance as a number
    } else {
      throw new Error(`Failed to fetch balance for account: ${accountAddress}`);
    }
  } catch (error) {
    console.error(`Error fetching balance for account: ${accountAddress}`, error);
    return 0;  // Return 0 if there's an error fetching balance
  }
};




// Function to fetch token supply by dividing the total supply by the decimals
const getTokenSupply = async (tokenAddress) => {
  try {
    // Fetch the base URL from the environment variables
    const explorerApiBaseUrl = process.env.EXPLORER_V2_API_BASE_URL; // e.g., 'https://explorer.poodl.org/api/v2/'

    // Construct the API URL using the token address
    const apiUrl = `${explorerApiBaseUrl}/addresses/${tokenAddress}`;

    // Fetch the response from the Explorer API
    const response = await fetch(apiUrl);
    const result = await response.json();

    // Check if the result contains token data
    if (result && result.token) {
      const { total_supply, decimals } = result.token;

   

      // Convert total_supply and decimals to numbers
      const totalSupply = parseFloat(total_supply);
      const tokenDecimals = parseInt(decimals, 10);

      // Calculate the token supply by dividing total supply by decimals
      const tokenSupply = totalSupply / Math.pow(10, tokenDecimals);

      console.log(`Total Supply: ${totalSupply}, Decimals: ${tokenDecimals}, Token Supply: ${tokenSupply}`);

      // Return the calculated token supply
      return tokenSupply;
    } else {
      throw new Error(`Failed to fetch token details for address: ${tokenAddress}`);
    }
  } catch (error) {
    console.error(`Error fetching token supply for address: ${tokenAddress}`, error);
    return 0; // Return 0 if there's an error fetching token supply
  }
};

export default getTokenSupply;





// Function to fetch the total supply of the native coin (e.g., ETH) from the Explorer API
const getTotalSupply = async () => {
  try {
    const response = await fetch(`${process.env.EXPLORER_API_BASE_URL}?module=stats&action=ethsupply`);
    const result = await response.json();

    if (result && result.result) {
      // Convert the total supply from Wei to ETH
      const decimals = process.env.NATIVE_COIN_DECIMALS || 18;  // Default to 18 decimals if not specified
      const totalSupply = (parseFloat(result.result) / Math.pow(10, decimals)).toFixed(decimals);
      return totalSupply;
    } else {
      throw new Error('Failed to fetch total supply');
    }
  } catch (error) {
    console.error('Error fetching total supply:', error);
    return 0;  // Return 0 in case of error
  }
};



// Function to iterate over a set of accounts, fetch balances, and return the total balance
const getTotalHoldBalance = async (accounts) => {
  let totalHoldBalance = 0;

  for (let account of accounts) {
    const balance = await getAccountBalance(account);
    totalHoldBalance += balance;
  }

  return totalHoldBalance.toFixed(process.env.NATIVE_COIN_DECIMALS || 18);  // Return the total balance
};

// Function to get the total circulating supply
export const getTotalCirculationSupply = async (totSupply,accounts) => {
  try {
    // Step 1: Get the total supply
    const totalSupply = totSupply;

    console.log(totalSupply)

    // Step 2: Get the total hold balance
    const totalHoldBalance = await getTotalHoldBalance(accounts);

    console.log('Holding :'+totalHoldBalance);

    // Step 3: Calculate the circulating supply by subtracting hold balance from total supply
    const totalCirculationSupply = parseFloat(totalSupply) - parseFloat(totalHoldBalance);

    console.log(totalCirculationSupply);

    // Step 4: Return the circulating supply in ETH
    return totalCirculationSupply.toFixed(process.env.NATIVE_COIN_DECIMALS || 18);
  } catch (error) {
    console.error('Error calculating total circulating supply:', error);
    return 'Error calculating total circulating supply';
  }
};





function addMarketDataForChart(marketData, timestamp, priceUSD, totalTradeVolume, totalMarketCap) {

  marketData.push({
    date: timestamp,
    value: priceUSD,
    volume: totalTradeVolume,
    market_cap: totalMarketCap,
  });

  
}







//========================================FUNCTION BLOCK CLOSE===========================================