import dotenv from 'dotenv';
dotenv.config();
import express from 'express';
import { getTokenPriceData,marketChartForAnalytics,marketChartsForApp ,getTokenFullStats} from './utils.js'; // Ensure the file extension is specified if necessary


const app = express();
const PORT = process.env.PORT || 4000;

app.use(express.json());

// THIS FUNCTION WILL RETURN NATIVE COIN PRICE 

app.get('/getTokenPrice', async (req, res) => {
  const tokenAddress = req.query.tokenID || process.env.WDAPO;  // Get tokenAddress from query parameters
  const days = req.query.days || 1;  // Default days to 20 if not provided

  console.log(process.env.WDAPO)

  try {
    // Call getTokenPriceData with the tokenAddress and days
    const data = await getTokenPriceData(tokenAddress.toLowerCase(), days);

    if (data && data.currentPrice) {
      res.json({
        currentPrice: data.currentPrice,
        pastPrice: data.pastPrice,
        priceChangePercent: data.priceChangePercent,  // Already formatted by calculateRateOfChange
        daysAgo: data.daysAgo
      });
    } else {

      // in this case graph has no data 

      res.json({
        currentPrice: '0.000000',
        pastPrice: '0.000000',
        priceChangePercent: '0.00',
        daysAgo: days  // Return the number of days passed in the request
      });
      
    }
  } catch (error) {
    if (error.message === 'Failed to fetch data') {
      res.status(502).send('Bad Gateway Error');
    } else {
      res.status(503).send('Service Unavailable');
    }
  }
});


app.get('/tokenPriceByAddress', async (req, res) => {
  const tokenAddress = req.query.tokenID || process.env.WDAPO;  // Get tokenAddress from query parameters
  const days = req.query.days || 1;  // Default days to 1 if not provided

  console.log(process.env.WDAPO);

  try {
    // Call getTokenPriceData with the tokenAddress and days
    const data = await getTokenPriceData(tokenAddress.toLowerCase(), days);

    if (data && data.currentPrice) {
      res.json({
        [tokenAddress.toLowerCase()]: {
          usd: (data.currentPrice),  // Format the price to 2 decimal places
          usd_24h_change: parseFloat(data.priceChangePercent).toFixed(8)  // Format the change to 8 decimal places
        }
      });
    } else {

      // In this case, the graph has no data

      res.json({
        [tokenAddress.toLowerCase()]: {
          usd: '0.00',
          usd_24h_change: '0.00000000'
        }
      });
    }
  } catch (error) {
    if (error.message === 'Failed to fetch data') {
      res.status(502).send('Bad Gateway Error');
    } else {
      res.status(503).send('Service Unavailable');
    }
  }
});


//=======================THIS IS TEMP FUNCTION LATER WE CAN REMOVE============

app.post('/coinPrice', async (req, res) => {
  const days = req.body.days || 1; // Assume getCoinPrice is an asynchronous function fetching price data
  const tokenAddress = req.body.tokenID || process.env.WDAPO;
  try {
    const data = await getTokenPriceData(tokenAddress.toLowerCase(), days);
    if (data && data.currentPrice) {
      res.json({
        price: data.currentPrice,
        day24hoursChangePercent: data.priceChangePercent
      });
    } else {

      res.json({
        price: 0,
        day24hoursChangePercent:0
      });

    }
  } catch (error) {
    if (error.message === 'Failed to fetch data') {
      res.status(502).send('Bad Gateway Error');
    } else {

      console.log(error)
      res.status(503).send('Service Unavailable');
    }
  }
});



// Define the GET endpoint for fetching token full stats
app.get('/tokenStats', async (req, res) => {

  try {

    // Extract tokenID from query parameters
    const tokenID = req.query.tokenID|| process.env.WDAPO;

    // Validate the tokenID parameter
    if (!tokenID) {
      return res.status(400).json({ error: 'tokenID parameter is required' });
    }

    console.log(`Received request for token full stats: tokenID=${tokenID}`);

    // Call the getTokenFullStats function with the tokenID
    const result = await getTokenFullStats(tokenID.toLowerCase());

    // Check if the result contains an error
    if (result.length > 0 && result[0].error) {
      console.error(`Error returned from getTokenFullStats: ${result[0].error}`);
      return res.status(500).json({ error: result[0].error });
    }

    // Send the result back to the client
    res.status(200).json(result);
  } catch (error) {
    console.error('Error in /api/token-full-stats:', error);
    res.status(500).json({ error: 'Failed to fetch token full stats due to an internal error' });
  }

  
});



app.get('/market-chart-analytics', async (req, res) => {
  const { tokenID, days, interval } = req.query;
  const defaultTokenId =process.env.WDAPO;

  console.log(days)

  try {
    const marketData = await marketChartForAnalytics(tokenID.toLocaleLowerCase() || defaultTokenId,days,interval);

    console.log("=========marketData========");
    console.log(marketData);


    if (marketData.error) {
      res.status(500).json({ error: marketData.error });
    } else {
      res.json(marketData); // Directly returning the structured data
    }
  } catch (error) {
    console.error('Error fetching market data:', error);
    res.status(500).send('Internal Server Error');
  }
});



app.get('/market-analytics', async (req, res) => {
  const { tokenID, days, interval } = req.query;
  const defaultTokenId = process.env.WDAPO;

  try {
    const marketData = await marketChartsForApp(tokenID || defaultTokenId,days,interval);



    if (marketData.error) {
      
      res.status(500).json({ error: marketData.error });
    } else {
      console.log("=========marketData========");
      console.log(marketData);


      res.json({
        prices: marketData.prices,
        market_caps: marketData.market_caps,
        total_volumes: marketData.total_volumes
      });
    }
  } catch (error) {
    console.error('Error fetching market data:', error);
    res.status(500).send('Internal Server Error');
  }
});




//=============================JUST FOR TEST PURPOSE IT WILL RMOVE/UPDATE BY DEV======



app.get('/coinsmarkets', async (req, res) => {
  const platform = req.query.platform || 'ios'; // Set default platform to 'ios'

  try {
    // Simulate fetching data (you can replace this with an actual API call)
    const marketData = [
      {
        "id": "bitcoin",
        "symbol": "btc",
        "name": "Bitcoin",
        "image": "https://coin-images.coingecko.com/coins/images/1/large/bitcoin.png?1696501400",
        "current_price": 68949,
        "market_cap": 1363577308334,
        "market_cap_rank": 1,
        "fully_diluted_valuation": 1448094077972,
        "total_volume": 32241308090,
        "high_24h": 69218,
        "low_24h": 67467,
        "price_change_24h": 1312.88,
        "price_change_percentage_24h": 1.9411,
        "market_cap_change_24h": 26093254632,
        "market_cap_change_percentage_24h": 1.95092,
        "circulating_supply": 19774353,
        "total_supply": 21000000,
        "max_supply": 21000000,
        "ath": 73738,
        "ath_change_percentage": -6.48986,
        "ath_date": "2024-03-14T07:10:36.635Z",
        "atl": 67.81,
        "atl_change_percentage": 101586.27924,
        "atl_date": "2013-07-06T00:00:00.000Z",
        "roi": null,
        "last_updated": "2024-10-28T18:41:58.366Z"
      },
      {
        "id": "ethereum",
        "symbol": "eth",
        "name": "Ethereum",
        "image": "https://coin-images.coingecko.com/coins/images/279/large/ethereum.png?1696501628",
        "current_price": 2499.11,
        "market_cap": 300573922868,
        "market_cap_rank": 2,
        "fully_diluted_valuation": 300573922868,
        "total_volume": 14472623746,
        "high_24h": 2537.88,
        "low_24h": 2471.44,
        "price_change_24h": 7.35,
        "price_change_percentage_24h": 0.29508,
        "market_cap_change_24h": 581399102,
        "market_cap_change_percentage_24h": 0.1938,
        "circulating_supply": 120403276.307204,
        "total_supply": 120403276.307204,
        "max_supply": null,
        "ath": 4878.26,
        "ath_change_percentage": -48.76059,
        "ath_date": "2021-11-10T14:24:19.604Z",
        "atl": 0.432979,
        "atl_change_percentage": 577201.16735,
        "atl_date": "2015-10-20T00:00:00.000Z",
        "roi": {
          "times": 47.4611072619133,
          "currency": "btc",
          "percentage": 4746.11072619133
        },
        "last_updated": "2024-10-28T18:42:01.832Z"
      }
    ];

    // No filtering, return the full market data list
    res.json(marketData);

  } catch (error) {
    console.error(`Error fetching market data for platform: ${platform}`, error);
    res.status(500).json({ error: 'Internal server error' });
  }
});




app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
