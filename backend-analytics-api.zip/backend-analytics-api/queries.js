const BUNDLE_ID = '1'; // Assuming you have a constant BUNDLE_ID

 export const COIN_PRICE_QUERY = (block) => {
  return block
    ? `
      query {
        bundles(where: { id: ${BUNDLE_ID} }, block: {number: ${block}}) {
          id
          ethPrice
        }
      }
    `
    : `
      query {
        bundles(where: { id: ${BUNDLE_ID} }) {
          id
          ethPrice
        }
      }
    `;
};


export const GET_BLOCK_FROM_TIMESTAMP_QUERY = (timestamp) => {
  return `
    query {
      blocks(first: 1, orderBy: timestamp, orderDirection: desc, where: { timestamp_lte: ${timestamp} }) {
        id
        number
        timestamp
      }
    }
  `;
};


export const TOKEN_BASE_STATS_QUERY = (TOKEN_ID) => {

  // let dateFilter = '';

  // if (timeFrame === 'year') {
  //   const oneYearAgo = new Date(new Date().setFullYear(new Date().getFullYear() - 1)).toISOString().slice(0, 10);
  //   dateFilter = `where: {date_gte: "${oneYearAgo}"}`;
  // } else if (timeFrame === 'day') {
  //   const oneDayAgo = new Date(new Date().setDate(new Date().getDate() - 1)).toISOString().slice(0, 10);
  //   dateFilter = `where: {date_gte: "${oneDayAgo}"}`;
  // } // 'current' implies no date filter

  return `
    query {
      tokens(where: {id: "${TOKEN_ID}"}) {
        tradeVolume
        totalSupply
        symbol
        name
      }
    }
  `;
};


export const TOKEN_DAILY_STATS_QUERY = (tokenID, timeFrame, numRecords = 0, orderDirection = 'desc') => {
 
 
  let dateFilter = '';
  // Determine the date filter based on the timeFrame parameter
  if (timeFrame === 'year') {
    const oneYearAgo = Math.floor(new Date().setFullYear(new Date().getFullYear() - 1) / 1000);
    dateFilter = `date_gte: ${oneYearAgo}, `;
  } else if (timeFrame === 'month') {
    const oneMonthAgo = Math.floor(new Date().setMonth(new Date().getMonth() - 1) / 1000);
    dateFilter = `date_gte: ${oneMonthAgo}, `;
  } else if (timeFrame === 'week') {
    const oneWeekAgo = Math.floor(new Date().setDate(new Date().getDate() - 7) / 1000);
    dateFilter = `date_gte: ${oneWeekAgo}, `;
  } else if (timeFrame === 'day') {
    const oneDayAgo = Math.floor(new Date().setDate(new Date().getDate() - 1) / 1000);
    dateFilter = `date_gte: ${oneDayAgo}, `;
  } // 'current' or no input implies no date filter

  // Conditionally include the `first` argument
  const firstArgument = numRecords > 0 ? `first: ${numRecords}` : '';

  // Constructing the GraphQL query
  return `
    query {
      token(id: "${tokenID}") {
        id
        name
        symbol
        tokenDayData(
          where: { ${dateFilter} }
          ${firstArgument}
          orderBy: date
          orderDirection: ${orderDirection}
        ) {
          id
          dailyVolumeUSD
          date
          priceUSD
          totalLiquidityUSD
        }
      }
    }
  `;
};





export const ETH_MARKET_STATS_QUERY = (tokenID, orderDirection = 'desc') => {

  const oneDayAgo = Math.floor(new Date().setDate(new Date().getDate() - 1) / 1000);
  const dateFilter = `timestamp_gte: ${oneDayAgo}, `;

  // Constructing the GraphQL query
  return `
    query MyQuery {
      swaps(
        where: { 
          ${dateFilter}
          pair_: { token1: "${tokenID}" }
        } 
        orderBy: timestamp
        orderDirection: ${orderDirection}
      ) {
        timestamp
        pair {
          totalVolumeUSD: volumeUSD
          priceETH: token0Price
          token1 {
            tokenSymbol: symbol
            totalTradeVolumeUSD: tradeVolumeUSD
            tokenID: id
            supplyTotal: totalSupply
            untrackedVolumeUSD: untrackedVolumeUSD
            totalTradeVolume: tradeVolume
          }
        }
      }
    }
  `;
};



export const TOKEN_MARKET_STATS_QUERY = (
  token0ID,
  token1ID,
  priceTokenID, // New parameter for the token used to fetch the price
  block, // Required block parameter
  orderDirection = 'desc',
  selectedToken = 'token0'
) => {
  // Ensure that the selectedToken is either 'token0' or 'token1'
  const tokenAlias = selectedToken;

  // Determine which price field to use based on the priceTokenID
  const priceField = priceTokenID === 'token0' ? 'token0Price' : 'token1Price';

  // Constructing the GraphQL query with the block parameter
  return `
    query MyQuery {
      swaps(
        where: { 
          pair_: {
            token0: "${token0ID}",
            token1: "${token1ID}"
          }
        } 
        orderBy: timestamp
        orderDirection: ${orderDirection}
        block: { number: ${block} }
      ) {
        timestamp
        pair {
        
          price: ${priceField}
          tokens: ${tokenAlias} {
            tokenSymbol: symbol
         
            tokenID: id
            supplyTotal: totalSupply
           
            totalTradeVolume: tradeVolume
          }
        }
      }
    }
  `;
};


// export const TOKEN_MARKET_STATS_QUERY = (
//   token0ID,
//   token1ID,
//   priceTokenID, // New parameter for the token used to fetch the price
//   days = 1,
//   orderDirection = 'desc',
//   selectedToken = 'token0'
// ) => {
//   const startTime = Math.floor(new Date().getTime() / 1000) - days * 86400;
//   const dateFilter = `timestamp_gte: ${startTime}, `;

//   // Ensure that the selectedToken is either 'token0' or 'token1'
//   const tokenAlias = selectedToken ;

//   // Determine which price field to use based on the priceTokenID
//   const priceField = priceTokenID === 'token0' ? 'token0Price' : 'token1Price';
  
//   // Constructing the GraphQL query
//   return `
//     query MyQuery {
//       swaps(
//         where: { 
//           ${dateFilter}
//           pair_: {
//             token0: "${token0ID}",
//             token1: "${token1ID}"
//           }
//         } 
//         orderBy: timestamp
//         orderDirection: ${orderDirection}
//       ) {
//         timestamp
//         pair {
//           totalVolumeUSD: volumeUSD
//           price:${priceField}
//           tokens: ${tokenAlias} {
//             tokenSymbol: symbol
//             totalTradeVolumeUSD: tradeVolumeUSD
//             tokenID: id
//             supplyTotal: totalSupply
//             untrackedVolumeUSD: untrackedVolumeUSD
//             totalTradeVolume: tradeVolume
//           }
//         }
//       }
//     }
//   `;
// };



export const TOKEN_PAIR_VALIDATION_QUERY = (token0ID, token1ID, block = null) => {
  // Construct the block parameter string if block number is provided
  const blockString = block ? `block: { number: ${block} }` : '';

  return `
    query {
      pairs(
        where: {
          token0: "${token0ID}",
          token1: "${token1ID}"
        }
        ${blockString}  
      ) {
        id
        token0Price
        token1Price
        token0 {
          id
          symbol
        }
        token1 {
          id
          symbol
        }
        reserve0
        reserve1
      }
    }
  `;
};



export const USER_TOKEN_INFO_QUERY = (tokenID, userAddress) => {
  return `
    query {
      token(id: "${tokenID}") {
        id
        symbol
        name
      }
      user(id: "${userAddress}") {
        balances(where: { token: "${tokenID}" }) {
          balance
        }
      }
    }
  `;
};



