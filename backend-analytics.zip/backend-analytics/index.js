import dotenv from 'dotenv';
dotenv.config();
import express from 'express';
import { getCoinPrice } from './utils.js'; // Ensure the file extension is specified if necessary

const app = express();
const PORT = process.env.PORT || 4000;

app.use(express.json());

// THIS FUNCTION WILL RETURN NATIVE COIN PRICE 

app.post('/coinPrice', async (req, res) => {
    const block = req.body.block || ''; // Assume getCoinPrice is an asynchronous function fetching price data

  try {
    const data = await getCoinPrice(block);
    if (data && data.bundles) {
      res.json(data.bundles.map(bundle => ({ id: bundle.id, coinPrice: bundle.ethPrice })));
    } else {
      res.status(404).send('No data found');
    }
  } catch (error) {
    if (error.message === 'Failed to fetch data') {
      res.status(502).send('Bad Gateway Error');
    } else {
      res.status(503).send('Service Unavailable');
    }
  }
});




app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
