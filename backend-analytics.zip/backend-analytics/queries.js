const BUNDLE_ID = '1'; // Assuming you have a constant BUNDLE_ID

 export const COIN_PRICE_QUERY = (block) => {
  return block
    ? `
      query {
        bundles(where: { id: ${BUNDLE_ID} }, block: {number: ${block}}) {
          id
          ethPrice
        }
      }
    `
    : `
      query {
        bundles(where: { id: ${BUNDLE_ID} }) {
          id
          ethPrice
        }
      }
    `;
};


