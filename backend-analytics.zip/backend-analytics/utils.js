import fetch from 'node-fetch';
import { COIN_PRICE_QUERY } from './queries.js';  // Make sure the file extension is correctly specified

const fetchGraphQL = async (query) => {
  try {
    const response = await fetch(process.env.GRAPH_SUBGRAPH_CLIENT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({ query })
    });

    const { data, errors } = await response.json();
    if (errors) {
      console.error(errors);
      throw new Error('Failed to fetch data');
    }
    return data;
  } catch (error) {
    console.error('Network error:', error);
    throw new Error('Network error');
  }
};

 export const getCoinPrice = async (block) => {
  const query = COIN_PRICE_QUERY(block);
  return await fetchGraphQL(query);
};


