"use client";

import { createAppKit } from "@reown/appkit/react";
import { EthersAdapter } from "@reown/appkit-adapter-ethers";
import { type ReactNode } from "react";
import {
  ALL_APPKIT_CHAINS,
  DEFAULT_NETWORK,
} from "@/lib/networkConfig";

// ── AppKit initialization ───────────────────────────────────────────
const projectId = process.env.NEXT_PUBLIC_REOWN_PROJECT_ID ?? "";

if (projectId && ALL_APPKIT_CHAINS.length > 0) {
  createAppKit({
    adapters: [new EthersAdapter()],
    networks: ALL_APPKIT_CHAINS as [typeof ALL_APPKIT_CHAINS[0], ...typeof ALL_APPKIT_CHAINS],
    defaultNetwork: DEFAULT_NETWORK.appKitChain,
    projectId,
    metadata: {
      name: "RESVA Presale",
      description: "Premium DeFi Presale & Lending Portal",
      url: typeof window !== "undefined" ? window.location.origin : "https://resva.io",
      icons: ["/brand/resva-logo-transparent.png"],
    },

    // ── Feature toggles ─────────────────────────────────────────────
    features: {
      analytics: false,
      email: false,
      socials: false,
      swaps: false,
      onramp: false,
    },

    // ── Featured wallets ────────────────────────────────────────────
    featuredWalletIds: [
      "c57ca95b47569778a828d19178114f4db188b89b763c899ba0be274e97267d96", // MetaMask
      "4622a2b2d6af1c9844944291e5e7351a6aa24cd7b23099efac1b2fd875da31a0", // Trust Wallet
      "8a0ee50d1f22f6651afcae7eb4253e52a3310b90af5daef78a8c4929a9bb99d4", // Binance Web3 Wallet
      "20459438007b75f4f4acb98bf29aa3b800550571e8c22f8850cfc3f7e2e3f2f7", // TokenPocket
      "225affb176778569276e484e1b92637ad061b01e13a048b35a9d280c0b58970c", // SafePal
      "fd20dc426fb37566d803205b19bbc1d4096b248ac04548e18e93c30f6b884cd8", // Coinbase Wallet
    ],

    // ── Premium dark theme matching RESVA branding ──────────────────
    themeMode: "dark",
    themeVariables: {
      "--w3m-accent": "#f59e0b",
      "--w3m-color-mix": "#0c0a09",
      "--w3m-color-mix-strength": 40,
      "--w3m-font-family": "Inter, system-ui, -apple-system, sans-serif",
      "--w3m-border-radius-master": "2px",
      "--w3m-z-index": 100,
    },
  });
}

// ── Provider component (just needs to exist so the import runs) ─────
export default function Web3ModalProvider({ children }: { children: ReactNode }) {
  return <>{children}</>;
}
