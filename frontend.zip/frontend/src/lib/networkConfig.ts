import { defineChain } from "@reown/appkit/networks";

// ─────────────────────────────────────────────────────────────────────
//  Network Configuration — single source of truth for all chains
// ─────────────────────────────────────────────────────────────────────

export interface NetworkMeta {
  /** Unique chain ID */
  chainId: number;
  /** CAIP-2 identifier, e.g. "eip155:1" */
  caipNetworkId: string;
  /** Human-readable name */
  name: string;
  /** Short label for pills / badges */
  shortName: string;
  /** Is this a testnet? */
  isTestnet: boolean;
  /** Native gas token */
  nativeCurrency: { name: string; symbol: string; decimals: number };
  /** Default RPC URL */
  rpcUrl: string;
  /** Block explorer base URL */
  explorerUrl: string;
  /** Presale contract address on this chain (empty if not deployed) */
  contractAddress: string;
  /** Emoji icon for quick identification */
  icon: string;
  /** AppKit-compatible chain definition (created by defineChain) */
  appKitChain: ReturnType<typeof defineChain>;
}

// ── Helper ──────────────────────────────────────────────────────────
function buildNetwork(
  opts: Omit<NetworkMeta, "appKitChain">,
): NetworkMeta {
  return {
    ...opts,
    appKitChain: defineChain({
      id: opts.chainId,
      caipNetworkId: opts.caipNetworkId as `eip155:${number}`,
      chainNamespace: "eip155",
      name: opts.name,
      nativeCurrency: opts.nativeCurrency,
      rpcUrls: { default: { http: [opts.rpcUrl] } },
      blockExplorers: {
        default: { name: opts.shortName + " Explorer", url: opts.explorerUrl },
      },
    }),
  };
}

// ── Env-based lookup ───────────────────────────────────────────────
function getContractForChain(chainId: number): string {
  switch (chainId) {
    case 1: return process.env.NEXT_PUBLIC_CONTRACT_1 || "";
    case 11155111: return process.env.NEXT_PUBLIC_CONTRACT_11155111 || "";
    case 56: return process.env.NEXT_PUBLIC_CONTRACT_56 || "";
    case 97: return process.env.NEXT_PUBLIC_CONTRACT_97 || "";
    case 137: return process.env.NEXT_PUBLIC_CONTRACT_137 || "";
    case 8453: return process.env.NEXT_PUBLIC_CONTRACT_8453 || "";
    case 42161: return process.env.NEXT_PUBLIC_CONTRACT_42161 || "";
    default: return "";
  }
}

function getPaymentTokensForChain(chainId: number): string[] {
  // Try per-chain env first, fallback to the general one for backward compatibility
  const perChain = process.env[`NEXT_PUBLIC_PAYMENT_TOKENS_${chainId}`];
  if (perChain) return perChain.split(",").filter(Boolean).map(t => t.toLowerCase().trim());
  
  if (chainId === 97 && process.env.NEXT_PUBLIC_SALE_PAYMENT_TOKENS) {
    return process.env.NEXT_PUBLIC_SALE_PAYMENT_TOKENS.split(",").filter(Boolean).map(t => t.toLowerCase().trim());
  }
  return [];
}

function getTokenLabelsForChain(chainId: number): Record<string, string> {
  const labels: Record<string, string> = {};
  const perChain = process.env[`NEXT_PUBLIC_TOKEN_LABELS_${chainId}`] || 
                   (chainId === 97 ? process.env.NEXT_PUBLIC_SALE_TOKEN_LABELS : "");
  
  if (perChain) {
    perChain.split(",").forEach((pair) => {
      const [addr, label] = pair.split(":");
      if (addr && label) labels[addr.toLowerCase().trim()] = label.trim();
    });
  }
  return labels;
}

export interface NetworkMeta {
  chainId: number;
  caipNetworkId: string;
  name: string;
  shortName: string;
  isTestnet: boolean;
  nativeCurrency: { name: string; symbol: string; decimals: number };
  rpcUrl: string;
  explorerUrl: string;
  contractAddress: string;
  paymentTokens: string[];
  tokenLabels: Record<string, string>;
  icon: string;
  appKitChain: ReturnType<typeof defineChain>;
}// ── All supported networks ──────────────────────────────────────────
export const SUPPORTED_NETWORKS: NetworkMeta[] = [
  // ── Ethereum ────────────────────────────────────────────────────
  buildNetwork({
    chainId: 1,
    caipNetworkId: "eip155:1",
    name: "Ethereum Mainnet",
    shortName: "ETH",
    isTestnet: false,
    nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
    rpcUrl: "https://eth.llamarpc.com",
    explorerUrl: "https://etherscan.io",
    contractAddress: getContractForChain(1),
    paymentTokens: getPaymentTokensForChain(1),
    tokenLabels: getTokenLabelsForChain(1),
    icon: "eth",
  }),
  buildNetwork({
    chainId: 11155111,
    caipNetworkId: "eip155:11155111",
    name: "Ethereum Sepolia",
    shortName: "Sepolia",
    isTestnet: true,
    nativeCurrency: { name: "Sepolia ETH", symbol: "SepoliaETH", decimals: 18 },
    rpcUrl: "https://rpc.sepolia.org",
    explorerUrl: "https://sepolia.etherscan.io",
    contractAddress: getContractForChain(11155111),
    paymentTokens: getPaymentTokensForChain(11155111),
    tokenLabels: getTokenLabelsForChain(11155111),
    icon: "eth",
  }),

  // ── BNB Smart Chain ─────────────────────────────────────────────
  buildNetwork({
    chainId: 56,
    caipNetworkId: "eip155:56",
    name: "BNB Smart Chain",
    shortName: "BSC",
    isTestnet: false,
    nativeCurrency: { name: "BNB", symbol: "BNB", decimals: 18 },
    rpcUrl: "https://bsc-dataseed.binance.org",
    explorerUrl: "https://bscscan.com",
    contractAddress: getContractForChain(56),
    paymentTokens: getPaymentTokensForChain(56),
    tokenLabels: getTokenLabelsForChain(56),
    icon: "bnb",
  }),
  buildNetwork({
    chainId: 97,
    caipNetworkId: "eip155:97",
    name: "BSC Testnet",
    shortName: "BSC-T",
    isTestnet: true,
    nativeCurrency: { name: "Test BNB", symbol: "tBNB", decimals: 18 },
    rpcUrl: "https://bsc-testnet-rpc.publicnode.com",
    explorerUrl: "https://testnet.bscscan.com",
    contractAddress: getContractForChain(97),
    paymentTokens: getPaymentTokensForChain(97),
    tokenLabels: getTokenLabelsForChain(97),
    icon: "bnb",
  }),
];

// ── Lookup helpers ──────────────────────────────────────────────────
/** Map chainId → NetworkMeta for O(1) lookups */
export const NETWORK_MAP = new Map<number, NetworkMeta>(
  SUPPORTED_NETWORKS.map((n) => [n.chainId, n]),
);

/** Get network config by chainId (undefined if unsupported) */
export function getNetworkByChainId(chainId: number | undefined): NetworkMeta | undefined {
  if (!chainId) return undefined;
  return NETWORK_MAP.get(chainId);
}

/** Default chain ID from env, fallback to BSC Testnet (97) */
export const DEFAULT_CHAIN_ID = Number(
  process.env.NEXT_PUBLIC_DEFAULT_CHAIN_ID ?? "97",
);

/** The default network config */
export const DEFAULT_NETWORK =
  NETWORK_MAP.get(DEFAULT_CHAIN_ID) ?? SUPPORTED_NETWORKS.find((n) => n.chainId === 97)!;

/** All AppKit chain definitions (for createAppKit registration) */
export const ALL_APPKIT_CHAINS = SUPPORTED_NETWORKS.map((n) => n.appKitChain);

/** Only networks that have a deployed contract */
export const NETWORKS_WITH_CONTRACT = SUPPORTED_NETWORKS.filter(
  (n) => !!n.contractAddress,
);
