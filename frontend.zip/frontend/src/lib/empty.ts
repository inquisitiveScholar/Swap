// This file is intentionally empty — used as a browser-side stub for Node.js
// built-in modules that WalletConnect / Reown packages reference but never
// actually use in the browser.
export {};
