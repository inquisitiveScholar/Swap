import { formatEther } from "ethers";

export function toShortAddress(address: string) {
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function formatDisplay(amount: bigint, decimals = 4) {
  const value = Number(formatEther(amount || 0n));
  if (!Number.isFinite(value)) return "0";
  return value.toLocaleString("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  });
}

export function humanizeError(error: any) {
  // Convert the error object to a string safely
  let errorString = "";
  console.log("[RESVA] Humanizing Error. Raw Data:", error);
  try {
    const cache = new Set();
    errorString = JSON.stringify(error, (key, value) => {
      if (typeof value === "object" && value !== null) {
        if (cache.has(value)) return;
        cache.add(value);
      }
      return value;
    }).toLowerCase();
  } catch (e) {
    errorString = (String(error?.message || "") + " " + String(error || "")).toLowerCase();
  }

  // Merge important plain-text fields because Error objects often stringify to "{}".
  const rawMsg = error?.message || String(error);
  errorString = `${errorString} ${String(rawMsg || "")} ${String(error?.reason || "")}`.toLowerCase();

  // 0. High-Specificity Diagnostic Pass-through
  if (rawMsg.includes("Account Mismatch") || rawMsg.includes("contact Admin") || rawMsg.includes("LOCAL_VALIDATION_ERROR")) {
    return rawMsg;
  }

  // 1. Check for specific contract custom error selectors (must match on-chain contract)
  if (errorString.includes("0x584a7938") || errorString.includes("notwhitelisted")) 
    return "Your wallet is not whitelisted. The Admin must add your address to the whitelist first.";
  if (errorString.includes("0xb7b24097") || errorString.includes("salenotactive")) 
    return "The presale is not currently active. Please wait for the start time or check if it has ended.";
  if (errorString.includes("0xc1d315bc") || errorString.includes("contributionoutofrange")) 
    return "The amount is outside the allowed limits. Check your minimum and maximum allocation.";
  if (errorString.includes("0x3895e792") || errorString.includes("hardcapexceeded")) 
    return "The hard cap for this sale has been reached. No more tokens can be purchased.";
  if (errorString.includes("0x9d98b04b") || errorString.includes("salenotended")) 
    return "The sale has not ended. You can only claim or refund once the sale is officially over.";
  if (errorString.includes("0x2c5211c6") || errorString.includes("invalidamount")) 
    return "Invalid purchase amount. Ensure you have enough balance and meet the sale requirements.";
  if (errorString.includes("0x2bdc91ad") || errorString.includes("softcapnotreached")) 
    return "The soft cap hasn't been met yet. Claiming tokens is currently disabled.";
  if (errorString.includes("0xd92e233d") || errorString.includes("zeroaddress"))
    return "A required address field is missing or invalid.";

  // 2. Map standard RPC/Wallet errors to human phrases
  if (errorString.includes("user rejected") || errorString.includes("action_rejected")) 
    return "Transaction was cancelled in your wallet.";
  if (errorString.includes("insufficient funds")) 
    return "You don't have enough balance to cover the purchase and gas fees.";
  if (errorString.includes("exceeds max contribution")) 
    return "This amount would exceed your total allowed contribution limit.";
  if (errorString.includes("paused")) 
    return "The sale is currently paused by the administrator.";
  if (errorString.includes("ownable") || errorString.includes("not the owner")) 
    return "Access Denied: This action can only be performed by the contract owner.";
  if (errorString.includes("chain") || errorString.includes("network")) 
    return "Wrong Network: Please switch your wallet to the correct blockchain.";
  if (errorString.includes("nonce")) 
    return "Your wallet's transaction count is out of sync. Please try again or reset your wallet.";
  if (errorString.includes("replacement fee too low") || errorString.includes("intrinsic gas")) 
    return "Gas settings are too low. Please increase the gas limit in your wallet.";
  if (errorString.includes("timeout") || errorString.includes("timed out"))
    return "Connection timed out. Please check your internet or unlock your wallet extension.";
  if (errorString.includes("failed to fetch") || errorString.includes("network error"))
    return "Network error. The blockchain node is unresponsive. Please try again in a moment.";

  // 3. Extract any hex code for debugging if no match found
  const hexMatch = errorString.match(/0x[0-9a-f]{8}/);
  const hexCode = hexMatch ? ` (Error Code: ${hexMatch[0]})` : "";

  // 4. Last-resort fallback: only return the message if it's clearly non-technical
  const msg = error?.reason || error?.message || "";
  const isTechnical = /[{}[]_()]/.test(msg) || msg.includes("0x") || msg.includes("revert");
  
  if (msg && msg.length < 120 && !isTechnical) {
    return msg + hexCode;
  }

  return `The transaction could not be completed${hexCode}. Please ensure you are whitelisted, have enough funds, and the sale is active.`;
}
