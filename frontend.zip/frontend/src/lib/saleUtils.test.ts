import { describe, expect, it } from "vitest";
import { formatDisplay, humanizeError, toShortAddress } from "./saleUtils";

describe("saleUtils", () => {
  it("shortens an address for compact display", () => {
    expect(toShortAddress("0x1234567890abcdef1234567890abcdef12345678")).toBe("0x1234...5678");
  });

  it("formats wei amounts to readable values", () => {
    expect(formatDisplay(1_234_567_000_000_000_000n, 3)).toBe("1.235");
  });

  it("maps known contract and wallet errors to friendly messages", () => {
    expect(humanizeError(new Error("execution reverted: NotWhitelisted"))).toBe(
      "Your wallet is not whitelisted. The Admin must add your address to the whitelist first.",
    );
    expect(humanizeError(new Error("execution reverted with custom error 0xc1d315bc"))).toBe(
      "The amount is outside the allowed limits. Check your minimum and maximum allocation.",
    );
    expect(humanizeError(new Error("execution reverted with custom error 0x584a7938"))).toBe(
      "Your wallet is not whitelisted. The Admin must add your address to the whitelist first.",
    );
    expect(humanizeError(new Error("user rejected request"))).toBe(
      "Transaction was cancelled in your wallet.",
    );
    expect(humanizeError(new Error("execution reverted: OwnableUnauthorizedAccount"))).toBe(
      "Access Denied: This action can only be performed by the contract owner.",
    );
    expect(humanizeError(new Error("random rpc failure"))).toBe(
      "random rpc failure",
    );
  });
});
