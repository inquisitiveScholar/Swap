"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { BrowserProvider, Contract, formatEther, formatUnits, parseEther, parseUnits } from "ethers";
import { privateSaleAbi } from "@/lib/privateSaleAbi";
import { formatDisplay, humanizeError, toShortAddress } from "@/lib/saleUtils";
import Link from "next/link";
import Image from "next/image";
import { useAppKit, useAppKitAccount, useAppKitNetwork, useAppKitProvider, useDisconnect } from "@reown/appkit/react";
import type { Provider } from "@reown/appkit-adapter-ethers";
import { 
  SUPPORTED_NETWORKS, 
  getNetworkByChainId, 
  DEFAULT_NETWORK,
  DEFAULT_CHAIN_ID,
  NETWORKS_WITH_CONTRACT
} from "@/lib/networkConfig";

type TxState = "idle" | "pending" | "success" | "failed";
const ZERO_ADDRESS = "0x0000000000000000000000000000000000000000";

type SaleSnapshot = {
  owner: string;
  whitelistStatus: boolean;
  contribution: bigint;
  paymentContribution: bigint;
  purchasedTokens: bigint;
  claimedTokens: bigint;
  claimable: bigint;
  tokenPriceInWei: bigint;
  totalRaised: bigint;
  softCap: bigint;
  hardCap: bigint;
  saleStart: bigint;
  saleEnd: bigint;
  tgeTime: bigint;
  cliff: bigint;
  vesting: bigint;
  saleConfigured: boolean;
  isPaused: boolean;
  minContribution: bigint;
  maxContribution: bigint;
  customMaxContribution: bigint;
  paymentTokenEnabled: boolean;
  paymentTokenPrice: bigint; // price in native-equivalent units
  paymentTokenDecimals: number;
};

const ZERO_SNAPSHOT: SaleSnapshot = {
  owner: "",
  whitelistStatus: false,
  contribution: 0n,
  paymentContribution: 0n,
  purchasedTokens: 0n,
  claimedTokens: 0n,
  claimable: 0n,
  tokenPriceInWei: 0n,
  totalRaised: 0n,
  softCap: 0n,
  hardCap: 0n,
  saleStart: 0n,
  saleEnd: 0n,
  tgeTime: 0n,
  cliff: 0n,
  vesting: 0n,
  saleConfigured: false,
  isPaused: false,
  minContribution: 0n,
  maxContribution: 0n,
  customMaxContribution: 0n,
  paymentTokenEnabled: true,
  paymentTokenPrice: 10n ** 18n, // Default to 1:1 for native
  paymentTokenDecimals: 18,
};

/** Safely call a contract read — returns fallback on revert instead of throwing. */
async function safeRead<T>(fn: () => Promise<T>, fallback: T): Promise<T> {
  try { return await fn(); } catch { return fallback; }
}

function TokenIcon({ symbol, className = "h-5 w-5" }: { symbol: string; className?: string }) {
  const s = symbol.toLowerCase();
  if (s.includes("usdt")) {
    return (
      <svg className={className} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="16" cy="16" r="16" fill="#26A17B"/>
        <path d="M17.922 17.383v-.002c-.017.008-.67.311-1.888.311-1.107 0-1.758-.273-1.832-.304v.001c-3.132-.143-5.465-.724-5.465-1.42 0-.694 2.333-1.275 5.465-1.42v2.247c.18.067.753.262 1.832.262 1.054 0 1.637-.182 1.888-.262v-2.247c3.132.145 5.465.726 5.465 1.42 0 .694-2.333 1.275-5.465 1.422zM16.034 13.91c-3.414 0-6.183-.69-6.183-1.539 0-.85 2.769-1.539 6.183-1.539 3.413 0 6.183.69 6.183 1.539 0 .85-2.77 1.539-6.183 1.539zM17.922 18.066c3.132.143 5.465.724 5.465 1.42 0 .696-2.333 1.277-5.465 1.421v-.001c-.017.008-.67.311-1.888.311-1.107 0-1.758-.273-1.832-.304v.002c-3.132-.145-5.465-.726-5.465-1.422 0-.696 2.333-1.277 5.465-1.421V18.1c.18.067.753.262 1.832.262 1.054 0 1.637-.182 1.888-.262v-.034z" fill="white"/>
      </svg>
    );
  }
  if (s.includes("usdc")) {
    return (
      <svg className={className} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="16" cy="16" r="16" fill="#2775CA"/>
        <path d="M16 4C9.37 4 4 9.37 4 16s5.37 12 12 12 12-5.37 12-12S22.63 4 16 4zm0 21.6c-5.3 0-9.6-4.3-9.6-9.6S10.7 6.4 16 6.4s9.6 4.3 9.6 9.6-4.3 9.6-9.6 9.6z" fill="white"/>
        <path d="M19.1 19.3c-1.2.6-2.7.9-3.7.9-2.9 0-4.8-1.7-4.8-4.2s1.9-4.2 4.8-4.2c1.1 0 2.5.3 3.7.9l.6-2.1c-1.3-.6-2.8-.9-4.3-.9-4.3 0-7.3 2.6-7.3 6.3s3 6.3 7.3 6.3c1.5 0 3-.3 4.3-.9l-.6-2.1z" fill="white"/>
      </svg>
    );
  }
  if (s.includes("dai")) {
    return (
      <svg className={className} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="16" cy="16" r="16" fill="#F5AC37"/>
        <path d="M16 6c-5.523 0-10 4.477-10 10s4.477 10 10 10 10-4.477 10-10-4.477-10-10-10zm0 18c-4.418 0-8-3.582-8-8s3.582-8 8-8 8 3.582 8 8-3.582 8-8 8z" fill="white"/>
        <path d="M11 15h10v2H11v-2z" fill="white"/>
        <path d="M11 11h10v2H11v-2z" fill="white"/>
      </svg>
    );
  }
  return (
    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-white/10 text-[10px] font-black text-slate-300">
      {symbol[0].toUpperCase()}
    </div>
  );
}

function NetworkIcon({ type, className = "h-5 w-5" }: { type: string; className?: string }) {
  if (type === "eth") {
    return (
      <svg viewBox="0 0 256 417" className={className} xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid">
        <path fill="#343434" d="M127.961 0l-2.795 9.5v275.668l2.795 2.79 127.962-75.638z"/>
        <path fill="#8C8C8C" d="M127.962 0L0 212.32l127.962 75.639V154.158z"/>
        <path fill="#3C3C3B" d="M127.961 312.187l-1.575 1.92v98.199l1.575 4.59 128.038-180.32z"/>
        <path fill="#8C8C8C" d="M127.962 416.896V312.187L0 236.585z"/>
        <path fill="#141414" d="M127.961 287.958l127.96-75.637-127.96-58.162z"/>
        <path fill="#393939" d="M0 212.32l127.962 75.638V154.158z"/>
      </svg>
    );
  }
  if (type === "bnb") {
    return (
      <svg viewBox="0 0 2000 2000" className={className} xmlns="http://www.w3.org/2000/svg">
        <path fill="#F3BA2F" d="M1000 0C447.715 0 0 447.715 0 1000s447.715 1000 1000 1000 1000-447.715 1000-1000S1552.285 0 1000 0z"/>
        <path fill="#FFF" d="M642.857 857.143L1000 500l357.143 357.143L1500 1000l-142.857 142.857L1000 1500l-357.143-357.143L500 1000l142.857-142.857zM1000 1171.429L1171.429 1000 1000 828.571 828.571 1000 1000 1171.429z"/>
      </svg>
    );
  }
  return <span className="text-lg">🌐</span>;
}

export default function SalePage() {
  // ── AppKit hooks (standard multi-wallet modal) ──────────────────
  const { open } = useAppKit();
  const { address: appKitAddress, isConnected } = useAppKitAccount();
  const { walletProvider } = useAppKitProvider<Provider>("eip155");
  const { disconnect: appKitDisconnect } = useDisconnect();
  const { chainId: currentChainId, switchNetwork } = useAppKitNetwork();
  const [isMounted, setIsMounted] = useState(false);
  const normalizedChainId = useMemo(() => {
    if (typeof currentChainId === "string") {
      const parsed = Number(currentChainId);
      return Number.isFinite(parsed) ? parsed : undefined;
    }
    return currentChainId;
  }, [currentChainId]);

  // ── Network Detection ───────────────────────────────────────────
  const activeNetwork = useMemo(() => {
    return getNetworkByChainId(normalizedChainId) ?? DEFAULT_NETWORK;
  }, [normalizedChainId]);

  const displayNetwork = useMemo(() => (isMounted ? activeNetwork : DEFAULT_NETWORK), [isMounted, activeNetwork]);

  const saleAddress = activeNetwork.contractAddress;
  const walletAddress = appKitAddress ?? "";
  
  // We only show "Wrong Network" if they are connected to something not in our SUPPORTED_NETWORKS list
  const isSupported = useMemo(() => {
    return isConnected ? !!getNetworkByChainId(normalizedChainId) : true;
  }, [isConnected, normalizedChainId]);
  
  const isWrongNetwork = isConnected && !isSupported;
  const hasContract = !!saleAddress;

  const [saleData, setSaleData] = useState<SaleSnapshot>(ZERO_SNAPSHOT);
  const [buyAmount, setBuyAmount] = useState("");
  const [selectedPaymentToken, setSelectedPaymentToken] = useState("native");
  const [acceptedPaymentTokens, setAcceptedPaymentTokens] = useState<string[]>([]);
  const [paymentTokenMeta, setPaymentTokenMeta] = useState<Record<string, { symbol: string; decimals: number }>>({});
  const [userContributionsByToken, setUserContributionsByToken] = useState<Record<string, bigint>>({});
  const [txState, setTxState] = useState<TxState>("idle");
  const [txMessage, setTxMessage] = useState("");
  const [txHash, setTxHash] = useState("");
  const [isSelectorOpen, setIsSelectorOpen] = useState(false);
  const [isNetworkSelectorOpen, setIsNetworkSelectorOpen] = useState(false);
  const [adminWhitelistInput, setAdminWhitelistInput] = useState("");
  const [adminRemoveWhitelistInput, setAdminRemoveWhitelistInput] = useState("");
  const [adminPaymentToken, setAdminPaymentToken] = useState("");
  const [adminPaymentEnabled, setAdminPaymentEnabled] = useState(true);
  const [adminWeiPerUnit, setAdminWeiPerUnit] = useState("");
  const [adminInvestorAddress, setAdminInvestorAddress] = useState("");
  const [adminInvestorMaxWei, setAdminInvestorMaxWei] = useState("");
  const [userBalance, setUserBalance] = useState<bigint>(0n);
  const [selectedTokenDecimals, setSelectedTokenDecimals] = useState(18);
  const [adminSaleStart, setAdminSaleStart] = useState("");
  const [adminSaleEnd, setAdminSaleEnd] = useState("");
  const [adminTge, setAdminTge] = useState("");
  const [adminCliff, setAdminCliff] = useState("");
  const [adminVesting, setAdminVesting] = useState("");
  const [nowUnix, setNowUnix] = useState(0);
  const refreshInFlight = useRef(false);

  useEffect(() => {
    setIsMounted(true);
    setNowUnix(Math.floor(Date.now() / 1000));
    const interval = setInterval(() => {
      setNowUnix(Math.floor(Date.now() / 1000));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const saleInfoReady = !!walletAddress && !!saleAddress && isConnected && !isWrongNetwork;

  useEffect(() => {
    if (isMounted) {
      console.log(`[RESVA] Connectivity Status:
        Connected: ${isConnected}
        Address: ${walletAddress.slice(0,6)}...
        Contract: ${saleAddress}
        WrongNetwork: ${isWrongNetwork}
        Ready: ${saleInfoReady}
      `);
    }
  }, [isConnected, walletAddress, saleAddress, isWrongNetwork, saleInfoReady, isMounted]);

  // ── Auto-switch to the default chain if not on any supported chain ──
  useEffect(() => {
    if (isConnected && isWrongNetwork) {
      console.log("[RESVA] Unsupported network. Switching to default:", DEFAULT_NETWORK.name);
      switchNetwork(DEFAULT_NETWORK.appKitChain);
    }
  }, [isConnected, isWrongNetwork, switchNetwork]);

  const getActiveProvider = useCallback(() => {
    if (!walletProvider) throw new Error("No wallet connected. Please connect your wallet.");
    return walletProvider;
  }, [walletProvider]);

  // ── Contract helpers (use AppKit provider) ────────────────────────
  const getReadContract = useCallback(async () => {
    if (!saleAddress) throw new Error(`Presale contract is not configured for ${activeNetwork.name}.`);
    const provider = new BrowserProvider(getActiveProvider());
    const contract = new Contract(saleAddress, privateSaleAbi, provider);
    return { contract };
  }, [getActiveProvider, saleAddress, activeNetwork]);

  const getWriteContract = useCallback(async () => {
    if (!saleAddress) throw new Error(`Presale contract is not configured for ${activeNetwork.name}.`);
    console.log("[RESVA] Initializing write contract...");
    const activeProv = getActiveProvider();
    const provider = new BrowserProvider(activeProv);
    
    // Signer request can sometimes hang if wallet is busy
    const signerPromise = provider.getSigner();
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error("Wallet connection timed out. Please unlock your wallet and try again.")), 10000)
    );
    
    const signer = (await Promise.race([signerPromise, timeoutPromise])) as Awaited<ReturnType<typeof provider.getSigner>>;
    console.log("[RESVA] Signer obtained");
    
    const contract = new Contract(saleAddress, privateSaleAbi, signer);
    return { contract, signer, provider };
  }, [saleAddress, activeNetwork, getActiveProvider]);

  const getTokenContract = useCallback(
    async (tokenAddress: string) => {
      const provider = new BrowserProvider(getActiveProvider());
      const signer = await provider.getSigner();
      return new Contract(
        tokenAddress,
        [
          "function allowance(address owner, address spender) view returns (uint256)",
          "function approve(address spender, uint256 amount) returns (bool)",
          "function balanceOf(address account) view returns (uint256)",
          "function decimals() view returns (uint8)",
          "function symbol() view returns (string)",
        ],
        signer,
      );
    },
    [getActiveProvider],
  );

  const paymentTokenAddress = useMemo(() => {
    if (selectedPaymentToken === "native") return ZERO_ADDRESS;
    return selectedPaymentToken;
  }, [selectedPaymentToken]);

  const refreshData = useCallback(async (addressOverride?: string) => {
    const user = addressOverride ?? walletAddress;
    if (!user || !saleAddress || refreshInFlight.current || !walletProvider) return;

    refreshInFlight.current = true;
    try {
      const { contract } = await getReadContract();

      // Explicitly check whitelist with NO safeRead fallback to avoid "False Negatives"
      const isSignerWhitelisted = await contract.whitelist(user).catch(err => {
        console.error("[RESVA] CRITICAL: Whitelist check failed on-chain:", err);
        return false; // Only default to false if the call ACTUALLY fails
      });

      const [owner, contribution, purchasedTokens, claimedTokens, claimable, tokenPriceInWei, totalRaised, softCap, hardCap, saleStart, saleEnd, tgeTime, cliff, vesting, saleConfigured, isPaused, minContribution, maxContribution, customMaxContribution, paymentContribution, paymentTokens, paymentOption] =
        await Promise.all([
          safeRead(() => contract.owner() as Promise<string>, ""),
          safeRead(() => contract.contributions(user) as Promise<bigint>, 0n),
          safeRead(() => contract.purchasedTokens(user) as Promise<bigint>, 0n),
          safeRead(() => contract.claimedTokens(user) as Promise<bigint>, 0n),
          safeRead(() => contract.claimableTokens(user) as Promise<bigint>, 0n),
          safeRead(() => contract.tokenPriceInWei() as Promise<bigint>, 0n),
          safeRead(() => contract.totalRaised() as Promise<bigint>, 0n),
          safeRead(() => contract.softCap() as Promise<bigint>, 0n),
          safeRead(() => contract.hardCap() as Promise<bigint>, 0n),
          safeRead(() => contract.saleStart() as Promise<bigint>, 0n),
          safeRead(() => contract.saleEnd() as Promise<bigint>, 0n),
          safeRead(() => contract.tgeTimestamp() as Promise<bigint>, 0n),
          safeRead(() => contract.cliffDuration() as Promise<bigint>, 0n),
          safeRead(() => contract.vestingDuration() as Promise<bigint>, 0n),
          safeRead(() => contract.saleConfigured() as Promise<boolean>, false),
          safeRead(() => contract.paused() as Promise<boolean>, false),
          safeRead(() => contract.minContribution() as Promise<bigint>, 0n),
          safeRead(() => contract.maxContribution() as Promise<bigint>, 0n),
          safeRead(() => contract.customMaxContribution(user) as Promise<bigint>, 0n),
          safeRead(() => contract.paymentContributions(user, paymentTokenAddress) as Promise<bigint>, 0n),
          safeRead(() => contract.getAcceptedPaymentTokens() as Promise<string[]>, [] as string[]),
          safeRead(() => contract.paymentOptions(paymentTokenAddress) as Promise<[boolean, bigint, number]>, [true, 10n**18n, 18] as any),
        ]);

      const normalizedTokens = (paymentTokens.length > 0 ? paymentTokens : [ZERO_ADDRESS]).map((token) =>
        token.toLowerCase(),
      );

      console.log(`[RESVA] Diagnostic Report for ${user}:
        - Contract: ${saleAddress}
        - Whitelisted: ${isSignerWhitelisted}
        - Contribution: ${contribution.toString()}
        - Sale End: ${new Date(Number(saleEnd) * 1000).toLocaleString()}
        - Payment Token: ${paymentLabel} (${paymentTokenAddress})
        - Token Price (Native): ${tokenPriceInWei.toString()}
        - Payment Token Price: ${paymentOption[1].toString()}
      `);

      // Fetch user balance and decimals based on selected token
      let balance = 0n;
      let decimals = 18;
      try {
        const provider = new BrowserProvider(walletProvider);
        if (selectedPaymentToken === "native") {
          balance = await provider.getBalance(user);
          decimals = 18;
        } else {
          const token = await getTokenContract(selectedPaymentToken);
          const [b, d] = await Promise.all([
            token.balanceOf(user),
            token.decimals()
          ]);
          balance = b;
          decimals = Number(d);
        }
      } catch (e) {
        console.log("[RESVA] Balance/Decimals fetch info:", e);
      }

      if (!owner) throw new Error("Could not read contract owner.");

      setUserBalance(balance);
      setSelectedTokenDecimals(decimals);
      setSaleData({
        owner,
        totalRaised,
        softCap,
        hardCap,
        saleStart,
        saleEnd,
        tgeTime,
        cliff,
        vesting,
        saleConfigured,
        isPaused,
        minContribution,
        maxContribution,
        customMaxContribution,
        paymentContribution,
        tokenPriceInWei,
        purchasedTokens,
        claimedTokens,
        claimable,
        contribution,
        paymentTokenEnabled: paymentOption[0],
        paymentTokenPrice: paymentOption[1],
        paymentTokenDecimals: Number(paymentOption[2]),
        whitelistStatus: isSignerWhitelisted,
      });
      setAcceptedPaymentTokens(normalizedTokens.filter((token) => token !== ZERO_ADDRESS));

      const provider = new BrowserProvider(walletProvider);
      const tokenRows = await Promise.all(
        normalizedTokens.map(async (token) => {
          const contributionRaw = await safeRead(
            () => contract.paymentContributions(user, token) as Promise<bigint>,
            0n,
          );
          if (token === ZERO_ADDRESS) {
            return {
              token,
              symbol: displayNetwork.nativeCurrency.symbol,
              decimals: 18,
              contributionRaw,
            };
          }
          try {
            const erc20 = new Contract(
              token,
              ["function symbol() view returns (string)", "function decimals() view returns (uint8)"],
              provider,
            );
            const [symbol, decimals] = await Promise.all([
              safeRead(() => erc20.symbol() as Promise<string>, tokenLabels[token] ?? "TOKEN"),
              safeRead(() => erc20.decimals() as Promise<number>, 18),
            ]);
            return { token, symbol, decimals: Number(decimals), contributionRaw };
          } catch {
            return {
              token,
              symbol: tokenLabels[token] ?? "TOKEN",
              decimals: 18,
              contributionRaw,
            };
          }
        }),
      );

      setPaymentTokenMeta(
        Object.fromEntries(tokenRows.map((row) => [row.token, { symbol: row.symbol, decimals: row.decimals }])),
      );
      setUserContributionsByToken(
        Object.fromEntries(tokenRows.map((row) => [row.token, row.contributionRaw])),
      );
      console.log(`[RESVA] Data fetched for ${activeNetwork.name}. Contract: ${saleAddress}`);
    } catch (error) {
      console.log("[RESVA] refreshData info:", error);
      // Keep read/refresh failures separate from transaction failure state.
      // Connection can succeed even when dashboard reads fail (e.g. wrong chain/RPC hiccups).
      setTxMessage((prev) =>
        prev ||
        `Wallet connected, but sale data could not be loaded yet (${humanizeError(error)}). Check selected network and try refresh.`,
      );
    } finally {
      refreshInFlight.current = false;
    }
  }, [getReadContract, paymentTokenAddress, saleAddress, walletAddress, walletProvider, selectedPaymentToken, getTokenContract]);

  // Refresh data when wallet connects / changes
  useEffect(() => {
    if (isConnected && walletAddress && saleAddress && walletProvider) {
      refreshData();
    }
  }, [isConnected, walletAddress, saleAddress, walletProvider, refreshData]);

  useEffect(() => {
    if (!saleInfoReady) return;
    const interval = setInterval(() => {
      if (typeof document !== "undefined" && document.visibilityState !== "visible") return;
      refreshData();
    }, 15000);

    return () => clearInterval(interval);
  }, [refreshData, saleInfoReady]);

  // Reset sale data when wallet disconnects or network has no contract
  useEffect(() => {
    if (!isConnected || !hasContract) {
      setSaleData(ZERO_SNAPSHOT);
      setTxState("idle");
      setTxMessage("");
    }
  }, [isConnected, hasContract]);

  const estimatedTokens = useMemo(() => {
    if (!buyAmount || !saleData.tokenPriceInWei) return "0";
    try {
      const units = parseUnits(buyAmount, selectedTokenDecimals);
      const weiEquivalent = (units * saleData.paymentTokenPrice) / (10n ** BigInt(selectedTokenDecimals));
      const tokenOut = (weiEquivalent * 10n ** 18n) / (saleData.tokenPriceInWei || 1n);
      return formatEther(tokenOut);
    } catch {
      return "0";
    }
  }, [buyAmount, saleData.tokenPriceInWei, selectedTokenDecimals, saleData.paymentTokenPrice]);

  const tokenLabels = useMemo(() => activeNetwork.tokenLabels, [activeNetwork.tokenLabels]);

  const paymentLabel = useMemo(() => {
    if (selectedPaymentToken === "native") return displayNetwork.nativeCurrency.symbol;
    const key = selectedPaymentToken.toLowerCase();
    return paymentTokenMeta[key]?.symbol ?? tokenLabels[key] ?? "TOKEN";
  }, [selectedPaymentToken, displayNetwork, paymentTokenMeta, tokenLabels]);

  const effectiveMaxContributionWei = useMemo(
    () => (saleData.customMaxContribution > 0n ? saleData.customMaxContribution : saleData.maxContribution),
    [saleData.customMaxContribution, saleData.maxContribution],
  );

  const selectedPaymentDecimals = useMemo(
    () => (selectedPaymentToken === "native" ? 18 : saleData.paymentTokenDecimals || selectedTokenDecimals),
    [selectedPaymentToken, saleData.paymentTokenDecimals, selectedTokenDecimals],
  );

  const paymentAmountUnits = useMemo(() => {
    if (!buyAmount) return 0n;
    try {
      return parseUnits(buyAmount, selectedPaymentDecimals);
    } catch {
      return 0n;
    }
  }, [buyAmount, selectedPaymentDecimals]);

  const paymentContributionWei = useMemo(() => {
    if (!paymentAmountUnits || !saleData.paymentTokenPrice) return 0n;
    return (paymentAmountUnits * saleData.paymentTokenPrice) / (10n ** BigInt(selectedPaymentDecimals));
  }, [paymentAmountUnits, saleData.paymentTokenPrice, selectedPaymentDecimals]);

  const nextContributionWei = useMemo(
    () => saleData.contribution + paymentContributionWei,
    [saleData.contribution, paymentContributionWei],
  );

  const remainingHardCapWei = useMemo(() => {
    if (saleData.hardCap <= saleData.totalRaised) return 0n;
    return saleData.hardCap - saleData.totalRaised;
  }, [saleData.hardCap, saleData.totalRaised]);

  const formatWeiAsSelectedPayment = useCallback(
    (weiAmount: bigint) => {
      if (!saleData.paymentTokenPrice) return "0";
      const units = (weiAmount * (10n ** BigInt(selectedPaymentDecimals))) / saleData.paymentTokenPrice;
      return formatUnits(units, selectedPaymentDecimals);
    },
    [saleData.paymentTokenPrice, selectedPaymentDecimals],
  );

  const purchaseValidationMessage = useMemo(() => {
    if (!isConnected || !walletAddress || isWrongNetwork || !hasContract) return "";
    if (!saleData.saleConfigured) return "Sale is not configured yet by admin.";
    if (saleData.isPaused) return "Sale is paused by admin.";
    if (nowUnix < Number(saleData.saleStart)) return "Sale has not started yet.";
    if (nowUnix > Number(saleData.saleEnd)) return "Sale has ended.";
    if (!saleData.whitelistStatus) return "Wallet is not whitelisted on contract.";
    if (!saleData.paymentTokenEnabled) return `${paymentLabel} payments are disabled on contract.`;
    if (!buyAmount) return "";
    if (paymentAmountUnits <= 0n) return "Enter a valid amount.";
    if (paymentContributionWei <= 0n) return "Amount is too small for this payment token.";
    if (saleData.totalRaised + paymentContributionWei > saleData.hardCap) {
      return "Amount exceeds remaining hard cap.";
    }
    if (nextContributionWei < saleData.minContribution) {
      const neededWei = saleData.minContribution > saleData.contribution ? saleData.minContribution - saleData.contribution : 0n;
      return `Minimum additional contribution needed: ${formatWeiAsSelectedPayment(neededWei)} ${paymentLabel}.`;
    }
    if (effectiveMaxContributionWei > 0n && nextContributionWei > effectiveMaxContributionWei) {
      const remainingWei = effectiveMaxContributionWei > saleData.contribution ? effectiveMaxContributionWei - saleData.contribution : 0n;
      return `Max additional contribution allowed: ${formatWeiAsSelectedPayment(remainingWei)} ${paymentLabel}.`;
    }
    return "";
  }, [
    buyAmount,
    effectiveMaxContributionWei,
    formatWeiAsSelectedPayment,
    hasContract,
    isConnected,
    isWrongNetwork,
    nextContributionWei,
    nowUnix,
    paymentAmountUnits,
    paymentContributionWei,
    paymentLabel,
    saleData.contribution,
    saleData.hardCap,
    saleData.isPaused,
    saleData.minContribution,
    saleData.paymentTokenEnabled,
    saleData.saleConfigured,
    saleData.saleEnd,
    saleData.saleStart,
    saleData.totalRaised,
    saleData.whitelistStatus,
    walletAddress,
  ]);

  const safePurchaseValidationMessage = isMounted ? purchaseValidationMessage : "";
  const purchaseStatusText = safePurchaseValidationMessage || "Eligible to buy";
  const isBuyDisabled = !isMounted || !saleInfoReady || !buyAmount || txState === "pending" || !!safePurchaseValidationMessage;

  const contributionRows = useMemo(() => {
    const tokens = [ZERO_ADDRESS, ...acceptedPaymentTokens];
    return tokens
      .map((token) => {
        const contribution = userContributionsByToken[token] ?? 0n;
        const meta =
          token === ZERO_ADDRESS
            ? { symbol: displayNetwork.nativeCurrency.symbol, decimals: 18 }
            : paymentTokenMeta[token] ?? { symbol: tokenLabels[token] ?? "TOKEN", decimals: 18 };
        return {
          token,
          symbol: meta.symbol,
          display: formatUnits(contribution, meta.decimals),
          hasContribution: contribution > 0n,
        };
      })
      .filter((row) => row.hasContribution);
  }, [acceptedPaymentTokens, displayNetwork.nativeCurrency.symbol, paymentTokenMeta, tokenLabels, userContributionsByToken]);

  const buyTokens = useCallback(async () => {
    if (!buyAmount) {
      console.log("[RESVA] Buy aborted: No amount entered.");
      return;
    }
    setTxState("pending");
    setTxMessage("Preparing transaction...");
    console.log("[RESVA] BuyTokens triggered — Amount:", buyAmount);
    try {
      const { contract, signer, provider } = await getWriteContract();
      const { chainId: walletChainId } = await provider.getNetwork();
      console.log(`[RESVA] Pre-Flight Check:
        - Wallet Chain ID: ${walletChainId}
        - App Chain ID: ${activeNetwork.chainId}
        - Target Contract: ${saleAddress}
      `);

      if (Number(walletChainId) !== Number(activeNetwork.chainId)) {
        throw new Error(`Network Mismatch: Your wallet is on Chain ${walletChainId} but the app is configured for ${activeNetwork.name} (Chain ${activeNetwork.chainId}). Please switch networks in your wallet.`);
      }

      const signerAddress = await signer.getAddress();
        console.log(`[RESVA] Execution Signer: ${signerAddress}`);
        
        // Address Mismatch Diagnostic
        if (signerAddress.toLowerCase() !== walletAddress?.toLowerCase()) {
          throw new Error(`Account Mismatch: Your wallet is using ${signerAddress.slice(0,6)}... but the dashboard is showing ${walletAddress?.slice(0,6)}... Please switch to the correct account in your wallet extension.`);
        }

        // Preflight checks to surface precise revert reasons from contract rules before sending tx.
        const [isWhitelisted, saleConfigured, saleStart, saleEnd, isPaused, minContributionWei, maxContributionWei, customMaxWei, currentContributionWei, hardCapWei, totalRaisedWei, paymentOption] =
          await Promise.all([
            contract.whitelist(signerAddress) as Promise<boolean>,
            contract.saleConfigured() as Promise<boolean>,
            contract.saleStart() as Promise<bigint>,
            contract.saleEnd() as Promise<bigint>,
            contract.paused() as Promise<boolean>,
            contract.minContribution() as Promise<bigint>,
            contract.maxContribution() as Promise<bigint>,
            contract.customMaxContribution(signerAddress) as Promise<bigint>,
            contract.contributions(signerAddress) as Promise<bigint>,
            contract.hardCap() as Promise<bigint>,
            contract.totalRaised() as Promise<bigint>,
            contract.paymentOptions(paymentTokenAddress) as Promise<[boolean, bigint, number]>,
          ]);

        const now = BigInt(Math.floor(Date.now() / 1000));
        if (!saleConfigured || now < saleStart || now > saleEnd) {
          throw new Error("LOCAL_VALIDATION_ERROR: Sale is not active on contract.");
        }
        if (isPaused) {
          throw new Error("LOCAL_VALIDATION_ERROR: Sale is paused on contract.");
        }
        if (!isWhitelisted) {
          throw new Error(
            `LOCAL_VALIDATION_ERROR: Wallet ${signerAddress} is not whitelisted on ${activeNetwork.name}.`,
          );
        }
        if (!paymentOption[0]) {
          throw new Error(`LOCAL_VALIDATION_ERROR: ${paymentLabel} payment option is disabled on contract.`);
        }

        const effectiveMaxContributionWei = customMaxWei > 0n ? customMaxWei : maxContributionWei;
        const paymentAmountUnits =
          selectedPaymentToken === "native"
            ? parseEther(buyAmount)
            : parseUnits(buyAmount, Number(paymentOption[2]));
        const [, paymentWeiPerUnit, paymentDecimals] = paymentOption;
        const paymentContributionWei =
          (paymentAmountUnits * paymentWeiPerUnit) / (10n ** BigInt(paymentDecimals));
        if (paymentContributionWei <= 0n) {
          throw new Error("LOCAL_VALIDATION_ERROR: Amount is too small for selected payment token.");
        }
        const nextContributionWei = currentContributionWei + paymentContributionWei;
        if (totalRaisedWei + paymentContributionWei > hardCapWei) {
          throw new Error("LOCAL_VALIDATION_ERROR: Amount exceeds remaining hard cap.");
        }

        if (nextContributionWei < minContributionWei) {
          throw new Error(
            `LOCAL_VALIDATION_ERROR: Minimum total contribution is ${formatEther(minContributionWei)} ${displayNetwork.nativeCurrency.symbol} equivalent. Your total would be ${formatEther(nextContributionWei)}.`,
          );
        }
        if (nextContributionWei > effectiveMaxContributionWei) {
          throw new Error(
            `LOCAL_VALIDATION_ERROR: Maximum total contribution is ${formatEther(effectiveMaxContributionWei)} ${displayNetwork.nativeCurrency.symbol} equivalent. Your total would be ${formatEther(nextContributionWei)}.`,
          );
        }

        let tx;
        if (selectedPaymentToken === "native") {
          const value = paymentAmountUnits;
          console.log(`[RESVA] Submitting native purchase... Signer: ${signerAddress} Value: ${value}`);
          setTxMessage("Confirm in your wallet...");
          tx = await contract.buyTokens({ value });
        } else {
          const token = await getTokenContract(selectedPaymentToken);
          const tokenAmount = paymentAmountUnits;
          const signer = contract.runner as any;
          
          const spender = saleAddress;
          const owner = signerAddress;
        
        console.log(`[RESVA] Token Purchase — Token: ${selectedPaymentToken} Amount: ${tokenAmount}`);
        
        const allowance = (await token.allowance(owner, spender)) as bigint;
        if (allowance < tokenAmount) {
          console.log("[RESVA] Allowance insufficient. Requesting approval...");
          setTxMessage("Approve token usage in wallet...");
          const approveTx = await token.approve(spender, tokenAmount);
          console.log("[RESVA] Approval submitted. Waiting for confirmation...");
          await approveTx.wait();
          console.log("[RESVA] Approval confirmed.");
        }
        
        console.log("[RESVA] Submitting token purchase...");
        setTxMessage("Confirm purchase in wallet...");
        tx = await contract.buyTokensWithToken(selectedPaymentToken, tokenAmount);
      }
      
      setTxHash(tx.hash);
      console.log("[RESVA] Transaction submitted. Hash:", tx.hash);
      setTxMessage("Transaction submitted. Waiting for blockchain confirmation...");
      await tx.wait();
      console.log("[RESVA] Transaction confirmed!");
      
      setTxState("success");
      setTxMessage("Purchase successful.");
      await refreshData();
    } catch (error) {
      console.log("[RESVA] Transaction error caught:", error);
      setTxState("failed");
      setTxMessage(humanizeError(error));
    }
  }, [
    activeNetwork,
    buyAmount,
    displayNetwork.nativeCurrency.symbol,
    getTokenContract,
    getWriteContract,
    paymentTokenAddress,
    refreshData,
    saleAddress,
    selectedPaymentToken,
    walletAddress,
    paymentLabel,
  ]);

  const isOwner = useMemo(
    () => !!walletAddress && !!saleData.owner && walletAddress.toLowerCase() === saleData.owner.toLowerCase(),
    [walletAddress, saleData.owner],
  );

  const runAdminTx = useCallback(
    async (message: string, executor: (contract: Contract) => Promise<{ hash: string; wait: () => Promise<unknown> }>) => {
      setTxState("pending");
      setTxMessage(message);
      try {
        const { contract } = await getWriteContract();
        const tx = await executor(contract);
        setTxHash(tx.hash);
        setTxMessage("Transaction submitted. Waiting for confirmation...");
        await tx.wait();
        setTxState("success");
        setTxMessage("Admin transaction successful.");
        await refreshData();
      } catch (error) {
        setTxState("failed");
        setTxMessage(humanizeError(error));
      }
    },
    [getWriteContract, refreshData],
  );

  const parseAddressCsv = (value: string) =>
    value
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);

  const claimTokens = useCallback(async () => {
    setTxState("pending");
    setTxMessage("Submitting claim transaction...");
    try {
      const { contract } = await getWriteContract();
      const tx = await contract.claimTokens();
      setTxHash(tx.hash);
      await tx.wait();
      setTxState("success");
      setTxMessage("Claim successful.");
      await refreshData();
    } catch (error) {
      setTxState("failed");
      setTxMessage(humanizeError(error));
    }
  }, [getWriteContract, refreshData]);

  const refundTokens = useCallback(async () => {
    setTxState("pending");
    setTxMessage("Submitting refund transaction...");
    try {
      const { contract } = await getWriteContract();
      let tx;
      if (selectedPaymentToken === "native") {
        tx = await contract.refund();
      } else {
        tx = await contract.refundWithToken(selectedPaymentToken);
      }
      setTxHash(tx.hash);
      await tx.wait();
      setTxState("success");
      setTxMessage("Refund successful.");
      await refreshData();
    } catch (error) {
      setTxState("failed");
      setTxMessage(humanizeError(error));
    }
  }, [getWriteContract, refreshData, selectedPaymentToken]);

  const isSaleActive = nowUnix >= Number(saleData.saleStart) && nowUnix <= Number(saleData.saleEnd);
  const hasNotStarted = nowUnix < Number(saleData.saleStart);
  
  const timeRemaining = hasNotStarted 
    ? Number(saleData.saleStart) - nowUnix 
    : (Number(saleData.saleEnd) > nowUnix ? Number(saleData.saleEnd) - nowUnix : 0);

  const progress =
    saleData.hardCap > 0n ? Number((saleData.totalRaised * 10000n) / saleData.hardCap) / 100 : 0;
    
  const countdown = useMemo(() => {
    const d = Math.floor(timeRemaining / 86400);
    const h = Math.floor((timeRemaining % 86400) / 3600);
    const m = Math.floor((timeRemaining % 3600) / 60);
    const s = Math.floor(timeRemaining % 60);
    return { d, h, m, s };
  }, [timeRemaining]);

  const vestingStats = useMemo(() => {
    const purchased = saleData.purchasedTokens;
    const claimed = saleData.claimedTokens;
    const claimable = saleData.claimable;
    const unlocked = claimed + claimable;
    const remainingLocked = purchased > unlocked ? purchased - unlocked : 0n;
    const tge = Number(saleData.tgeTime || 0n);
    const cliffEnd = tge + Number(saleData.cliff || 0n);
    const vestingEnd = cliffEnd + Number(saleData.vesting || 0n);
    const hasSchedule = tge > 0 && Number(saleData.vesting || 0n) > 0;

    let unlockPercent = 0;
    if (purchased > 0n) {
      unlockPercent = Number((unlocked * 10000n) / purchased) / 100;
    }

    let phase = "Not configured";
    let etaSeconds = 0;
    if (hasSchedule) {
      if (nowUnix < tge) {
        phase = "Waiting for TGE";
        etaSeconds = tge - nowUnix;
      } else if (nowUnix < cliffEnd) {
        phase = "Cliff active";
        etaSeconds = cliffEnd - nowUnix;
      } else if (nowUnix < vestingEnd) {
        phase = "Linear vesting";
        etaSeconds = vestingEnd - nowUnix;
      } else {
        phase = "Fully unlocked";
      }
    }

    return {
      hasSchedule,
      tge,
      cliffEnd,
      vestingEnd,
      unlocked,
      remainingLocked,
      unlockPercent,
      phase,
      etaSeconds,
    };
  }, [saleData.purchasedTokens, saleData.claimedTokens, saleData.claimable, saleData.tgeTime, saleData.cliff, saleData.vesting, nowUnix]);

  const vestingEtaText = useMemo(() => {
    const sec = vestingStats.etaSeconds;
    if (sec <= 0) return "Completed";
    const d = Math.floor(sec / 86400);
    const h = Math.floor((sec % 86400) / 3600);
    const m = Math.floor((sec % 3600) / 60);
    return `${d}d ${h}h ${m}m`;
  }, [vestingStats.etaSeconds]);

  const formatDateTime = useCallback(
    (unixSeconds: number) => {
      if (!isMounted || unixSeconds <= 0) return "Not set";
      return new Date(unixSeconds * 1000).toLocaleString();
    },
    [isMounted],
  );

  const statusTheme =
    txState === "success"
      ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-200"
      : txState === "failed"
        ? "border-rose-500/50 bg-rose-500/10 text-rose-200"
        : txState === "pending"
          ? "border-amber-500/50 bg-amber-500/10 text-amber-200"
          : "border-slate-700 bg-slate-900/40 text-slate-200";

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#030712] text-white">
      <div className="pointer-events-none absolute -left-24 top-0 h-96 w-96 rounded-full bg-cyan-500/20 blur-[130px]" />
      <div className="pointer-events-none absolute right-[-7rem] top-10 h-[28rem] w-[28rem] rounded-full bg-violet-500/20 blur-[130px]" />
      <div className="pointer-events-none absolute bottom-0 left-[35%] h-80 w-80 rounded-full bg-blue-500/20 blur-[120px]" />
      <div className="aurora-ribbon" />
      <div className="animated-grid" />
      <div className="noise-overlay" />

      <header className="sticky top-0 z-20 border-b border-amber-300/20 bg-[#090505]/75 backdrop-blur-2xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 md:px-8">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-3 transition hover:opacity-85">
              <span className="relative h-9 w-9 overflow-hidden rounded-full border border-amber-300/40 shadow-[0_0_18px_rgba(251,191,36,0.45)]">
                <Image src="/brand/resva-logo-transparent.png" alt="Resva logo" fill sizes="36px" className="object-cover" />
              </span>
              <span className="text-xl font-black tracking-wide bg-gradient-to-r from-amber-100 to-yellow-300 bg-clip-text text-transparent">RESVA</span>
            </Link>
            <nav className="hidden items-center gap-5 text-xs uppercase tracking-[0.2em] text-slate-400 md:flex">
              <Link href="/" className="transition hover:text-amber-300">Home</Link>
              <a href="#sale-status" className="transition hover:text-amber-300">Dashboard</a>
              <a href="#allocation" className="transition hover:text-amber-300">Allocation</a>
              <a href="#purchase" className="transition hover:text-amber-300">Purchase</a>
            </nav>
          </div>
          <div className="flex items-center gap-3">
            {isMounted && !isConnected && (
              <button
                onClick={() => open()}
                className="group relative rounded-full bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500 px-6 py-2.5 text-sm font-bold text-slate-950 shadow-[0_0_20px_rgba(251,191,36,0.5)] transition-all duration-300 hover:scale-[1.04] hover:shadow-[0_0_35px_rgba(251,191,36,0.7)] active:scale-95"
              >
                <span className="relative z-10 flex items-center gap-2">
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m9.586-5.586l4.5-4.5a4.5 4.5 0 016.364 6.364l-1.757 1.757" /></svg>
                  Connect Wallet
                </span>
                <span className="absolute inset-0 rounded-full bg-gradient-to-r from-amber-200 to-yellow-300 opacity-0 blur-md transition-opacity duration-300 group-hover:opacity-60" />
              </button>
            )}
            {isMounted && isConnected && walletAddress && (
              <button
                onClick={() => open()}
                className="flex items-center gap-2.5 rounded-full border border-amber-300/30 bg-amber-300/10 px-4 py-2.5 text-sm font-semibold text-amber-100 backdrop-blur-sm transition-all duration-200 hover:border-amber-300/50 hover:bg-amber-300/20"
              >
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                </span>
                {toShortAddress(walletAddress)}
              </button>
            )}
            
            {/* Network Switcher Dropdown */}
            <div className="relative">
              <button 
                onClick={() => setIsNetworkSelectorOpen(!isNetworkSelectorOpen)}
                className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-slate-300 transition hover:bg-white/10"
              >
                <NetworkIcon type={displayNetwork.icon} className="h-4 w-4" />
                <span className="hidden sm:inline">{displayNetwork.shortName}</span>
                <svg className={`h-4 w-4 text-slate-500 transition-transform ${isNetworkSelectorOpen ? "rotate-180" : ""}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              
              {isNetworkSelectorOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setIsNetworkSelectorOpen(false)} />
                  <div className="absolute right-0 mt-2 w-52 origin-top-right z-50 animate-in fade-in zoom-in-95 duration-200">
                    <div className="rounded-2xl border border-white/10 bg-[#0c0a09]/95 p-2 shadow-2xl backdrop-blur-xl">
                      <p className="px-3 py-2 text-[10px] font-bold uppercase tracking-widest text-slate-500">Switch Network</p>
                      {SUPPORTED_NETWORKS.map((net) => (
                        <button
                          key={net.chainId}
                          onClick={() => {
                            switchNetwork(net.appKitChain);
                            setIsNetworkSelectorOpen(false);
                          }}
                          className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-xs font-semibold transition hover:bg-white/10 ${currentChainId === net.chainId ? "text-amber-300 bg-amber-500/10" : "text-slate-300"}`}
                        >
                          <NetworkIcon type={net.icon} className="h-4 w-4" />
                          <span>{net.name}</span>
                          {!!net.contractAddress && (
                            <span className="ml-auto flex items-center gap-1.5">
                              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]" />
                            </span>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Wrong Network Banner */}
      {isMounted && isConnected && isWrongNetwork && (
        <div className="sticky top-[73px] z-10 border-b border-rose-500/30 bg-rose-950/80 backdrop-blur-lg">
          <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 md:px-8">
            <div className="flex items-center gap-3">
              <span className="text-lg">⚠️</span>
              <p className="text-sm font-medium text-rose-100">
                Unsupported network — please switch to a supported network to use this dApp.
              </p>
            </div>
            <button
              onClick={() => switchNetwork(DEFAULT_NETWORK.appKitChain)}
              className="shrink-0 rounded-full bg-rose-500 px-4 py-1.5 text-xs font-bold text-white transition hover:bg-rose-400"
            >
              Switch to Default
            </button>
          </div>
        </div>
      )}

      {/* No Contract Deployed Banner */}
      {isMounted && isConnected && !isWrongNetwork && !hasContract && (
        <div className="sticky top-[73px] z-10 border-b border-amber-500/30 bg-amber-950/80 backdrop-blur-lg">
          <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 md:px-8">
            <div className="flex items-center gap-3">
              <span className="text-lg">ℹ️</span>
              <p className="text-sm font-medium text-amber-100">
                Presale is not yet deployed on <strong>{displayNetwork.name}</strong>. Please switch network.
              </p>
            </div>
          </div>
        </div>
      )}

      <main className="relative mx-auto flex w-full max-w-7xl flex-col gap-10 px-4 py-12 md:px-8">
        <div className="text-center md:mb-6">
          <p className="text-xs uppercase tracking-[0.35em] text-amber-300">Private Presale Portal</p>
          <h1 className="bg-gradient-to-r from-white via-cyan-100 to-slate-400 bg-clip-text text-4xl font-black tracking-tight text-transparent md:text-6xl">
            Secure Allocation Engine
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-slate-300">
            Wallet-gated allocation with transparent progress, vesting-ready claim flow, and institutional-grade visibility for every contributor.
          </p>
        </div>

        <section id="sale-status" className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
          <div className="flex flex-col gap-6">
            <div className="relative overflow-hidden rounded-3xl border border-white/15 bg-gradient-to-b from-white/[0.08] to-white/[0.02] p-8 shadow-xl backdrop-blur-xl">
              <div className="absolute top-0 right-0 rounded-full bg-amber-500/15 p-32 blur-[100px]" />
              <h2 className="text-2xl font-black">
                {hasNotStarted ? "Sale Starts In" : "Presale Countdown"}
              </h2>
              <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
                {[
                  { label: "Days", value: countdown.d },
                  { label: "Hours", value: countdown.h },
                  { label: "Mins", value: countdown.m },
                  { label: "Secs", value: countdown.s },
                ].map((item) => (
                  <div key={item.label} className="rounded-2xl border border-white/10 bg-black/35 p-4 text-center">
                    <p className="text-3xl font-black text-white">{String(item.value).padStart(2, "0")}</p>
                    <p className="mt-1 text-[10px] uppercase tracking-[0.1em] text-amber-200/80">{item.label}</p>
                  </div>
                ))}
              </div>

              <div className="mt-8">
                <div className="flex justify-between text-sm font-medium tracking-wide text-slate-300">
                  <span>Total Raised: {formatDisplay((saleData.totalRaised * 10n ** BigInt(selectedTokenDecimals)) / (saleData.paymentTokenPrice || 1n))} {paymentLabel} eq.</span>
                  <span>Hard Cap: {formatDisplay((saleData.hardCap * 10n ** BigInt(selectedTokenDecimals)) / (saleData.paymentTokenPrice || 1n))} {paymentLabel} eq.</span>
                </div>
                <div className="mt-3 h-3 w-full overflow-hidden rounded-full border border-white/5 bg-slate-900/80 shadow-inner">
                  <div
                    className="relative h-full rounded-full bg-gradient-to-r from-amber-300 via-yellow-500 to-amber-600"
                    style={{ width: `${Math.min(progress, 100)}%` }}
                  >
                    <div className="absolute inset-0 h-full w-full animate-pulse bg-white/20 blur-[1px]" />
                  </div>
                </div>
                <p className="mt-2 text-right text-xs font-semibold text-amber-300">{progress.toFixed(2)}% Filled</p>
              </div>
            </div>

            <div id="allocation" className="grid gap-6 rounded-3xl border border-white/10 bg-white/[0.03] p-8 shadow-xl backdrop-blur-md md:grid-cols-2">
              <div className="rounded-2xl border border-white/10 bg-black/30 p-5">
                <p className="text-xs uppercase font-semibold tracking-wider text-slate-400">Whitelist Status</p>
                <div className="mt-2 flex items-center gap-3">
                  <div
                    className={`h-3 w-3 rounded-full ${
                      saleData.whitelistStatus
                        ? "bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.85)]"
                        : "bg-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.8)]"
                    }`}
                  />
                  <p className={`text-lg font-bold ${saleData.whitelistStatus ? "text-emerald-300" : "text-rose-400"}`}>
                    {saleData.whitelistStatus ? "Approved" : "Not Approved"}
                  </p>
                </div>
              </div>
              <div className="rounded-2xl border border-white/10 bg-black/30 p-5">
                <p className="text-xs uppercase font-semibold tracking-wider text-slate-400">Your Contribution</p>
                <p className="mt-2 text-2xl font-black text-white">
                  {formatDisplay(saleData.paymentContribution)}{" "}
                  <span className="text-sm font-medium text-slate-400">{paymentLabel}</span>
                </p>
                <p className="mt-1 text-xs text-slate-500">Total contribution ({displayNetwork.nativeCurrency.symbol} eq.): {formatDisplay(saleData.contribution)}</p>
              </div>
              <div className="col-span-full rounded-2xl border border-amber-300/20 bg-amber-300/5 p-5">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-xs uppercase font-semibold tracking-wider text-slate-400">Claimable Tokens</p>
                    <p className="mt-2 text-2xl font-black text-amber-200">
                      {formatDisplay(saleData.claimable)} <span className="text-sm font-medium text-slate-400">RESVA</span>
                    </p>
                    <p className="mt-1 text-xs text-slate-500">
                      Purchased: {formatDisplay(saleData.purchasedTokens)} RESVA | Claimed: {formatDisplay(saleData.claimedTokens)} RESVA
                    </p>
                  </div>
                  <button
                    onClick={claimTokens}
                    disabled={!saleInfoReady || saleData.claimable === 0n || txState === "pending"}
                    className="rounded-xl border border-slate-600 bg-slate-800 px-6 py-3 text-sm font-bold text-white transition hover:border-slate-500 hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {txState === "pending" ? "Processing..." : "Claim Tokens"}
                  </button>
                  <button
                    onClick={refundTokens}
                    disabled={!saleInfoReady || saleData.contribution === 0n || txState === "pending"}
                    className="rounded-xl border border-rose-500/45 bg-rose-500/15 px-6 py-3 text-sm font-bold text-rose-100 transition hover:bg-rose-500/25 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {txState === "pending" ? "Processing..." : "Refund"}
                  </button>
                </div>
              </div>
              <div className="col-span-full relative overflow-hidden rounded-2xl border border-cyan-400/20 bg-gradient-to-br from-[#0b1018] via-black/40 to-[#111827] p-5">
                <div className="pointer-events-none absolute -right-20 -top-16 h-44 w-44 rounded-full bg-cyan-500/10 blur-3xl" />
                <div className="pointer-events-none absolute -left-12 bottom-0 h-28 w-28 rounded-full bg-emerald-500/10 blur-2xl" />
                <div className="relative flex flex-wrap items-center justify-between gap-3">
                  <p className="text-xs uppercase font-bold tracking-[0.18em] text-slate-300">Vesting Overview</p>
                  <span className="rounded-full border border-amber-300/30 bg-amber-300/10 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-amber-200">
                    {vestingStats.phase}
                  </span>
                </div>

                <div className="relative mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                  <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">TGE</p>
                    <p className="mt-1 text-sm font-semibold text-slate-100">{vestingStats.hasSchedule ? formatDateTime(vestingStats.tge) : "Not set"}</p>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Cliff Ends</p>
                    <p className="mt-1 text-sm font-semibold text-slate-100">{vestingStats.hasSchedule ? formatDateTime(vestingStats.cliffEnd) : "Not set"}</p>
                  </div>
                  <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Vesting Ends</p>
                    <p className="mt-1 text-sm font-semibold text-slate-100">{vestingStats.hasSchedule ? formatDateTime(vestingStats.vestingEnd) : "Not set"}</p>
                  </div>
                  <div className="rounded-xl border border-cyan-300/25 bg-cyan-400/5 p-3">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-300/80">Next Milestone</p>
                    <p className="mt-1 text-sm font-black text-cyan-200">{vestingEtaText}</p>
                  </div>
                </div>

                <div className="relative mt-5 h-2.5 w-full overflow-hidden rounded-full border border-white/10 bg-slate-900/80">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-sky-400 to-emerald-400 shadow-[0_0_18px_rgba(56,189,248,0.45)]"
                    style={{ width: `${Math.min(100, vestingStats.unlockPercent)}%` }}
                  />
                </div>

                <div className="relative mt-4 grid gap-3 sm:grid-cols-3">
                  <div className="rounded-xl border border-emerald-400/20 bg-emerald-500/10 p-3">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-200/80">Unlocked</p>
                    <p className="mt-1 text-base font-black text-emerald-300">{formatDisplay(vestingStats.unlocked)} RESVA</p>
                  </div>
                  <div className="rounded-xl border border-amber-400/20 bg-amber-500/10 p-3">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-amber-200/80">Locked</p>
                    <p className="mt-1 text-base font-black text-amber-300">{formatDisplay(vestingStats.remainingLocked)} RESVA</p>
                  </div>
                  <div className="rounded-xl border border-cyan-400/20 bg-cyan-500/10 p-3">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-cyan-200/80">Progress</p>
                    <p className="mt-1 text-base font-black text-cyan-300">{vestingStats.unlockPercent.toFixed(2)}%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <aside id="purchase" className="relative flex flex-col overflow-hidden rounded-3xl border border-white/10 bg-black/45 p-8 shadow-2xl backdrop-blur-xl">
            <div className="absolute -top-40 -right-40 rounded-full bg-blue-600/20 p-40 blur-[120px]" />
            <p className="text-xs uppercase tracking-[0.3em] text-amber-300">Purchase Flow</p>
            <h3 className="mt-2 text-3xl font-black">Invest in RESVA</h3>
            <p className="mt-2 text-sm text-slate-400">
              1 {displayNetwork.nativeCurrency.symbol} = {formatDisplay((parseEther("1") * 10n ** 18n) / (saleData.tokenPriceInWei || 1n))} RESVA
            </p>

            <div className="mt-8 flex-1">
              <div className="flex justify-between pl-1 text-[10px] font-bold uppercase tracking-widest text-slate-400">
                <span>Payment Method</span>
                {isMounted && isConnected && (
                  <span className="text-amber-400/80">
                    Wallet: <span className="text-white">{formatDisplay(userBalance)} {paymentLabel}</span>
                  </span>
                )}
              </div>
              <div className="relative mt-2">
                <button
                  onClick={() => setIsSelectorOpen(!isSelectorOpen)}
                  className="flex w-full items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-4 text-sm font-medium transition hover:bg-white/10 focus:border-amber-400/50"
                >
                  <div className="flex items-center gap-3">
                    {selectedPaymentToken === "native" ? (
                      <NetworkIcon type={displayNetwork.icon} className="h-6 w-6" />
                    ) : (
                      <TokenIcon symbol={paymentLabel} className="h-6 w-6" />
                    )}
                    <span className="font-bold">
                      {selectedPaymentToken === "native" 
                        ? `${displayNetwork.nativeCurrency.symbol} (Native)` 
                        : paymentLabel}
                    </span>
                  </div>
                  <svg className={`h-5 w-5 text-slate-500 transition-transform ${isSelectorOpen ? "rotate-180" : ""}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>

                {isSelectorOpen && (
                  <>
                    <div className="fixed inset-0 z-30" onClick={() => setIsSelectorOpen(false)} />
                    <div className="absolute left-0 right-0 top-full z-40 mt-2 overflow-hidden rounded-2xl border border-white/10 bg-[#0c0a09]/95 shadow-2xl backdrop-blur-xl animate-in fade-in zoom-in-95 duration-200">
                      <div className="max-h-60 overflow-y-auto p-1.5">
                        <button
                          onClick={() => { setSelectedPaymentToken("native"); setIsSelectorOpen(false); }}
                          className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left text-sm transition hover:bg-white/5 ${selectedPaymentToken === "native" ? "bg-amber-400/10 text-amber-300" : "text-slate-300"}`}
                        >
                          <NetworkIcon type={displayNetwork.icon} className="h-5 w-5" />
                          <span className="font-semibold">{displayNetwork.nativeCurrency.symbol} (Native)</span>
                        </button>
                        {acceptedPaymentTokens.map((token) => {
                          const key = token.toLowerCase();
                          const label = paymentTokenMeta[key]?.symbol || tokenLabels[key] || "TOKEN";
                          return (
                            <button
                              key={token}
                              onClick={() => { setSelectedPaymentToken(token); setIsSelectorOpen(false); }}
                              className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left text-sm transition hover:bg-white/5 ${selectedPaymentToken === token ? "bg-amber-400/10 text-amber-300" : "text-slate-300"}`}
                            >
                              <TokenIcon symbol={label} className="h-5 w-5" />
                              <span className="font-semibold">{label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </>
                )}
              </div>

              <div className="mt-6">
                <label className="pl-1 text-[10px] font-bold uppercase tracking-widest text-slate-400">
                  Amount to Pay
                </label>
                <div className="relative mt-2">
                  <input
                    type="number"
                    value={buyAmount}
                    onChange={(e) => setBuyAmount(e.target.value)}
                    placeholder="0.0"
                    className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-4 pr-16 text-xl font-bold outline-none ring-amber-400/30 transition focus:border-amber-400/50 focus:ring-2"
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-500">
                    {paymentLabel}
                  </div>
                </div>
              </div>

              <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="flex justify-between text-sm">
                  <span className="text-slate-400">Estimated Receive</span>
                  <span className="font-bold text-amber-200">{Number(estimatedTokens).toLocaleString()} RESVA</span>
                </p>
              </div>

              <div className="mt-4 space-y-2 text-xs text-slate-400">
                <p>
                  • Contract limits: Min {formatWeiAsSelectedPayment(saleData.minContribution)} {paymentLabel}, Max {formatWeiAsSelectedPayment(effectiveMaxContributionWei)} {paymentLabel} (total contribution).
                </p>
                <p>
                  • Remaining hard cap: {formatWeiAsSelectedPayment(remainingHardCapWei)} {paymentLabel}. Current status: {purchaseStatusText}.
                </p>
                <p>• Contributions are visible in your dashboard after confirmation.</p>
                <p>• Claim opens according to sale finalization conditions.</p>
              </div>
              <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 p-4">
                <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-slate-400">
                  Your Contributions by Payment Mode
                </p>
                {contributionRows.length === 0 ? (
                  <p className="text-xs text-slate-500">No confirmed purchases yet.</p>
                ) : (
                  <div className="space-y-1.5 text-xs">
                    {contributionRows.map((row) => (
                      <p key={row.token} className="flex items-center justify-between">
                        <span className="text-slate-400">{row.symbol}</span>
                        <span className="font-semibold text-amber-200">{Number(row.display).toLocaleString()} {row.symbol}</span>
                      </p>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="mt-8 flex flex-col gap-3">
              {isMounted && isConnected && (
                <div className="flex items-center justify-between px-2 mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Signer:</span>
                    <span className="text-[10px] font-mono text-slate-300">{toShortAddress(walletAddress || "")}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className={`h-1.5 w-1.5 rounded-full ${saleData.whitelistStatus ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]" : "bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)]"}`} />
                    <span className={`text-[10px] font-bold uppercase tracking-widest ${saleData.whitelistStatus ? "text-emerald-400" : "text-rose-400"}`}>
                      {saleData.whitelistStatus ? "Whitelisted ✅" : "Not Whitelisted ❌"}
                    </span>
                  </div>
                </div>
              )}
              {!!safePurchaseValidationMessage && (
                <div className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-xs font-semibold text-rose-200">
                  {safePurchaseValidationMessage}
                </div>
              )}
              <button
                onClick={buyTokens}
                disabled={isBuyDisabled}
                className="w-full rounded-2xl bg-gradient-to-r from-amber-300 to-yellow-500 p-4 text-lg font-black text-slate-950 shadow-[0_0_24px_rgba(251,191,36,0.35)] transition hover:shadow-[0_0_36px_rgba(251,191,36,0.5)] active:translate-y-0.5 disabled:opacity-50 disabled:shadow-none"
              >
                {txState === "pending" ? "Processing..." : "Confirm Purchase"}
              </button>
            </div>
          </aside>
        </section>

        <section className="grid gap-5 rounded-3xl border border-white/10 bg-white/[0.03] p-6 md:grid-cols-3">
          {[
            { title: "Secure Allocation", copy: "Wallet-gated participation and whitelist constraints are enforced directly by the smart contract." },
            { title: "Transparent Progress", copy: "Raised amount and hard cap metrics update in real time from contract reads." },
            { title: "Claim Visibility", copy: "Track your claimable token balance with clear status and one-click claim execution." },
          ].map((item) => (
            <article key={item.title} className="rounded-2xl border border-white/10 bg-black/25 p-5">
              <h4 className="text-lg font-bold">{item.title}</h4>
              <p className="mt-2 text-sm text-slate-400">{item.copy}</p>
            </article>
          ))}
        </section>
        {isMounted && isOwner && (
          <section className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-xl font-black">Admin Controls</h3>
              <div className="flex flex-wrap gap-2">
                <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-[10px] font-bold text-emerald-200">
                  Owner Wallet
                </span>
                <span className={`rounded-full px-3 py-1 text-[10px] font-bold ${saleData.isPaused ? "bg-rose-500/20 text-rose-200" : "bg-cyan-500/20 text-cyan-200"}`}>
                  {saleData.isPaused ? "SALE PAUSED" : "SALE LIVE"}
                </span>
                <span className="rounded-full bg-slate-500/20 px-3 py-1 text-[10px] font-bold text-slate-300">
                  Raised: {formatDisplay(saleData.totalRaised)} {displayNetwork.nativeCurrency.symbol}
                </span>
              </div>
            </div>
            
            {/* Live Config Summary */}
            <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
              {[
                { label: "Start", val: Number(saleData.saleStart) === 0 ? "Not Set" : new Date(Number(saleData.saleStart) * 1000).toLocaleDateString() },
                { label: "End", val: Number(saleData.saleEnd) === 0 ? "Not Set" : new Date(Number(saleData.saleEnd) * 1000).toLocaleDateString() },
                { label: "TGE", val: Number(saleData.tgeTime) === 0 ? "Not Set" : new Date(Number(saleData.tgeTime) * 1000).toLocaleDateString() },
                { label: "Vesting", val: `${Number(saleData.vesting) / 86400} Days` },
              ].map((b) => (
                <div key={b.label} className="rounded-xl border border-white/5 bg-black/40 p-3">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500">{b.label}</p>
                  <p className="mt-1 text-xs font-mono text-slate-200">{b.val}</p>
                </div>
              ))}
            </div>
            <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-xl border border-white/10 bg-black/20 p-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold">Whitelist Add</p>
                <button 
                  onClick={() => setAdminWhitelistInput(walletAddress || "")}
                  className="text-[10px] uppercase font-bold text-amber-400 hover:text-amber-300 transition"
                >
                  Whitelist Me
                </button>
              </div>
              <input
                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-amber-500/50"
                placeholder="0xabc...,0xdef..."
                value={adminWhitelistInput}
                onChange={(e) => setAdminWhitelistInput(e.target.value)}
              />
              <button
                disabled={!isOwner || !adminWhitelistInput || txState === "pending"}
                onClick={() => runAdminTx("Updating whitelist...", (c) => c.addToWhitelist(parseAddressCsv(adminWhitelistInput)))}
                className="mt-2 rounded-lg bg-emerald-500/80 px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                Add Wallets
              </button>
            </div>
            <div className="rounded-xl border border-white/10 bg-black/20 p-4">
              <p className="mb-2 text-sm font-semibold">Whitelist Remove</p>
              <input
                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm"
                placeholder="0xabc...,0xdef..."
                value={adminRemoveWhitelistInput}
                onChange={(e) => setAdminRemoveWhitelistInput(e.target.value)}
              />
              <button
                disabled={!isOwner || !adminRemoveWhitelistInput || txState === "pending"}
                onClick={() =>
                  runAdminTx("Removing from whitelist...", (c) => c.removeFromWhitelist(parseAddressCsv(adminRemoveWhitelistInput)))
                }
                className="mt-2 rounded-lg bg-rose-500/80 px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                Remove Wallets
              </button>
            </div>
            <div className="rounded-xl border border-white/10 bg-black/20 p-4">
              <p className="mb-2 text-sm font-semibold">Payment Token Config</p>
              <input
                className="mb-2 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm"
                placeholder="token address or native"
                value={adminPaymentToken}
                onChange={(e) => setAdminPaymentToken(e.target.value)}
              />
              <input
                className="mb-2 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm"
                placeholder="weiPerUnit"
                value={adminWeiPerUnit}
                onChange={(e) => setAdminWeiPerUnit(e.target.value)}
              />
              <label className="mb-2 flex items-center gap-2 text-sm">
                <input type="checkbox" checked={adminPaymentEnabled} onChange={(e) => setAdminPaymentEnabled(e.target.checked)} />
                Enabled
              </label>
              <button
                disabled={!isOwner || !adminPaymentToken || !adminWeiPerUnit || txState === "pending"}
                onClick={() =>
                  runAdminTx("Updating payment option...", (c) =>
                    c.setPaymentOption(
                      adminPaymentToken.toLowerCase() === "native"
                        ? "0x0000000000000000000000000000000000000000"
                        : adminPaymentToken,
                      adminPaymentEnabled,
                      BigInt(adminWeiPerUnit),
                    ),
                  )
                }
                className="rounded-lg bg-blue-500/80 px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                Save Payment Option
              </button>
            </div>
            <div className="rounded-xl border border-white/10 bg-black/20 p-4">
              <p className="mb-2 text-sm font-semibold">Investor Max Contribution</p>
              <input
                className="mb-2 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm"
                placeholder="investor address"
                value={adminInvestorAddress}
                onChange={(e) => setAdminInvestorAddress(e.target.value)}
              />
              <input
                className="mb-2 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm"
                placeholder="max contribution wei (0 to clear)"
                value={adminInvestorMaxWei}
                onChange={(e) => setAdminInvestorMaxWei(e.target.value)}
              />
              <button
                disabled={!isOwner || !adminInvestorAddress || !adminInvestorMaxWei || txState === "pending"}
                onClick={() =>
                  runAdminTx("Setting investor max...", (c) =>
                    c.setInvestorCustomMaxContribution(adminInvestorAddress, BigInt(adminInvestorMaxWei)),
                  )
                }
                className="rounded-lg bg-violet-500/80 px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                Save Investor Limit
              </button>
            </div>
            <div className="rounded-xl border border-white/10 bg-black/20 p-4">
              <p className="mb-2 text-sm font-semibold">Sale and TGE</p>
              <div className="mb-2">
                <input className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm" placeholder="start unix" value={adminSaleStart} onChange={(e) => setAdminSaleStart(e.target.value)} />
                {adminSaleStart && <p className="mt-1 px-1 text-[10px] text-amber-400">Preview: {new Date(Number(adminSaleStart) * 1000).toLocaleString()}</p>}
              </div>
              <div className="mb-2">
                <input className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm" placeholder="end unix" value={adminSaleEnd} onChange={(e) => setAdminSaleEnd(e.target.value)} />
                {adminSaleEnd && <p className="mt-1 px-1 text-[10px] text-amber-400">Preview: {new Date(Number(adminSaleEnd) * 1000).toLocaleString()}</p>}
              </div>
              <button
                disabled={!isOwner || !adminSaleStart || !adminSaleEnd || txState === "pending"}
                onClick={() => runAdminTx("Starting sale...", (c) => c.startSale(BigInt(adminSaleStart), BigInt(adminSaleEnd)))}
                className="mr-2 rounded-lg bg-amber-500/80 px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                Start Sale
              </button>
              <button
                disabled={!isOwner || txState === "pending"}
                onClick={() => runAdminTx("Stopping sale...", (c) => c.stopSale())}
                className="rounded-lg bg-rose-500/80 px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                Stop Sale
              </button>
              <div className="mt-2 mb-2">
                <input className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm" placeholder="tge unix" value={adminTge} onChange={(e) => setAdminTge(e.target.value)} />
                {adminTge && <p className="mt-1 px-1 text-[10px] text-amber-400">Preview: {new Date(Number(adminTge) * 1000).toLocaleString()}</p>}
              </div>
              <button
                disabled={!isOwner || !adminTge || txState === "pending"}
                onClick={() => runAdminTx("Setting TGE...", (c) => c.configureTge(BigInt(adminTge)))}
                className="rounded-lg bg-cyan-500/80 px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                Set TGE
              </button>
            </div>
            <div className="rounded-xl border border-white/10 bg-black/20 p-4">
              <p className="mb-2 text-sm font-semibold">Vesting and Pause</p>
              <input className="mb-2 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm" placeholder="cliff seconds" value={adminCliff} onChange={(e) => setAdminCliff(e.target.value)} />
              <input className="mb-2 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm" placeholder="vesting seconds" value={adminVesting} onChange={(e) => setAdminVesting(e.target.value)} />
              <button
                disabled={!isOwner || !adminCliff || !adminVesting || txState === "pending"}
                onClick={() => runAdminTx("Setting vesting...", (c) => c.setVestingDurations(BigInt(adminCliff), BigInt(adminVesting)))}
                className="mr-2 rounded-lg bg-indigo-500/80 px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                Set Vesting
              </button>
              <button
                disabled={!isOwner || txState === "pending"}
                onClick={() => runAdminTx("Pausing sale...", (c) => c.pause())}
                className="mr-2 rounded-lg bg-slate-600 px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                Pause
              </button>
              <button
                disabled={!isOwner || txState === "pending"}
                onClick={() => runAdminTx("Unpausing sale...", (c) => c.unpause())}
                className="rounded-lg bg-emerald-600 px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
              >
                Unpause
              </button>
            </div>
            </div>
          </section>
        )}

        {isMounted && (!hasContract || !process.env.NEXT_PUBLIC_REOWN_PROJECT_ID) && (
          <section className="flex items-center gap-3 rounded-xl border border-amber-400/30 bg-amber-500/10 p-4 text-sm text-amber-100">
            <span className="text-xl">⚠️</span>
            <p>
              Configuration missing for <strong>{displayNetwork.name}</strong>. 
              Ensure <code>NEXT_PUBLIC_CONTRACT_{displayNetwork.chainId}</code> and <code>NEXT_PUBLIC_REOWN_PROJECT_ID</code> are set in <code>.env.local</code>.
            </p>
          </section>
        )}

        <TransactionModal
          state={txState}
          message={txMessage} 
          txHash={txHash}
          explorer={activeNetwork.explorerUrl}
          onClose={() => {
            setTxState("idle");
            setTxMessage("");
            setTxHash("");
          }} 
        />
      </main>
    </div>
  );
}

const TransactionModal = ({
  state,
  message,
  txHash,
  explorer,
  onClose,
}: {
  state: TxState;
  message: string;
  txHash?: string;
  explorer?: string;
  onClose: () => void;
}) => {
  if (state === "idle") return null;

  const icons = {
    pending: (
      <div className="relative flex h-20 w-20 items-center justify-center">
        <div className="absolute h-full w-full animate-spin rounded-full border-4 border-amber-500/20 border-t-amber-500" />
        <div className="h-12 w-12 animate-pulse rounded-full bg-amber-500/20" />
      </div>
    ),
    success: (
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-500">
        <svg className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
        </svg>
      </div>
    ),
    failed: (
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-rose-500/20 text-rose-500">
        <svg className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </div>
    ),
  };

  const titles = {
    pending: "Transaction in Progress",
    success: "Transaction Successful",
    failed: "Transaction Failed",
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 backdrop-blur-md">
      <div className="absolute inset-0 bg-slate-950/60 transition-opacity" onClick={state !== "pending" ? onClose : undefined} />
      <div className="relative w-full max-w-md overflow-hidden rounded-[2.5rem] border border-white/10 bg-[#0c0a09] p-8 shadow-2xl transition-all scale-100">
        <div className="absolute -right-20 -top-20 h-40 w-40 rounded-full bg-amber-500/10 blur-3xl" />
        
        <div className="flex flex-col items-center text-center">
          <div className="mb-6">{icons[state]}</div>
          <h3 className="mb-2 text-xl font-black tracking-tight text-white">{titles[state]}</h3>
          <p className="mb-6 text-sm leading-relaxed text-slate-400">{message}</p>
          
          {txHash && explorer && (
            <a
              href={`${explorer}/tx/${txHash}`}
              target="_blank"
              rel="noopener noreferrer"
              className="group mb-8 flex items-center gap-2 rounded-full border border-amber-400/20 bg-amber-400/5 px-4 py-2 text-[10px] font-bold uppercase tracking-[0.2em] text-amber-400 transition hover:bg-amber-400/10 hover:border-amber-400/40"
            >
              <span>View on Explorer</span>
              <svg className="h-3 w-3 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
            </a>
          )}
          
          {state !== "pending" && (
            <button
              onClick={onClose}
              className="w-full rounded-2xl bg-white/5 py-4 text-sm font-bold text-white transition hover:bg-white/10 active:scale-95"
            >
              Close Window
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
