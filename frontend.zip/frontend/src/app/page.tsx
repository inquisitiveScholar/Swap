import Link from "next/link";
import { Metadata } from "next";
import Image from "next/image";

export const metadata: Metadata = {
  title: "RESVA | Premium DeFi Lending & Presale",
  description:
    "A premium DeFi experience for presale allocation, collateralized lending, and high-conviction ecosystem growth.",
};

export default function LandingPage() {
  const lendingHighlights = [
    {
      title: "Collateralized Lending Vaults",
      description:
        "Over-collateralized borrow markets with transparent reserve ratios, dynamic interest curves, and automated liquidation protection bands.",
      metric: "82% avg utilization",
    },
    {
      title: "Risk Engine & Capital Protection",
      description:
        "Real-time risk scoring monitors wallet concentration, protocol leverage, and liquidity depth to preserve lender confidence in volatile conditions.",
      metric: "Sub-second risk checks",
    },
    {
      title: "Presale Advantage Loop",
      description:
        "Presale participants unlock fee rebates, lending APY boosts, and governance multipliers to reward long-term participation instead of short-term exits.",
      metric: "Up to 1.8x rewards",
    },
  ];

  const tokenFlow = [
    { label: "Community Incentives", percent: "34%" },
    { label: "Lending Liquidity", percent: "24%" },
    { label: "Protocol Treasury", percent: "16%" },
    { label: "Private Presale", percent: "14%" },
    { label: "Core Builders", percent: "12%" },
  ];

  const roadmap = [
    {
      phase: "Q2 2026",
      status: "Live",
      title: "Presale Core",
      items: ["Whitelist orchestration", "Audit + KYC framework", "Capital intake dashboard"],
    },
    {
      phase: "Q3 2026",
      status: "Building",
      title: "Lending Mainnet",
      items: ["Isolated borrow markets", "Risk oracle integration", "Vault health automations"],
    },
    {
      phase: "Q4 2026",
      status: "Planned",
      title: "Yield Expansion",
      items: ["Cross-chain collateral", "Adaptive APY routing", "Treasury-backed insurance pool"],
    },
    {
      phase: "Q1 2027",
      status: "Vision",
      title: "Institutional Layer",
      items: ["Governance V2", "Permissioned lending pools", "API + analytics terminal"],
    },
  ];

  const lendingTracks = [
    {
      title: "Lender Desk",
      points: ["Stable reserve-first APY", "Auto-compounding vault routes", "Treasury-protected downside layer"],
    },
    {
      title: "Borrower Desk",
      points: ["Cross-asset collateral models", "Dynamic borrow rates by utilization", "Health-factor early warning signals"],
    },
    {
      title: "Protocol Desk",
      points: ["Oracle monitoring framework", "Liquidity stress test windows", "Governance-controlled market expansions"],
    },
  ];

  const buyJourney = [
    {
      step: "01",
      title: "Connect Wallet",
      description:
        "Open the sale app, connect MetaMask or WalletConnect, and switch to the configured RESVA sale network.",
      accent: "from-cyan-300 to-blue-500",
    },
    {
      step: "02",
      title: "Choose Payment Coin",
      description:
        "Select supported payment assets like BNB (native) and configured stablecoins/tokens such as USDT, BUSD, or ETH-like mocks for testing.",
      accent: "from-amber-300 to-yellow-500",
    },
    {
      step: "03",
      title: "Confirm Allocation",
      description:
        "Enter amount, approve token spend if needed, then confirm purchase. Your contribution and claimable balance update on-chain in the dashboard.",
      accent: "from-violet-300 to-fuchsia-500",
    },
  ];

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-[#030712] text-white">
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="absolute left-[-15%] top-[-5%] h-[35rem] w-[35rem] rounded-full bg-cyan-500/20 blur-[150px] animate-float-slow" />
        <div className="absolute right-[-12%] top-[22%] h-[32rem] w-[32rem] rounded-full bg-violet-500/20 blur-[140px] animate-float-medium" />
        <div className="absolute bottom-[-18%] left-[22%] h-[34rem] w-[34rem] rounded-full bg-blue-500/20 blur-[150px] animate-float-slow" />
        <div className="aurora-ribbon" />
        <div className="animated-grid" />
        <div className="noise-overlay" />
      </div>

      <header className="fixed top-0 z-50 w-full border-b border-amber-300/20 bg-[#090505]/70 backdrop-blur-2xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 md:px-8">
          <div className="flex items-center gap-3">
            <div className="relative h-10 w-10 overflow-hidden rounded-full border border-amber-300/35 shadow-[0_0_20px_rgba(251,191,36,0.45)]">
              <Image src="/brand/resva-logo-transparent.png" alt="Resva logo" fill className="object-cover" />
            </div>
            <div>
              <p className="text-lg font-black tracking-[0.2em] text-amber-100">RESVA</p>
              <p className="text-[10px] uppercase tracking-[0.35em] text-amber-200/70">Reserve Value Layer</p>
            </div>
          </div>

          <nav className="hidden items-center gap-7 text-sm font-medium text-slate-300 md:flex">
            <a href="#home" className="transition hover:text-amber-200">Home</a>
            <a href="#markets" className="transition hover:text-amber-200">Markets</a>
            <a href="#tokenomics" className="transition hover:text-amber-200">Tokenomics</a>
            <a href="#roadmap" className="transition hover:text-amber-200">Roadmap</a>
            <a href="#governance" className="transition hover:text-amber-200">Governance</a>
          </nav>

          <Link
            href="/sale"
            className="group relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-full border border-amber-200/40 bg-gradient-to-r from-amber-300 to-amber-500 px-5 py-2.5 text-sm font-semibold text-slate-950 shadow-[0_0_26px_rgba(251,191,36,0.4)] transition hover:shadow-[0_0_36px_rgba(251,191,36,0.55)]"
          >
            <span>Launch Sale App</span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="transition-transform group-hover:translate-x-1">
              <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </Link>
        </div>
      </header>

      <main className="relative z-10">
        <section id="home" className="relative flex flex-col items-center justify-center px-6 pb-24 pt-36 text-center md:px-8 lg:pb-28 lg:pt-44">
          <div className="inline-flex items-center gap-2 rounded-full border border-cyan-400/35 bg-cyan-300/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-cyan-200 backdrop-blur-xl">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-400 opacity-70" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-cyan-300" />
            </span>
            Presale Window Active
          </div>

          <h1 className="mt-7 max-w-4xl text-4xl font-black tracking-tight sm:text-5xl lg:text-6xl">
            A Smarter DeFi Hub for
            <span className="block bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-500 bg-clip-text text-transparent">
              Lending, Yield, and Presale
            </span>
          </h1>

          <p className="mt-8 max-w-3xl text-lg leading-relaxed text-slate-300 sm:text-xl">
            RESVA combines presale allocation, collateralized lending, and governance utilities into one high-conviction protocol layer. Built for disciplined treasury growth and long-term token durability.
          </p>

          <div className="mt-10 flex w-full max-w-xl flex-col gap-4 sm:flex-row">
            <Link
              href="/sale"
              className="flex-1 rounded-full bg-gradient-to-r from-amber-300 to-yellow-500 px-8 py-4 text-base font-black text-slate-950 shadow-[0_0_40px_rgba(251,191,36,0.3)] transition duration-300 hover:-translate-y-1"
            >
              Reserve Presale Allocation
            </Link>
            <a
              href="#markets"
              className="flex-1 rounded-full border border-amber-200/25 bg-white/5 px-8 py-4 text-base font-semibold text-white backdrop-blur-xl transition hover:border-amber-200/45 hover:bg-white/10"
            >
              Explore Markets
            </a>
          </div>

          <div className="mt-20 w-full max-w-6xl rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.08] to-white/[0.03] p-3 backdrop-blur-xl">
            <div className="relative grid gap-6 rounded-2xl border border-amber-200/15 bg-[#130a05]/85 p-6 md:grid-cols-[1.2fr_1fr]">
              <div className="rounded-2xl border border-white/10 bg-black/35 p-6 text-left">
                <p className="text-xs uppercase tracking-[0.3em] text-cyan-300">Protocol Terminal</p>
                <h3 className="mt-3 text-2xl font-black">Capital Efficiency Monitor</h3>
                <div className="mt-6 grid gap-4 sm:grid-cols-3">
                  {[
                    { label: "TVL", value: "$28.4M" },
                    { label: "Borrow Demand", value: "71%" },
                    { label: "Reserve Ratio", value: "163%" },
                  ].map((metric) => (
                    <div key={metric.label} className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
                      <p className="text-xs uppercase tracking-[0.15em] text-slate-400">{metric.label}</p>
                      <p className="mt-2 text-2xl font-black text-amber-200">{metric.value}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-6 h-2 w-full overflow-hidden rounded-full bg-white/10">
                  <div className="h-full w-3/4 animate-pulse bg-gradient-to-r from-amber-300 via-yellow-500 to-amber-600" />
                </div>
                <p className="mt-3 text-sm text-slate-400">Risk engine synced with liquidity and price oracles every block.</p>
              </div>
              <div className="rounded-2xl border border-amber-200/20 bg-amber-300/5 p-6 text-left">
                <p className="text-xs uppercase tracking-[0.2em] text-amber-200">Presale R&D Snapshot</p>
                <ul className="mt-4 space-y-3 text-sm text-slate-300">
                  <li className="rounded-lg border border-white/10 bg-white/[0.02] p-3">Tiered allocation with anti-whale enforcement and vesting integrity.</li>
                  <li className="rounded-lg border border-white/10 bg-white/[0.02] p-3">Treasury-backed lender safety module with dynamic emergency caps.</li>
                  <li className="rounded-lg border border-white/10 bg-white/[0.02] p-3">Governance weight multipliers for long-term stakers and lenders.</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section id="markets" className="px-6 py-24 md:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="mb-12 text-center">
              <p className="text-xs uppercase tracking-[0.3em] text-amber-300">Lending Architecture</p>
              <h2 className="mt-3 text-4xl font-black md:text-5xl">Built Like a Prime DeFi Desk</h2>
              <p className="mx-auto mt-4 max-w-2xl text-slate-400">
                The lending model is designed around measurable risk and sustainable yields, not unsustainable token emissions.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              {lendingHighlights.map((item) => (
                <article
                  key={item.title}
                  className="group rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.08] to-white/[0.02] p-7 backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:border-cyan-300/40"
                >
                  <p className="text-xs uppercase tracking-[0.2em] text-amber-300">{item.metric}</p>
                  <h3 className="mt-4 text-2xl font-black">{item.title}</h3>
                  <p className="mt-4 leading-relaxed text-slate-300">{item.description}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="px-6 pb-24 md:px-8">
          <div className="mx-auto max-w-7xl rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.08] via-white/[0.03] to-transparent p-7 backdrop-blur-xl md:p-9">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
              <div>
              <p className="text-xs uppercase tracking-[0.3em] text-amber-300">Rich Lending Layer</p>
                <h2 className="mt-3 text-3xl font-black md:text-4xl">Deep Capital Utility, Not Just a Token</h2>
              </div>
              <p className="max-w-xl text-sm text-slate-300">
                Purpose-built modules for lenders, borrowers, and protocol operators with transparent mechanics and premium execution UX.
              </p>
            </div>
            <div className="grid gap-5 md:grid-cols-3">
              {lendingTracks.map((track) => (
                <article key={track.title} className="group rounded-2xl border border-white/10 bg-black/30 p-6 transition hover:-translate-y-1 hover:border-amber-300/45">
                  <h3 className="text-xl font-black text-amber-200">{track.title}</h3>
                  <ul className="mt-4 space-y-2 text-sm text-slate-300">
                    {track.points.map((point) => (
                      <li key={point} className="flex items-center gap-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-amber-300" />
                        {point}
                      </li>
                    ))}
                  </ul>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="px-6 pb-24 md:px-8">
          <div className="mx-auto max-w-7xl rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.08] via-white/[0.03] to-transparent p-7 backdrop-blur-xl md:p-9">
            <div className="mb-8 text-center">
              <p className="text-xs uppercase tracking-[0.3em] text-cyan-300">How To Buy</p>
              <h2 className="mt-3 text-3xl font-black md:text-4xl">Animated Presale Purchase Journey</h2>
              <p className="mx-auto mt-3 max-w-2xl text-sm text-slate-300">
                Built for a simple investor flow with multi-coin support, wallet-based permissions, and transparent on-chain settlement.
              </p>
            </div>

            <div className="grid gap-5 md:grid-cols-3">
              {buyJourney.map((item) => (
                <article
                  key={item.step}
                  className="group relative overflow-hidden rounded-2xl border border-white/10 bg-black/30 p-6 transition duration-300 hover:-translate-y-1 hover:border-cyan-300/45"
                >
                  <div
                    className={`pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full bg-gradient-to-br ${item.accent} opacity-20 blur-2xl transition duration-500 group-hover:scale-125`}
                  />
                  <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-400">Step {item.step}</p>
                  <h3 className="mt-3 text-xl font-black text-white">{item.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-slate-300">{item.description}</p>
                </article>
              ))}
            </div>

            <div className="mt-6 grid gap-4 md:grid-cols-2">
              <div className="rounded-2xl border border-emerald-300/20 bg-emerald-400/10 p-5">
                <p className="text-xs uppercase tracking-[0.2em] text-emerald-200">Supported Payments</p>
                <p className="mt-3 text-sm text-slate-200">
                  Native coin payments (BNB) plus enabled ERC20 payment tokens configured by admin (for example USDT, BUSD, ETH-style test tokens).
                </p>
              </div>
              <div className="rounded-2xl border border-amber-300/20 bg-amber-300/10 p-5">
                <p className="text-xs uppercase tracking-[0.2em] text-amber-200">Control & Safety</p>
                <p className="mt-3 text-sm text-slate-200">
                  Owner wallet controls payment token activation, whitelist, vesting, and limits from dashboard; investor wallets only see/execute participant actions.
                </p>
              </div>
            </div>

            <div className="mt-7 text-center">
              <Link
                href="/sale"
                className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-amber-300 to-yellow-500 px-6 py-3 text-sm font-black text-slate-950 shadow-[0_0_26px_rgba(251,191,36,0.35)] transition hover:-translate-y-0.5"
              >
                Open Presale Dashboard
                <span>→</span>
              </Link>
            </div>
          </div>
        </section>

        <section id="tokenomics" className="border-y border-white/10 px-6 py-24 md:px-8">
          <div className="mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-amber-300">Tokenomics</p>
              <h2 className="mt-3 text-4xl font-black md:text-5xl">Capital-Aligned Distribution</h2>
              <p className="mt-5 max-w-2xl text-lg text-slate-300">
                RESVA token supply is allocated to liquidity depth, lender incentives, and governance durability to support a high-quality lending protocol lifecycle.
              </p>
              <div className="mt-9 space-y-5">
                {tokenFlow.map((item, idx) => (
                  <div key={item.label}>
                    <div className="mb-1 flex items-center justify-between">
                      <p className="font-semibold text-slate-200">{item.label}</p>
                      <p className="font-black text-white">{item.percent}</p>
                    </div>
                    <div className="h-2.5 w-full overflow-hidden rounded-full bg-white/10">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-amber-300 via-yellow-500 to-amber-600"
                        style={{ width: item.percent, animationDelay: `${idx * 140}ms` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative rounded-3xl border border-white/15 bg-black/35 p-8 backdrop-blur-xl">
              <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-amber-500/20 blur-2xl" />
              <div className="absolute -bottom-8 left-2 h-24 w-24 rounded-full bg-yellow-500/20 blur-2xl" />
              <div className="relative mx-auto h-72 w-72">
                <div className="absolute inset-0 rounded-full border border-amber-300/40 animate-spin-slow" />
                <div className="absolute inset-3 rounded-full border border-amber-400/35 animate-spin-medium-reverse" />
                <div className="absolute inset-7 rounded-full border border-yellow-400/45 animate-spin-fast" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative h-28 w-28 overflow-hidden rounded-full border border-amber-200/40 bg-[#1f1205] shadow-[0_0_45px_rgba(251,191,36,0.45)]">
                    <Image src="/brand/resva-logo-transparent.png" alt="Resva coin symbol" fill className="object-cover scale-110" />
                  </div>
                </div>
              </div>
              <p className="mt-3 text-center text-sm text-slate-400">Deflationary fee routing + lending revenue buyback architecture</p>
            </div>
          </div>
        </section>

        <section id="roadmap" className="px-6 py-24 md:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="mb-14 text-center">
              <p className="text-xs uppercase tracking-[0.3em] text-amber-300">Execution Timeline</p>
              <h2 className="mt-3 text-4xl font-black md:text-5xl">Live Product Roadmap</h2>
              <p className="mx-auto mt-4 max-w-2xl text-slate-400">A timeline-style rollout with clear phase signals, delivery focus, and visible momentum.</p>
            </div>

            <div className="relative hidden lg:block">
              <div className="absolute left-0 right-0 top-10 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
              <div className="roadmap-beam absolute left-[10%] top-[37px] h-1.5 w-24 rounded-full bg-gradient-to-r from-amber-300 via-yellow-500 to-amber-600 blur-[1px]" />
              <div className="grid grid-cols-4 gap-5">
                {roadmap.map((phase, index) => (
                  <article key={phase.phase} className="group relative pt-16">
                    <div className="absolute left-1/2 top-7 h-6 w-6 -translate-x-1/2 rounded-full border-2 border-amber-300/60 bg-[#0f0805] shadow-[0_0_18px_rgba(251,191,36,0.4)]" />
                    <div className="roadmap-pulse absolute left-1/2 top-7 h-6 w-6 -translate-x-1/2 rounded-full border border-amber-300/60" />
                    <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.08] to-transparent p-6 transition duration-300 hover:-translate-y-1 hover:border-cyan-300/45">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-200">{phase.phase}</p>
                        <p className="rounded-full border border-white/15 bg-white/5 px-2 py-1 text-[10px] uppercase tracking-[0.15em] text-slate-300">
                          {phase.status}
                        </p>
                      </div>
                      <h3 className="mt-4 text-2xl font-black">{phase.title}</h3>
                      <ul className="mt-5 space-y-3">
                        {phase.items.map((item) => (
                          <li key={item} className="flex items-center gap-2 text-sm text-slate-300">
                            <span className="h-1.5 w-1.5 rounded-full bg-amber-300" />
                            {item}
                          </li>
                        ))}
                      </ul>
                      <p className="mt-4 text-xs uppercase tracking-[0.25em] text-slate-500">Stage 0{index + 1}</p>
                    </div>
                  </article>
                ))}
              </div>
            </div>

            <div className="relative space-y-5 lg:hidden">
              <div className="absolute bottom-4 left-3 top-4 w-px bg-gradient-to-b from-cyan-300/60 to-transparent" />
              {roadmap.map((phase) => (
                <article key={phase.phase} className="relative pl-9">
                  <div className="absolute left-0 top-6 h-6 w-6 rounded-full border border-amber-300/60 bg-[#0f0805] shadow-[0_0_15px_rgba(251,191,36,0.4)]" />
                  <div className="rounded-2xl border border-white/10 bg-white/[0.05] p-5">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-200">{phase.phase}</p>
                      <p className="text-[10px] uppercase tracking-[0.15em] text-slate-400">{phase.status}</p>
                    </div>
                    <h3 className="mt-3 text-xl font-black">{phase.title}</h3>
                    <ul className="mt-3 space-y-2">
                      {phase.items.map((item) => (
                        <li key={item} className="text-sm text-slate-300">
                          • {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="governance" className="border-t border-white/10 px-6 pb-24 pt-20 md:px-8">
          <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[1.1fr_1fr]">
            <div className="rounded-3xl border border-white/10 bg-white/[0.05] p-8 backdrop-blur-xl">
              <p className="text-xs uppercase tracking-[0.3em] text-amber-300">Governance Utility</p>
              <h2 className="mt-3 text-4xl font-black">Value Beyond Speculation</h2>
              <p className="mt-4 text-slate-300">
                RESVA holders shape collateral parameters, new lending markets, and treasury strategy through on-chain proposals with transparent execution windows.
              </p>
              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                <div className="rounded-2xl border border-white/10 bg-black/35 p-5">
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-400">Vote Participation</p>
                  <p className="mt-2 text-3xl font-black text-amber-200">68%</p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-black/35 p-5">
                  <p className="text-xs uppercase tracking-[0.2em] text-slate-400">Proposal Pass Rate</p>
                  <p className="mt-2 text-3xl font-black text-amber-200">91%</p>
                </div>
              </div>
            </div>

            <div className="rounded-3xl border border-amber-300/20 bg-amber-300/5 p-8">
              <p className="text-xs uppercase tracking-[0.3em] text-amber-200">Investor Readiness</p>
              <h3 className="mt-3 text-2xl font-black">Presale Priorities</h3>
              <ul className="mt-4 space-y-3 text-sm text-slate-300">
                <li className="rounded-xl border border-white/10 bg-white/[0.02] p-4">Clear vesting timeline and transparent unlock reporting.</li>
                <li className="rounded-xl border border-white/10 bg-white/[0.02] p-4">Multi-sig treasury with publicly auditable fund movement.</li>
                <li className="rounded-xl border border-white/10 bg-white/[0.02] p-4">Weekly protocol health updates from launch to TGE + listing phases.</li>
              </ul>
              <Link
                href="/sale"
                className="mt-6 inline-flex rounded-full bg-gradient-to-r from-amber-300 to-yellow-500 px-6 py-3 text-sm font-black text-slate-950 transition hover:-translate-y-0.5"
              >
                Join Presale Dashboard
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="relative z-10 border-t border-white/10 bg-black/40 py-10 text-slate-400">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-6 text-center md:px-8">
          <p className="text-xl font-black tracking-[0.2em] text-white">RESVA</p>
          <p className="mx-auto max-w-xl text-sm">
            This interface is for informational and protocol access purposes only. Digital assets involve risk; always do your own research before participating.
          </p>
          <div className="flex justify-center gap-6 text-sm">
            <a href="#" className="transition hover:text-amber-300">Twitter</a>
            <a href="#" className="transition hover:text-amber-300">Telegram</a>
            <a href="#" className="transition hover:text-amber-300">Discord</a>
            <a href="#" className="transition hover:text-amber-300">Docs</a>
          </div>
          <p className="pt-2 text-xs text-slate-500">© {new Date().getFullYear()} RESVA Protocol. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
