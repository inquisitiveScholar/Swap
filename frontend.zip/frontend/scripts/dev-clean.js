/* eslint-disable @typescript-eslint/no-require-imports */
const { execSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");

function killWindowsPortListeners(ports) {
  try {
    const output = execSync("netstat -ano -p tcp", { encoding: "utf8" });
    const pids = new Set();
    const lines = output.split(/\r?\n/);

    lines.forEach((line) => {
      if (line.includes("LISTENING")) {
        const match = line.match(/:(\d+)\s+.*?\s+(\d+)\s*$/);
        if (match) {
          const port = parseInt(match[1], 10);
          const pid = match[2];
          if (ports.includes(port)) {
            pids.add(pid);
          }
        }
      }
    });

    for (const pid of pids) {
      console.log(`[CLEAN] Killing process ${pid} on target port...`);
      try {
        execSync(`taskkill /PID ${pid} /F`, { stdio: "ignore" });
      } catch { /* ignore */ }
    }
  } catch (err) {
    console.error("[CLEAN] Failed to list or kill processes:", err.message);
  }
}

function removeDevLock() {
  const lockPath = path.join(process.cwd(), ".next", "dev", "lock");
  if (fs.existsSync(lockPath)) {
    fs.rmSync(lockPath, { force: true });
  }
}

function wipeStaticCache() {
  const staticPath = path.join(process.cwd(), ".next", "static");
  if (fs.existsSync(staticPath)) {
    console.log("[CLEAN] Wiping stale static chunks...");
    fs.rmSync(staticPath, { recursive: true, force: true });
  }
}

function startDev() {
  const { spawn } = require("node:child_process");
  const child = spawn("npx", ["next", "dev"], {
    stdio: "inherit",
    shell: true,
    env: {
      ...process.env,
      NODE_OPTIONS: "--max-old-space-size=8192",
    },
  });

  child.on("exit", (code) => {
    if (code !== 0) {
      console.log(`\n⚠ Dev server exited with code ${code}. Restarting in 2s...`);
      setTimeout(startDev, 2000);
    }
  });
}

killWindowsPortListeners([3000, 3001]);
removeDevLock();
wipeStaticCache();
startDev();
