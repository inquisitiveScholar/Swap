import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Required for WalletConnect v2.23.x — the ethereum-provider internally does
  // `import("@reown/appkit/core")` at runtime.  Without transpilePackages,
  // Next.js / Turbopack cannot resolve that nested dynamic ESM import and the
  // QR modal silently fails to initialise.
  transpilePackages: [
    "@walletconnect/ethereum-provider",
    "@walletconnect/universal-provider",
    "@reown/appkit",
    "@reown/appkit-common",
    "@reown/appkit-controllers",
    "@reown/appkit-core",
    "@reown/appkit-polyfills",
    "@reown/appkit-scaffold-ui",
    "@reown/appkit-ui",
    "@reown/appkit-utils",
    "@reown/appkit-wallet",
    "@reown/appkit-pay",
  ],

  // Turbopack config (Next.js 16 default bundler).
  // WalletConnect / Reown packages reference Node.js builtins that don't exist
  // in the browser — alias them to an empty stub so the build succeeds.
  turbopack: {
    resolveAlias: {
      net: "./src/lib/empty.ts",
      tls: "./src/lib/empty.ts",
      fs: "./src/lib/empty.ts",
      encoding: "./src/lib/empty.ts",
      pino: "./src/lib/empty.ts",
      "pino-pretty": "./src/lib/empty.ts",
    },
  },
};

export default nextConfig;
